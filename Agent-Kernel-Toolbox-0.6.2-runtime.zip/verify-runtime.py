#!/usr/bin/env python3
"""Verify toolbox bytes without executing archive members.

Embedded hashes establish consistency. Pin an independently obtained ZIP digest
when publisher identity matters. Local configuration and installed dependencies
are outside the shipped file inventory.
"""
import argparse
import ast
from contextlib import ExitStack
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import zipfile
import zlib

MAX_ARCHIVE_BYTES = 1536 * 1024
MAX_EXPANDED_BYTES = 4 * 1024 * 1024
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_ENTRIES = 320

# A release has one explicit resource policy shared by the builder, extractor
# and verifier. Extra files in a developer checkout never enter the payload.
EXTERNAL_FILES = frozenset("""
    browser/cli.mjs
    browser/extension/background.mjs
    browser/extension/content.js
    browser/extension/control.css
    browser/extension/control.html
    browser/extension/control.mjs
    browser/extension/manifest.json
    browser/extension/rules.mjs
    browser/package-lock.json
    browser/package.json
    browser/portable-evidence.mjs
    browser/route-analysis.mjs
    browser/route-evidence.mjs
    browser/runtime.mjs
    browser/semantic-query.mjs
    browser/text-input.mjs
    browser/traffic-policy.mjs
    build-runtime.py
    native/build.py
    native/managed-jvm/RuntimeManagedAgent.java
    native/managed-jvm/build.py
    native/managed-probe/RuntimeProbe.java
    native/managed-probe/build.py
    native/managed-probe/managed_probe.c
    native/probe-sdk/probe.c
    native/probe-sdk/probe.h
    native/render_filter.cpp
    native/runtime-agent/Cargo.lock
    native/runtime-agent/Cargo.toml
    native/runtime-agent/agent.c
    native/runtime-agent/agent.h
    native/runtime-agent/build.py
    native/runtime-agent/src/main.rs
    native/runtime-extensions/CMakeLists.txt
    native/runtime-extensions/detours_agent.cpp
    native/runtime-extensions/detours_model.cpp
    native/runtime-extensions/detours_model.def
    native/runtime-extensions/hardening_runner.c
    native/runtime-extensions/hardening_sdk.c
    native/runtime-extensions/hardening_sdk.h
    native/runtime-extensions/monitor_native_helper.c
    native/runtime-extensions/monitor_preload.c
    native/worker/GO-LICENSE
    native/worker/GO-PATENTS
    native/worker/go.mod
    native/worker/main.go
    native/worker/platform_linux.go
    native/worker/platform_other.go
    requirements-optional.txt
    runtime-manifest.json
    skills/agent-kernel-toolbox/SKILL.md
    skills/agent-kernel-toolbox/agents/openai.yaml
    skills/agent-kernel-toolbox/scripts/inspect_mcp.py
    tools/CMakeLists.lab.txt
    tools/RuntimeAccessEmulate.java
    tools/RuntimeAccessEmulateMemory.java
    tools/RuntimeAccessExport.java
    tools/check_installation.py
    tools/configure_runtime.py
    tools/coordinated_watchdog.py
    tools/environment_probe_agent.py
    tools/execution_lab_dynamorio.c
    tools/execution_lab_native.h
    tools/execution_lab_runner.c
    tools/execution_lab_worker.py
    tools/extract_sources.py
    tools/file_activity_agent.py
    tools/lldb_agent.py
    tools/managed_jvm_guardian.py
    tools/native_probe.js
    tools/native_probe_agent.py
    tools/native_symbolic_agent.py
    tools/runtime-platform.py
    tools/tree_guardian.py
    verify-runtime.py
""".split())
PYTHON_FILES = frozenset("""
    __main__.py _s19_03_closure_common.py page_snapshot_recognizer.py
""".split()) | frozenset('observation_extension/' + name + '.py' for name in """
    __init__ abi advanced_catalog advanced_common advanced_tools analysis_tools app_routes
    appium_native bridge capture_budget compatibility compatibility_control compiler_metadata
    context_tools coordinated_state coordination debugger_bridge environment_probe
    file_activity hardening_tools ir_analysis javascript_static lab_tools linux_tracing
    lldb_native malware_triage managed_jvm managed_probe memory_tools monitor_tools
    native_accessibility native_control native_debug native_helper native_probe native_runtime
    native_symbolic native_translation network_policy object_runtime operation_brake
    owned_process_guardian platform_interfaces policy portable_build portable_emulation
    process_tree program_monitor record_projection record_reference record_tools record_vm
    register_control resource_tools reverse_mcp reverse_native
    runtime_catalog runtime_host runtime_mcp runtime_state semantic_agent semantic_tools snapshot_analysis
    snapshot_tools structured_recovery telemetry tool_arguments translation version whole_system
    windows_tools
""".split())
ARCHIVE_FILES = EXTERNAL_FILES | {'runtime-access.pyz'}
ENTRYPOINT = (b'from observation_extension.runtime_mcp import main\n'
              b'if __name__ == "__main__":\n    raise SystemExit(main())\n')


def valid_path(name):
    return (type(name) is str and re.fullmatch(r'[A-Za-z0-9_./-]{1,200}', name)
            and not name.startswith('/') and not any(part in ('', '.', '..') for part in name.split('/')))


def json_object(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError('duplicate_manifest_key')
            value[key] = item
        return value
    value = json.loads(raw, object_pairs_hook=pairs)
    if type(value) is not dict:
        raise ValueError('manifest_object_required')
    return value


def read_archive(raw):
    if type(raw) is not bytes or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('archive_budget')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        if not 1 <= len(entries) <= MAX_ENTRIES:
            raise ValueError('entry_limit')
        values, total = {}, 0
        for item in entries:
            if (not valid_path(item.filename) or item.orig_filename != item.filename or item.filename in values
                    or stat.S_IFMT(item.external_attr >> 16) != stat.S_IFREG
                    or item.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)
                    or item.flag_bits & 1 or item.file_size > MAX_FILE_BYTES):
                raise ValueError('invalid_archive_entry')
            total += item.file_size
            if total > MAX_EXPANDED_BYTES:
                raise ValueError('expanded_budget')
            with archive.open(item) as stream:
                data = stream.read(MAX_FILE_BYTES + 1)
                if len(data) != item.file_size or stream.read(1):
                    raise ValueError('archive_size_mismatch')
            values[item.filename] = data
        return values


def hash_inventory(values, hashes):
    if type(hashes) is not dict or set(hashes) != set(values):
        raise ValueError('member_inventory_mismatch')
    for name, digest in hashes.items():
        if (not valid_path(name) or type(digest) is not str
                or re.fullmatch(r'[0-9a-f]{64}', digest) is None
                or hashlib.sha256(values[name]).hexdigest() != digest):
            raise ValueError('member_digest_mismatch')


def validate_python_sources(values):
    if set(values) != PYTHON_FILES:
        raise ValueError('unexpected_runtime_members')
    if values['__main__.py'] != ENTRYPOINT:
        raise ValueError('unexpected_entrypoint')


def verified_sources(raw, hashes):
    sources = read_archive(raw)
    validate_python_sources(sources)
    hash_inventory(sources, hashes)
    return sources


def validate_inventory(inventory):
    if set(inventory) != {'schema_version', 'package_id', 'package_name', 'package_version', 'files', 'python_files'}:
        raise ValueError('invalid_inventory')
    if (type(inventory['schema_version']) is not int or inventory['schema_version'] != 1
            or inventory['package_id'] != 'agent-kernel.toolbox'
            or inventory['package_name'] != 'Agent-Kernel-Toolbox'
            or type(inventory['package_version']) is not str
            or re.fullmatch(r'[0-9]+(?:\.[0-9]+){2,3}', inventory['package_version']) is None):
        raise ValueError('invalid_inventory')
    if (type(inventory['files']) is not dict or set(inventory['files']) != ARCHIVE_FILES
            or type(inventory['python_files']) is not dict or set(inventory['python_files']) != PYTHON_FILES):
        raise ValueError('unexpected_release_members')


def python_identity(raw):
    """Read the three literal CLI/MCP constants without importing the zipapp."""
    if len(raw) > 8192:
        raise ValueError('python_identity_mismatch')
    try:
        body = ast.parse(raw.decode('utf-8')).body
    except (SyntaxError, UnicodeError, RecursionError) as error:
        raise ValueError('python_identity_mismatch') from error
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant):
        body = body[1:]
    fields = {}
    for node in body:
        if (not isinstance(node, ast.Assign) or len(node.targets) != 1
                or not isinstance(node.targets[0], ast.Name)
                or not isinstance(node.value, ast.Constant) or type(node.value.value) is not str
                or node.targets[0].id in fields):
            raise ValueError('python_identity_mismatch')
        fields[node.targets[0].id] = node.value.value
    return fields


def cargo_identity_tables(raw, header, fields):
    """Extract canonical single-line identity fields on all supported Python versions."""
    tables = []
    current = None
    for line in raw.decode('utf-8').splitlines():
        line = line.partition('#')[0].strip()
        if line.startswith('['):
            current = {} if line == header else None
            if current is not None:
                tables.append(current)
        elif current is not None:
            key, _, value = line.partition('=')
            key = key.strip()
            if key in fields:
                match = re.fullmatch(r'''(["'])([A-Za-z0-9_.+-]+)\1''', value.strip())
                if not match or key in current:
                    raise ValueError('native_manifest_mismatch')
                current[key] = match.group(2)
    return tables


def validate_release_identity(values, inner, runtime):
    release, name = runtime['version'], runtime['name']
    expected = {'PACKAGE_NAME': name, 'PACKAGE_ID': runtime['id'], 'VERSION': release}
    if python_identity(inner['observation_extension/version.py']) != expected:
        raise ValueError('python_identity_mismatch')
    parts = release.split('.')
    component = '.'.join(parts[:3]) + ('+toolbox.' + parts[3] if len(parts) == 4 else '')
    browser = json_object(values['browser/package.json'])
    lock = json_object(values['browser/package-lock.json'])
    extension = json_object(values['browser/extension/manifest.json'])
    packages = lock.get('packages')
    root = packages.get('') if type(packages) is dict else None
    if (type(root) is not dict or browser.get('name') != 'agent-kernel-toolbox-browser'
            or lock.get('name') != browser['name'] or root.get('name') != browser['name']
            or extension.get('name') != name or extension.get('version') != release
            or (browser.get('toolbox_release'), lock.get('toolbox_release')) != (release, release)
            or any(record.get('version') != component for record in (browser, lock, root))
            or any(type(browser.get(key)) is not dict or browser[key] != root.get(key)
                   for key in ('dependencies', 'engines'))):
        raise ValueError('browser_manifest_mismatch')
    manifest = values['native/runtime-agent/Cargo.toml']
    fields = ('name', 'version')
    crate = {'name': 'runtime-control', 'version': component}
    packages = cargo_identity_tables(values['native/runtime-agent/Cargo.lock'], '[[package]]', fields)
    if (cargo_identity_tables(manifest, '[package]', fields) != [crate]
            or [record for record in packages if record.get('name') == crate['name']] != [crate]
            or cargo_identity_tables(manifest, '[package.metadata.toolbox]', ('name', 'release'))
                != [{'name': name, 'release': release}]):
        raise ValueError('native_manifest_mismatch')


def verify_members(values):
    values = dict(values)
    inventory = json_object(values.pop('CONTENTS.json'))
    validate_inventory(inventory)
    hash_inventory(values, inventory['files'])
    inner = verified_sources(values['runtime-access.pyz'], inventory['python_files'])
    runtime = json_object(values['runtime-manifest.json'])
    if ((runtime.get('id'), runtime.get('name'), runtime.get('version')) !=
            (inventory['package_id'], inventory['package_name'], inventory['package_version'])
            or runtime.get('entrypoint') != 'runtime-access.pyz'
            or runtime.get('inventory') != 'CONTENTS.json'
            or type(runtime.get('python_members')) is not int or runtime['python_members'] != len(inner)):
        raise ValueError('runtime_manifest_mismatch')
    validate_release_identity(values, inner, runtime)
    return {'status': 'verified_toolbox_consistency', 'name': inventory['package_name'],
            'package_version': inventory['package_version'], 'members': len(values) + 1,
            'python_members': len(inner), 'runtime_sources_verified': True,
            'publisher_authenticated': False}


def verify(raw, expected_sha256=None):
    if type(raw) is not bytes or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('archive_budget')
    digest = hashlib.sha256(raw).hexdigest()
    if expected_sha256 is not None and (type(expected_sha256) is not str
            or re.fullmatch(r'[0-9a-f]{64}', expected_sha256) is None or expected_sha256 != digest):
        raise ValueError('archive_digest_mismatch')
    try:
        result = verify_members(read_archive(raw))
    except (KeyError, TypeError, UnicodeError, RecursionError, zipfile.BadZipFile,
            zlib.error, EOFError, RuntimeError) as error:
        raise ValueError('invalid_archive') from error
    return {**result, 'archive_sha256': digest,
            'expected_archive_digest_pinned': expected_sha256 is not None}


def read_regular(root, name):
    if not valid_path(name):
        raise ValueError('invalid_file_path')
    # Pin every ancestor as well as the leaf. Checking resolve() before open()
    # alone permits a concurrent directory replacement between the two calls.
    parts = name.split('/')
    dir_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | os.O_NOFOLLOW
    with ExitStack() as handles:
        directory = os.open(root, dir_flags)
        handles.callback(os.close, directory)
        for part in parts[:-1]:
            directory = os.open(part, dir_flags, dir_fd=directory)
            handles.callback(os.close, directory)
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                     dir_fd=directory)
        handles.callback(os.close, fd)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_FILE_BYTES:
            raise ValueError('invalid_file')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(fd)
        if len(raw) != before.st_size or any(getattr(before, k) != getattr(after, k)
                for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')):
            raise ValueError('file_changed')
        return raw


def installed_sources(root):
    try:
        inventory = json_object(read_regular(root, 'CONTENTS.json'))
        validate_inventory(inventory)
        name = 'runtime-access.pyz'
        raw = read_regular(root, name)
        hash_inventory({name: raw}, {name: inventory['files'][name]})
        return verified_sources(raw, inventory['python_files'])
    except (KeyError, TypeError, UnicodeError, RecursionError, zipfile.BadZipFile,
            zlib.error, EOFError, RuntimeError) as error:
        raise ValueError('invalid_installed_runtime_sources') from error


def verify_directory(directory):
    try:
        root = Path(directory).resolve()
        raw = read_regular(root, 'CONTENTS.json')
        inventory = json_object(raw)
        validate_inventory(inventory)
        values, total = {'CONTENTS.json': raw}, len(raw)
        for name in ARCHIVE_FILES:
            data = read_regular(root, name)
            total += len(data)
            if total > MAX_EXPANDED_BYTES:
                raise ValueError('expanded_budget')
            values[name] = data
        return verify_members(values)
    except (KeyError, TypeError, UnicodeError, RecursionError, zipfile.BadZipFile,
            zlib.error, EOFError, RuntimeError) as error:
        raise ValueError('invalid_installed_toolbox') from error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--expected-sha256')
    args = parser.parse_args()
    try:
        with args.archive.open('rb') as stream:
            raw = stream.read(MAX_ARCHIVE_BYTES + 1)
        print(json.dumps(verify(raw, args.expected_sha256), sort_keys=True))
        return 0
    except (OSError, ValueError):
        print('toolbox_verification_failed', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
