#!/usr/bin/env python3
"""Inspect a zipapp through stdio MCP and optionally test a generated local fixture."""
import argparse
import binascii
import hashlib
import json
import math
import os
from pathlib import Path
import re
import select
import subprocess
import sys
import tempfile
import time
import uuid

VERSIONS = ('2025-11-25', '2025-06-18')
MAX_REPLY = 2 * 1024 * 1024
DIAGNOSTICS = ('runtime.status', 'runtime.capabilities', 'build.inspect')
FIXTURE = bytes.fromhex('ff ff ff ff ff ff ff fe 01')
FIXTURE_CALLS = {
    'snapshot.summary': {'snapshot': 'fixture', 'tiles': 2, 'include_source': True},
    'snapshot.scalars': {'snapshot': 'fixture', 'width': 8, 'signed': False, 'byteorder': 'big', 'include_source': True},
}
RECORD = b'\x03\x00abc'
REPLAY_TOOLS = ('replay.open', 'replay.fork', 'replay.run', 'replay.compare',
                'replay.release', 'ir.evaluate_replay')
FIXTURE_IR = {'schema_version': 1, 'width': 32, 'inputs': ['payload_length', 'crc32'],
              'instructions': [{'id': 'mixed', 'op': 'xor', 'args': ['payload_length', 'crc32']}],
              'result': 'mixed'}


class ToolFailure(RuntimeError):
    """A valid MCP response reported a tool error or uncertain effect."""


def json_value(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError('duplicate reply key')
            value[key] = item
        return value
    def invalid(_value):
        raise ValueError('non-finite reply number')
    def finite(text):
        value = float(text)
        if not math.isfinite(value):
            raise ValueError('non-finite reply number')
        return value
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid, parse_float=finite)


def canonical(value):
    return json.dumps(value, ensure_ascii=True, allow_nan=False, sort_keys=True,
                      separators=(',', ':')).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def tool_value(result, name, arguments):
    value, content = result.get('structuredContent'), result.get('content')
    if (type(result.get('isError')) is not bool or type(value) is not dict
            or type(value.get('ok')) is not bool or result['isError'] is value['ok']
            or type(content) is not list or len(content) != 1
            or type(content[0]) is not dict or content[0].get('type') != 'text'
            or type(content[0].get('text')) is not str
            or canonical(json_value(content[0]['text'])) != canonical(value)):
        raise RuntimeError('MCP tool text/structured result or error flag is inconsistent')
    if value['ok']:
        receipt = value.get('evidence')
        if (type(receipt) is not dict or receipt.get('tool') != name
                or receipt.get('arguments_sha256') != digest(canonical(arguments))
                or 'data' not in value or receipt.get('data_sha256') != digest(canonical(value['data']))
                or receipt.get('receipt_sha256') != digest(canonical(
                    {k: v for k, v in receipt.items() if k != 'receipt_sha256'}))):
            raise RuntimeError('MCP observation receipt does not match the call and data')
    return value


def check_chain(receipt, previous):
    # One serial inspector owns the entire connection and sees every success.
    expected_sequence = previous['sequence'] + 1 if previous else 1
    expected_parent = previous['receipt_sha256'] if previous else None
    if (type(receipt.get('sequence')) is not int or receipt['sequence'] != expected_sequence
            or 'previous_receipt_sha256' not in receipt or receipt['previous_receipt_sha256'] != expected_parent
            or type(receipt.get('runtime_id')) is not str or not receipt['runtime_id']
            or type(receipt.get('config_sha256')) is not str or len(receipt['config_sha256']) != 64
            or previous and (receipt['runtime_id'] != previous['runtime_id']
                             or receipt['config_sha256'] != previous['config_sha256'])):
        raise RuntimeError('MCP observation receipts do not form a continuous chain for this host')


def fixture_source(alias, data, offset, length):
    return {'snapshot': alias, 'snapshot_sha256': digest(data), 'offset': offset, 'length': length,
            'sha256': digest(data[offset:offset + length])}


def check_fixture(name, data, typed_source):
    if (type(data) is not dict or data.get('schema_version') != 1 or data.get('snapshot') != 'fixture'
            or data.get('offset') != 0 or data.get('file_size') != len(FIXTURE)
            or data.get('snapshot_sha256') != digest(FIXTURE)
            or typed_source and data.get('source') != fixture_source(
                'fixture', FIXTURE, 0, 8 if name == 'snapshot.scalars' else len(FIXTURE))):
        raise RuntimeError('fixture snapshot identity or file coordinates differ')
    if name == 'snapshot.scalars':
        if (data.get('mode') != 'scalars' or data.get('length') != 8 or data.get('width') != 8
                or data.get('count') != 1 or data.get('signed') is not False
                or data.get('byteorder') != 'big' or data.get('sha256') != digest(FIXTURE[:8])
                or data.get('values') != ['18446744073709551614']):
            raise RuntimeError('fixture uint64 or selected range differs')
    else:
        if (data.get('mode') != 'summary' or data.get('length') != len(FIXTURE)
                or data.get('sha256') != digest(FIXTURE)
                or data.get('histogram') != [FIXTURE.count(b) for b in range(256)]):
            raise RuntimeError('fixture summary or byte counts differ')
        expected = [(0, 4, digest(FIXTURE[:4])), (4, 5, digest(FIXTURE[4:]))]
        actual = [(t['offset'], t['length'], t['sha256']) for t in data['tiles']]
        if actual != expected or typed_source and any(tile.get('source') != fixture_source('fixture', FIXTURE, offset, length)
                                     for tile, (offset, length, _) in zip(data['tiles'], expected)):
            raise RuntimeError('fixture tile coverage, digests or reusable references differ')


def check_short_summary(call):
    for length in (1, 0):
        offset = len(FIXTURE) - length
        data = call('snapshot.summary', {'snapshot': 'fixture', 'offset': offset,
                    'length': length, 'tiles': 64, 'include_source': True})
        expected = fixture_source('fixture', FIXTURE, offset, length)
        if data['source'] != expected or [tile['source'] for tile in data['tiles']] != [expected] * length:
            raise RuntimeError('short or empty summary did not use the available nonempty tiles')


def check_replay(call, expect_mixed_denial, typed_source, *, check_terminal_reuse=False):
    """Pass a summary tile directly to replay and compare it with the legacy handoff."""
    raw = RECORD + RECORD
    if typed_source:
        window = call('snapshot.summary', {'snapshot': 'record', 'tiles': 2, 'include_source': True})
        source = window['tiles'][1]['source']
        if window.get('source') != fixture_source('record', raw, 0, len(raw)):
            raise RuntimeError('record fixture full-window reference differs')
        expect_mixed_denial(source)
        open_arguments = {'source': source}
    else:
        window = call('snapshot.summary', {'snapshot': 'record', 'offset': len(RECORD), 'length': len(RECORD)})
        source = {key: window[key] for key in ('snapshot', 'snapshot_sha256', 'offset', 'length', 'sha256')}
        open_arguments = source
    if source != fixture_source('record', raw, len(RECORD), len(RECORD)):
        raise RuntimeError('record fixture selected range differs')
    handles = []

    def change(name, **arguments):
        data = call(name, {**arguments, 'request_id': uuid.uuid4().hex})
        handle = data.get('checkpoint')
        if (type(handle) is not str or not handle or handle in handles or data.get('source') != source):
            raise RuntimeError('replay checkpoint identity or source differs')
        handles.append(handle)
        return handle, data

    initial, _ = change('replay.open', **open_arguments, prefix_width=2, byteorder='little', checksum='unavailable')
    after_header, paused = change('replay.run', checkpoint=initial, step_budget=1)
    if paused['state']['status'] != 'paused' or paused['state']['phase'] != 'bounds':
        raise RuntimeError('record fixture did not pause after the header')
    incomplete = call('replay.compare', {'checkpoint': after_header})['comparison']
    if incomplete['status'] != 'incomplete' or incomplete['equal'] is not None:
        raise RuntimeError('an unfinished checkpoint has a final comparison')
    blocked, dependency = change('replay.run', checkpoint=after_header, step_budget=2)
    if dependency['state']['missing'] != {'kind': 'model', 'name': 'crc32'}:
        raise RuntimeError('record did not identify its unavailable checksum model')
    resumed, bound = change('replay.fork', checkpoint=blocked, checksum='crc32')
    if bound['state']['phase'] != 'payload' or bound['state']['steps_completed'] != 2:
        raise RuntimeError('binding CRC32 discarded the completed header and bounds checks')
    forked, _ = change('replay.fork', checkpoint=resumed, edits=[{'offset': 2, 'hex': '78'}])
    for checkpoint, payload in ((forked, b'xbc'), (resumed, b'abc')):
        finished, result = change('replay.run', checkpoint=checkpoint, step_budget=3, trace_limit=0)
        state = result['state']
        expected_output = binascii.crc32(payload).to_bytes(4, 'little') + bytes(4)
        if (state['status'] != 'completed' or state['return_value'] != len(payload)
                or state['output_hex'] != expected_output.hex()
                or state['write']['committed_bytes'] != 4 or result['execution']['trace']
                or result['execution']['trace_omitted'] < 1):
            raise RuntimeError('record result, checksum, private guard bytes or trace accounting differs')
        comparison = call('replay.compare', {'checkpoint': finished})['comparison']
        if comparison['status'] != 'match' or comparison['equal'] is not True:
            raise RuntimeError('record execution disagrees with its independent reference')
        evaluated = call('ir.evaluate_replay', {'module': 'fixture_mix', 'checkpoint': finished})
        checksum = binascii.crc32(payload)
        if (evaluated.get('value') != str(checksum ^ len(payload)) or evaluated.get('source') != source
                or evaluated.get('inputs') != {'payload_length': len(payload), 'crc32': checksum}
                or evaluated.get('reference_checked') is not True or evaluated.get('checkpoint') != finished
                or evaluated.get('module_sha256') != digest(canonical(FIXTURE_IR))):
            raise RuntimeError('registered IR result or checkpoint provenance differs')
    if check_terminal_reuse:
        repeated = call('replay.run', {'checkpoint': finished, 'request_id': uuid.uuid4().hex})
        if (repeated['checkpoint'] != finished or repeated['parent_checkpoint'] != resumed
                or repeated['state'] != result['state'] or repeated['execution']['steps_attempted'] != 0):
            raise RuntimeError('terminal replay allocated a checkpoint or executed more steps')
    unknown, _ = change('replay.open', **source, unknown_ranges=[{'offset': 4, 'length': 1}])
    stopped, strict = change('replay.run', checkpoint=unknown)
    if strict['state']['missing'] != {'kind': 'input', 'offset': 4, 'length': 1}:
        raise RuntimeError('strict record run did not identify the missing payload byte')
    modeled, _ = change('replay.fork', checkpoint=stopped, mode='assume_zero')
    finished, assumed = change('replay.run', checkpoint=modeled)
    evaluated = call('ir.evaluate_replay', {'module': 'fixture_mix', 'checkpoint': finished})
    if (assumed['state']['reads']['assumed_zero_bytes'] != 1 or evaluated.get('assumed_zero_bytes') != 1
            or evaluated.get('value') != str(binascii.crc32(b'ab\x00') ^ 3)):
        raise RuntimeError('the modeled zero byte or its downstream provenance differs')
    for handle in handles:
        released = call('replay.release', {'checkpoint': handle, 'request_id': uuid.uuid4().hex})
        if released.get('checkpoint') != handle or released.get('released') is not True:
            raise RuntimeError('checkpoint release receipt differs')


def inspect(args):
    records = []
    sequence = 0
    buffered = bytearray()
    child = None
    failed = False
    negotiated = None
    catalog_count = None
    catalog_sha256 = None
    shutdown_forced = False
    full_records = getattr(args, 'full_records', False)
    outcomes = {}
    replay_check = getattr(args, 'replay_self_test', False)
    fixture_check = getattr(args, 'snapshot_self_test', False) or replay_check
    replay_outcome = 'not_run'
    server_info = None
    previous_receipt = None
    typed_source = False
    with tempfile.TemporaryFile() as diagnostics:
        try:
            child = subprocess.Popen([args.python, '-IB', str(args.entry), 'serve', '--config', str(args.config)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=diagnostics)

            def send(method, params=None, notify=False, expected_invalid=None):
                nonlocal sequence
                message = {'jsonrpc': '2.0', 'method': method}
                if params is not None:
                    message['params'] = params
                if not notify:
                    sequence += 1
                    message['id'] = sequence
                child.stdin.write(json.dumps(message, separators=(',', ':')).encode() + b'\n')
                child.stdin.flush()
                if notify:
                    return None
                deadline = time.monotonic() + args.timeout
                while b'\n' not in buffered:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0 or not select.select([child.stdout], [], [], remaining)[0]:
                        raise RuntimeError('MCP reply timed out')
                    data = os.read(child.stdout.fileno(), 65536)
                    if not data:
                        raise RuntimeError('MCP closed before reply')
                    buffered.extend(data)
                    if len(buffered) > MAX_REPLY:
                        raise RuntimeError('MCP reply exceeded budget')
                raw, _, tail = buffered.partition(b'\n')
                buffered[:] = tail
                reply = json_value(raw)
                if (type(reply) is not dict or reply.get('jsonrpc') != '2.0'
                        or type(reply.get('id')) is not int or reply['id'] != sequence):
                    raise RuntimeError('MCP reply identity mismatch')
                if ('result' in reply) == ('error' in reply):
                    raise RuntimeError('MCP reply must contain exactly one result or error')
                if 'result' in reply and type(reply['result']) is not dict:
                    raise RuntimeError('MCP method result must be an object')
                if 'error' in reply and (type(reply['error']) is not dict
                        or type(reply['error'].get('code')) is not int
                        or type(reply['error'].get('message')) is not str):
                    raise RuntimeError('MCP error response is malformed')
                records.append({'method': method, 'response': reply})
                if expected_invalid is not None:
                    error = reply.get('error', {})
                    data = error.get('data', {})
                    details = data.get('error_details') if type(data) is dict else None
                    if (error.get('code') != -32602 or type(details) is not dict
                            or data.get('error') != expected_invalid or data.get('effect_dispatched') is not False
                            or details.get('kind') != 'arguments' or details.get('path') != '/source'
                            or details.get('rule') != 'oneOf'
                            or data.get('effect_unknown') is True or data.get('unknown_effect') is True):
                        raise RuntimeError('fixture expected a pre-dispatch invalid-arguments response')
                    return None
                if 'error' in reply:
                    raise RuntimeError('MCP protocol error: ' + str(reply['error']['code']) + ': '
                                       + reply['error']['message'][:160])
                return reply['result']

            initialized = send('initialize', {'protocolVersion': args.protocol, 'capabilities': {},
                'clientInfo': {'name': 'agent-kernel-toolbox-skill', 'version': '1'}})
            negotiated = initialized.get('protocolVersion')
            if type(negotiated) is not str or negotiated != args.protocol or negotiated not in VERSIONS:
                raise RuntimeError('MCP negotiated protocol differs from requested supported version')
            capabilities = initialized.get('capabilities')
            info = initialized.get('serverInfo')
            if (type(capabilities) is not dict or type(capabilities.get('tools')) is not dict
                    or 'listChanged' in capabilities['tools'] and type(capabilities['tools']['listChanged']) is not bool
                    or type(info) is not dict or type(info.get('name')) is not str
                    or type(info.get('version')) is not str):
                raise RuntimeError('MCP initialization capabilities or server identity are malformed')
            server_info = {'name': info['name'], 'version': info['version']}
            release = re.fullmatch(r'([0-9]{1,9})\.([0-9]{1,9})\.([0-9]{1,9})', info['version'])
            edge_fixtures = (info['name'] == 'Agent-Kernel-Toolbox' and release is not None
                             and tuple(map(int, release.groups())) >= (0, 6, 2))
            send('notifications/initialized', notify=True)
            catalog = send('tools/list', {})
            tools = catalog.get('tools')
            if type(tools) is not list or any(type(row) is not dict or type(row.get('name')) is not str
                    or type(row.get('inputSchema')) is not dict for row in tools):
                raise RuntimeError('MCP tool catalog is malformed')
            names = {row['name'] for row in tools}
            if len(names) != len(tools):
                raise RuntimeError('MCP tool catalog contains duplicate names')
            if fixture_check:
                expected_schemas = set(FIXTURE_CALLS)
                if replay_check:
                    expected_schemas.update(REPLAY_TOOLS)
                for row in tools:
                    if row['name'] in expected_schemas:
                        schema = row.get('outputSchema')
                        if type(schema) is not dict or schema.get('type') != 'object':
                            raise RuntimeError(row['name'] + ' output schema is missing or malformed')
            catalog_count, catalog_sha256 = len(tools), hashlib.sha256(canonical(catalog)).hexdigest()
            if not full_records:
                records[-1]['response']['result'] = {'tool_count': catalog_count,
                    'tool_names': sorted(names), 'catalog_sha256': catalog_sha256,
                    'schemas_omitted_from_report': True}
            calls = {name: {} for name in DIAGNOSTICS}
            if fixture_check:
                descriptors = {tool['name']: tool['inputSchema'].get('properties', {}) for tool in tools}
                sources = ['include_source' in descriptors.get(name, {}) for name in FIXTURE_CALLS]
                if replay_check:
                    sources.append('source' in descriptors.get('replay.open', {}))
                if any(sources) and not all(sources):
                    raise RuntimeError('snapshot and replay reference schemas disagree')
                typed_source = all(sources)
                for name, arguments in FIXTURE_CALLS.items():
                    calls[name] = dict(arguments)
                    if not typed_source:
                        calls[name].pop('include_source')
            outcomes = dict.fromkeys([*calls, *(REPLAY_TOOLS if replay_check else ())], 'not_run')

            def call(name, arguments):
                nonlocal previous_receipt
                outcomes[name] = 'failed'
                result = send('tools/call', {'name': name, 'arguments': arguments})
                records[-1]['tool'] = name
                value = tool_value(result, name, arguments)
                if not full_records:
                    records[-1]['response']['result'] = {'structuredContent': value,
                        'isError': result['isError'], 'text_matches_structured': True,
                        'duplicate_text_omitted_from_report': True}
                if not value['ok'] or value.get('effect_unknown') or value.get('unknown_effect'):
                    raise ToolFailure(name + ' returned ' + str(value.get('error', 'an uncertain outcome')))
                check_chain(value['evidence'], previous_receipt)
                previous_receipt = value['evidence']
                outcomes[name] = 'passed'
                return value['data']

            for name, arguments in calls.items():
                if name not in names:
                    outcomes[name] = 'not_advertised'
                    failed |= getattr(args, 'temporary_config', False)
                    continue
                try:
                    data = call(name, arguments)
                    if name in FIXTURE_CALLS:
                        outcomes[name] = 'failed'
                        check_fixture(name, data, typed_source)
                        outcomes[name] = 'passed'
                except ToolFailure as error:
                    failed = True
                    outcomes[name] = 'failed'
                    records.append({'inspection_error': str(error)})
            if fixture_check and edge_fixtures and outcomes['snapshot.summary'] == 'passed':
                try:
                    check_short_summary(call)
                except (KeyError, TypeError, RuntimeError):
                    outcomes['snapshot.summary'] = 'failed'
                    raise
            if replay_check:
                replay_outcome = 'failed'
                if not set(REPLAY_TOOLS).issubset(names):
                    raise RuntimeError('replay tool missing from fixture catalog')
                def expect_mixed_denial(source):
                    arguments = {'source': source, **source, 'request_id': uuid.uuid4().hex}
                    send('tools/call', {'name': 'replay.open', 'arguments': arguments},
                         expected_invalid='replay_source_forms_mixed')
                    records[-1].update(tool='replay.open', outcome='expected_invalid_arguments')
                check_replay(call, expect_mixed_denial, typed_source, check_terminal_reuse=edge_fixtures)
                replay_outcome = 'passed'
        except (OSError, ValueError, RuntimeError, KeyError, TypeError, RecursionError) as error:
            failed = True
            records.append({'inspection_error': str(error)})
        finally:
            if child is not None:
                if child.stdin and not child.stdin.closed:
                    try:
                        child.stdin.close()
                    except OSError:
                        failed = True
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    failed = True
                    shutdown_forced = True
                    child.terminate()
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=3)
                if child.stdout:
                    child.stdout.close()
                failed |= child.returncode != 0
            diagnostics.seek(0)
            stderr = diagnostics.read(16385)
    report = {'passed': not failed, 'scope': 'stdio_handshake_catalog_and_advertised_inspection_tools_only',
        'all_backends_verified': False, 'exit_code': child.returncode if child else None,
        'protocol_requested': args.protocol, 'protocol_negotiated': negotiated,
        'server_info': server_info, 'catalog_tools': catalog_count, 'catalog_sha256': catalog_sha256,
        'catalog_checked': catalog_count is not None, 'successful_receipts_verified': previous_receipt['sequence'] if previous_receipt else 0,
        'records_compact': not full_records, 'shutdown_forced': shutdown_forced,
        'tools_checked': outcomes, 'records': records, 'stderr': stderr[:16384].decode('utf-8', 'replace'),
        'stderr_truncated': len(stderr) > 16384}
    advertised = [name for name in DIAGNOSTICS if outcomes.get(name) in ('passed', 'failed')]
    report['diagnostics_checked'] = len(advertised)
    if not advertised and catalog_count is not None and not fixture_check:
        report['scope'] = 'stdio_handshake_and_catalog_only'
    if replay_check:
        report['scope'] = 'stdio_diagnostics_snapshot_and_private_record_replay'
        report['replay_fixture'] = replay_outcome
    elif fixture_check:
        report['scope'] = 'stdio_diagnostics_and_generated_offline_snapshot'
    if fixture_check and catalog_count is not None:
        report['snapshot_handoff'] = 'typed_reference' if typed_source else 'legacy_flat'
    encoded = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    if args.report:
        args.report.write_text(encoded)
    print(encoded, end='')
    return int(failed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry', required=True, type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--config', type=Path)
    mode.add_argument('--snapshot-self-test', action='store_true',
                      help='Also verify summary, tile digests and exact uint64 on a temporary fixture')
    mode.add_argument('--replay-self-test', action='store_true',
                      help='Also exercise snapshot evidence, private checkpoints and reference comparisons on temporary fixtures')
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--protocol', choices=VERSIONS, default=VERSIONS[0])
    parser.add_argument('--timeout', type=float, default=15)
    parser.add_argument('--report', type=Path)
    parser.add_argument('--full-records', action='store_true',
                        help='Retain full catalog schemas and duplicate tool text for protocol diagnosis')
    args = parser.parse_args()
    if not args.entry.is_absolute() or not args.entry.is_file() or args.entry.suffix != '.pyz':
        parser.error('--entry must name the selected absolute runtime-access.pyz file')
    if not .1 <= args.timeout <= 60:
        parser.error('--timeout must be in [0.1, 60] seconds')
    if args.config is not None and (not args.config.is_absolute() or not args.config.is_file()):
        parser.error('--config must name an existing absolute configuration file')
    if args.report is not None and args.report.exists():
        inputs = (args.entry, args.config, Path(__file__))
        if any(path is not None and args.report.samefile(path) for path in inputs):
            parser.error('--report must be separate from the runtime, configuration and inspector')
    with tempfile.TemporaryDirectory(prefix='toolbox-inspect-') as temporary:
        args.temporary_config = args.config is None
        if args.temporary_config:
            directory = Path(temporary).resolve()
            args.config = directory / 'config.json'
            config = {'schema_version': 1, 'state_directory': str(directory / 'state'),
                      'allowed_tools': list(DIAGNOSTICS), 'portable_build': {'profiles': {}}}
            if args.snapshot_self_test or args.replay_self_test:
                path = directory / 'fixture.bin'
                path.write_bytes(FIXTURE)
                path.chmod(0o400)
                config['snapshots'] = {'fixture': {'path': str(path), 'sha256': digest(FIXTURE),
                                                   'max_bytes': len(FIXTURE)}}
                config['allowed_tools'].extend(FIXTURE_CALLS)
            if args.replay_self_test:
                path = directory / 'record.bin'
                raw = RECORD + RECORD
                path.write_bytes(raw)
                path.chmod(0o400)
                config['snapshots']['record'] = {'path': str(path), 'sha256': digest(raw),
                                                 'max_bytes': len(raw)}
                config['allowed_tools'].extend(REPLAY_TOOLS)
                config['ir_modules'] = {'fixture_mix': FIXTURE_IR}
            args.config.write_text(json.dumps(config))
            args.config.chmod(0o600)
        return inspect(args)


if __name__ == '__main__':
    raise SystemExit(main())
