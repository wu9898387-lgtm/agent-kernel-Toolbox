#!/usr/bin/env python3
"""Local subreaper for one fixed, owned process tree; no global signalling.

CPU samples briefly quiesce the proved-owned tree. At a closed sample, live
own+waited-child CPU and this guardian's wait4 totals form disjoint partitions.
Final CPU is the sum of actual wait4 receipts, including waited descendants.
RSS is summed per process and can double-count shared pages. These are sampled
budgets, not cgroup hard quotas or hard real-time limits.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import select
import selectors
import signal
import stat
import subprocess
import sys
import time

MAX_SCAN=16384
MAX_TRACKED=512
MAX_ROWS=64
EXECUTE=r'''
import ctypes,json,os,resource,signal,sys
fd,gate,parent=map(int,sys.argv[1:4])
profile=json.loads(open(sys.argv[4],encoding='utf-8').read())
if os.getppid()!=parent:sys.exit(71)
libc=ctypes.CDLL(None,use_errno=True)
libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
if libc.prctl(1,signal.SIGKILL,0,0,0) or libc.prctl(38,1,0,0,0):sys.exit(72)
if os.getppid()!=parent:sys.exit(73)
for key,wanted in ((resource.RLIMIT_CORE,0),(resource.RLIMIT_AS,profile['address_space_bytes']),
                   (resource.RLIMIT_NOFILE,profile['open_files']),
                   (resource.RLIMIT_CPU,(profile['cpu_milliseconds']+999)//1000+1)):
 soft,hard=resource.getrlimit(key)
 limit=min([wanted]+[x for x in (soft,hard) if x!=resource.RLIM_INFINITY])
 resource.setrlimit(key,(limit,limit))
if os.read(gate,1)!=b'G':sys.exit(74)
os.close(gate)
os.set_inheritable(fd,False)
environment={'PATH':'/usr/bin:/bin','LC_ALL':'C',**profile.get('environment',{})}
os.execve(fd,profile['argv'],environment)
'''


class TreeFailure(RuntimeError):
    pass


def read_stat(pid,path=None):
    raw=Path(path if path is not None else f'/proc/{pid}/stat').read_bytes()
    if len(raw)>16384 or b') ' not in raw:
        raise TreeFailure('tree_invalid_proc_stat')
    fields=raw[raw.rfind(b') ')+2:].split()
    if len(fields)<22:
        raise TreeFailure('tree_invalid_proc_stat')
    return {'pid':pid,'state':fields[0].decode('ascii'),'ppid':int(fields[1]),
            'ticks':sum(int(fields[i]) for i in (11,12)),
            'waited_ticks':sum(int(fields[i]) for i in (13,14)),
            'start_ticks':int(fields[19]),'rss_pages':max(0,int(fields[21]))}


def all_rows():
    rows={}
    with os.scandir('/proc') as entries:
        for entry in entries:
            if not entry.name.isdecimal():
                continue
            if len(rows)>=MAX_SCAN:
                raise TreeFailure('tree_process_scan_capacity')
            try:
                row=read_stat(int(entry.name));rows[row['pid']]=row
            except (FileNotFoundError,ProcessLookupError,PermissionError):
                continue
    return rows


def subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
    if libc.prctl(36,1,0,0,0):
        raise TreeFailure('tree_subreaper_unavailable')


def emit(value):
    raw=json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':')).encode()
    if len(raw)>49152:
        raise TreeFailure('tree_result_budget')
    os.write(1,raw+b'\n')


class Supervisor:
    def __init__(self,profile,host_fd,exe_fd,profile_path):
        self.p=profile;self.host_fd=host_fd;self.exe_fd=exe_fd;self.profile_path=profile_path
        self.pid=os.getpid();self.tracked={};self.identities=[];self.seen=set()
        self.reaped_user=0.0;self.reaped_system=0.0;self.reaped_count=0
        self.root=None;self.root_status=None;self.root_identity=None
        self.pause_ns=0;self.pause_count=0;self.samples=[];self.max_gap_ns=0
        self.last_sample_ns=None;self.peak_rss=0;self.peak_count=0
        self.max_cpu_ms=0;self.stopping=False;self.failure=None;self.ready=False
        self.max_threads=0
        self.output={'stdout':{'bytes':0,'prefix':bytearray(),'sha':hashlib.sha256()},
                     'stderr':{'bytes':0,'prefix':bytearray(),'sha':hashlib.sha256()}}
        self.selector=selectors.DefaultSelector()

    def stopped(self,_signal,_frame):
        self.stopping=True

    def pin(self,row,owned):
        old=self.tracked.get(row['pid'])
        if old is not None and old['start_ticks']==row['start_ticks']:
            return False
        if old is not None:
            os.close(old['fd']);del self.tracked[row['pid']]
        if len(self.tracked)>=MAX_TRACKED:
            raise TreeFailure('tree_tracking_capacity')
        parent=row['ppid']
        if parent!=self.pid:
            ancestor=owned.get(parent)
            if ancestor is None or select.select([ancestor['fd']],[],[],0)[0]:
                return False
        fd=None
        try:
            fd=os.pidfd_open(row['pid'])
            after=read_stat(row['pid'])
            if after['start_ticks']!=row['start_ticks'] or after['ppid']!=parent:
                return False
            if parent!=self.pid and select.select([owned[parent]['fd']],[],[],0)[0]:
                return False
            self.tracked[row['pid']]={**after,'fd':fd};fd=None
            identity=(row['pid'],row['start_ticks'])
            if identity not in self.seen:
                self.seen.add(identity)
                if len(self.identities)<MAX_ROWS:
                    self.identities.append({'pid':row['pid'],'start_ticks':row['start_ticks']})
            return True
        except (FileNotFoundError,ProcessLookupError):
            return False
        finally:
            if fd is not None:os.close(fd)

    def discover(self):
        rows=all_rows();owned={}
        for pid,entry in list(self.tracked.items()):
            row=rows.get(pid)
            if row is None or row['start_ticks']!=entry['start_ticks']:
                os.close(entry['fd']);del self.tracked[pid]
            elif not select.select([entry['fd']],[],[],0)[0]:
                owned[pid]=entry
        changed=True
        while changed:
            changed=False
            for row in rows.values():
                if row['pid']==self.pid or row['pid'] in self.tracked:
                    continue
                if row['ppid']==self.pid or row['ppid'] in owned:
                    if self.pin(row,owned):
                        owned[row['pid']]=self.tracked[row['pid']];changed=True
        self.peak_count=max(self.peak_count,len(self.tracked))
        return rows

    def reap(self):
        no_children=False
        while True:
            try:
                pid,status,usage=os.wait4(-1,os.WNOHANG)
            except ChildProcessError:
                no_children=True;break
            if not pid:break
            self.reaped_count+=1
            self.reaped_user+=usage.ru_utime;self.reaped_system+=usage.ru_stime
            if self.root is not None and pid==self.root.pid:
                self.root_status=os.waitstatus_to_exitcode(status)
                self.root.returncode=self.root_status
            entry=self.tracked.pop(pid,None)
            if entry is not None:os.close(entry['fd'])
        return no_children

    def signal(self,entry,signum):
        try:
            signal.pidfd_send_signal(entry['fd'],signum)
        except ProcessLookupError:
            pass

    def threads_stopped(self,entry):
        if select.select([entry['fd']],[],[],0)[0]:return True
        count=0;closed=True
        try:
            with os.scandir(f'/proc/{entry["pid"]}/task') as tasks:
                for task in tasks:
                    if not task.name.isdecimal():continue
                    count+=1
                    if count>1024:raise TreeFailure('tree_thread_observation_capacity')
                    try:row=read_stat(int(task.name),Path(task.path)/'stat')
                    except (FileNotFoundError,ProcessLookupError):continue
                    if row['state'] not in ('T','t','Z','X'):closed=False
        except (FileNotFoundError,ProcessLookupError):
            if select.select([entry['fd']],[],[],0)[0]:return True
            raise TreeFailure('tree_thread_enumeration_unavailable')
        self.max_threads=max(self.max_threads,count)
        if not count and not select.select([entry['fd']],[],[],0)[0]:
            raise TreeFailure('tree_thread_enumeration_unavailable')
        return closed

    def sample(self):
        # Discover before pausing: global /proc enumeration does not stop any
        # target task. Once signals are sent, wait on the pinned tasks without
        # repeatedly scanning unrelated processes. A final discovery below
        # still closes fork/adoption races before any sample is accepted.
        self.discover()
        started=time.monotonic_ns();resumed={};closed=False
        self.pause_count+=1
        budget=self.p['max_pause_ms']*1_000_000-self.pause_ns
        if budget<=0:raise TreeFailure('tree_perturbation_budget')
        deadline=started+min(budget,100_000_000)
        try:
            for _ in range(16):
                waiting=False
                for pid,entry in list(self.tracked.items()):
                    try:row=read_stat(pid)
                    except (FileNotFoundError,ProcessLookupError):continue
                    if row['start_ticks']!=entry['start_ticks']:continue
                    if row['state'] not in ('T','t','Z','X'):
                        identity=(pid,entry['start_ticks'])
                        if identity not in resumed:resumed[identity]=os.dup(entry['fd'])
                        self.signal(entry,signal.SIGSTOP)
                        waiting=True
                    elif not self.threads_stopped(entry):
                        # A stopped leader is insufficient: another thread may
                        # still be running, waiting for children or in D state.
                        waiting=True
                if time.monotonic_ns()>deadline:
                    raise TreeFailure('tree_perturbation_budget' if self.pause_ns+time.monotonic_ns()-started>=self.p['max_pause_ms']*1_000_000 else 'tree_quiescence_not_closed')
                if waiting:
                    time.sleep(.001);continue
                # No owned task can fork or wait while stopped. Reap only our
                # direct/adopted zombies, then read a disjoint CPU partition.
                self.reap();rows=self.discover()
                if time.monotonic_ns()>deadline:
                    raise TreeFailure('tree_perturbation_budget' if self.pause_ns+time.monotonic_ns()-started>=self.p['max_pause_ms']*1_000_000 else 'tree_quiescence_not_closed')
                live=[]
                for pid,entry in self.tracked.items():
                    row=rows.get(pid)
                    if row is None or row['start_ticks']!=entry['start_ticks']:continue
                    if row['state'] not in ('T','t','Z','X') or not self.threads_stopped(entry):
                        waiting=True;break
                    live.append(row)
                if waiting:continue
                cpu=(self.reaped_user+self.reaped_system)*1000+sum(r['ticks']+r['waited_ticks'] for r in live)*1000/os.sysconf('SC_CLK_TCK')
                rss=sum(r['rss_pages'] for r in live)*os.sysconf('SC_PAGE_SIZE')
                now=time.monotonic_ns()
                if self.last_sample_ns is not None:self.max_gap_ns=max(self.max_gap_ns,now-self.last_sample_ns)
                self.last_sample_ns=now;self.peak_rss=max(self.peak_rss,rss);self.max_cpu_ms=max(self.max_cpu_ms,cpu)
                row={'elapsed_ms':int((now-self.started_ns)/1e6),'cpu_milliseconds':int(cpu),
                     'rss_bytes':rss,'observed_processes':len(live)}
                if len(self.samples)<16:self.samples.append(row)
                else:self.samples[-1]=row
                closed=True
                return row
            raise TreeFailure('tree_quiescence_not_closed')
        finally:
            for descriptor in resumed.values():
                try:signal.pidfd_send_signal(descriptor,signal.SIGCONT)
                except ProcessLookupError:pass
                finally:os.close(descriptor)
            self.pause_ns+=time.monotonic_ns()-started
            if closed and self.pause_ns>self.p['max_pause_ms']*1_000_000:
                self.failure='tree_perturbation_budget'

    def drain(self,timeout):
        for key,_ in self.selector.select(timeout):
            if key.data=='host':
                self.stopping=True;self.selector.unregister(key.fileobj);continue
            name=key.data
            raw=os.read(key.fd,8192)
            if not raw:
                self.selector.unregister(key.fileobj);continue
            item=self.output[name];item['bytes']+=len(raw);item['sha'].update(raw)
            if self.p.get('capture_output',False) and len(item['prefix'])<1024:
                item['prefix'].extend(raw[:1024-len(item['prefix'])])
            if sum(x['bytes'] for x in self.output.values())>1024*1024:
                self.failure='tree_output_budget'

    def cleanup(self,seconds=3):
        deadline=time.monotonic()+seconds
        attempt=0
        while True:
            # Killing pinned ancestors makes even setsid descendants reparent
            # to this subreaper; no process-group membership is used as proof.
            for entry in list(self.tracked.values()):self.signal(entry,signal.SIGKILL)
            try:self.discover()
            except (OSError,TreeFailure):pass
            for entry in list(self.tracked.values()):self.signal(entry,signal.SIGKILL)
            if self.reap():return True
            if time.monotonic()>=deadline:return False
            self.drain(min(.25,.005*(2**min(attempt,6))))
            attempt+=1

    def report_and_retain(self,result,complete):
        try:
            emit(result)
        finally:
            # Host death may close the result pipe. It never releases our
            # subreaper ownership while a child is still uninterruptible.
            while not complete:complete=self.cleanup()

    def result(self,status,reason,complete):
        cpu=(self.reaped_user+self.reaped_system)*1000
        pending={key.data for key in self.selector.get_map().values()}
        outputs={name:{'bytes':item['bytes'],'sha256':item['sha'].hexdigest(),
                      'prefix':bytes(item['prefix']).decode('utf-8','replace'),
                      'complete':name not in pending,'redacted':not self.p.get('capture_output',False),
                      'truncated':item['bytes']>len(item['prefix'])} for name,item in self.output.items()}
        return {'event':'result','status':status,'reason':reason,'root_exit_code':self.root_status,
            'aggregate_usage':{'cpu_milliseconds':int(cpu),'cpu_complete':complete,
                'wait4_user_milliseconds':int(self.reaped_user*1000),'wait4_system_milliseconds':int(self.reaped_system*1000),
                'peak_sampled_cpu_milliseconds':int(self.max_cpu_ms),'peak_sampled_rss_bytes':self.peak_rss,
                'peak_observed_processes':self.peak_count,'rss_shared_pages_may_be_double_counted':True,
                'cgroup_hard_quota':False},
            'cleanup':{'complete':complete,'all_owned_exited_and_reaped':complete,
                       'wait4_receipts':self.reaped_count,'guardian_retained':not complete},
            'sampling':{'method':'owned_tree_quiescent_samples','samples':len(self.samples),
                'quiesce_count':self.pause_count,'quiesce_upper_bound_milliseconds':int(self.pause_ns/1e6),
                'max_observed_sample_gap_milliseconds':int(self.max_gap_ns/1e6),
                'max_threads_observed_in_process':self.max_threads,
                'configured_interval_milliseconds':self.p.get('sample_ms',200),
                'cpu_overshoot_milliseconds':max(0,int(cpu)-self.p['cpu_milliseconds']),
                'hard_realtime':False,'unknown_external_writers_excluded':False},
            'samples':self.samples,'owned_identities':self.identities,
            'identity_list_truncated':len(self.seen)>len(self.identities),
            'observed_identity_count':len(self.seen),'output':outputs,
            'elapsed_milliseconds':int((time.monotonic_ns()-self.started_ns)/1e6)}

    def run(self):
        subreaper()
        for signum in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(signum,self.stopped)
        signal.signal(signal.SIGPIPE,signal.SIG_IGN)
        if select.select([self.host_fd],[],[],0)[0]:raise TreeFailure('tree_host_already_exited')
        gate_read,gate_write=os.pipe2(os.O_CLOEXEC)
        try:
            self.root=subprocess.Popen([sys.executable,'-I','-S','-c',EXECUTE,str(self.exe_fd),str(gate_read),
                str(self.pid),str(self.profile_path)],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,close_fds=True,pass_fds=(self.exe_fd,gate_read),bufsize=0)
        finally:os.close(gate_read)
        try:
            first=read_stat(self.root.pid)
            self.pin(first,{})
            self.root_identity={'pid':first['pid'],'start_ticks':first['start_ticks']}
            self.started_ns=time.monotonic_ns()
            self.selector.register(self.host_fd,selectors.EVENT_READ,'host')
            for name in ('stdout','stderr'):
                pipe=getattr(self.root,name);os.set_blocking(pipe.fileno(),False)
                self.selector.register(pipe,selectors.EVENT_READ,name)
            emit({'event':'ready','guardian_pid':self.pid,'root':self.root_identity})
            os.write(gate_write,b'G')
        finally:os.close(gate_write)
        reason=None;status='completed';next_sample=0
        try:
            while True:
                if self.reap():break
                elapsed=(time.monotonic_ns()-self.started_ns)/1e6
                if select.select([self.host_fd],[],[],0)[0]:reason='host_exit';break
                if self.stopping:reason='controller_cancelled';break
                if elapsed>=self.p['wall_ms']:reason='wall_clock';break
                if self.failure is not None:reason=self.failure;break
                if time.monotonic()>=next_sample:
                    row=self.sample()
                    if row['observed_processes']>self.p['max_processes']:reason='process_count';break
                    if row['cpu_milliseconds']>=self.p['cpu_milliseconds']:reason='cpu';break
                    if row['rss_bytes']>=self.p['rss_bytes']:reason='rss';break
                    next_sample=time.monotonic()+self.p.get('sample_ms',200)/1000
                self.drain(min(.02,max(0,next_sample-time.monotonic())))
        except (OSError,ValueError,TreeFailure) as error:
            reason=str(error) if isinstance(error,TreeFailure) else 'tree_observation_failed'
            if reason=='tree_perturbation_budget':reason='perturbation';status='budget_exceeded'
            else:status='unknown'
        if reason is not None:
            if status!='unknown':status='cancelled' if reason in ('host_exit','controller_cancelled') else 'budget_exceeded'
        elif self.root_status:
            status='target_failed';reason='root_exit_nonzero'
        complete=self.cleanup()
        # Drain bounded trailing output after every owned writer has exited.
        drain_deadline=time.monotonic()+.25
        while any(key.data in ('stdout','stderr') for key in self.selector.get_map().values()):
            self.drain(.005)
            if time.monotonic()>=drain_deadline:break
        if not complete:status='unknown';reason='tree_cleanup_unresolved'
        self.report_and_retain(self.result(status,reason,complete),complete)
        return 0

    def close(self):
        if self.root is not None:
            complete=False
            while not complete:
                try:complete=self.cleanup()
                except (OSError,TreeFailure):time.sleep(.1)
        for entry in self.tracked.values():os.close(entry['fd'])
        self.tracked.clear()
        if self.root is not None:
            for pipe in (self.root.stdout,self.root.stderr):pipe.close()
        self.selector.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host-fd',type=int,required=True)
    parser.add_argument('--exe-fd',type=int,required=True)
    parser.add_argument('--profile',type=Path,required=True)
    args=parser.parse_args()
    supervisor=None
    try:
        if args.host_fd<3 or args.exe_fd<3 or args.host_fd==args.exe_fd:
            raise TreeFailure('tree_invalid_descriptors')
        if 'Pid:' not in Path(f'/proc/self/fdinfo/{args.host_fd}').read_text():
            raise TreeFailure('tree_host_pidfd_required')
        profile=json.loads(args.profile.read_bytes())
        fd=args.exe_fd;info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_mode&0o6000 or info.st_size>64*1024*1024:
            raise TreeFailure('tree_executable_type')
        digest=hashlib.sha256();offset=0
        while offset<info.st_size:
            raw=os.pread(fd,min(65536,info.st_size-offset),offset)
            if not raw:raise TreeFailure('tree_executable_changed')
            digest.update(raw);offset+=len(raw)
        if digest.hexdigest()!=profile['binary_sha256']:
            raise TreeFailure('tree_executable_digest_mismatch')
        supervisor=Supervisor(profile,args.host_fd,args.exe_fd,args.profile)
        return supervisor.run()
    except BaseException as error:
        try:emit({'event':'error','status':'unknown' if supervisor and supervisor.root else 'rejected',
                  'error':str(error) if isinstance(error,TreeFailure) else 'tree_guardian_failed'})
        except (OSError,TreeFailure):pass
        return 2
    finally:
        if supervisor is not None:supervisor.close()


if __name__=='__main__':
    raise SystemExit(main())
