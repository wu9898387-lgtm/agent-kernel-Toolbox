// Fixed ABI execution in Ghidra's shared p-code VM, with private RAM only.
// @category RuntimeAccess
import ghidra.app.script.GhidraScript;
import ghidra.app.emulator.EmulatorHelper;
import ghidra.app.emulator.AdaptedEmulator;
import ghidra.app.emulator.Emulator;
import ghidra.app.emulator.MemoryAccessFilter;
import ghidra.pcode.memstate.MemoryFaultHandler;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSpace;
import ghidra.program.model.lang.Register;
import ghidra.program.model.lang.RegisterValue;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.pcode.Varnode;
import ghidra.program.model.symbol.Symbol;
import com.google.gson.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

@SuppressWarnings("removal")
public class RuntimeAccessEmulateMemory extends GhidraScript {
    private static final long STACK_LOW=0x70010000L,STACK_HIGH=0x70020000L,RETURN_PC=0x70000000L;
    private final JsonArray trace=new JsonArray(),memoryEvents=new JsonArray();
    private final List<Region> regions=new ArrayList<>();
    private int evidenceChars,evidenceNodes,traceOmitted,memoryAccesses,maxMemoryEvents,maxRecordedEvents,currentStep;
    private boolean readingFinalState;
    private String currentPC="initialization";
    private static class Region {
        String id;long address;byte[] initial;boolean writable;
        boolean contains(long offset,int size){return size>0 && offset>=address && offset<address+initial.length && size<=address+initial.length-offset;}
    }
    private static boolean stack(long offset,int size){return size>0 && offset>=STACK_LOW && offset<STACK_HIGH && size<=STACK_HIGH-offset;}
    private static String hex(byte[] bytes){return HexFormat.of().formatHex(bytes);}
    private static String digest(byte[] bytes)throws Exception{return hex(MessageDigest.getInstance("SHA-256").digest(bytes));}
    private Region region(long offset,int size){for(Region r:regions)if(r.contains(offset,size))return r;return null;}
    private static JsonObject node(Varnode value){
        if(value==null)return null;
        JsonObject out=new JsonObject();out.addProperty("space",value.getAddress().getAddressSpace().getName());
        out.addProperty("offset","0x"+Long.toUnsignedString(value.getOffset(),16));out.addProperty("bytes",value.getSize());return out;
    }
    private static int nodes(JsonElement value){
        int count=1;
        if(value.isJsonObject())for(Map.Entry<String,JsonElement> item:value.getAsJsonObject().entrySet())count+=1+nodes(item.getValue());
        else if(value.isJsonArray())for(JsonElement item:value.getAsJsonArray())count+=nodes(item);
        return count;
    }
    private boolean fits(JsonObject value){return evidenceChars+value.toString().length()<=43000 && evidenceNodes+nodes(value)<=3400;}
    private void append(JsonArray array,JsonObject value){evidenceChars+=value.toString().length();evidenceNodes+=nodes(value);array.add(value);}
    private void traceStep(JsonObject value){
        // Preserve a prefix; leave room for final RAM and the host envelope.
        if(traceOmitted>0 || !fits(value)){++traceOmitted;return;}
        append(trace,value);
    }
    private void memoryEvent(JsonObject value){
        while(!fits(value) && trace.size()>0){
            JsonElement removed=trace.remove(trace.size()-1);
            evidenceChars-=removed.toString().length();evidenceNodes-=nodes(removed);++traceOmitted;
        }
        if(fits(value))append(memoryEvents,value);
    }
    private void access(String kind,long offset,int size,byte[] values,Region r){
        if(size<1 || size>64)throw new IllegalStateException("memory_access_size_unsupported");
        if(memoryAccesses>=maxMemoryEvents)throw new IllegalStateException("memory_event_budget_exhausted");
        ++memoryAccesses;
        // Retain a prefix. Access controls and the hard work budget apply to every event.
        if(memoryAccesses>maxRecordedEvents || memoryEvents.size()!=memoryAccesses-1)return;
        JsonObject out=new JsonObject();out.addProperty("seq",memoryAccesses);out.addProperty("pc",currentPC);
        out.addProperty("instruction_step",currentStep);
        out.addProperty("kind",kind);out.addProperty("region",r==null?"private_stack":r.id);
        out.addProperty("space",r==null?"stack":"profile_region");
        out.addProperty("offset",offset-(r==null?STACK_LOW:r.address));out.addProperty("bytes",size);
        out.addProperty("value_hex",hex(Arrays.copyOf(values,size)));memoryEvent(out);
    }
    @Override public void run()throws Exception {
        String[] args=getScriptArgs();
        if(args.length!=2 || currentProgram==null)throw new IllegalArgumentException("output and fixed configuration required");
        byte[] configuration=Files.readAllBytes(Path.of(args[1]));
        if(configuration.length>32768)throw new IllegalArgumentException("configuration budget");
        JsonObject config=JsonParser.parseString(new String(configuration,StandardCharsets.UTF_8)).getAsJsonObject();
        String symbol=config.get("function").getAsString(),abi=config.get("abi").getAsString();
        String language=currentProgram.getLanguageID().toString();
        boolean arm64=language.equals("AARCH64:LE:64:v8A"),x64=language.equals("x86:LE:64:default");
        if(!currentProgram.getExecutableFormat().contains("ELF") || !(x64 && abi.equals("sysv_amd64_buffer_i32") || arm64 && abi.equals("aapcs64_buffer_i32")))throw new IllegalArgumentException("ELF language and registered ABI mismatch");
        int maxSteps=config.get("max_steps").getAsInt();maxMemoryEvents=config.get("max_memory_events").getAsInt();
        maxRecordedEvents=config.has("max_recorded_events")?config.get("max_recorded_events").getAsInt():maxMemoryEvents;
        if(maxRecordedEvents<0 || maxRecordedEvents>maxMemoryEvents)throw new IllegalArgumentException("invalid recorded event budget");
        if(maxSteps<1 || maxSteps>4096 || maxMemoryEvents<1 || maxMemoryEvents>256 || !symbol.matches("[A-Za-z_][A-Za-z0-9_]{0,127}"))throw new IllegalArgumentException("invalid budgets or symbol");
        AddressSpace ram=currentProgram.getAddressFactory().getDefaultAddressSpace();
        List<Symbol> symbols=currentProgram.getSymbolTable().getGlobalSymbols(symbol);
        if(symbols.size()!=1)throw new IllegalArgumentException("ambiguous or missing registered function");
        Function function=currentProgram.getFunctionManager().getFunctionAt(symbols.get(0).getAddress());
        if(function==null || function.isExternal() || function.isThunk())throw new IllegalArgumentException("registered symbol is not an internal analyzed function");
        if(currentProgram.getMemory().intersects(ram.getAddress(STACK_LOW),ram.getAddress(STACK_HIGH-1)) || currentProgram.getMemory().contains(ram.getAddress(RETURN_PC)))throw new IllegalArgumentException("reserved stack overlaps program image");
        int total=0;
        for(JsonElement item:config.getAsJsonArray("regions")){
            JsonObject value=item.getAsJsonObject();Region r=new Region();r.id=value.get("id").getAsString();
            r.address=value.get("address").getAsLong();r.initial=HexFormat.of().parseHex(value.get("initial_hex").getAsString());r.writable=value.get("writable").getAsBoolean();
            if(!r.id.matches("[A-Za-z][A-Za-z0-9_]{0,31}") || r.address<0x60000000L || r.address>=0x60010000L || r.initial.length<1 || r.initial.length>1024 || r.address+r.initial.length>0x60010000L)throw new IllegalArgumentException("invalid private RAM region");
            for(Region old:regions)if(old.id.equals(r.id) || r.address<old.address+old.initial.length && old.address<r.address+r.initial.length)throw new IllegalArgumentException("overlapping or duplicate private RAM");
            if(currentProgram.getMemory().intersects(ram.getAddress(r.address),ram.getAddress(r.address+r.initial.length-1)))throw new IllegalArgumentException("private RAM overlaps program image");
            total+=r.initial.length;regions.add(r);
        }
        if(regions.isEmpty() || regions.size()>4 || total>4096)throw new IllegalArgumentException("private RAM budget");
        JsonArray arguments=config.getAsJsonArray("arguments");
        if(arguments.size()!=2)throw new IllegalArgumentException("two fixed ABI arguments required");
        JsonObject pointer=arguments.get(0).getAsJsonObject();Region input=null;
        for(Region r:regions)if(r.id.equals(pointer.get("region").getAsString()))input=r;
        int offset=pointer.get("offset").getAsInt();
        if(input==null || offset<0 || offset>=input.initial.length)throw new IllegalArgumentException("argument outside registered private RAM");
        int count=arguments.get(1).getAsJsonObject().get("i32").getAsInt();
        // DefaultEmulator's legacy filter runs after a store. The mature 12.2
        // AdaptedEmulator dispatches the same guard before setVar commits it.
        EmulatorHelper helper=new EmulatorHelper(currentProgram){
            @Override protected Emulator newEmulator(){return new AdaptedEmulator(this);}
        };String status="unknown",reason="step_budget_exhausted";
        int executed=0,attempted=0,registers=0;
        boolean setupComplete=false,readbackComplete=true;
        BigInteger returned=null;
        JsonArray finals=new JsonArray();
        try{
            helper.setMemoryFaultHandler(new MemoryFaultHandler(){
                @Override public boolean unknownAddress(Address address,boolean write){return false;}
                @Override public boolean uninitializedRead(Address address,int size,byte[] data,int offset){return false;}
            });
            helper.writeMemory(ram.getAddress(STACK_LOW),new byte[(int)(STACK_HIGH-STACK_LOW)]);
            for(Region r:regions)helper.writeMemory(ram.getAddress(r.address),r.initial);
            for(Register register:currentProgram.getLanguage().getRegisters()){
                if(register.isBaseRegister() && !register.isProcessorContext() && register.getNumBytes()<=256){
                    if(registers>=1024)throw new IllegalStateException("register_initialization_budget");
                    helper.writeRegister(register,BigInteger.ZERO);
                    ++registers;
                }
            }
            long sp=STACK_HIGH-(x64?8:16);helper.writeRegister(helper.getStackPointerRegister(),sp);
            if(x64){helper.writeMemoryValue(ram.getAddress(sp),8,RETURN_PC);helper.writeRegister("RDI",input.address+offset);helper.writeRegister("RSI",Integer.toUnsignedLong(count));}
            else{helper.writeRegister("x30",RETURN_PC);helper.writeRegister("x0",input.address+offset);helper.writeRegister("x1",Integer.toUnsignedLong(count));}
            helper.writeRegister(helper.getPCRegister(),function.getEntryPoint().getOffset());
            Register context=currentProgram.getLanguage().getContextBaseRegister();
            if(context!=null){
                RegisterValue value=currentProgram.getProgramContext().getRegisterValue(context,function.getEntryPoint());
                if(value!=null)helper.getEmulator().setContextRegisterValue(value);
            }
            helper.getEmulator().addMemoryAccessFilter(new MemoryAccessFilter(){
                @Override protected void processRead(AddressSpace space,long offset,int size,byte[] values){
                    if(!space.equals(ram) || readingFinalState)return;
                    Region r=region(offset,size);
                    if(r!=null || stack(offset,size)){access("read",offset,size,values,r);return;}
                    Address address=space.getAddress(offset);MemoryBlock block=currentProgram.getMemory().getBlock(address);
                    if(size<1 || size>64 || block==null || !block.isInitialized() || !block.isRead() || block.isVolatile() || !block.contains(address.add(size-1)))throw new IllegalStateException("read_outside_registered_RAM_or_readonly_ELF_image");
                }
                @Override protected void processWrite(AddressSpace space,long offset,int size,byte[] values){
                    if(!space.equals(ram))return;
                    Region r=region(offset,size);
                    if(r==null && !stack(offset,size) || r!=null && !r.writable)throw new IllegalStateException("write_outside_writable_private_RAM_or_stack");
                    access("write",offset,size,values,r);
                }
            });
            setupComplete=true;
            while(true){
                monitor.checkCancelled();Address pc=helper.getExecutionAddress();currentPC=pc.toString();
                if(pc.getOffset()==RETURN_PC){
                    returned=helper.readRegister(arm64?"x0":"RAX").and(new BigInteger("ffffffff",16));
                    status="completed";reason="returned_to_private_sentinel";break;
                }
                if(executed>=maxSteps)break;
                if(!function.getBody().contains(pc)){reason="execution_left_registered_function";break;}
                Instruction instruction=currentProgram.getListing().getInstructionAt(pc);
                if(instruction==null){reason="undecoded_instruction";break;}
                JsonObject step=new JsonObject();step.addProperty("step",executed);step.addProperty("pc",currentPC);
                JsonArray pcode=new JsonArray();boolean unsupported=false;
                PcodeOp[] operations=instruction.getPcode();
                if(operations.length>64){reason="instruction_pcode_budget";break;}
                for(PcodeOp op:operations){
                    int code=op.getOpcode();if(code==PcodeOp.CALLOTHER || code==PcodeOp.CALL || code==PcodeOp.CALLIND)unsupported=true;
                    if(op.getNumInputs()>16)throw new IllegalStateException("pcode_input_budget");
                    JsonObject operation=new JsonObject();operation.addProperty("opcode",op.getMnemonic());operation.add("output",node(op.getOutput()));
                    JsonArray inputs=new JsonArray();for(int i=0;i<op.getNumInputs();i++)inputs.add(node(op.getInput(i)));operation.add("inputs",inputs);pcode.add(operation);
                }
                if(unsupported){reason="syscall_userop_or_nested_call_unsupported";break;}
                step.add("pcode",pcode);step.addProperty("step_completed",false);traceStep(step);
                currentStep=executed;
                ++attempted;
                if(!helper.step(monitor)){reason="pcode_step_failed:"+helper.getLastError();break;}
                step.addProperty("step_completed",true);++executed;
            }
        }catch(RuntimeException error){reason=error.getMessage()==null?"pcode_execution_error":error.getMessage();}
        finally{
            // Only this host readback phase suppresses access logging. Guest work has stopped.
            readingFinalState=true;
            try{
                for(Region r:regions){
                    JsonObject value=new JsonObject();value.addProperty("id",r.id);value.addProperty("virtual_address","0x"+Long.toUnsignedString(r.address,16));
                    value.addProperty("bytes",r.initial.length);value.addProperty("writable",r.writable);value.addProperty("initial_sha256",digest(r.initial));
                    byte[] bytes=null;
                    if(setupComplete){
                        try{bytes=helper.readMemory(ram.getAddress(r.address),r.initial.length);}
                        catch(RuntimeException ignored){/* A failed readback has its own status below. */}
                    }
                    if(bytes!=null && bytes.length==r.initial.length){
                        int changed=0;
                        for(int i=0;i<bytes.length;++i)if(bytes[i]!=r.initial[i])++changed;
                        value.addProperty("readback","available");value.addProperty("changed_bytes",changed);
                        value.addProperty("final_hex",hex(bytes));value.addProperty("final_sha256",digest(bytes));
                    }else{
                        readbackComplete=false;value.addProperty("readback","unavailable");
                    }
                    finals.add(value);
                }
            }finally{helper.dispose();}
        }
        JsonObject out=new JsonObject();out.addProperty("schema_version",1);out.addProperty("engine","Ghidra EmulatorHelper shared p-code");
        out.addProperty("status",status);out.addProperty("reason",reason.length()>256?reason.substring(0,256):reason);out.addProperty("language_id",language);
        out.addProperty("program_sha256",currentProgram.getExecutableSHA256());out.addProperty("function",symbol);out.addProperty("abi",abi);
        out.addProperty("steps",executed);out.addProperty("max_steps",maxSteps);out.addProperty("memory_accesses",memoryAccesses);out.addProperty("max_memory_events",maxMemoryEvents);
        out.addProperty("evidence_revision",2);out.addProperty("steps_attempted",attempted);
        out.addProperty("max_recorded_events",maxRecordedEvents);
        out.addProperty("memory_events_recorded",memoryEvents.size());out.addProperty("memory_events_omitted",memoryAccesses-memoryEvents.size());
        out.addProperty("final_readback",readbackComplete?"complete":"incomplete");
        JsonObject initial=new JsonObject();
        initial.addProperty("setup_completed",setupComplete);initial.addProperty("base_registers_zeroed",registers);
        initial.addProperty("register_source","model_zero_then_abi_overrides");
        initial.addProperty("stack_source","model_zero_then_abi_setup");initial.addProperty("stack_bytes",STACK_HIGH-STACK_LOW);
        initial.addProperty("private_regions_source","registered_profile");
        initial.addProperty("assumption_dependence","not_tracked");
        out.add("initial_state",initial);
        out.add("returned_u32",returned==null?JsonNull.INSTANCE:new JsonPrimitive(returned));out.add("trace",trace);out.add("memory_events",memoryEvents);out.add("regions",finals);
        out.addProperty("trace_truncated",traceOmitted>0);out.addProperty("trace_steps_omitted",traceOmitted);
        out.addProperty("evidence_node_budget",3400);out.addProperty("trace_source","decoded_typed_pcode_attempted_machine_step_prefix_not_runtime_pcode_callbacks");
        out.addProperty("memory_event_source","EmulatorHelper_RAM_memory_access_filter");out.addProperty("write_scope","private_emulator_RAM_and_stack");
        out.addProperty("memory_write_event_phase","before_emulator_store");out.addProperty("memory_read_event_phase","after_emulator_load");
        out.addProperty("native_target_executed",false);out.addProperty("host_process_memory_access",false);out.addProperty("hardware_trace",false);
        out.addProperty("OS_syscalls_supported",false);out.addProperty("device_memory_supported",false);out.addProperty("floating_point_AOT_implemented",false);
        out.addProperty("functional_equivalence_proven",false);out.addProperty("source_equivalence_proven",false);
        byte[] encoded=out.toString().getBytes(StandardCharsets.UTF_8);
        if(encoded.length>=65536 || nodes(out)>3900)throw new IllegalStateException("final_metadata_exceeds_host_budget");
        Path target=Path.of(args[0]),temporary=Path.of(args[0]+".tmp");
        Files.write(temporary,encoded,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
        Files.move(temporary,target,StandardCopyOption.ATOMIC_MOVE);
    }
}
