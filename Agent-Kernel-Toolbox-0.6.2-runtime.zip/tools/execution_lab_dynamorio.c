/* DynamoRIO official dr_api concrete snapshot client. See CMakeLists.lab.txt. */
#include "dr_api.h"
#include "execution_lab_native.h"
static lab_request request;
static bool active,finished;
static char output_path[4096];
static uint64_t steps,trace[1024];
static uint32_t trace_count,events[1024],event_count;
static uint64_t initial_registers[18];
static unsigned char initial_ram[8][4096];
static void registers(const dr_mcontext_t *mc,uint64_t *state) {
    uint64_t values[18]={mc->xax,mc->xbx,mc->xcx,mc->xdx,mc->xsi,mc->xdi,mc->xbp,mc->xsp,
        mc->r8,mc->r9,mc->r10,mc->r11,mc->r12,mc->r13,mc->r14,mc->r15,(uint64_t)(uintptr_t)mc->pc,mc->xflags};
    memcpy(state,values,sizeof(values));
}
static void put(file_t file,const void *data,size_t size) {
    if (dr_write_file(file,data,size)!=(ssize_t)size) dr_abort();
}
static void finish(dr_mcontext_t *mc,uint64_t reason) {
    if (finished) dr_abort(); finished=true;
    file_t file=dr_open_file(output_path,DR_FILE_WRITE_REQUIRE_NEW);
    if (file==INVALID_FILE) dr_abort();
    uint64_t state[18]; registers(mc,state);
    uint64_t status=reason?1:0;
    put(file,"LABOUT1\0",8); put(file,request.nonce,16); put(file,&status,8); put(file,&reason,8); put(file,&steps,8);
    put(file,initial_registers,sizeof(initial_registers)); put(file,state,sizeof(state)); put(file,&trace_count,4); put(file,&event_count,4);
    put(file,trace,trace_count*8); put(file,events,event_count*4);
    for (uint32_t i=0;i<request.region_count;i++) {
        unsigned char bytes[4096]; lab_region *r=&request.regions[i]; size_t read=0;
        if (!dr_safe_read((void *)(uintptr_t)r->address,r->size,bytes,&read)||read!=r->size) dr_abort();
        put(file,initial_ram[i],r->size); put(file,bytes,r->size);
    }
    dr_close_file(file); dr_exit_process(0);
}
static void observe(app_pc pc) {
    bool first=false;
    if (!active) { if ((uint64_t)(uintptr_t)pc!=request.entry) return; active=true; first=true; }
    void *context=dr_get_current_drcontext(); dr_mcontext_t mc={sizeof(mc),DR_MC_ALL};
    if (!dr_get_mcontext(context,&mc)) dr_abort(); mc.pc=pc;
    if (first) {
        registers(&mc,initial_registers);
        for (uint32_t i=0;i<request.region_count;i++) {
            size_t read=0; lab_region *r=&request.regions[i];
            if (!dr_safe_read((void *)(uintptr_t)r->address,r->size,initial_ram[i],&read)||read!=r->size) dr_abort();
            if (memcmp(initial_ram[i],r->bytes,r->size)) finish(&mc,5);
        }
        if (memcmp(initial_registers,request.regs,sizeof(initial_registers))) finish(&mc,5);
    }
    uint64_t address=(uint64_t)(uintptr_t)pc;
    if (address==request.stop||address==request.load+request.size) finish(&mc,0);
    if (steps>=request.steps) finish(&mc,1);
    int model=-1;
    for (uint32_t i=0;i<request.model_count;i++) if (request.models[i].address==address) model=(int)i;
    if (model<0&&(address<request.load||address>=request.load+request.size)) finish(&mc,2);
    steps++; if (trace_count<1024) trace[trace_count++]=address;
    if (model>=0) {
        lab_model *m=&request.models[model]; uint64_t returned; size_t size;
        if (event_count>=1024) finish(&mc,7);
        if (!lab_permitted(&request,mc.xsp,8,0)||!dr_safe_read((void *)(uintptr_t)mc.xsp,8,&returned,&size)||size!=8) finish(&mc,6);
        if (m->size) {
            lab_region *r=&request.regions[m->region];
            if (!dr_safe_write((void *)(uintptr_t)(r->address+m->offset),m->size,m->bytes,&size)||size!=m->size) finish(&mc,4);
        }
        events[event_count++]=(uint32_t)model; mc.xax=m->value; mc.xsp+=8; mc.pc=(app_pc)(uintptr_t)returned;
        dr_redirect_execution(&mc); dr_abort();
    }
    instr_t instruction; instr_init(context,&instruction);
    if (!decode(context,pc,&instruction)||!instr_valid(&instruction)) finish(&mc,5);
    if (instr_length(context,&instruction)>request.load+request.size-address) finish(&mc,5);
    if (instr_is_syscall(&instruction)||instr_is_interrupt(&instruction)) finish(&mc,3);
    if (instr_is_rep_string_op(&instruction)) finish(&mc,5);
    uint bytes=instr_memory_reference_size(&instruction); app_pc memory; bool write;
    if (!bytes&&(instr_reads_memory(&instruction)||instr_writes_memory(&instruction))) finish(&mc,5);
    for (uint i=0;instr_compute_address_ex(&instruction,&mc,i,&memory,&write);i++)
        if (!lab_permitted(&request,(uint64_t)(uintptr_t)memory,bytes,write)) finish(&mc,4);
    instr_free(context,&instruction);
}
static dr_emit_flags_t instrument(void *context,void *tag,instrlist_t *bb,bool for_trace,bool translating) {
    (void)tag; (void)for_trace; (void)translating;
    for (instr_t *instruction=instrlist_first_app(bb);instruction;instruction=instr_get_next_app(instruction)) {
        app_pc pc=instr_get_app_pc(instruction);
        dr_insert_clean_call(context,bb,instruction,(void *)observe,false,1,OPND_CREATE_INTPTR(pc));
    }
    return DR_EMIT_DEFAULT;
}
static bool syscall(void *context,int number) {
    (void)number;
    if (active) { dr_mcontext_t mc={sizeof(mc),DR_MC_ALL}; if (!dr_get_mcontext(context,&mc)) dr_abort(); finish(&mc,3); }
    return true;
}
DR_EXPORT void dr_client_main(client_id_t id,int argc,const char *argv[]) {
    dr_set_client_name("Execution Lab fixed snapshot client","https://dynamorio.org/");
    if (argc!=3||strlen(argv[2])>=sizeof(output_path)) dr_abort();
    file_t file=dr_open_file(argv[1],DR_FILE_READ); if (file==INVALID_FILE) dr_abort();
    unsigned char *data=dr_global_alloc(LAB_MAX_REQUEST+1); if (!data) dr_abort();
    ssize_t size=dr_read_file(file,data,LAB_MAX_REQUEST+1); dr_close_file(file);
    if (size<0||size>LAB_MAX_REQUEST||!lab_parse(data,(size_t)size,&request)) dr_abort();
    dr_global_free(data,LAB_MAX_REQUEST+1); memcpy(output_path,argv[2],strlen(argv[2])+1);
    /* No arbitrary app launcher is used: parent pins the bundled runner digest. */
    dr_register_bb_event(instrument); dr_register_pre_syscall_event(syscall);
}
