#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / 'runtime-access.pyz'
READ_ONLY_TOOLS = ["runtime.status", "runtime.capabilities", "runtime.audit", "build.inspect"]


class SetupError(ValueError):
    def __init__(self, code, *, detail=None):
        super().__init__(code)
        self.detail = detail


def absolute_path(value, *, relative_to_cwd=False):
    path = Path(value)
    if ".." in path.parts or (not path.is_absolute() and not relative_to_cwd):
        raise SetupError("absolute_path_required")
    path = path.absolute()
    # Linux treats exactly two leading slashes as the same root while pathlib
    # preserves them lexically. Compare and publish one local POSIX spelling.
    return Path('/', *path.parts[1:])


def overlaps(left, right):
    return left == right or left in right.parents or right in left.parents


def directory(path, create=False):
    current = Path(path.anchor)
    info = current.lstat()
    existing = current
    for part in path.parts[1:]:
        current /= part
        try:
            found = current.lstat()
        except FileNotFoundError:
            if not create:
                continue
            current.mkdir(mode=0o700, exist_ok=True)
            found = current.lstat()
        if not stat.S_ISDIR(found.st_mode):
            raise SetupError("directory_or_symlink_invalid")
        info = found
        existing = current
    if info.st_mode & 0o022:
        raise SetupError("unsafe_parent")
    if not os.access(existing, os.W_OK | os.X_OK, effective_ids=os.access in os.supports_effective_ids):
        raise SetupError("directory_not_writable")
    return existing == path


def remove_owned(path, identity):
    try:
        info = path.lstat()
        if (info.st_dev, info.st_ino) == identity:
            path.unlink()
    except FileNotFoundError:
        pass


def replay_modules_from_files(entries):
    from observation_extension.record_projection import MODULE_ALIAS, validate_projection
    from observation_extension.runtime_mcp import parse_message
    from observation_extension.snapshot_tools import _open_snapshot

    modules = {}
    for alias, filename in entries:
        if (re.fullmatch(MODULE_ALIAS['pattern'], alias) is None or alias in modules
                or len(modules) >= 32):
            raise SetupError('invalid_or_duplicate_replay_module')
        path = absolute_path(filename)
        try:
            with _open_snapshot(str(path)) as (stream, before):
                if before.st_size > 65536:
                    raise SetupError('replay_module_byte_limit', detail=alias)
                raw = stream.read(65537)
                after = os.fstat(stream.fileno())
                if (len(raw) != before.st_size or before.st_ctime_ns != after.st_ctime_ns
                        or before.st_mtime_ns != after.st_mtime_ns):
                    raise SetupError('replay_module_changed', detail=alias)
        except FileNotFoundError as error:
            raise SetupError('replay_module_not_found', detail=alias) from error
        except OSError as error:
            raise SetupError('replay_module_unreadable', detail=alias) from error
        except SetupError:
            raise
        except ValueError as error:
            raise SetupError('replay_module_invalid_file', detail=alias) from error
        try:
            modules[alias] = validate_projection(parse_message(raw))
        except (ValueError, RuntimeError, RecursionError) as error:
            raise SetupError('invalid_replay_module', detail=alias) from error
    return modules


def configure(config, state_directory, mcp_config=None, *, include_extensions=False,
              coordination_directory=None, snapshots=(), snapshot_max_bytes=None, enable_stop=False,
              enable_replay=False, replay_modules=()):
    config, state = absolute_path(config), absolute_path(state_directory)
    mcp = absolute_path(mcp_config) if mcp_config is not None else None
    coordination = absolute_path(coordination_directory) if coordination_directory is not None else None
    outputs = [config] + ([mcp] if mcp is not None else [])
    if any(overlaps(state, path) for path in outputs) or (mcp is not None and overlaps(config, mcp)):
        raise SetupError("path_conflict")
    if coordination is not None and any(overlaps(coordination, path) for path in [state, *outputs]):
        raise SetupError('coordination_path_conflict')
    for path in outputs:
        if os.path.lexists(path):
            raise SetupError("path_must_not_exist")
        directory(path.parent)
    if directory(state):
        info = state.lstat()
        if info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise SetupError("state_directory_must_be_private")
    if coordination is not None and directory(coordination):
        info = coordination.lstat()
        if info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise SetupError('coordination_directory_must_be_private')
    tools = READ_ONLY_TOOLS + (["runtime.extensions"] if include_extensions else [])
    values = [{"schema_version": 1, "state_directory": str(state),
               "allowed_tools": tools, "portable_build": {"profiles": {}}}]
    if snapshot_max_bytes is not None and not snapshots:
        raise SetupError("snapshot_profile_required")
    if (enable_replay or replay_modules) and not snapshots:
        raise SetupError("replay_snapshot_required")
    if not ENTRY.is_file():
        raise SetupError('runtime_entry_unavailable')
    sys.path.insert(0, str(ENTRY))
    try:
        from observation_extension.policy import _json_copy
        if snapshots:
            from observation_extension.snapshot_tools import MAX_SUMMARY_BYTES, SPECS, validate_snapshots
            registry = {}
            limit = MAX_SUMMARY_BYTES if snapshot_max_bytes is None else snapshot_max_bytes
            for alias, path, digest in snapshots:
                if alias in registry:
                    raise SetupError("duplicate_snapshot_alias")
                registry[alias] = {"path": path, "sha256": digest, "max_bytes": limit}
            validate_snapshots(registry)
            for alias, profile in registry.items():
                source = Path(profile['path'])
                if any(overlaps(source, dest) for dest in outputs):
                    raise SetupError('snapshot_output_path_conflict', detail=alias)
                if any(source == target or source in target.parents
                       for target in (state, coordination) if target is not None):
                    raise SetupError('snapshot_directory_path_conflict', detail=alias)
            values[0]["snapshots"] = registry
        if replay_modules or enable_replay:
            from observation_extension.record_tools import SPECS as replay_specs
            tools.extend(sorted(replay_specs))
        if replay_modules:
            from observation_extension.record_projection import TOOL_NAME
            values[0]['ir_modules'] = replay_modules_from_files(replay_modules)
            tools.append(TOOL_NAME)
        if snapshots:
            # The host binds the ordered tool list into its persistent config digest.
            tools.extend(sorted(SPECS))
    except ImportError as error:
        raise SetupError('runtime_entry_import_failed') from error
    finally:
        sys.path.pop(0)
    if enable_stop:
        tools.append("runtime.stop")
    if coordination is not None:
        values[0]['coordination_directory'] = str(coordination)
    if len((json.dumps(values[0], indent=2) + '\n').encode('utf-8')) > 65536:
        raise SetupError('config_byte_limit')
    _json_copy(values[0])  # Apply the same structural limits as load_config before publication.
    if mcp is not None:
        values.append({"mcpServers": {"runtime-access": {
            "command": os.path.abspath(sys.executable),
            "args": [str(ENTRY), "serve", "--config", str(config),
                     "--bundle-root", str(ROOT)]}}})
    staged, published = [], []
    try:
        for path, value in zip(outputs, values):
            directory(path.parent, create=True)
            fd, name = tempfile.mkstemp(prefix=".runtime-setup-", dir=path.parent)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                info = os.fstat(fd)
                identity = (info.st_dev, info.st_ino)
                staged.append((Path(name), path, identity))
                os.fchmod(fd, 0o600)
                json.dump(value, stream, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(fd)
        for temporary, path, identity in staged:
            try:
                os.link(temporary, path, follow_symlinks=False)
            except FileExistsError as error:
                raise SetupError('path_must_not_exist') from error
            published.append((path, identity))
    except BaseException:
        for path, identity in reversed(published):
            remove_owned(path, identity)
        raise
    finally:
        for temporary, _path, identity in staged:
            remove_owned(temporary, identity)
    return {"config": str(config), **({"mcp_config": str(mcp)} if mcp is not None else {})}


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise SetupError("invalid_arguments", detail=message[:300])


def main(argv=None):
    parser = Parser(description="Create a private configuration for diagnostics and optional pinned snapshot reads.",
                    epilog="Relative config, state and coordination paths are interpreted from the current directory.")
    parser.add_argument("--config", required=True, help="Runtime config output path")
    parser.add_argument("--state-directory", required=True, help="Private state path")
    parser.add_argument("--mcp-config", help="Optional MCP config output path")
    parser.add_argument('--coordination-directory',
                        help='Explicit private shared coordination directory; use a distinct runtime state for every host')
    parser.add_argument("--extensions", action="store_true",
                        help="Enable read-only extension schema/profile inspection")
    parser.add_argument("--snapshot", action="append", nargs=3, metavar=("ID", "ABS_PATH", "EXPECTED_SHA256"),
                        help="Register one offline file for summary and scalar reads. May be repeated.")
    parser.add_argument("--snapshot-max-bytes", type=int,
                        help="Maximum whole file size for each supplied snapshot; defaults to 64 MiB")
    parser.add_argument("--enable-stop", action="store_true",
                        help="Allow MCP clients to latch the operation brake. Reset uses the offline operator command.")
    parser.add_argument("--enable-replay", action="store_true",
                        help="Enable private record checkpoints and reference comparisons for registered snapshots.")
    parser.add_argument("--replay-module", action="append", nargs=2, metavar=("ALIAS", "ABSOLUTE_WORD_IR_JSON"),
                        help="Embed one validated pure word-SSA module for ir.evaluate_replay. Implies --enable-replay.")
    try:
        args = parser.parse_args(argv)
        for option in ('config', 'state_directory', 'mcp_config', 'coordination_directory'):
            value = getattr(args, option)
            if value is not None:
                setattr(args, option, absolute_path(value, relative_to_cwd=True))
        result = configure(args.config, args.state_directory, args.mcp_config,
                           include_extensions=args.extensions,
                           coordination_directory=args.coordination_directory, snapshots=args.snapshot,
                           snapshot_max_bytes=args.snapshot_max_bytes, enable_stop=args.enable_stop,
                           enable_replay=args.enable_replay, replay_modules=args.replay_module)
    except (ValueError, OSError) as error:
        code = str(error) if isinstance(error, ValueError) else "write_failed"
        failure = {"ok": False, "error": code}
        if isinstance(error, SetupError) and error.detail:
            failure["detail"] = error.detail
        print(json.dumps(failure), file=sys.stderr)
        return 2
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
