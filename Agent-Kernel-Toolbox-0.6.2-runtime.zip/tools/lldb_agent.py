#!/usr/bin/env python3
"""Native LLDB JSON-lines agent; run with the interpreter matching LLDB bindings."""
import argparse
import json
import os
from pathlib import Path
import re
import stat
import sys

ROOT=Path(__file__).resolve().parents[1]
MODULES=ROOT/'runtime-access.pyz'
sys.path.insert(0,str(MODULES if MODULES.is_file() else ROOT/'src'))
from observation_extension.lldb_native import LLDBAgent

OPERATIONS={'launch':(), 'status':(), 'inspect':(), 'read_memory':('address','size'),
            'read_value':('address','size','type'), 'write_memory':('region','offset','data_hex','expected_sha256'),
            'step':('thread_index','instructions'), 'terminate':(), 'detach':()}


def output(value):
    raw=json.dumps(value,ensure_ascii=True,allow_nan=False,separators=(',',':'))
    if len(raw)>1048576:raise RuntimeError('debugger_output_budget')
    print(raw,flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,required=True);args=parser.parse_args()
    info=args.config.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size>65536 or os.name=='posix' and (info.st_uid!=os.geteuid() or info.st_mode&0o022):
        raise RuntimeError('debugger_config_must_be_private_regular_file')
    config=json.loads(args.config.read_bytes());agent=LLDBAgent(config)
    try:
        import hashlib
        profile_hash=hashlib.sha256(json.dumps(config,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()
        output({'event':'ready','capabilities':agent.capabilities(),'profile_sha256':profile_hash})
        while True:
            raw=sys.stdin.buffer.readline(65537)
            if not raw:break
            if len(raw)>65536 or not raw.endswith(b'\n'):return 2
            request=json.loads(raw);identifier=request.get('id');name=request.get('method');a=request.get('args',{})
            try:
                if name not in OPERATIONS or type(a) is not dict or set(a)!=set(OPERATIONS[name]):raise RuntimeError('invalid_debugger_request')
                if name=='launch':value=agent.launch()
                elif name=='status':value=agent.status()
                elif name=='inspect':value=agent.inspect()
                elif name in ('read_memory','read_value'):
                    if type(a['address']) is not str or re.fullmatch(r'0x[0-9a-fA-F]{1,16}',a['address']) is None:raise RuntimeError('invalid_address')
                    value=agent.read_memory(int(a['address'],16),a['size'],a.get('type'))
                elif name=='write_memory':
                    if type(a['data_hex']) is not str or re.fullmatch(r'(?:[0-9a-fA-F]{2}){1,4096}',a['data_hex']) is None or type(a['expected_sha256']) is not str or re.fullmatch(r'[0-9a-f]{64}',a['expected_sha256']) is None:raise RuntimeError('invalid_debugger_write')
                    value=agent.write_memory(a['region'],a['offset'],bytes.fromhex(a['data_hex']),a['expected_sha256'])
                elif name=='step':value=agent.step(a['thread_index'],a['instructions'])
                elif name=='terminate':value=agent.terminate()
                else:agent.close();agent=None;value={'detached':True}
                output({'id':identifier,'result':value})
                if agent is None:break
            except Exception as error:
                code=str(error)
                output({'id':identifier,'error':{'code':code if re.fullmatch(r'[a-z][a-z0-9_]{1,100}',code) else 'native_debugger_operation_failed'}})
    finally:
        if agent:agent.close()
    return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,ImportError) as error:
        print('native_debugger_agent_failed',file=sys.stderr);raise SystemExit(2)
