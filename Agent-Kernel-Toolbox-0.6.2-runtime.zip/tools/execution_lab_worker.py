#!/usr/bin/env python3
"""Disposable official-API concrete engines; no arbitrary scripts or models."""
from __future__ import annotations

import ctypes
import importlib.metadata
import json
from pathlib import Path
import struct
import sys

_ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(_ROOT/'runtime-access.pyz' if (_ROOT/'runtime-access.pyz').is_file() else _ROOT/'src'))
from observation_extension.lab_tools import (validate_profile, result_base, bounded_file,
    initial_registers, taint_base, _REGS, _json, _sha)


class Snapshot:
    def __init__(self,p,raw):
        self.p=p; self.raw=raw; self.result=result_base(p,p['nonce'])
        self.code_end=p['load_address']+len(raw); self.halted=False; self.resume=False
        self.models={m['address']:m for m in p['models']}
        self.regions={r['id']:r for r in p['regions']}

    def unknown(self,reason,kind='execution'):
        if not self.halted:
            self.result.update(status='unknown',reason=reason,unknown=[{'kind':kind,'detail':reason[:256]}])
        self.halted=True
        self.stop()

    def permitted(self,address,size,write=False):
        if not write and self.p['load_address']<=address and address+size<=self.code_end:
            return True
        return any(r['address']<=address and address+size<=r['address']+len(r['initial_hex'])//2 and (not write or r['writable']) for r in self.p['regions'])

    def access(self,address,size,write=False):
        if not self.permitted(address,size,write):
            self.unknown('memory_outside_registered_snapshot','memory')

    def valid_pc(self,pc):
        return pc in {self.p['stop_address'],self.code_end} or pc in self.models or self.p['load_address']<=pc<self.code_end

    def verify_initial(self):
        observed={r:self.reg_read(r) for r in _REGS}
        if observed!=initial_registers(self.p): raise RuntimeError('actual_initial_registers_mismatch')
        for r in self.p['regions']:
            if bytes(self.mem_read(r['address'],len(r['initial_hex'])//2)).hex()!=r['initial_hex']:
                raise RuntimeError('actual_initial_ram_mismatch')
        self.result['registers_before']=observed

    def tick(self,pc,size=None):
        self.resume=False
        if pc in {self.p['stop_address'],self.code_end}:
            self.halted=True; self.stop(); return
        if self.result['steps']>=self.p['max_steps']:
            self.unknown('step_budget_exhausted','budget'); return
        if pc not in self.models and not self.p['load_address']<=pc<self.code_end:
            self.unknown('uncovered_external_call_at_'+hex(pc),'external_call'); return
        if size is not None and pc not in self.models and (size<=0 or pc+size>self.code_end):
            self.unknown('instruction_crosses_registered_code','instruction'); return
        self.result['steps']+=1
        if len(self.result['trace'])<1024:
            self.result['trace'].append(pc)
        else:
            self.result['trace_steps_omitted']+=1
        if pc in self.models:
            m=self.models[pc]; rsp=self.reg_read('rsp')
            if not self.permitted(rsp,8):
                self.unknown('model_return_stack_outside_snapshot','memory'); return
            returned=int.from_bytes(self.mem_read(rsp,8),'little')
            if not self.valid_pc(returned):
                self.unknown('model_return_to_uncovered_external_call','external_call'); return
            if 'write_region' in m:
                r=self.regions[m['write_region']]
                self.mem_write(r['address']+m['write_offset'],bytes.fromhex(m['data_hex']))
            self.reg_write('rax',m['return_value']); self.reg_write('rsp',rsp+8); self.reg_write('rip',returned)
            self.result['model_events'].append({k:m[k] for k in ('name','kind','address')})
            self.resume=True; self.stop(); return
        # Prefixes may precede x86 syscall/sysenter/software-interrupt opcodes.
        code=self.raw[pc-self.p['load_address']:pc-self.p['load_address']+15]
        while code and (code[0] in (0xf0,0xf2,0xf3,0x2e,0x36,0x3e,0x26,0x64,0x65,0x66,0x67) or 0x40<=code[0]<=0x4f):
            code=code[1:]
        if code.startswith((b'\x0f\x05',b'\x0f\x34',b'\xcd',b'\xcc',b'\xce')):
            self.unknown('unmodeled_syscall_or_interrupt','external_call')

    def finish(self):
        self.result['registers_after']={r:self.reg_read(r) for r in _REGS}
        for row,r in zip(self.result['regions'],self.p['regions']):
            row['final_hex']=bytes(self.mem_read(r['address'],len(r['initial_hex'])//2)).hex()
        if hasattr(self,'collect_taint'):
            self.result['taint']=self.collect_taint()
        if not self.halted:
            pc=self.reg_read('rip')
            if pc not in {self.p['stop_address'],self.code_end}:
                self.unknown('engine_stopped_before_registered_return')
        return self.result


def version(module,distribution):
    try: return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return str(getattr(module,'__version__','unknown'))


def check_version(s,actual):
    if actual!=s.p['expected_version']:
        raise ImportError('engine_version_mismatch:'+actual[:100])


def unicorn_run(s):
    import unicorn as u
    from unicorn import x86_const
    check_version(s,version(u,'unicorn'))
    cpu=u.Uc(u.UC_ARCH_X86,u.UC_MODE_64)
    registers={r:getattr(x86_const,'UC_X86_REG_'+('EFLAGS' if r=='rflags' else r.upper())) for r in _REGS}
    s.reg_read=lambda r:cpu.reg_read(registers[r])
    s.reg_write=lambda r,v:cpu.reg_write(registers[r],v)
    s.mem_read=cpu.mem_read; s.mem_write=cpu.mem_write; s.stop=cpu.emu_stop
    cpu.mem_map(s.p['load_address'],(len(s.raw)+4095)//4096*4096,u.UC_PROT_READ|u.UC_PROT_EXEC)
    cpu.mem_write(s.p['load_address'],s.raw)
    for page in {m['address']//4096*4096 for m in s.p['models']}:
        cpu.mem_map(page,4096,u.UC_PROT_READ|u.UC_PROT_EXEC)
    for m in s.p['models']: cpu.mem_write(m['address'],b'\xc3')
    for r in s.p['regions']:
        cpu.mem_map(r['address'],4096,u.UC_PROT_READ|(u.UC_PROT_WRITE if r['writable'] else 0))
        cpu.mem_write(r['address'],bytes.fromhex(r['initial_hex']))
    for r,v in initial_registers(s.p).items(): s.reg_write(r,v)
    s.verify_initial()
    cpu.hook_add(u.UC_HOOK_CODE,lambda cpu,pc,size,data:s.tick(pc,size))
    cpu.hook_add(u.UC_HOOK_MEM_READ|u.UC_HOOK_MEM_WRITE,lambda cpu,access,address,size,value,data:s.access(address,size,access==u.UC_MEM_WRITE))
    cpu.hook_add(u.UC_HOOK_MEM_INVALID,lambda cpu,access,address,size,value,data:(s.unknown('unmapped_or_protected_memory','memory'),False)[1])
    while not s.halted:
        cpu.emu_start(s.reg_read('rip'),s.p['stop_address'],timeout=s.p['timeout_seconds']*1000000,count=s.p['max_steps']-s.result['steps']+1)
        if not s.resume: break
    return s.finish()


def qiling_run(s):
    import qiling
    import unicorn as u
    from qiling import Qiling
    from qiling.const import QL_ARCH, QL_OS, QL_VERBOSE
    check_version(s,version(qiling,'qiling'))
    ql=Qiling(code=s.raw,rootfs=str(Path.cwd()),archtype=QL_ARCH.X8664,ostype=QL_OS.LINUX,verbose=QL_VERBOSE.OFF)
    s.reg_read=lambda r:ql.arch.regs.read('eflags' if r=='rflags' else r)
    s.reg_write=lambda r,v:ql.arch.regs.write('eflags' if r=='rflags' else r,v)
    s.mem_read=ql.mem.read; s.mem_write=ql.mem.write; s.stop=ql.uc.emu_stop
    size=(len(s.raw)+4095)//4096*4096
    if not ql.mem.is_mapped(s.p['load_address'],size):
        ql.mem.map(s.p['load_address'],size,perms=7)
    ql.mem.write(s.p['load_address'],s.raw); ql.mem.protect(s.p['load_address'],size,5)
    for page in {m['address']//4096*4096 for m in s.p['models']}:
        if ql.mem.is_mapped(page,4096): raise RuntimeError('model_mapping_collision')
        ql.mem.map(page,4096,perms=5)
    for m in s.p['models']: ql.mem.write(m['address'],b'\xc3')
    for r in s.p['regions']:
        if ql.mem.is_mapped(r['address'],4096):
            raise RuntimeError('qiling_default_memory_overlaps_snapshot')
        ql.mem.map(r['address'],4096,perms=3); ql.mem.write(r['address'],bytes.fromhex(r['initial_hex']))
        ql.mem.protect(r['address'],4096,3 if r['writable'] else 1)
    for r,v in initial_registers(s.p).items(): s.reg_write(r,v)
    s.verify_initial()
    ql.hook_code(lambda ql,pc,size:s.tick(pc,size))
    ql.hook_mem_read(lambda ql,access,address,size,value:s.access(address,size))
    ql.hook_mem_write(lambda ql,access,address,size,value:s.access(address,size,True))
    while not s.halted:
        # Qiling 1.4 shellcode OS.run ignores run(begin=...) and restores its
        # loader entry. The public concrete emu_start API preserves our snapshot.
        ql.emu_start(s.reg_read('rip'),s.p['stop_address'],s.p['timeout_seconds']*1000000,s.p['max_steps']-s.result['steps']+1)
        if not s.resume: break
    return s.finish()


def triton_run(s):
    import triton
    from triton import TritonContext, ARCH, Instruction, MemoryAccess
    # The unrelated GPU package named triton intentionally fails this API check.
    check_version(s,version(triton,'triton-library'))
    ctx=TritonContext(ARCH.X86_64)
    registers={r:getattr(ctx.registers,'eflags' if r=='rflags' else r) for r in _REGS}
    s.reg_read=lambda r:ctx.getConcreteRegisterValue(registers[r])
    s.reg_write=lambda r,v:ctx.setConcreteRegisterValue(registers[r],v)
    s.mem_read=ctx.getConcreteMemoryAreaValue; s.mem_write=ctx.setConcreteMemoryAreaValue; s.stop=lambda:None
    ctx.setConcreteMemoryAreaValue(s.p['load_address'],s.raw)
    for r in s.p['regions']: s.mem_write(r['address'],bytes.fromhex(r['initial_hex']))
    for r,v in initial_registers(s.p).items(): s.reg_write(r,v)
    s.verify_initial()
    if 'taint_inputs' in s.p:
        regions={r['id']:r for r in s.p['regions']}
        for source in s.p['taint_inputs']:
            if 'register' in source:
                if not ctx.taintRegister(registers[source['register']]):
                    raise RuntimeError('taint_register_initialization_failed')
            else:
                address=regions[source['region']]['address']+source['offset']
                for offset in range(source['size']):
                    if not ctx.taintMemory(MemoryAccess(address+offset,1)):
                        raise RuntimeError('taint_memory_initialization_failed')
        def collect_taint():
            output=taint_base(s.p); output['initial_sources_applied']=True; budget=128
            output['registers']={r:bool(ctx.isRegisterTainted(registers[r])) for r in _REGS}
            for result,region in zip(output['regions'],s.p['regions']):
                start=None
                for offset in range(result['byte_length']+1):
                    marked=offset<result['byte_length'] and ctx.isMemoryTainted(MemoryAccess(region['address']+offset,1))
                    if marked:
                        result['tainted_byte_count']+=1
                        if start is None: start=offset
                    elif start is not None:
                        if budget:
                            result['tainted_ranges'].append({'offset':start,'size':offset-start}); budget-=1
                        else: result['ranges_omitted']+=1
                        start=None
            return output
        s.collect_taint=collect_taint
    while not s.halted:
        pc=s.reg_read('rip'); s.tick(pc)
        if s.halted or s.resume: continue
        opcode=s.raw[pc-s.p['load_address']:pc-s.p['load_address']+16]
        inst=Instruction(pc,opcode)
        exception=ctx.processing(inst)
        if int(exception)!=0:
            s.unknown('unsupported_or_invalid_instruction'); break
        for method,write in ((inst.getLoadAccess,False),(inst.getStoreAccess,True)):
            accesses=method()
            for memory,node in accesses.items() if isinstance(accesses,dict) else accesses:
                s.access(memory.getAddress(),memory.getSize(),write)
    return s.finish()


def native_guard(s,pc,instruction_size):
    """Fail-closed PREINST guard for a deliberately finite scalar x86 subset.

    QBDI's memory log describes the last instruction. It cannot prevent writes.
    This decoder therefore accepts only reviewed integer encodings, computes all
    explicit/implicit memory operands before execution, and rejects everything
    else. Unicorn/Qiling/Triton do not execute target instructions on the CPU.
    """
    code=s.raw[pc-s.p['load_address']:pc-s.p['load_address']+15]; pos=0; rex=0
    regnames=('rax','rcx','rdx','rbx','rsp','rbp','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15')
    accesses=[]; branch=None; stack_changes=[]
    def take(size,signed=False):
        nonlocal pos
        if pos+size>len(code): raise ValueError('truncated')
        value=int.from_bytes(code[pos:pos+size],'little',signed=signed); pos+=size; return value
    def reg(index): return s.reg_read(regnames[index])
    def target(value):
        if not s.valid_pc(value & (2**64-1)): raise ValueError('uncovered_external_branch')
    def stackread(address):
        if not s.permitted(address,8): raise ValueError('stack_read_outside_snapshot')
        return int.from_bytes(s.mem_read(address,8),'little')
    def modrm():
        value=take(1); mod=value>>6; group=(value>>3)&7; rm=value&7
        if mod==3: return group,None,rm+(8 if rex&1 else 0)
        displacement=0; base=0; rip=False
        if rm==4:
            sib=take(1); scale=1<<(sib>>6); index=(sib>>3)&7; baseid=sib&7
            if index!=4 or rex&2: base+=reg(index+(8 if rex&2 else 0))*scale
            if baseid==5 and mod==0: displacement=take(4,True)
            else: base+=reg(baseid+(8 if rex&1 else 0))
        elif rm==5 and mod==0:
            rip=True; displacement=take(4,True)
        else: base=reg(rm+(8 if rex&1 else 0))
        if mod==1: displacement+=take(1,True)
        elif mod==2: displacement+=take(4,True)
        return group,(base+displacement,rip),None
    def access(memory,size,write):
        if memory is not None: accesses.append((memory,size,write))
    try:
        if code and 0x40<=code[0]<=0x4f: rex=take(1)
        op=take(1); width=8 if rex&8 else 4
        if op==0x90: pass
        elif 0xb8<=op<=0xbf:
            if op-0xb8+(8 if rex&1 else 0)==4: raise ValueError('unreviewed_rsp_write')
            take(width)
        elif 0x50<=op<=0x57 or op in {0x68,0x6a}:
            if op==0x68: take(4)
            elif op==0x6a: take(1)
            accesses.append(((s.reg_read('rsp')-8,False),8,True))
            stack_changes.append(s.reg_read('rsp')-8)
        elif 0x58<=op<=0x5f:
            if op-0x58+(8 if rex&1 else 0)==4: raise ValueError('unreviewed_rsp_write')
            accesses.append(((s.reg_read('rsp'),False),8,False))
            stack_changes.append(s.reg_read('rsp')+8)
        elif op==0xc3:
            target(stackread(s.reg_read('rsp')))
            stack_changes.append(s.reg_read('rsp')+8)
        elif op==0xc9:
            accesses.append(((s.reg_read('rbp'),False),8,False))
            stack_changes.append(s.reg_read('rbp')+8)
        elif op in {0xe8,0xe9,0xeb}:
            displacement=take(1 if op==0xeb else 4,True); branch=pc+pos+displacement
            if op==0xe8:
                accesses.append(((s.reg_read('rsp')-8,False),8,True)); stack_changes.append(s.reg_read('rsp')-8)
        elif 0x70<=op<=0x7f:
            displacement=take(1,True); branch=pc+pos+displacement
        elif op==0x0f:
            second=take(1)
            if not 0x80<=second<=0x8f: raise ValueError('unsupported_opcode')
            displacement=take(4,True); branch=pc+pos+displacement
        elif op in {0x89,0x8b,0x8d,0x01,0x03,0x09,0x0b,0x11,0x13,0x19,0x1b,0x21,0x23,0x29,0x2b,0x31,0x33,0x39,0x3b,0x85,0x81,0x83,0xc7,0xff,0xf7,0xc1,0xd1,0xd3}:
            group,memory,register_index=modrm()
            if op==0x8d:
                if memory is None: raise ValueError('invalid_lea')
                if group+(8 if rex&4 else 0)==4: raise ValueError('unreviewed_rsp_write')
            elif op==0xff:
                if group not in {2,4}: raise ValueError('unsupported_ff_group')
                access(memory,8,False)
                # Resolve after complete instruction length for RIP-relative EAs.
                if memory is None: target(reg(register_index))
                else:
                    address=(memory[0]+(pc+pos if memory[1] else 0)) & (2**64-1)
                    target(stackread(address))
                if group==2:
                    accesses.append(((s.reg_read('rsp')-8,False),8,True)); stack_changes.append(s.reg_read('rsp')-8)
            else:
                write=op in {0x89,0x01,0x09,0x11,0x19,0x21,0x29,0x31,0xc7,0xf7,0xc1,0xd1,0xd3}
                if op in {0x81,0x83}: take(1 if op==0x83 else 4); write=group!=7
                elif op==0xc7:
                    if group: raise ValueError('unsupported_c7_group')
                    take(4)
                elif op==0xf7 and group not in {2,3}: raise ValueError('unsupported_f7_group')
                elif op in {0xc1,0xd1,0xd3}:
                    if group not in {4,5,7}: raise ValueError('unsupported_shift_group')
                    if op==0xc1: take(1)
                if write and memory is None and register_index==4: raise ValueError('unreviewed_rsp_write')
                if op in {0x8b,0x03,0x0b,0x13,0x1b,0x23,0x2b,0x33} and group+(8 if rex&4 else 0)==4:
                    raise ValueError('unreviewed_rsp_write')
                access(memory,width,write)
                # RMW operations also read, but write permission implies read.
        else: raise ValueError('unsupported_opcode')
        if pos!=instruction_size: raise ValueError('unsupported_instruction_encoding')
        if branch is not None: target(branch)
        for memory,size,write in accesses:
            address=(memory[0]+(pc+pos if memory[1] else 0)) & (2**64-1)
            if not s.permitted(address,size,write): raise ValueError('memory_outside_registered_snapshot')
        for rsp in [s.reg_read('rsp'),*stack_changes]:
            if not any(r['writable'] and r['address']+256<=rsp<=r['address']+len(r['initial_hex'])//2-256 for r in s.p['regions']):
                raise ValueError('native_stack_margin_outside_snapshot')
        return True
    except (ValueError,IndexError):
        s.unknown('native_instruction_or_effect_outside_reviewed_subset','pre_execution_guard')
        return False


def qbdi_run(s):
    import pyqbdi as q
    check_version(s,version(q,'PyQBDI'))
    libc=ctypes.CDLL(None,use_errno=True)
    libc.mmap.argtypes=(ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_long)
    libc.mmap.restype=ctypes.c_void_p
    libc.munmap.argtypes=(ctypes.c_void_p,ctypes.c_size_t)
    mappings=[]
    def mapped(address,size,data,perms):
        length=(size+4095)//4096*4096
        observed=libc.mmap(address,length,3,0x100022,-1,0) # PRIVATE|ANONYMOUS|FIXED_NOREPLACE
        if observed!=address: raise RuntimeError('native_snapshot_address_unavailable')
        mappings.append((address,length)); ctypes.memmove(address,data,len(data))
        if libc.mprotect(ctypes.c_void_p(address),length,perms)!=0: raise RuntimeError('native_protection_failed')
    try:
        mapped(s.p['load_address'],len(s.raw),s.raw,5)
        for page in {m['address']//4096*4096 for m in s.p['models']}:
            data=bytearray(4096)
            for m in s.p['models']:
                if m['address']//4096*4096==page: data[m['address']-page]=0xc3
            mapped(page,4096,bytes(data),5)
        for r in s.p['regions']: mapped(r['address'],4096,bytes.fromhex(r['initial_hex']),3 if r['writable'] else 1)
        vm=q.VM(); gpr=vm.getGPRState()
        names={r:'eflags' if r=='rflags' else r for r in _REGS}
        s.reg_read=lambda r:int(getattr(vm.getGPRState(),names[r]))
        def reg_write(r,v):
            state=vm.getGPRState(); setattr(state,names[r],v); vm.setGPRState(state)
        s.reg_write=reg_write
        s.mem_read=lambda a,n:ctypes.string_at(a,n)
        s.mem_write=lambda a,b:ctypes.memmove(a,b,len(b))
        s.stop=lambda:None
        for r,v in initial_registers(s.p).items(): setattr(gpr,names[r],v)
        vm.setGPRState(gpr)
        s.verify_initial()
        # All application PCs must pass our callback, including external calls.
        vm.addInstrumentedRange(1,0x7fffffffffff)
        vm.recordMemoryAccess(q.MEMORY_READ_WRITE)
        def before(vm,gpr,fpr,data):
            s.tick(int(gpr.rip))
            if s.halted: return q.STOP
            if s.resume: return q.BREAK_TO_VM
            analysis=vm.getInstAnalysis(q.ANALYSIS_INSTRUCTION)
            if not native_guard(s,int(gpr.rip),int(analysis.instSize)): return q.STOP
            return q.CONTINUE
        def after(vm,gpr,fpr,data):
            for access in vm.getInstMemoryAccess():
                s.access(int(access.accessAddress),int(access.size),bool(access.type & q.MEMORY_WRITE))
            return q.STOP if s.halted else q.CONTINUE
        vm.addCodeCB(q.PREINST,before,None); vm.addCodeCB(q.POSTINST,after,None)
        vm.run(s.p['entry'],s.p['stop_address'])
        return s.finish()
    finally:
        for address,length in mappings: libc.munmap(address,length)


def main():
    if len(sys.argv)==3 and sys.argv[1]=='--inspect':
        import importlib
        names={'unicorn':('unicorn','unicorn','Uc'),'qiling':('qiling','qiling','Qiling'),'triton':('triton','triton-library','TritonContext'),'qbdi':('pyqbdi','PyQBDI','VM')}
        if sys.argv[2] not in names: return 2
        module,distribution,api=names[sys.argv[2]]
        try:
            imported=importlib.import_module(module)
            if not hasattr(imported,api): raise ImportError('required_official_API_missing')
            answer={'available':True,'version':version(imported,distribution)}
        except ImportError as error:
            answer={'available':False,'reason':'dependency_or_API_unavailable:'+str(error)[:160]}
        sys.stdout.buffer.write(_json(answer)+b'\n'); return 0
    if len(sys.argv)!=2: return 2
    p=json.loads(bounded_file(Path(sys.argv[1]),131072)); nonce=p.pop('nonce')
    validate_profile(p); p['nonce']=nonce
    raw=bounded_file(p['binary'],16384,p['binary_sha256']); s=Snapshot(p,raw)
    try:
        implementation={'unicorn':unicorn_run,'qiling':qiling_run,'triton':triton_run,'qbdi':qbdi_run}[p['engine']]
        result=implementation(s)
    except (ImportError,ModuleNotFoundError,AttributeError) as error:
        if s.result['steps']: raise
        result=result_base(p,nonce)
        reason='dependency_or_API_unavailable:'+str(error)[:160]
        result.update(status='unavailable',reason=reason,unknown=[{'kind':'dependency','detail':reason}])
    except Exception as error:
        if not s.result['steps']:
            result=result_base(p,nonce)
            reason='engine_initialization_unavailable:'+type(error).__name__+':'+str(error)[:100]
            result.update(status='unavailable',reason=reason,unknown=[{'kind':'initialization','detail':reason}])
        else:
            s.unknown('engine_exception:'+type(error).__name__)
            result=s.finish()
    encoded=_json(result)
    if len(encoded)>p['max_output_bytes']: return 3
    sys.stdout.buffer.write(encoded+b'\n')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
