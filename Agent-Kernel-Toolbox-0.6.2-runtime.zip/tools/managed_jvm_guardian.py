#!/usr/bin/env python3
"""Supervise a fixed JDI controller when its runtime host disappears.

The host passes its already-open pidfd and a write-only readiness pipe. This
avoids guessing the host from getppid() after a launch/death race. Standard
input/output are a bounded byte-transparent protocol; readiness is just the
controller PID followed by LF on the separate ready fd.
"""
from __future__ import annotations

import argparse
from collections import deque
import ctypes
import os
from pathlib import Path
import re
import select
import selectors
import signal
import stat
import subprocess
import sys
import time

MAX_BUFFER = 128 * 1024
MAX_INPUT_LINE = 1024
MAX_OUTPUT_LINE = 32768


class GuardianError(RuntimeError):
    pass


def _subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    libc.prctl.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong,
                          ctypes.c_ulong, ctypes.c_ulong]
    libc.prctl.restype = ctypes.c_int
    if libc.prctl(36, 1, 0, 0, 0):  # PR_SET_CHILD_SUBREAPER, this helper only.
        raise GuardianError('managed_guardian_subreaper_unavailable')


def _own_children():
    try:
        data = Path(f'/proc/self/task/{os.getpid()}/children').read_bytes()
        if len(data) > 16384:
            raise GuardianError('managed_guardian_child_limit')
        return [int(item) for item in data.split()]
    except FileNotFoundError:
        # Some managed kernels omit task/<tid>/children. Absence is not proof
        # that there are no adopted targets; use bounded parent-ID discovery.
        result, scanned = [], 0
        with os.scandir('/proc') as entries:
            for entry in entries:
                if not entry.name.isdecimal():
                    continue
                scanned += 1
                if scanned > 16384:
                    raise GuardianError('managed_guardian_process_scan_limit')
                try:
                    status = (Path('/proc')/entry.name/'status').read_text()
                except (FileNotFoundError, ProcessLookupError, PermissionError):
                    continue
                if re.search(r'^PPid:\s+'+str(os.getpid())+r'\s*$', status, re.M):
                    result.append(int(entry.name))
        return result


def _kill_child(pid):
    descriptor = None
    try:
        descriptor = os.pidfd_open(pid)
        status = Path(f'/proc/{pid}/status').read_text()
        if re.search(r'^PPid:\s+'+str(os.getpid())+r'\s*$', status, re.M):
            signal.pidfd_send_signal(descriptor, signal.SIGKILL)
    except (ProcessLookupError, FileNotFoundError):
        pass
    finally:
        if descriptor is not None:
            os.close(descriptor)


def cleanup(child, timeout=2):
    """Kill our controller group and reap only children adopted by this helper."""
    if child is not None and child.poll() is None:
        # The unreaped direct child pins this PID against unrelated group reuse.
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=.1)
        except subprocess.TimeoutExpired:
            pass
    deadline = time.monotonic()+timeout
    while True:
        for pid in _own_children():
            _kill_child(pid)
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if not pid:
                break
            if child is not None and pid == child.pid:
                child.returncode = os.waitstatus_to_exitcode(status)
        if not _own_children() and (child is None or child.poll() is not None):
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(.01)


def _validate(host_fd, ready_fd, command, cleanup_fd=None):
    if host_fd < 3 or ready_fd < 3 or host_fd == ready_fd:
        raise GuardianError('managed_guardian_invalid_fds')
    if not stat.S_ISFIFO(os.fstat(ready_fd).st_mode):
        raise GuardianError('managed_guardian_ready_pipe_required')
    if cleanup_fd is not None and (cleanup_fd<3 or cleanup_fd in (host_fd,ready_fd)
            or not stat.S_ISFIFO(os.fstat(cleanup_fd).st_mode)):
        raise GuardianError('managed_guardian_cleanup_pipe_required')
    info = Path(f'/proc/self/fdinfo/{host_fd}').read_text()
    if re.search(r'^Pid:\s+-?[0-9]+\s*$', info, re.M) is None:
        raise GuardianError('managed_guardian_host_pidfd_required')
    if (not 1 <= len(command) <= 64 or not command[0] or not Path(command[0]).is_absolute()
            or any('\0' in value or len(value) > 4096 for value in command)):
        raise GuardianError('managed_guardian_invalid_command')


def _receipt(descriptor, frame):
    if descriptor is None:return True
    try:return os.write(descriptor,frame)==len(frame)
    except OSError:return False


def run(host_fd, ready_fd, command, *, startup_ms=15000, command_ms=6000, cleanup_fd=None):
    _validate(host_fd, ready_fd, command, cleanup_fd)
    if select.select([host_fd], [], [], 0)[0]:
        os.close(ready_fd)
        return 4
    _subreaper()
    selector, child, controller_fd = selectors.DefaultSelector(), None, None
    stopping, result, failure = False, 0, None
    def stop(_signum, _frame):
        nonlocal stopping
        stopping = True
    for name in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(name, stop)
    signal.signal(signal.SIGPIPE, signal.SIG_IGN)
    try:
        # Optional private ownership protocol. A is emitted only after the
        # subreaper and stop handlers exist, strictly before any target spawn.
        if not _receipt(cleanup_fd,b'MP1 ARMED\n'):
            raise GuardianError('managed_guardian_cleanup_channel_failed')
        if stopping:return 0
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 close_fds=True, start_new_session=True, bufsize=0)
        controller_fd = os.pidfd_open(child.pid)
        os.write(ready_fd, (str(child.pid)+'\n').encode('ascii'))
        os.close(ready_fd)
        ready_fd = None
        for descriptor in (0, 1, child.stdin.fileno(), child.stdout.fileno()):
            os.set_blocking(descriptor, False)
        selector.register(host_fd, selectors.EVENT_READ, 'host_death')
        selector.register(controller_fd, selectors.EVENT_READ, 'controller_death')
        selector.register(0, selectors.EVENT_READ, 'host_input')
        selector.register(child.stdout, selectors.EVENT_READ, 'controller_output')
        input_queue, output_queue = bytearray(), bytearray()
        pending = deque([time.monotonic()+startup_ms/1000])
        input_length, output_length = 0, 0
        controller_dead, output_eof, drain_deadline = False, False, None

        def writing(descriptor, enabled, label):
            try:
                selector.get_key(descriptor)
                registered = True
            except KeyError:
                registered = False
            if enabled and not registered:
                selector.register(descriptor, selectors.EVENT_WRITE, label)
            elif not enabled and registered:
                selector.unregister(descriptor)

        def frame_lengths(data, length, maximum, *, requests):
            for part in data.splitlines(keepends=True):
                length += len(part)
                if length > maximum:
                    raise GuardianError('managed_guardian_frame_budget')
                if part.endswith(b'\n'):
                    length = 0
                    if requests:
                        if len(pending) >= 64:
                            raise GuardianError('managed_guardian_pending_budget')
                        pending.append(time.monotonic()+command_ms/1000)
                    elif pending:
                        pending.popleft()
            return length

        while not stopping:
            now = time.monotonic()
            if not controller_dead and pending and now >= min(pending):
                raise GuardianError('managed_guardian_response_timeout')
            if controller_dead and (output_eof and not output_queue or now >= drain_deadline):
                result = child.returncode or 0
                break
            writing(child.stdin, bool(input_queue) and not controller_dead, 'controller_input')
            writing(1, bool(output_queue), 'host_output')
            for key, _events in selector.select(.05):
                label = key.data
                if label == 'host_death':
                    stopping = True
                    break
                if label == 'controller_death':
                    selector.unregister(controller_fd)
                    controller_dead = True
                    drain_deadline = time.monotonic()+.5
                    # Keep buffered stdout available while removing any escaped
                    # adopted target that could otherwise hold a pipe open.
                    if not cleanup(child):
                        raise GuardianError('managed_guardian_cleanup_unresolved')
                elif label == 'host_input':
                    data = os.read(0, 8192)
                    if not data:
                        stopping = True
                        break
                    if controller_dead:
                        continue
                    input_length = frame_lengths(data, input_length, MAX_INPUT_LINE, requests=True)
                    input_queue.extend(data)
                    if len(input_queue) > MAX_BUFFER:
                        raise GuardianError('managed_guardian_input_budget')
                elif label == 'controller_output':
                    data = os.read(child.stdout.fileno(), 8192)
                    if not data:
                        output_eof = True
                        selector.unregister(child.stdout)
                        continue
                    output_length = frame_lengths(data, output_length, MAX_OUTPUT_LINE, requests=False)
                    output_queue.extend(data)
                    if len(output_queue) > MAX_BUFFER:
                        raise GuardianError('managed_guardian_output_budget')
                elif label == 'controller_input':
                    del input_queue[:os.write(child.stdin.fileno(), input_queue)]
                elif label == 'host_output':
                    del output_queue[:os.write(1, output_queue)]
        return result
    except (GuardianError, OSError) as error:
        failure = str(error) if isinstance(error, GuardianError) else 'managed_guardian_transport_failed'
        return 124 if failure == 'managed_guardian_response_timeout' else 70
    finally:
        cleaned = cleanup(child)
        if not cleaned:
            failure = 'managed_guardian_cleanup_unresolved'
        else:
            # Root-process exit is insufficient: C certifies cleanup() closed
            # and reaped every descendant owned by this subreaper.
            _receipt(cleanup_fd,b'MP1 COMPLETE\n')
        if failure:
            try:
                os.write(2, (failure+'\n').encode('ascii'))
            except OSError:
                pass
        for descriptor in (controller_fd, ready_fd, cleanup_fd):
            if descriptor is not None:
                os.close(descriptor)
        if child is not None:
            for stream in (child.stdin, child.stdout):
                stream.close()
        selector.close()
        if not cleaned:
            return 70


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host-pidfd', required=True, type=int)
    parser.add_argument('--ready-fd', required=True, type=int)
    parser.add_argument('--cleanup-fd', type=int)
    parser.add_argument('--startup-ms', type=int, default=15000)
    parser.add_argument('--command-ms', type=int, default=6000)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not 100 <= args.startup_ms <= 20000 or not 100 <= args.command_ms <= 10000:
        parser.error('managed_guardian_invalid_deadline')
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    try:
        return run(args.host_pidfd, args.ready_fd, command,
                   startup_ms=args.startup_ms, command_ms=args.command_ms,cleanup_fd=args.cleanup_fd)
    except (GuardianError, OSError):
        os.write(2, b'managed_guardian_start_failed\n')
        return 70


if __name__ == '__main__':
    raise SystemExit(main())
