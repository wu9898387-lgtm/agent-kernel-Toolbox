"""Fixed Frida worker plus independent, Linux subreaper ownership guardian."""
import ctypes
import array
import hashlib
import json
import os
from pathlib import Path
import resource
import select
import signal
import socket
import sys
import time


def output(fd, value):
    raw = json.dumps(value, separators=(',', ':'), ensure_ascii=True).encode() + b'\n'
    if len(raw) > 16384:
        raise RuntimeError('probe_record_budget')
    os.write(fd, raw)


def parent_guard(parent):
    if os.getppid() != parent:
        os._exit(125)
    if ctypes.CDLL(None).prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
        os._exit(125)


def owned_children():
    """Only this dedicated subreaper's kernel-reported direct children.

    Some kernels omit task/children (CONFIG_CHECKPOINT_RESTORE). PPid remains
    available; verify it again after opening a pidfd before granting a signal.
    """
    result=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        try:
            status=(path/'status').read_text()
            if int(status.split('PPid:')[1].split()[0])==os.getpid():result.append(int(path.name))
        except (OSError,IndexError,ValueError):pass
    return result


def worker(config, log_fd, register_fd, ack_fd, supervisor):
    parent_guard(supervisor)
    # Load Frida only after fork: its GLib threads must not be copied by fork.
    import frida
    target = None
    device = frida.get_local_device()
    session = script = None
    sequence, count, byte_count = 0, 0, 0
    dropped = 0
    done = False
    script_failed = False
    controls = 0

    def on_message(message, _data):
        nonlocal sequence, count, byte_count, dropped,done,script_failed,controls
        if message.get('type') == 'error':
            if not script_failed:
                output(log_fd, {'control': 'script_error', 'error': 'native_probe_script_failed',
                                'diagnostic':str(message.get('description',''))[:512]})
            script_failed=True;done=True
            return
        value = message.get('payload', {})
        if value.get('type') == 'events':
            for event in value['events']:
                if count >= config['max_events']:
                    dropped += 1
                    continue
                event.update(source='native_probe', session_id=config['session_id'])
                sequence += 1
                event['seq'] = sequence
                raw = json.dumps(event, separators=(',', ':'), ensure_ascii=True).encode() + b'\n'
                if len(raw) > 4096 or byte_count + len(raw) > config['max_bytes']:
                    dropped += 1
                    continue
                count += 1
                byte_count += len(raw)
                os.write(log_fd, raw)
        elif value.get('type') == 'coverage':
            if controls<256:
                output(log_fd, {'control': 'coverage', **value, 'collector_dropped': dropped,
                                'collector_bytes': byte_count, 'collector_events': count})
                controls+=1

    def detached(_reason, _crash=None):
        nonlocal done
        done = True
        output(log_fd,{'control':'detached','reason':str(_reason)[:64],
                       'crash':str(_crash)[:512] if _crash else None})

    executable_fd = os.open(config['executable'], os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        with os.fdopen(os.dup(executable_fd), 'rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        if digest != config['sha256']:
            raise RuntimeError('native_probe_binary_digest_changed')
        target = device.spawn(['/proc/' + str(os.getpid()) + '/fd/' + str(executable_fd), *config['argv']],
                              stdio='pipe', env={'PATH': '/usr/bin:/bin', 'LANG': 'C'})
        os.write(register_fd, (str(target) + '\n').encode())
        if os.read(ack_fd, 1) != b'R':
            raise RuntimeError('native_probe_guardian_unarmed')
        session = device.attach(target)
        session.on('detached', detached)
        config['worker_pid'] = os.getpid()
        source = Path(config['script']).read_text().replace('__CONFIG__', json.dumps(config, separators=(',', ':')))
        script = session.create_script(source)
        script.on('message', on_message)
        script.load()
        ready = script.exports_sync.ready()
        if ready['arch'] != 'x64':
            raise RuntimeError('native_probe_arch_unsupported')
        # Frida's attach first materializes its own agent binary. Set the log
        # ceiling after injection, and after target spawn so the application
        # does not inherit this collector-only file-size policy.
        ceiling=config['max_bytes']+262144
        soft,hard=resource.getrlimit(resource.RLIMIT_FSIZE)
        ceiling=min([ceiling]+[x for x in (soft,hard) if x!=resource.RLIM_INFINITY])
        resource.setrlimit(resource.RLIMIT_FSIZE,(ceiling,ceiling))
        output(log_fd, {'control': 'ready', 'target_pid': target, 'worker_pid': os.getpid(),
                        'guardian_pid': supervisor, 'arch': ready['arch'],'frida_version':frida.__version__,
                        'function_resolution':ready['function_resolution']})
        device.resume(target)
        while not done:
            time.sleep(.02)
        # Detached targets cannot service RPCs. In particular, do not wait on
        # an RPC response from a script whose process has already exited.
        output(log_fd, {'control': 'target_exit', 'target_pid': target})
    except BaseException as error:
        output(log_fd, {'control': 'error', 'error': 'native_probe_worker_failed',
                        'diagnostic':str(error)[:1024]})
    finally:
        if target is not None:
            try:
                device.kill(target)
            except Exception:
                pass
        if session is not None:
            try:
                session.detach()
            except Exception:
                pass
        os.close(executable_fd)


def guardian(config, host_fd, log_fd, control_fd):
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise RuntimeError('native_probe_subreaper_required')
    # The guardian's single stable main thread owns the worker. Parent-death
    # signalling never binds a target to an ephemeral host SDK thread.
    register_read, register_write = os.pipe()
    ack_read, ack_write = os.pipe()
    deadline = time.monotonic() + config['lifetime_ms'] / 1000
    supervisor=os.getpid()
    child = os.fork()
    if child == 0:
        os.close(register_read); os.close(ack_write); os.close(host_fd);os.close(control_fd)
        try:
            worker(config, log_fd, register_write, ack_read, supervisor)
        finally:
            os._exit(0)
    os.close(register_write); os.close(ack_read)
    child_fd = os.pidfd_open(child)
    target_fd, target_pid = None, None
    stop = False
    reason = 'target_exit'

    def stopping(_signal, _frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    try:
        for key, limit in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_CPU, 2),
                           (resource.RLIMIT_AS, 128 * 1024**2), (resource.RLIMIT_NOFILE, 64)):
            soft, hard = resource.getrlimit(key)
            wanted = min([limit] + [x for x in (soft, hard) if x != resource.RLIM_INFINITY])
            resource.setrlimit(key, (wanted, wanted))
        buffer = b''
        while True:
            left = deadline - time.monotonic()
            if stop or left <= 0:
                reason = 'operator_close' if stop else 'lifetime_budget'
                break
            ready = select.select([host_fd, child_fd, register_read], [], [], min(left, .05))[0]
            if host_fd in ready:
                reason = 'host_exit'; break
            if child_fd in ready:
                break
            if register_read in ready:
                part = os.read(register_read, 128)
                buffer += part
                if b'\n' in buffer:
                    target_pid = int(buffer.split(b'\n')[0])
                    target_fd = os.pidfd_open(target_pid)
                    # Numeric data comes only from our worker's private pipe.
                    # Confirm it is still that worker's direct child.
                    status = Path('/proc/' + str(target_pid) + '/status').read_text()
                    parent = int(status.split('PPid:')[1].split()[0])
                    if parent != child:
                        raise RuntimeError('native_probe_target_parent_changed')
                    channel=socket.socket(fileno=control_fd)
                    channel.sendmsg([b'T'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',[target_fd]))])
                    channel.detach()
                    os.write(ack_write, b'R')
                    os.close(register_read)
                    register_read = os.open('/dev/null', os.O_RDONLY)
                    # Do not select an EOF descriptor in the running loop.
                    os.close(register_read); register_read = os.dup(child_fd)
                elif not part:
                    break
    finally:
        for descriptor in (target_fd, child_fd):
            if descriptor is not None:
                try:
                    signal.pidfd_send_signal(descriptor, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        # Subreaping covers a worker crash in the spawn→registration gap.
        # Only this dedicated guardian's own kernel-reported children qualify.
        until = time.monotonic() + 2
        while time.monotonic() < until:
            try:
                while os.waitpid(-1, os.WNOHANG)[0]:
                    pass
            except ChildProcessError:
                break
            for value in owned_children():
                try:
                    descriptor = os.pidfd_open(value)
                    try:
                        status=Path('/proc/'+str(value)+'/status').read_text()
                        if int(status.split('PPid:')[1].split()[0])==os.getpid():
                            signal.pidfd_send_signal(descriptor, signal.SIGKILL)
                    finally:
                        os.close(descriptor)
                except (OSError,IndexError,ValueError):
                    pass
            time.sleep(.01)
        exited = target_fd is None or bool(select.select([target_fd], [], [], 0)[0])
        output(log_fd, {'control': 'closed', 'reason': reason, 'target_pid': target_pid,
                        'target_exit_confirmed': exited, 'guardian_pid': os.getpid()})
        for descriptor in (target_fd, child_fd, register_read, ack_write, host_fd,control_fd):
            if descriptor is not None:
                os.close(descriptor)


if __name__ == '__main__':
    settings = json.loads(Path(sys.argv[1]).read_bytes())
    try:
        guardian(settings, int(sys.argv[2]), int(sys.argv[3]),int(sys.argv[4]))
    except BaseException as error:
        output(int(sys.argv[3]),{'control':'guardian_error','error':type(error).__name__,
                                'diagnostic':str(error)[:512]})
        sys.exit(70)
