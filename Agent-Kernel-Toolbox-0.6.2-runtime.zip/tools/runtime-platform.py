#!/usr/bin/env python3
"""Plan or interpret pinned word IR offline; compile through the durable host."""
import argparse
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import sys

ROOT = Path(__file__).resolve().parents[1]
MODULES = ROOT / 'runtime-access.pyz'
sys.path.insert(0, str(MODULES if MODULES.is_file() else ROOT / 'src'))
from observation_extension.portable_build import PortableBuild, PortableBuildError, detect_host


def error_result(error, *, unknown=False):
    code = str(error)
    result = {'ok': False, 'error': code if re.fullmatch(r'[a-z][a-z0-9_]{1,100}', code)
              else 'build_cli_failed', 'effect_unknown': unknown}
    dispatched = getattr(error, 'effect_dispatched', None)
    if type(dispatched) is bool:
        result['effect_dispatched'] = dispatched
    return result


def read_build_config(path):
    flags = os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0) | getattr(os, 'O_BINARY', 0)
    with os.fdopen(os.open(path, flags), 'rb') as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise PortableBuildError('build_config_must_be_regular')
        raw = stream.read(65537)
    if len(raw) > 65536:
        raise PortableBuildError('build_config_budget')

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise PortableBuildError('build_duplicate_config_key')
            result[key] = value
        return result

    return json.loads(raw, object_pairs_hook=pairs)


def is_host_config(config):
    return type(config) is dict and 'schema_version' in config


def compile_profile(config, profile, request_id):
    # Import lazily: detection and planning remain usable without a POSIX host.
    from observation_extension.runtime_host import RuntimeHost
    host = RuntimeHost(config, bundle_root=ROOT)
    try:
        try:
            result = host.call('build.compile', {'profile': profile, 'request_id': request_id})
        except (OSError, ValueError, RuntimeError, sqlite3.Error) as error:
            # A journal/transport error after entering call cannot establish
            # whether compilation ran. Leave Pending/Unknown for reconciliation.
            result = error_result(error, unknown=True)
    finally:
        try:
            cleanup = host.close()
        except (OSError, ValueError, RuntimeError, sqlite3.Error) as error:
            cleanup = {'cleanup_errors': [error_result(error)['error']]}
    if cleanup['cleanup_errors']:
        result = {**result, **({'error': 'build_cli_cleanup_unresolved'} if result['ok'] else {}),
                  'ok': False, 'cleanup_errors': cleanup['cleanup_errors']}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('detect', 'inspect', 'plan', 'evaluate', 'compile'))
    parser.add_argument('--config', type=Path, help='Build-only or full runtime configuration')
    parser.add_argument('--state-directory', type=Path,
                        help='Required for build-only compilation; full runtime configs declare their state path')
    parser.add_argument('--profile')
    parser.add_argument('--request-id', help='Required for compile; never reuse a completed or uncertain request ID')
    parser.add_argument('--inputs', help='JSON unsigned-word array for evaluate; no native target is executed')
    args = parser.parse_args()
    if args.action == 'compile' and args.request_id is None:
        parser.error('compile requires --request-id; inspect the previous outcome before retrying')
    if args.action != 'compile' and args.request_id is not None:
        parser.error('--request-id is only valid for compile')
    if args.action == 'evaluate':
        if args.inputs is None or len(args.inputs) > 8192:
            parser.error('evaluate requires bounded --inputs JSON')
    elif args.inputs is not None:
        parser.error('--inputs is only valid for evaluate')
    try:
        if args.action == 'detect':
            if args.config or args.state_directory or args.profile:
                parser.error('detect accepts no configuration or profile')
            result = {'ok': True, 'data': detect_host()}
        else:
            if args.config is None:
                parser.error('inspect/plan/evaluate/compile require --config')
            if args.action in ('plan', 'evaluate', 'compile') and args.profile is None:
                parser.error('plan/evaluate/compile require --profile')
            state = args.state_directory.absolute() if args.state_directory is not None else None
            if args.action == 'compile':
                if os.name != 'posix':
                    raise PortableBuildError('build_cli_host_unavailable')
                from observation_extension.runtime_host import load_config
                config = load_config(args.config)
                if is_host_config(config):
                    configured_state = config.get('state_directory')
                    if state is not None and (type(configured_state) is not str or state != Path(configured_state)):
                        raise PortableBuildError('build_cli_state_directory_conflict')
                else:
                    if state is None:
                        parser.error('compile with a build-only config requires --state-directory')
                    config = {'schema_version': 1, 'state_directory': str(state),
                              'allowed_tools': ['build.compile'], 'portable_build': config}
                result = compile_profile(config, args.profile, args.request_id)
            else:
                config = read_build_config(args.config)
                if is_host_config(config):
                    if type(config['schema_version']) is not int or config['schema_version'] != 1:
                        raise PortableBuildError('build_invalid_config')
                    config = config.get('portable_build', {})
                service = PortableBuild(config, state or args.config.resolve().parent)
                try:
                    if args.action == 'inspect':
                        if args.profile: parser.error('inspect accepts no profile')
                        value = service.inspect()
                    elif args.action == 'evaluate':
                        value = service.evaluate(args.profile, json.loads(args.inputs))
                    else:
                        value = service.plan(args.profile)
                    result = {'ok': True, 'data': value}
                finally:
                    service.close()
        print(json.dumps(result, sort_keys=True, allow_nan=False))
        return 0 if result['ok'] and not result.get('effect_unknown') and not result.get('unknown_effect') else 2
    except (OSError, ValueError, RuntimeError, sqlite3.Error) as error:
        print(json.dumps(error_result(error), sort_keys=True))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
