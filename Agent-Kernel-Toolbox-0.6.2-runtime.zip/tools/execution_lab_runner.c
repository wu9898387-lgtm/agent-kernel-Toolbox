/* Fixed mapping runner for the bundled DynamoRIO client. Never run uninstrumented. */
#define _GNU_SOURCE
#include "execution_lab_native.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#ifndef __x86_64__
#error x86_64_snapshot_runner_required
#endif
uint64_t lab_entry_address;
static lab_request request;
extern void lab_enter(const uint64_t *registers) __attribute__((noreturn));
__asm__(
".text\n.global lab_enter\n.type lab_enter,@function\nlab_enter:\n"
"mov %rdi,%r15\npushq 136(%r15)\npopfq\nmov 56(%r15),%rsp\n"
"mov 0(%r15),%rax\nmov 8(%r15),%rbx\nmov 16(%r15),%rcx\nmov 24(%r15),%rdx\n"
"mov 32(%r15),%rsi\nmov 48(%r15),%rbp\nmov 64(%r15),%r8\nmov 72(%r15),%r9\n"
"mov 80(%r15),%r10\nmov 88(%r15),%r11\nmov 96(%r15),%r12\nmov 104(%r15),%r13\n"
"mov 112(%r15),%r14\nmov 40(%r15),%rdi\nmov 120(%r15),%r15\njmp *lab_entry_address(%rip)\n"
".size lab_enter,.-lab_enter\n");
static void map_bytes(uint64_t address,size_t size,const void *data,int perms) {
    size_t length=(size+4095)&~(size_t)4095;
    void *memory=mmap((void *)(uintptr_t)address,length,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE,-1,0);
    if (memory!=(void *)(uintptr_t)address) _exit(72);
    memcpy(memory,data,size);
    if (mprotect(memory,length,perms)) _exit(73);
}
int main(int argc,char **argv) {
    if (argc!=3||strcmp(argv[1],"--instrumented-snapshot-v1")) return 70;
    FILE *file=fopen(argv[2],"rb"); if (!file) return 71;
    unsigned char *data=malloc(LAB_MAX_REQUEST+1); if (!data) return 71;
    size_t size=fread(data,1,LAB_MAX_REQUEST+1,file); fclose(file);
    if (size>LAB_MAX_REQUEST||!lab_parse(data,size,&request)) return 71;
    free(data);
    map_bytes(request.load,request.size,request.code,PROT_READ|PROT_EXEC);
    for (uint32_t i=0;i<request.region_count;i++) {
        lab_region *r=&request.regions[i]; map_bytes(r->address,r->size,r->bytes,PROT_READ|(r->writable?PROT_WRITE:0));
    }
    uint64_t pages[33]; size_t count=0;
    for (uint32_t i=0;i<=request.model_count;i++) {
        uint64_t address=i<request.model_count?request.models[i].address:request.stop;
        uint64_t page=address&~UINT64_C(4095); int exists=0;
        if (page>=request.load&&page<request.load+((request.size+4095)&~UINT64_C(4095))) continue;
        for (size_t j=0;j<count;j++) if (pages[j]==page) exists=1;
        if (exists) continue;
        for (uint32_t j=0;j<request.region_count;j++) if (request.regions[j].address==page) return 74;
        unsigned char bytes[4096]={0};
        for (uint32_t j=0;j<request.model_count;j++) if ((request.models[j].address&~UINT64_C(4095))==page) bytes[request.models[j].address-page]=0xc3;
        map_bytes(page,4096,bytes,PROT_READ|PROT_EXEC); pages[count++]=page;
    }
    if (!lab_permitted(&request,request.regs[7]-8,16,1)) return 74;
    lab_entry_address=request.entry; lab_enter(request.regs);
}
