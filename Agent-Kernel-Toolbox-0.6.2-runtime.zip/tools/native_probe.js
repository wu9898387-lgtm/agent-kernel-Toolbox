'use strict';
const config = __CONFIG__;
const main = Process.mainModule;
// Follow application control flow across library calls without translating
// allocator/Frida internals; allocator semantics come from the fixed hooks.
for (const module of Process.enumerateModules()) {
  if (!module.base.equals(main.base)) Stalker.exclude({base:module.base,size:module.size});
}
let sequence = 0, recorded = 0, bytes = 0, dropped = 0, instructions = 0;
let callbackMs = 0, stopped = false, pending = [], reason = null;
const active = new Map();
const hooks=[];
let symbols=null;
const functionResolution=[];
function resolveFunction(name,size){
  let address=main.findExportByName(name),source='export';
  if(address===null){
    if(symbols===null)symbols=main.enumerateSymbols();
    const candidates=symbols.filter(symbol=>symbol.type==='function'&&symbol.name===name);
    if(candidates.length!==1)throw new Error('function_symbol_missing_or_ambiguous');
    address=candidates[0].address;source='unique_function_symbol';
  }
  const mapping=Process.findRangeByAddress(address),end=address.add(size);
  if(address.compare(main.base)<0||end.compare(main.base.add(main.size))>0||mapping===null||
      !mapping.protection.includes('x')||end.compare(mapping.base.add(mapping.size))>0)
    throw new Error('function_range_outside_executable_image');
  functionResolution.push({name,source,address:address.toString(),size});
  return address;
}
const ranges = Object.keys(config.functions).map(name => {
  const start = resolveFunction(name,config.functions[name]);
  return {name, start, end:start.add(config.functions[name])};
});
function inside(pc) { return ranges.some(r => pc.compare(r.start)>=0 && pc.compare(r.end)<0); }
function application(pc) { return pc.compare(main.base)>=0 && pc.compare(main.base.add(main.size))<0; }
function flush() { if (pending.length) { send({type:'events',events:pending}); pending=[]; } }
function emit(value) {
  value.tid = value.tid || Process.getCurrentThreadId();
  value.seq = ++sequence;
  const length = JSON.stringify(value).length + 1;
  if (stopped) { dropped++; return; }
  if (recorded >= config.max_events || bytes+length > config.max_bytes) {
    dropped++;
    stop('event_or_byte_budget');
    return;
  }
  recorded++; bytes+=length; pending.push(value);
  // All producers, including hooks outside selected instruction ranges, share
  // the same stop condition. Publish stopped before report/drain can re-enter.
  if (recorded >= config.max_events || bytes >= config.max_bytes) {
    stop('event_or_byte_budget');
    return;
  }
  if (pending.length>=32) flush();
}
function stop(why) {
  if (stopped) return;
  reason=why; stopped=true;
  for (const tid of active.keys()) Stalker.unfollow(tid);
  for(const hook of hooks)hook.detach();
  Stalker.flush(); flush();report();
}
function report() {
  if(!stopped&&callbackMs*1000+nativeCallbackUs()>=config.max_callback_us)stop('callback_wall_budget');
  drainAllocations(); flush();
  send({type:'coverage',instructions,recorded,dropped,bytes,callback_ms:callbackMs,
        callback_clock_resolution_ms:1,native_callback_us:nativeCallbackUs(),
        callback_budget_scope:'instruction_JS_wall_plus_native_selected_callbacks',
        stopped,stop_reason:reason,
        instruction_phase:'before',hardware_retired:false,values_read:false,native_allocator_dropped:allocatorLoss(),
        entry_interceptor_relocated_prologue_gap:true,selected_ranges_only:true,
        environment_wrappers:config.environment_functions,direct_syscalls_observed:false,
        global_hardware_order_proven:false});
}
function word(value) {
  const text = uint64(value.toString()).toString();
  const number = Number(text);
  return Number.isSafeInteger(number) ? number : text;
}
function register(context, name, next) {
  if (name === undefined || name === null || name === 'invalid') return ptr(0);
  if (name === 'rip') return next;
  if (/^(r(ax|bx|cx|dx|si|di|bp|sp)|r(8|9|1[0-5]))$/.test(name) && context[name]!==undefined)
    return context[name];
  if (/^e(ax|bx|cx|dx|si|di|bp|sp)$/.test(name)) return context['r'+name.slice(1)].and('0xffffffff');
  throw new Error('unsupported_address_register');
}
function unsupported(pc, tid, why, instructionId) {
  emit({kind:'unsupported',pc:pc.toString(),tid,reason:why,instruction_id:instructionId,
        identity_uncertain:true});
}
const allocatorNames=['malloc','calloc','realloc','free','mmap','munmap',
  'getenv','clock_gettime','uname','getrandom','connect','ioctl'];
const allocatorAddresses=allocatorNames.map((name,index)=>index<6||config.environment_functions.includes(name)?
  Module.findGlobalExportByName(name):null);
const loadBias=main.base.sub(ptr(config.elf.lowest_load_vaddr));
const allocatorThunks=allocatorNames.map(name=>config.elf.import_thunks[name]===undefined?null:
  loadBias.add(config.elf.import_thunks[name]));
const nativeState=Memory.alloc(262144),nativeRecord=Memory.alloc(64),nativeBounds=Memory.alloc(16);
nativeBounds.writeU64(uint64(main.base.toString()));
nativeBounds.add(8).writeU64(uint64(main.base.add(main.size).toString()));
const allocatorNative=new CModule(`
#include <gum/guminterceptor.h>
#include <gum/gumspinlock.h>
#include <gum/gumprocess.h>
typedef struct {guint64 op,tid,pc,a,b,result;} Record;
typedef struct {guint64 tid,pc;guint expected,suppressed;} Thread;
typedef struct {GumSpinlock lock;guint head,tail,lost;guint64 callback_ns;Thread threads[64];Record records[2048];} State;
typedef struct {guint64 op,tid,pc,a,b;gboolean capture;} Call;
extern State state;
extern int native_gettid(void);
extern long native_syscall(long number,...);
extern guint64 bounds[2];
static guint64 now(void){struct {guint64 seconds,nanos;} t={0,0};
 if(native_syscall(228,1,&t)!=0)return 0;return t.seconds*1000000000+t.nanos;}
static void account(guint64 started){guint64 ended=now();gum_spinlock_acquire(&state.lock);
 if(ended>=started)state.callback_ns+=ended-started;gum_spinlock_release(&state.lock);}
static Thread *thread(guint64 tid){guint i;Thread *empty=NULL;for(i=0;i<64;i++){
 if(state.threads[i].tid==tid)return &state.threads[i];
 if(state.threads[i].tid==0 && empty==NULL)empty=&state.threads[i];}
 if(empty!=NULL)empty->tid=tid;return empty;}
void begin_probe(GumCpuContext *context,gpointer data){
 Thread *t;gum_spinlock_acquire(&state.lock);t=thread(native_gettid());
 if(t!=NULL){t->suppressed=1;t->expected=0;}else state.lost++;
 gum_spinlock_release(&state.lock);}
void end_probe(GumCpuContext *context,gpointer data){
 Thread *t;gum_spinlock_acquire(&state.lock);t=thread(native_gettid());
 if(t!=NULL)t->suppressed=0;gum_spinlock_release(&state.lock);}
void expect(guint64 tid,guint op,guint64 pc){Thread *t;
 gum_spinlock_acquire(&state.lock);t=thread(tid);if(t!=NULL){t->expected=op;t->pc=pc;}
 gum_spinlock_release(&state.lock);}
static void enter(GumInvocationContext *ic,guint op){
 guint64 tid=native_gettid(),pc=(guint64)gum_invocation_context_get_return_address(ic);
 gboolean capture=FALSE;Thread *t;Call *call;guint64 started;
 gum_spinlock_acquire(&state.lock);t=thread(tid);
 if(t!=NULL&&!t->suppressed){capture=(pc>=bounds[0]&&pc<bounds[1])||t->expected==op;
 if(t->expected==op){pc=t->pc;t->expected=0;}}
 gum_spinlock_release(&state.lock);
 call=gum_invocation_context_get_listener_invocation_data(ic,sizeof(Call));call->capture=capture;
 if(!capture)return;started=now();call->op=op;call->tid=tid;call->pc=pc;
 call->a=(guint64)gum_invocation_context_get_nth_argument(ic,0);
 call->b=(guint64)gum_invocation_context_get_nth_argument(ic,1);
 account(started);
}
static void leave(GumInvocationContext *ic){Call *c=gum_invocation_context_get_listener_invocation_data(ic,sizeof(Call));
 Record *r;guint64 started;if(!c->capture)return;started=now();gum_spinlock_acquire(&state.lock);
 if(state.head-state.tail>=2048)state.lost++;else {r=&state.records[state.head++%2048];
 r->op=c->op;r->tid=c->tid;r->pc=c->pc;r->a=c->a;r->b=c->b;
 r->result=(guint64)gum_invocation_context_get_return_value(ic);}
 gum_spinlock_release(&state.lock);account(started);}
#define HOOK(name,op) void name##_enter(GumInvocationContext *ic){enter(ic,op);} \
void name##_leave(GumInvocationContext *ic){leave(ic);}
HOOK(malloc,1) HOOK(calloc,2) HOOK(realloc,3) HOOK(free,4) HOOK(mmap,5) HOOK(munmap,6)
HOOK(getenv,7) HOOK(clock_gettime,8) HOOK(uname,9) HOOK(getrandom,10) HOOK(connect,11) HOOK(ioctl,12)
guint take(Record *out){guint found=0;gum_spinlock_acquire(&state.lock);
 if(state.tail!=state.head){*out=state.records[state.tail++%2048];found=1;}
 gum_spinlock_release(&state.lock);return found;}
guint loss(void){guint n;gum_spinlock_acquire(&state.lock);n=state.lost;gum_spinlock_release(&state.lock);return n;}
guint64 callback_us(void){guint64 n;gum_spinlock_acquire(&state.lock);n=state.callback_ns/1000;gum_spinlock_release(&state.lock);return n;}
`,{native_gettid:Module.getGlobalExportByName('gettid'),native_syscall:Module.getGlobalExportByName('syscall'),
   state:nativeState,bounds:nativeBounds});
const expectAllocator=new NativeFunction(allocatorNative.expect,'void',['uint64','uint','uint64']);
const takeAllocator=new NativeFunction(allocatorNative.take,'uint',['pointer']);
const allocatorLoss=new NativeFunction(allocatorNative.loss,'uint',[]);
const nativeCallbackUsRaw=new NativeFunction(allocatorNative.callback_us,'uint64',[]);
function nativeCallbackUs(){return Number(nativeCallbackUsRaw().toString());}
for(let index=0;index<allocatorNames.length;index++)if(allocatorAddresses[index]!==null)
  hooks.push(Interceptor.attach(allocatorAddresses[index],{onEnter:allocatorNative[allocatorNames[index]+'_enter'],
    onLeave:allocatorNative[allocatorNames[index]+'_leave']}));
function nativeWord(offset){const value=nativeRecord.add(offset).readU64();const text=value.toString();
 const number=Number(text);return Number.isSafeInteger(number)?number:text;}
function drainAllocations(){
 while(takeAllocator(nativeRecord)){
  const operation=allocatorNames[nativeWord(0)-1],tid=Number(nativeWord(8)),pc=ptr('0x'+nativeRecord.add(16).readU64().toString(16)).toString();
  const a=ptr('0x'+nativeRecord.add(24).readU64().toString(16)),b=nativeWord(32),result=ptr('0x'+nativeRecord.add(40).readU64().toString(16));
  if(nativeWord(0)>6){emit({kind:'environment',operation,pc,tid,phase:'after_return',
    return_value:operation==='getenv'?result.toString():operation==='getrandom'?nativeRecord.add(40).readS64().toString():result.toInt32(),
    return_interpretation:operation==='getenv'?'pointer':operation==='getrandom'?'signed_64_bit_decimal':'signed_32_bit',
    buffers_read:false,strings_read:false,behavior_replaced:false,
    provenance:'native application-origin wrapper hook'});continue;}
  const old=operation==='realloc'?a.toString():null;
  let size=operation==='free'?null:operation==='realloc'||operation==='mmap'||operation==='munmap'?b:word(a);
  let success=operation==='free'?true:operation==='munmap'?result.toInt32()===0:!result.isNull();
  if(operation==='mmap')success=!result.equals(ptr(-1));
  const event={kind:'allocation',operation,address:operation==='free'||operation==='munmap'?a.toString():result.toString(),
    size,old_address:old,success,pc,tid,phase:'after_return',provenance:'native application-origin allocator hook',
    object_identity_known:false};
  if(operation==='calloc'){const product=Number(word(a))*Number(b);event.count=word(a);event.element_size=b;
    event.size=Number.isSafeInteger(product)?product:null;event.size_overflow_unknown=event.size===null;}
  if(operation==='free'&&a.isNull())event.zero_size_behavior='free_null_noop';
  if(operation==='realloc'&&Number(size)===0){event.success=result.isNull()?null:true;
    event.zero_size_behavior='implementation_defined_old_allocation_may_be_freed';}
  if((operation==='malloc'||operation==='calloc')&&Number(event.size)===0)
    event.zero_size_behavior='implementation_defined_zero_size_allocation';
  emit(event);
 }
}
// Only the root entry needs an Interceptor. Nested selected functions retain
// their original entry bytes, so Stalker can observe their complete operands.
for (const range of ranges.filter(r=>r.name===config.entry_function)) hooks.push(Interceptor.attach(range.start, {
  onEnter() {
    const tid=Process.getCurrentThreadId(); this.tid=tid;
    emit({kind:'function',operation:'enter',function:range.name,pc:range.start.toString(),tid});
    const depth=active.get(tid)||0; active.set(tid,depth+1);
    if (depth || stopped) return;
    Stalker.follow(tid,{transform(iterator) {
      let instruction;
      while ((instruction=iterator.next())!==null) {
        if (inside(instruction.address)) {
          const pc=instruction.address, next=pc.add(instruction.size), mnemonic=instruction.mnemonic;
          const operands=instruction.operands;
          const memory=operands.filter(o=>o.type==='mem');
          const vector=operands.some(o=>o.type==='reg' && /^(xmm|ymm|zmm|k)[0-9]+$/.test(o.value));
          iterator.putCallout(allocatorNative.begin_probe);
          iterator.putCallout(context=> {
            if (stopped) return;
            const started=Date.now(); const id=++instructions;
            drainAllocations();
            if(/^call/.test(mnemonic)&&operands.length){
              let target=null;const operand=operands[0];
              if(operand.type==='imm')target=ptr(operand.value);
              else if(operand.type==='reg'&&context[operand.value]!==undefined)target=context[operand.value];
              if(target!==null){const index=allocatorNames.findIndex((_n,i)=>
                allocatorAddresses[i]!==null&&target.equals(allocatorAddresses[i])||
                allocatorThunks[i]!==null&&target.equals(allocatorThunks[i]));
                if(index>=0)expectAllocator(tid,index+1,uint64(pc.toString()));}
            }
            const nested=ranges.find(r=>r.name!==config.entry_function && pc.equals(r.start));
            if(nested)emit({kind:'function',operation:'enter',function:nested.name,pc:pc.toString(),tid,phase:'before'});
            emit({kind:'instruction',pc:pc.toString(),module_offset:pc.sub(main.base).toString(),
                  mnemonic,instruction_id:id,tid,phase:'before',committed:false});
            if (vector) unsupported(pc,tid,'vector_operand',id);
            if (/^(push|pop|call|ret|enter|leave|rep|movs|stos|lods|scas|cmps|xlat)/.test(mnemonic))
              unsupported(pc,tid,'implicit_memory_not_reconstructed',id);
            if(/^ret/.test(mnemonic)){
              const range=ranges.find(r=>pc.compare(r.start)>=0&&pc.compare(r.end)<0);
              if(range&&range.name!==config.entry_function)emit({kind:'function',operation:'leave',function:range.name,
                pc:pc.toString(),tid,phase:'before',committed:false});
            }
            for (const operand of memory) {
              if (/^(lea|nop|rep|movs|stos|lods|scas|cmps|xlat)/.test(mnemonic)) continue;
              const value=operand.value;
              if (vector || value.segment && value.segment!=='invalid' ||
                  !Number.isInteger(operand.size) || operand.size<1 || operand.size>16 ||
                  !['r','w','rw'].includes(operand.access)) {
                unsupported(pc,tid,'unsupported_memory_operand',id); continue;
              }
              try {
                const base=register(context,value.base,next);
                const index=register(context,value.index,next);
                const scale=value.scale || 1;
                if (![1,2,4,8].includes(scale) || !Number.isSafeInteger(value.disp))
                  throw new Error('unsupported_address_expression');
                const addressBits=/^e/.test(value.base||value.index||'')?32:64;
                let address=base.add(index.shl(Math.log2(scale))).add(value.disp);
                if(addressBits===32)address=address.and('0xffffffff');
                emit({kind:'memory',pc:pc.toString(),address:address.toString(),size:operand.size,
                      access:{r:'read',w:'write',rw:'read_write'}[operand.access],phase:'before',
                      committed:false,instruction_id:id,tid,
                      provenance:'Frida.Stalker explicit x86_64 operand',
                      operand:{base:value.base||null,index:value.index||null,scale,disp:value.disp,
                               access:operand.access,size:operand.size},
                      address_evidence:{base_register:value.base||null,base_value:base.toString(),
                        index_register:value.index||null,index_value:index.toString(),scale,disp:value.disp,
                        pc_next:next.toString(),rip_relative:value.base==='rip',address_bits:addressBits}});
              } catch(error) { unsupported(pc,tid,String(error.message),id); }
            }
            callbackMs+=Math.max(0,Date.now()-started);
            if (instructions>=config.max_instructions) stop('instruction_budget');
            else if (callbackMs*1000+nativeCallbackUs()>=config.max_callback_us) stop('callback_wall_budget');
            else if (recorded>=config.max_events || bytes>=config.max_bytes) stop('event_or_byte_budget');
          });
          iterator.putCallout(allocatorNative.end_probe);
        }
        iterator.keep();
      }
    }});
  },
  onLeave() {
    emit({kind:'function',operation:'leave',function:range.name,pc:range.start.toString(),tid:this.tid});
    const depth=(active.get(this.tid)||1)-1;
    if (depth) active.set(this.tid,depth); else {active.delete(this.tid);Stalker.unfollow(this.tid);Stalker.flush();}
    report();
  }
}));
for (const [operation,name] of Object.entries(config.registration_hooks||{})) {
  const hook=resolveFunction(name,1);
  Stalker.exclude({base:hook,size:1});
  hooks.push(Interceptor.attach(hook,{
    onEnter(args){
      this.event={kind:'object',operation,object_id:String(word(args[0])),
                  generation:String(word(args[operation==='retire'?1:3])),tid:Process.getCurrentThreadId(),
                  provenance:'explicit fixed registration ABI',phase:'after_return'};
      if(operation!=='retire'){this.event.address=args[1].toString();this.event.size=word(args[2]);}
      if(operation==='define')this.event.type_slot=word(args[4]);
    },
    onLeave(){drainAllocations();emit(this.event);}
  }));
}
// The worker is owned by an independent supervisor. Bind this target to its
// creator too, so supervisor failure kills the worker and then this target.
const getppid=new NativeFunction(Module.getGlobalExportByName('getppid'),'int',[]);
const prctl=new NativeFunction(Module.getGlobalExportByName('prctl'),'int',['int','ulong','ulong','ulong','ulong']);
if(getppid()!==config.worker_pid || prctl(1,9,0,0,0)!==0 || getppid()!==config.worker_pid)
  throw new Error('target_parent_guard_failed');
emit({kind:'module',base:main.base.toString(),path:main.path,build_sha:config.sha256,page_size:Process.pageSize});
flush();
setInterval(report,200);
rpc.exports={ready(){return {arch:Process.arch,pid:Process.id,operand_source:'Frida.Instruction.operands',
                           function_resolution:functionResolution};},
             stop(){stop('operator_close');report();}};
