#!/usr/bin/env python3
"""Fixed multi-writer pause lease: resume only the supplied running pidfds.

The host sends S to request a stop, then D to finish. EOF, host death, a
deadline or a handled termination signal always resumes the same pidfds.
No PID lookup, memory access or model-supplied command is accepted here.
"""
import json
import os
import select
import signal
import sys
import time


def main():
    host,control,pause=map(int,sys.argv[1:4]);fds=json.loads(sys.argv[4])
    if not 100<=pause<=2000 or type(fds)is not list or len(fds)>8:
        return 2
    if any(type(fd)is not int or fd<3 for fd in [host,control,*fds]):return 2
    cancelled=False;stopped=[];reason='not_started';started=0
    def cancel(_signum,_frame):
        nonlocal cancelled
        cancelled=True
    for signum in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(signum,cancel)
    signal.signal(signal.SIGPIPE,signal.SIG_IGN)
    def emit(value):
        os.write(1,json.dumps(value,separators=(',',':')).encode()+b'\n')
    try:
        emit({'event':'armed'})
        ready=select.select([host,control],[],[],3)[0]
        if cancelled or host in ready or control not in ready or os.read(control,1)!=b'S':return 0
        started=time.monotonic_ns();deadline=started+pause*1_000_000
        for fd in fds:
            # Record the debt before signalling: errors cannot drop a resume.
            stopped.append(fd)
            try:signal.pidfd_send_signal(fd,signal.SIGSTOP)
            except ProcessLookupError:pass
        emit({'event':'stopped','started_ns':started,'deadline_ns':deadline})
        reason='cancelled'
        while not cancelled:
            left=(deadline-time.monotonic_ns())/1e9
            if left<=0:reason='lease_expired';break
            ready=select.select([host,control],[],[],min(left,.05))[0]
            if host in ready:reason='host_exit';break
            if control in ready:
                reason='completed'if os.read(control,1)==b'D'else'control_closed'
                break
        return 0
    finally:
        for fd in stopped:
            try:signal.pidfd_send_signal(fd,signal.SIGCONT)
            except OSError:pass
        try:emit({'event':'resumed','reason':reason,'finished_ns':time.monotonic_ns(),'started_ns':started})
        except OSError:pass


if __name__=='__main__':raise SystemExit(main())
