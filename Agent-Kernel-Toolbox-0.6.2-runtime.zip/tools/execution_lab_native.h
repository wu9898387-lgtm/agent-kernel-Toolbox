/* Bounded x86-64 snapshot protocol shared by the runner and DynamoRIO client. */
#ifndef EXECUTION_LAB_NATIVE_H
#define EXECUTION_LAB_NATIVE_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#define LAB_MAX_REQUEST 262144
typedef struct { uint64_t address; uint32_t size,writable; unsigned char bytes[4096]; } lab_region;
typedef struct { uint64_t address,value; uint32_t region,offset,size,kind; char name[64]; unsigned char bytes[4096]; } lab_model;
typedef struct {
    unsigned char nonce[16];
    uint64_t load,size,entry,stop,steps,regs[18];
    uint32_t region_count,model_count;
    unsigned char code[16384]; lab_region regions[8]; lab_model models[32];
} lab_request;
typedef struct { const unsigned char *p; size_t left; } lab_reader;
static int lab_take(lab_reader *reader,void *output,size_t size) {
    if (size>reader->left) return 0;
    memcpy(output,reader->p,size); reader->p+=size; reader->left-=size; return 1;
}
static int lab_parse(const unsigned char *data,size_t size,lab_request *r) {
    lab_reader reader={data,size}; char magic[8];
    if (!lab_take(&reader,magic,8)||memcmp(magic,"EXLAB01\0",8)||
        !lab_take(&reader,r->nonce,16)||!lab_take(&reader,&r->load,8)||
        !lab_take(&reader,&r->size,8)||!lab_take(&reader,&r->entry,8)||
        !lab_take(&reader,&r->stop,8)||!lab_take(&reader,&r->steps,8)||
        !lab_take(&reader,&r->region_count,4)||!lab_take(&reader,&r->model_count,4)||
        !lab_take(&reader,r->regs,sizeof(r->regs))) return 0;
    if (!r->size||r->size>16384||!r->steps||r->steps>100000||r->region_count>8||r->model_count>32||
        r->load<4096||r->load%4096||r->load>UINT64_C(0x7fffffff0000)||
        r->entry<r->load||r->entry>=r->load+r->size||r->stop<4096||r->stop>UINT64_C(0x7fffffffffff)) return 0;
    if (!lab_take(&reader,r->code,r->size)) return 0;
    for (uint32_t i=0;i<r->region_count;i++) {
        lab_region *m=&r->regions[i];
        if (!lab_take(&reader,&m->address,8)||!lab_take(&reader,&m->size,4)||!lab_take(&reader,&m->writable,4)||
            !m->size||m->size>4096||m->writable>1||m->address<4096||m->address%4096||m->address>UINT64_C(0x7fffffff0000)||
            !lab_take(&reader,m->bytes,m->size)) return 0;
    }
    for (uint32_t i=0;i<r->model_count;i++) {
        lab_model *m=&r->models[i];
        if (!lab_take(&reader,&m->address,8)||!lab_take(&reader,&m->value,8)||
            !lab_take(&reader,&m->region,4)||!lab_take(&reader,&m->offset,4)||
            !lab_take(&reader,&m->size,4)||!lab_take(&reader,&m->kind,4)||!lab_take(&reader,m->name,64)||
            m->size>4096||m->kind>3||m->address<4096||m->address>UINT64_C(0x7fffffffffff)||
            (m->size&&(m->region>=r->region_count||m->offset>4096-m->size||
             m->offset+m->size>r->regions[m->region].size||!r->regions[m->region].writable))||
            !memchr(m->name,0,64)||!lab_take(&reader,m->bytes,m->size)) return 0;
    }
    return reader.left==0;
}
static int lab_permitted(const lab_request *r,uint64_t address,size_t size,int write) {
    if (address>UINT64_MAX-size) return 0;
    if (!write&&address>=r->load&&address+size<=r->load+r->size) return 1;
    for (uint32_t i=0;i<r->region_count;i++) {
        const lab_region *m=&r->regions[i];
        if (address>=m->address&&address+size<=m->address+m->size&&(!write||m->writable)) return 1;
    }
    return 0;
}
#endif
