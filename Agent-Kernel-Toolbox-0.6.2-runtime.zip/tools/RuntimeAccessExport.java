// Bounded headless decompiler export for Agent-Kernel-Toolbox.
// @category RuntimeAccess
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import ghidra.program.model.pcode.PcodeOpAST;
import ghidra.program.model.pcode.Varnode;
import ghidra.program.database.mem.AddressSourceInfo;
import ghidra.program.model.address.Address;
import ghidra.program.model.data.DataType;
import ghidra.program.model.data.DataTypeComponent;
import ghidra.program.model.data.Structure;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Iterator;

/** Analysis output is evidence, not source equivalence or object identity proof. */
public class RuntimeAccessExport extends GhidraScript {
    private static String quote(String value) {
        if (value == null) return "null";
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 0x20 || c > 0x7e) out.append(String.format("\\u%04x", (int)c));
                    else out.append(c);
            }
        }
        return out.append('"').toString();
    }

    private static String bounded(String text) {
        return text.length() > 256 ? text.substring(0, 256) : text;
    }

    private static String node(Varnode value) {
        if (value == null) return "null";
        return "{\"space\":" + quote(value.getAddress().getAddressSpace().getName())
            + ",\"offset\":" + quote("0x" + Long.toUnsignedString(value.getOffset(), 16))
            + ",\"bytes\":" + value.getSize() + ",\"constant\":" + value.isConstant()
            + ",\"register\":" + value.isRegister() + ",\"unique\":" + value.isUnique() + "}";
    }

    private String sourceOffset(Address address) {
        AddressSourceInfo source = currentProgram.getMemory().getAddressSourceInfo(address);
        return source == null || source.getFileOffset() < 0 ? "null" : quote("0x" + Long.toHexString(source.getFileOffset()));
    }

    @Override public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length != 1 || currentProgram == null) throw new IllegalArgumentException("one output path and program required");
        DecompInterface decompiler = new DecompInterface();
        decompiler.toggleCCode(true);
        decompiler.toggleSyntaxTree(true);
        if (!decompiler.openProgram(currentProgram)) throw new IllegalStateException("decompiler unavailable");
        int count = 0;
        int operations = 0;
        int characters = 0;
        boolean truncated = false;
        try (BufferedWriter out = Files.newBufferedWriter(Path.of(args[0]), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
            out.write("{\"schema_version\":1,\"language_id\":" + quote(currentProgram.getLanguageID().toString())
                    + ",\"compiler_spec_id\":" + quote(currentProgram.getCompilerSpec().getCompilerSpecID().toString())
                    + ",\"program_sha256\":" + quote(currentProgram.getExecutableSHA256())
                    + ",\"processor\":" + quote(currentProgram.getLanguage().getProcessor().toString())
                    + ",\"pointer_bits\":" + (8 * currentProgram.getDefaultPointerSize())
                    + ",\"byte_order\":" + quote(currentProgram.getLanguage().isBigEndian() ? "big" : "little")
                    + ",\"image_base\":" + quote(currentProgram.getImageBase().toString())
                    + ",\"pcode_representation\":\"Ghidra high-function SSA\""
                    + ",\"functions\":[");
            FunctionIterator functions = currentProgram.getFunctionManager().getFunctions(true);
            while (functions.hasNext()) {
                monitor.checkCancelled();
                Function function = functions.next();
                if (function.isExternal() || function.isThunk()) continue;
                if (count >= 32 || operations >= 128 || characters >= 20000) { truncated = true; break; }
                DecompileResults result = decompiler.decompileFunction(function, 5, monitor);
                if (count++ > 0) out.write(",");
                out.write("{\"name\":" + quote(bounded(function.getName())) + ",\"entry\":" + quote(function.getEntryPoint().toString())
                        + ",\"source_file_offset\":" + sourceOffset(function.getEntryPoint())
                        + ",\"prototype\":" + quote(bounded(function.getPrototypeString(false, false)))
                        + ",\"decompiled\":" + result.decompileCompleted()
                        + ",\"warning\":" + quote(result.getErrorMessage()));
                if (result.decompileCompleted() && result.getDecompiledFunction() != null) {
                    String code = result.getDecompiledFunction().getC();
                    if (code.length() > 8192) { code = code.substring(0, 8192); truncated = true; }
                    characters += code.length();
                    out.write(",\"pseudocode\":" + quote(code));
                }
                out.write(",\"pcode\":[");
                boolean first = true;
                if (result.getHighFunction() != null) {
                    Iterator<PcodeOpAST> iterator = result.getHighFunction().getPcodeOps();
                    while (iterator.hasNext() && operations < 128 && characters < 20000) {
                        PcodeOpAST op = iterator.next();
                        if (!first) out.write(",");
                        first = false;
                        ++operations;
                        out.write("{\"address\":" + quote(op.getSeqnum().getTarget().toString())
                                + ",\"source_file_offset\":" + sourceOffset(op.getSeqnum().getTarget())
                                + ",\"opcode\":" + quote(op.getMnemonic()) + ",\"output\":"
                                + quote(op.getOutput() == null ? null : bounded(op.getOutput().toString()))
                                + ",\"output_node\":" + node(op.getOutput()) + ",\"inputs\":[");
                        if (op.getNumInputs() > 16) truncated = true;
                        for (int index = 0; index < Math.min(op.getNumInputs(), 16); ++index) {
                            if (index > 0) out.write(",");
                            Varnode input = op.getInput(index);
                            String text = bounded(input.toString());
                            characters += text.length();
                            out.write(quote(text));
                        }
                        out.write("],\"input_nodes\":[");
                        for (int index = 0; index < Math.min(op.getNumInputs(), 16); ++index) {
                            if (index > 0) out.write(",");
                            out.write(node(op.getInput(index)));
                        }
                        out.write("]}");
                    }
                    if (iterator.hasNext()) truncated = true;
                }
                out.write("]}");
            }
            out.write("],\"static_type_layouts\":[");
            Iterator<DataType> types = currentProgram.getDataTypeManager().getAllDataTypes();
            int scanned = 0, structures = 0;
            while (types.hasNext() && scanned++ < 4096 && structures < 16) {
                DataType type = types.next();
                if (!(type instanceof Structure)) continue;
                Structure structure = (Structure)type;
                if (structures++ > 0) out.write(",");
                out.write("{\"type\":" + quote(bounded(structure.getPathName()))
                    + ",\"size\":" + structure.getLength() + ",\"alignment\":" + structure.getAlignment()
                    + ",\"source\":\"program datatype/debug metadata; no live object binding\",\"fields\":[");
                DataTypeComponent[] fields = structure.getDefinedComponents();
                for (int index = 0; index < Math.min(fields.length, 32); ++index) {
                    if (index > 0) out.write(",");
                    DataTypeComponent field = fields[index];
                    out.write("{\"name\":" + quote(field.getFieldName()) + ",\"offset\":" + field.getOffset()
                        + ",\"size\":" + field.getLength() + ",\"type\":" + quote(bounded(field.getDataType().getPathName())) + "}");
                }
                out.write("],\"fields_truncated\":" + (fields.length > 32) + "}");
            }
            out.write("],\"static_types_scan_truncated\":" + types.hasNext()
                + ",\"truncated\":" + truncated + ",\"source_equivalence_proven\":false,\"object_identity_proven\":false}");
        } finally {
            decompiler.dispose();
        }
    }
}
