#!/usr/bin/env python3
"""Bounded owned-program strace worker. Raw read buffers are never decoded.

This is a behavior observer, not a malware or anti-cheat verdict engine.
The host fixes executables, arguments, roots and all budgets before launch.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import posixpath
import re
import select
import signal
import stat
import subprocess
import sys
import time

SYSCALLS = ('open,openat,openat2,close,close_range,stat,lstat,fstat,newfstatat,statx,'
            'getdents,getdents64,read,pread64,dup,dup2,dup3,fcntl,chdir,fchdir,'
            'execve,execveat,clone,clone3,fork,vfork,exit,exit_group')
RAW = 'read,pread64,getdents,getdents64,execve,execveat'
LINE = re.compile(r'^(\d+)\s+(\d+\.\d{1,9})\s+(.*)$')
CALL = re.compile(r'^([a-z][a-z0-9_]*)\((.*)\)\s+=\s+(.*)$')
RETURN = re.compile(r'^(-?(?:0x[0-9a-fA-F]+|[0-9]+)|\?)(?:\b|$)')
WRAPPER = r'''
import ctypes,os,resource,signal,sys
expected=int(sys.argv[1]); seconds=int(sys.argv[2]); size=int(sys.argv[3])
libc=ctypes.CDLL(None,use_errno=True)
libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
if libc.prctl(1,signal.SIGKILL,0,0,0):raise OSError(ctypes.get_errno(),'PDEATHSIG')
if os.getppid()!=expected:os.kill(os.getpid(),signal.SIGKILL)
for key,wanted in [(resource.RLIMIT_CPU,seconds),(resource.RLIMIT_FSIZE,size),
 (resource.RLIMIT_AS,1073741824),(resource.RLIMIT_NOFILE,128),(resource.RLIMIT_CORE,0)]:
 soft,hard=resource.getrlimit(key)
 value=min([wanted]+[n for n in (soft,hard) if n!=resource.RLIM_INFINITY])
 resource.setrlimit(key,(value,value))
os.execv(sys.argv[4],sys.argv[4:])
'''


def _integer(token):
    found = re.match(r'^-?(?:0x[0-9a-fA-F]+|[0-9]+)', token.strip())
    if not found:return None
    text = found[0]
    return int(text, 16 if '0x' in text else 10)


def _decode(text):
    """Decode strace's -xx C bytes without eval or Python string escapes."""
    if len(text) > 20000:raise ValueError('path_budget')
    output, index = bytearray(), 0
    while index < len(text):
        if text[index] == '\\':
            if text[index:index+2] == '\\x' and index+4 <= len(text) and re.fullmatch('[0-9a-fA-F]{2}', text[index+2:index+4]):
                output.append(int(text[index+2:index+4],16));index += 4
            elif index+1 < len(text) and text[index+1] in '\\"':
                output.append(ord(text[index+1]));index += 2
            else:raise ValueError('invalid_c_escape')
        elif 32 <= ord(text[index]) < 127:
            output.append(ord(text[index]));index += 1
        else:raise ValueError('invalid_trace_character')
    if b'\0' in output or len(output) > 4096:raise ValueError('invalid_path_bytes')
    return output.decode('utf-8','surrogateescape')


def _args(text):
    result, start, stack, quoted, escaped = [], 0, [], False, False
    closes = {'(':')','[':']','{':'}','<':'>'}
    for index,char in enumerate(text):
        if quoted:
            if escaped:escaped=False
            elif char == '\\':escaped=True
            elif char == '"':quoted=False
            continue
        if char == '"':quoted=True
        elif char in closes:stack.append(closes[char])
        elif char in ')]}>':
            if not stack or stack.pop()!=char:raise ValueError('invalid_argument_nesting')
        elif char == ',' and not stack:
            result.append(text[start:index].strip());start=index+1
    if quoted or stack:raise ValueError('incomplete_arguments')
    result.append(text[start:].strip())
    return result


def _path(token):
    if token.startswith('"'):
        # -xx escapes embedded quotes; literal closing quotes delimit the string.
        close=token.find('"',1)
        if close < 0 or token[close+1:].strip():return None
        return _decode(token[1:close])
    begin=token.find('<')
    if begin < 0:return None
    # Reject device/socket annotations and nested angle metadata as paths.
    value=token[begin+1:token.rfind('>')]
    return _decode(value) if '<' not in value and '>' not in value else None


def _ns(text):
    left,right=text.split('.',1)
    return int(left)*1_000_000_000+int(right.ljust(9,'0'))


def _clone_flags(args):
    found=re.search(r'\bflags=([^,}]+)',','.join(args))
    if not found or '...' in found[1]:return None
    names=set();number=0
    for part in found[1].split('|'):
        token=part.strip()
        if re.fullmatch(r'(?:0x[0-9a-fA-F]+|[0-9]+)',token):number|=_integer(token)
        elif re.fullmatch(r'[A-Z][A-Z0-9_]+',token):names.add(token)
        else:return None
    return ('CLONE_FILES' in names or bool(number&0x400),
            'CLONE_FS' in names or bool(number&0x200),
            'CLONE_THREAD' in names or bool(number&0x10000))


def parse_trace(raw, profile, elapsed_ns):
    """Return bounded observations. Unparsed lines never become invented calls."""
    pending, calls, issues = {}, [], {'unparsed_lines':0,'orphan_resumes':0,'unfinished_calls':0,'unknown_clone_semantics':0,'unattributed_tids':0}
    exited=[]
    for line in raw.decode('ascii','strict').splitlines():
        found=LINE.match(line)
        if not found:
            issues['unparsed_lines']+=1;continue
        tid,at,text=int(found[1]),_ns(found[2]),found[3]
        if text.startswith('+++ exited with '):
            exited.append(tid);continue
        if text.startswith(('--- ','+++ killed by ')):continue
        if text.endswith('<unfinished ...>'):
            if len(pending)>=64:issues['unparsed_lines']+=1;continue
            pending[tid]=(at,text[:-len('<unfinished ...>')]);continue
        if text.startswith('<... '):
            resumed=re.match(r'^<\.\.\. ([a-z0-9_]+) resumed>(.*)$',text)
            before=pending.pop(tid,None)
            if before is None or resumed is None or not before[1].startswith(resumed[1]+'('):
                issues['orphan_resumes']+=1;continue
            at,text=before[0],before[1]+resumed[2]
        duration=None
        timing=re.search(r' <([0-9]+\.[0-9]+)>$',text)
        if timing:duration=_ns(timing[1]);text=text[:timing.start()]
        call=CALL.match(text)
        if not call:issues['unparsed_lines']+=1;continue
        returned=RETURN.match(call[3])
        if returned is None:issues['unparsed_lines']+=1;continue
        try:arguments=_args(call[2])
        except ValueError:issues['unparsed_lines']+=1;continue
        number=_integer(returned[1])
        error=re.search(r'\s([A-Z][A-Z0-9_]{1,31})(?:\s|$)',call[3][returned.end():])
        calls.append({'tid':tid,'time_ns':at,'duration_ns':duration,'name':call[1],
                      'args':arguments,'return':number,'return_text':call[3],
                      'errno':error[1] if error else None})
        if len(calls)>=65536:issues['unparsed_lines']+=1;break
    issues['unfinished_calls']=len(pending)
    calls.sort(key=lambda item:item['time_ns'])
    root=next((item['tid'] for item in calls if item['name'] in ('execve','execveat')),None)
    actors={root:{'tid':root,'pid':root,'parent_tid':None,'relation':'spawned_root'}} if root else {}
    fds={root:{}} if root else {}
    cwd={root:{'path':profile['cwd']}} if root else {}
    events=[];paths=set();directories=set();observed_events=0;counts={'file_events':0,'open_calls':0,'metadata_calls':0,'enumeration_calls':0,'read_calls':0,'read_bytes_observed':0}
    def resolve(value,tid,base=None):
        if value is None:return None
        if not value.startswith('/'):
            parent=base or cwd.get(tid,{}).get('path')
            if not parent:return None
            value=posixpath.join(parent,value)
        return '/'+posixpath.normpath(value).lstrip('/')
    def ref(path,source):
        inside=any(path==base or path.startswith(base.rstrip('/')+'/') for base in profile['roots'])
        result={'sha256':hashlib.sha256(path.encode('utf-8','surrogateescape')).hexdigest(),
                'in_scope':inside,'source':source,'redacted':True}
        if profile.get('show_paths') and inside:
            visible=path.encode('utf-8','replace')[:256].decode('utf-8','ignore')
            result.update(path=visible,redacted=False,display_truncated=visible!=path)
        return result
    for item in calls:
        tid,name,args,returned=item['tid'],item['name'],item['args'],item['return']
        if tid not in actors:
            if len(actors)>=64:issues['unparsed_lines']+=1;continue
            issues['unattributed_tids']+=1
            actors[tid]={'tid':tid,'pid':None,'parent_tid':None,'relation':'unattributed_observed_tid'}
            fds[tid]={};cwd[tid]={'path':None}
        table=fds[tid]
        if name in ('clone','clone3','fork','vfork') and returned and 0<returned<2**31:
            if len(actors)<64:
                flags=(False,False,False) if name in ('fork','vfork') else _clone_flags(args)
                if flags is None:
                    issues['unknown_clone_semantics']+=1
                    actors[returned]={'tid':returned,'pid':None,'parent_tid':tid,'relation':'clone_attribution_unknown'}
                    fds[returned]={};cwd[returned]={'path':None}
                else:
                    share_files,share_fs,thread=flags
                    actors[returned]={'tid':returned,'pid':actors[tid]['pid'] if thread else returned,
                        'parent_tid':tid,'relation':'thread' if thread else 'descendant_process'}
                    fds[returned]=table if share_files else dict(table)
                    cwd[returned]=cwd[tid] if share_fs else dict(cwd[tid])
            continue
        if name in ('execve','execveat') and returned==0:
            fds[tid]={fd:value for fd,value in table.items() if not value[1]};continue
        if name in ('exit','exit_group'):
            exited.append(tid);continue
        fd=_integer(args[0]) if args else None
        path=None;source='unresolved';operation=None
        try:
            if name in ('open','openat','openat2','stat','lstat','newfstatat','statx','chdir'):
                index=1 if name in ('openat','openat2','newfstatat','statx') else 0
                value=_path(args[index])
                base=_path(args[0]) if index else None
                if base is None and index and fd is not None and fd in table:base=table[fd][0]
                path=resolve(value,tid,base)
                source='syscall_argument_resolved_lexically'
                if name in ('open','openat','openat2'):
                    operation='open'
                    if returned is not None and returned>=0:
                        canonical=_path(item['return_text'])
                        if canonical and canonical.startswith('/'):path=resolve(canonical,tid);source='strace_fd_annotation'
                        if path:table[returned]=(path,'O_CLOEXEC' in ','.join(args))
                elif name=='chdir':
                    if returned==0 and path:cwd[tid]['path']=path
                    continue
                else:operation='metadata'
            elif name in ('read','pread64','getdents','getdents64','fstat','fchdir'):
                path=table.get(fd,(None,False))[0] or _path(args[0])
                source='tracked_fd_from_open_or_clone' if fd in table else 'strace_fd_annotation'
                operation='read' if name in ('read','pread64') else 'enumerate' if name.startswith('getdents') else 'metadata'
                if name=='fchdir':
                    if returned==0 and path:cwd[tid]['path']=path
                    continue
            elif name=='close':
                if returned==0:table.pop(fd,None)
                continue
            elif name=='close_range':
                if returned==0:
                    first,last=_integer(args[0]),_integer(args[1])
                    flags=_integer(args[2]) if len(args)>2 else 0
                    flags=flags if flags is not None else 0
                    if 'CLOSE_RANGE_UNSHARE' in ','.join(args) or flags&2:table=dict(table);fds[tid]=table
                    for descriptor in list(table):
                        if first is None or last is None or first<=descriptor<=last:
                            if 'CLOSE_RANGE_CLOEXEC' in ','.join(args) or flags&4:table[descriptor]=(table[descriptor][0],True)
                            else:table.pop(descriptor,None)
                continue
            elif name in ('dup','dup2','dup3') or name=='fcntl' and len(args)>1 and 'F_DUPFD' in args[1]:
                if returned is not None and returned>=0 and fd in table:
                    table[returned]=(table[fd][0],'CLOEXEC' in ','.join(args))
                continue
        except (ValueError,IndexError):issues['unparsed_lines']+=1;continue
        if operation is None:continue
        observed_events+=1
        pathref=ref(path,source) if path else None
        scoped=pathref is not None and pathref['in_scope']
        if scoped:
            directory_access=operation=='enumerate' or 'O_DIRECTORY' in ','.join(args)
            paths.add(path);directories.add(path if directory_access else posixpath.dirname(path))
            counts['file_events']+=1
            counts[{'open':'open_calls','metadata':'metadata_calls','enumerate':'enumeration_calls','read':'read_calls'}[operation]]+=1
            if operation=='read' and returned is not None and 0<returned<2**63:counts['read_bytes_observed']+=returned
        if len(events)<64:
            event={'tid':tid,'pid':actors[tid]['pid'],'syscall':name,'operation':operation,
                   'timestamp_unix_ns':item['time_ns'],'syscall_duration_ns':item['duration_ns'],
                   'return_value':returned,'errno':item['errno'],'in_scope':scoped}
            if pathref is not None:event['path']=pathref
            if fd is not None:event['fd']=fd
            events.append(event)
    seconds=max(elapsed_ns/1e9,.001)
    summary={**counts,'distinct_paths':len(paths),'distinct_directories':len(directories),
             'scoped_events_per_second':round(counts['file_events']/seconds,3),
             'distinct_paths_per_second':round(len(paths)/seconds,3),
             'scope':'operator_registered_roots_only'}
    matched=len(paths)>=profile.get('scan_min_paths',8) and counts['enumeration_calls']>=profile.get('scan_min_enumerations',2)
    return {'root_pid':root,'actors':list(actors.values())[:32],'events':events,'summary':summary,
            'observed_scan_pattern':{'matched':matched,'classification':'observed_scan_pattern' if matched else 'no_observed_scan_pattern',
                'maliciousness_proven':False,'automatic_malware_label':False,
                'criteria':{'minimum_distinct_paths':profile.get('scan_min_paths',8),
                            'minimum_enumerations':profile.get('scan_min_enumerations',2)}},
            'parse_issues':issues,'root_exit_observed':root in exited,
            'events_truncated':observed_events>len(events),'actors_truncated':len(actors)>32,
            'raw_lines':len(raw.splitlines()),'raw_trace_sha256':hashlib.sha256(raw).hexdigest(),
            'raw_trace_sha256_scope':'retained complete-line prefix',
            'file_contents_captured':False,'directory_entry_buffers_captured':False,
            'path_privacy':'digest/redacted by default; hashes are not anonymity',
            'path_resolution_is_file_identity':False}


def run(config, host_fd):
    sys.path.insert(0,str(Path(__file__).resolve().parent))
    from managed_jvm_guardian import _subreaper,cleanup
    _subreaper()
    stopped=False
    def stop(_sig,_frame):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop)
    signal.signal(signal.SIGINT,stop)
    child=None;reason='exited';started=time.monotonic_ns();cleaned=False;seen=0;line_count=0
    log=Path(config['log'])
    argv=[config['strace'],'-f','--kill-on-exit','-qq','-ttt','-T','-xx','-yy','-s','4096',
          '-e','trace='+SYSCALLS,'-e','raw='+RAW,'-o',str(log),'--',*config['argv']]
    try:
        if select.select([host_fd],[],[],0)[0]:return None
        child=subprocess.Popen([sys.executable,'-I','-S','-c',WRAPPER,str(os.getpid()),
            str(max(1,(config['duration_ms']+999)//1000+1)),str(config['max_log_bytes']),*argv],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
            cwd=config['cwd'],env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},start_new_session=True,close_fds=True)
        deadline=time.monotonic()+config['duration_ms']/1000
        while child.poll() is None:
            if stopped:reason='closed';break
            if select.select([host_fd],[],[],0)[0]:reason='host_exited';break
            if time.monotonic()>=deadline:reason='duration_budget';break
            if log.exists():
                size=log.stat().st_size
                if size>=config['max_log_bytes']:reason='byte_budget';break
                if size>seen:
                    with log.open('rb') as stream:
                        stream.seek(seen);new=stream.read(min(size-seen,config['max_log_bytes']-seen))
                    seen+=len(new);line_count+=new.count(b'\n')
                if line_count>=config['max_events']:reason='event_budget';break
            time.sleep(.005)
    finally:
        cleaned=cleanup(child)
    elapsed=time.monotonic_ns()-started
    if reason=='host_exited':return None
    raw=log.read_bytes()[:config['max_log_bytes']] if log.exists() else b''
    if raw and not raw.endswith(b'\n'):raw=raw.rsplit(b'\n',1)[0]+b'\n'
    result=parse_trace(raw,config,elapsed)
    partial=reason!='exited' or not cleaned or child.returncode!=0 or any(result['parse_issues'].values())
    result.update(status='partial' if partial else 'observed',stop_reason=reason,
        tracer_exit_code=child.returncode,elapsed_ns=elapsed,capture_cleanup_confirmed=cleaned,
        binary_sha256=config['binary_sha256'],truncated=partial or result['events_truncated'] or result['actors_truncated'],
        lost_event_count=None,coverage_complete=not partial,
        loss_reporting='strace has no kernel lost-record counter; parse/budget coverage is reported',
        budget={'duration_ms':config['duration_ms'],'max_log_bytes':config['max_log_bytes'],
                'max_raw_lines':config['max_events'],'ptrace_is_intrusive':True,'hard_target_slowdown_bound':False},
        limitations=['mmap/io_uring/file descriptors received via IPC are not fully attributed',
                     'only fixed selected syscalls are observed; scan volume is not a malware verdict'])
    while len(json.dumps(result,ensure_ascii=True,separators=(',',':')).encode())>56000 and result['events']:
        result['events'].pop();result['events_truncated']=True;result['truncated']=True
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host-pidfd',type=int,required=True)
    args=parser.parse_args()
    raw=sys.stdin.buffer.readline(65537)
    if len(raw)>65536 or not raw.endswith(b'\n'):return 2
    try:
        result=run(json.loads(raw),args.host_pidfd)
        if result is not None:print(json.dumps(result,ensure_ascii=True,separators=(',',':')),flush=True)
        return 0
    except Exception:
        print(json.dumps({'status':'unknown','error':'file_activity_worker_failed','effect_dispatched':True}),flush=True)
        return 2


if __name__=='__main__':raise SystemExit(main())
