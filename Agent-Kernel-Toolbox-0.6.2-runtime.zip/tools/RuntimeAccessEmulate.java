// Bounded offline machine instruction execution using Ghidra's shared p-code VM.
// @category RuntimeAccess
import ghidra.app.script.GhidraScript;
import ghidra.app.emulator.EmulatorHelper;
import ghidra.app.emulator.AdaptedEmulator;
import ghidra.app.emulator.Emulator;
import ghidra.app.emulator.MemoryAccessFilter;
import ghidra.pcode.memstate.MemoryFaultHandler;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSpace;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.lang.Register;
import ghidra.program.model.lang.RegisterValue;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.symbol.Symbol;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** This is a pure-function ABI adapter, not an OS or device emulator. */
@SuppressWarnings("removal")
public class RuntimeAccessEmulate extends GhidraScript {
    private static final long STACK_LOW = 0x70010000L;
    private static final long STACK_HIGH = 0x70020000L;
    private static final long RETURN_PC = 0x70000000L;

    private static String quote(String value) {
        if (value == null) return "null";
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            if (c == '"' || c == '\\') out.append('\\').append(c);
            else if (c >= 0x20 && c <= 0x7e) out.append(c);
            else out.append(String.format("\\u%04x", (int)c));
        }
        return out.append('"').toString();
    }

    private static boolean stack(long offset, int size) {
        return size > 0 && offset >= STACK_LOW && offset < STACK_HIGH && size <= STACK_HIGH - offset;
    }

    private BigInteger argument(String value) {
        BigInteger result = new BigInteger(value);
        if (result.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) < 0 ||
                result.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) > 0) {
            throw new IllegalArgumentException("only signed 32-bit ABI arguments supported");
        }
        return result;
    }

    private void set(EmulatorHelper helper, String name, long value) {
        if (currentProgram.getRegister(name) != null) helper.writeRegister(name, value);
    }

    @Override public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length != 5 || currentProgram == null || !args[1].matches("[A-Za-z_][A-Za-z0-9_]{0,127}")) {
            throw new IllegalArgumentException("output, fixed function, two i32 arguments, max steps required");
        }
        BigInteger first = argument(args[2]);
        BigInteger second = argument(args[3]);
        int maximum = Integer.parseInt(args[4]);
        if (maximum < 1 || maximum > 100000) throw new IllegalArgumentException("step budget out of range");
        String language = currentProgram.getLanguageID().toString();
        if (!currentProgram.getExecutableFormat().contains("ELF")) {
            throw new IllegalArgumentException("only ELF ABI snapshots supported");
        }
        boolean x64 = language.equals("x86:LE:64:default");
        boolean x32 = language.equals("x86:LE:32:default");
        boolean arm64 = language.equals("AARCH64:LE:64:v8A");
        if (!x64 && !x32 && !arm64) throw new IllegalArgumentException("unsupported emulation ABI");
        List<Symbol> symbols = currentProgram.getSymbolTable().getGlobalSymbols(args[1]);
        if (symbols.size() != 1) throw new IllegalArgumentException("ambiguous or missing fixed function");
        Function function = currentProgram.getFunctionManager().getFunctionAt(symbols.get(0).getAddress());
        if (function == null || function.isExternal() || function.isThunk()) {
            throw new IllegalArgumentException("fixed function is not an internal analyzed function");
        }
        AddressSpace ram = currentProgram.getAddressFactory().getDefaultAddressSpace();
        if (currentProgram.getMemory().intersects(ram.getAddress(STACK_LOW), ram.getAddress(STACK_HIGH - 1)) ||
                currentProgram.getMemory().contains(ram.getAddress(RETURN_PC))) {
            throw new IllegalArgumentException("reserved emulation stack overlaps program snapshot");
        }
        // AdaptedEmulator invokes write filters before committing the store.
        EmulatorHelper helper = new EmulatorHelper(currentProgram) {
            @Override protected Emulator newEmulator() { return new AdaptedEmulator(this); }
        };
        String status = "unknown";
        String reason = "step_budget_exhausted";
        BigInteger returned = null;
        int executed = 0;
        List<String> trace = new ArrayList<>();
        Map<String,Integer> pcode = new TreeMap<>();
        final int[] writes = {0};
        try {
            helper.setMemoryFaultHandler(new MemoryFaultHandler() {
                @Override public boolean unknownAddress(Address address, boolean write) { return false; }
                @Override public boolean uninitializedRead(Address address, int size, byte[] data, int offset) { return false; }
            });
            helper.writeMemory(ram.getAddress(STACK_LOW), new byte[(int)(STACK_HIGH - STACK_LOW)]);
            for (String register : new String[]{"RAX","RBX","RCX","RDX","RSI","RDI","RBP","R8","R9","R10","R11","R12","R13","R14","R15", "EAX","EBX","ECX","EDX","ESI","EDI","EBP", "CF","PF","AF","ZF","SF","OF","DF"}) {
                set(helper, register, 0);
            }
            if (arm64) for (int index = 0; index < 31; ++index) set(helper, "x" + index, 0);
            long sp = STACK_HIGH - (x64 ? 8 : 16);
            helper.writeRegister(helper.getStackPointerRegister(), sp);
            if (arm64) {
                helper.writeRegister("x30", RETURN_PC);
                helper.writeRegister("x0", first.and(new BigInteger("ffffffff",16)));
                helper.writeRegister("x1", second.and(new BigInteger("ffffffff",16)));
            } else if (x64) {
                helper.writeMemoryValue(ram.getAddress(sp), 8, RETURN_PC);
                helper.writeRegister("RDI", first.and(new BigInteger("ffffffff",16)));
                helper.writeRegister("RSI", second.and(new BigInteger("ffffffff",16)));
            } else {
                helper.writeMemoryValue(ram.getAddress(sp), 4, RETURN_PC);
                helper.writeMemoryValue(ram.getAddress(sp + 4), 4, first.longValue());
                helper.writeMemoryValue(ram.getAddress(sp + 8), 4, second.longValue());
            }
            helper.writeRegister(helper.getPCRegister(), function.getEntryPoint().getOffset());
            Register context = currentProgram.getLanguage().getContextBaseRegister();
            if (context != null) {
                RegisterValue value = currentProgram.getProgramContext().getRegisterValue(context, function.getEntryPoint());
                if (value != null) helper.getEmulator().setContextRegisterValue(value);
            }
            helper.getEmulator().addMemoryAccessFilter(new MemoryAccessFilter() {
                @Override protected void processRead(AddressSpace space, long offset, int size, byte[] values) {
                    if (!space.equals(ram) || stack(offset, size)) return;
                    Address address = space.getAddress(offset);
                    MemoryBlock block = currentProgram.getMemory().getBlock(address);
                    if (block == null || !block.isInitialized() || size < 1 ||
                            !block.contains(address.add(size - 1))) {
                        throw new IllegalStateException("emulation_read_outside_initialized_snapshot_or_stack");
                    }
                }
                @Override protected void processWrite(AddressSpace space, long offset, int size, byte[] values) {
                    if (!space.equals(ram)) return;
                    if (!stack(offset, size)) throw new IllegalStateException("emulation_write_outside_private_stack");
                    ++writes[0];
                }
            });
            while (executed < maximum) {
                monitor.checkCancelled();
                Address pc = helper.getExecutionAddress();
                if (pc.getOffset() == RETURN_PC) {
                    status = "completed";
                    reason = "returned_to_private_sentinel";
                    returned = helper.readRegister(arm64 ? "x0" : x64 ? "RAX" : "EAX").and(new BigInteger("ffffffff",16));
                    break;
                }
                if (!function.getBody().contains(pc)) { reason = "execution_left_registered_function"; break; }
                Instruction instruction = currentProgram.getListing().getInstructionAt(pc);
                if (instruction == null) { reason = "undecoded_instruction"; break; }
                boolean unsupported = false;
                for (PcodeOp op : instruction.getPcode()) {
                    int code = op.getOpcode();
                    if (code == PcodeOp.CALLOTHER || code == PcodeOp.CALL || code == PcodeOp.CALLIND) unsupported = true;
                    pcode.put(op.getMnemonic(), pcode.getOrDefault(op.getMnemonic(), 0) + 1);
                }
                if (unsupported) { reason = "syscall_userop_or_nested_call_unsupported"; break; }
                if (trace.size() < 64) trace.add(pc.toString());
                if (!helper.step(monitor)) { reason = "pcode_step_failed:" + helper.getLastError(); break; }
                ++executed;
            }
        } catch (RuntimeException error) {
            reason = error.getMessage() == null ? "pcode_execution_error" : error.getMessage();
        } finally {
            helper.dispose();
        }
        StringBuilder out = new StringBuilder("{\"schema_version\":1,\"engine\":\"Ghidra EmulatorHelper p-code\",\"status\":")
            .append(quote(status)).append(",\"reason\":").append(quote(reason))
            .append(",\"language_id\":").append(quote(language))
            .append(",\"compiler_spec_id\":").append(quote(currentProgram.getCompilerSpec().getCompilerSpecID().toString()))
            .append(",\"program_sha256\":").append(quote(currentProgram.getExecutableSHA256()))
            .append(",\"function\":").append(quote(args[1]))
            .append(",\"abi\":").append(quote(arm64 ? "aapcs64_two_i32" : x64 ? "sysv_amd64_two_i32" : "cdecl_i386_two_i32"))
            .append(",\"input_i32\":[").append(first).append(',').append(second).append(']')
            .append(",\"returned_u32\":").append(returned == null ? "null" : returned)
            .append(",\"steps\":").append(executed).append(",\"max_steps\":").append(maximum)
            .append(",\"stack_writes\":").append(writes[0])
            .append(",\"trace_pc_prefix\":[");
        for (int index = 0; index < trace.size(); ++index) { if (index > 0) out.append(','); out.append(quote(trace.get(index))); }
        out.append("],\"pcode_counts\":{");
        boolean firstOp = true;
        for (Map.Entry<String,Integer> entry : pcode.entrySet()) {
            if (!firstOp) out.append(','); firstOp = false;
            out.append(quote(entry.getKey())).append(':').append(entry.getValue());
        }
        out.append("},\"native_target_executed\":false,\"OS_syscalls_supported\":false,\"device_memory_supported\":false,")
            .append("\"pcode_count_source\":\"decoded instruction p-code, not runtime op callbacks\",")
            .append("\"write_scope\":\"private_emulator_stack\",\"host_process_memory_access\":false,")
            .append("\"functional_equivalence_proven\":false,\"source_equivalence_proven\":false}");
        Files.writeString(Path.of(args[0]), out.toString(), StandardCharsets.UTF_8,
                          StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
    }
}
