#!/usr/bin/env python3
"""Owned-target neutral syscall evidence. Buffer arguments are never decoded."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import ipaddress
import json
from pathlib import Path
import re
import sys

CALLS={
 'file':{'open','openat','openat2','close','close_range','stat','lstat','fstat','newfstatat','statx',
         'getdents','getdents64','read','pread64','readv','preadv','preadv2','write','pwrite64','writev',
         'pwritev','pwritev2','dup','dup2','dup3','fcntl','chdir','fchdir','access','faccessat','faccessat2','readlink','readlinkat'},
 'memory':{'mmap','mmap2','munmap','mprotect','mremap','brk','madvise','mlock','munlock','mlockall','munlockall'},
 'process':{'execve','execveat','clone','clone3','fork','vfork','exit','exit_group','getpid','getppid','gettid','wait4','waitid','kill','tgkill'},
 'time':{'clock_gettime','clock_getres','gettimeofday','time','nanosleep','clock_nanosleep','timer_create','timer_settime','timer_gettime','timer_delete','timerfd_create','timerfd_settime','timerfd_gettime'},
 'random':{'getrandom'},
 'system':{'uname','sysinfo','getrlimit','prlimit64','getrusage','getuid','geteuid','getgid','getegid','getresuid','getresgid','personality','arch_prctl'},
 'scheduler':{'sched_getaffinity','sched_setaffinity','sched_getscheduler','sched_setscheduler','sched_getparam','sched_setparam','sched_yield','getpriority','setpriority','sched_getattr','sched_setattr','getcpu'},
 'network':{'socket','socketpair','connect','bind','listen','accept','accept4','getsockname','getpeername','sendto','sendmsg','sendmmsg','recvfrom','recvmsg','recvmmsg','shutdown','setsockopt','getsockopt','read','readv','write','writev'},
 'debug':{'ptrace','prctl','seccomp','capget','capset'},
 'device':{'ioctl','ioperm','iopl'}}
ATTRIBUTION={'execve','execveat','clone','clone3','fork','vfork','exit','exit_group'}
IO_SUPPORT={'open','openat','openat2','close','close_range','dup','dup2','dup3','fcntl','socket','socketpair','accept','accept4'}
RAW_IO={'read','pread64','readv','preadv','preadv2','write','pwrite64','writev','pwritev','pwritev2',
 'readlink','readlinkat','getdents','getdents64','execve','execveat','socketpair','sendto','sendmsg','sendmmsg',
 'recvfrom','recvmsg','recvmmsg','setsockopt','getsockopt'}
RAW=RAW_IO|CALLS['memory']|CALLS['time']|CALLS['random']|CALLS['system']|CALLS['scheduler']|CALLS['debug']|CALLS['device']|{'wait4','waitid'}


def shared_module():
    root=Path(__file__).resolve().parent
    path=root/'file_activity_shared.py'
    if not path.is_file():path=root/'file_activity_agent.py'
    spec=importlib.util.spec_from_file_location('environment_file_shared',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def frames(raw,shared):
    result=[];pending={}
    for line in raw.decode('ascii','strict').splitlines():
        row=shared.LINE.match(line)
        if row is None:continue
        tid,at,text=int(row[1]),shared._ns(row[2]),row[3]
        if text.endswith('<unfinished ...>'):
            if len(pending)<64:pending[tid]=(at,text[:-len('<unfinished ...>')])
            continue
        if text.startswith('<... '):
            resumed=re.match(r'^<\.\.\. ([a-z0-9_]+) resumed>(.*)$',text);before=pending.pop(tid,None)
            if resumed is None or before is None or not before[1].startswith(resumed[1]+'('):continue
            at,text=before[0],before[1]+resumed[2]
        duration=None;timing=re.search(r' <([0-9]+\.[0-9]+)>$',text)
        if timing:duration=shared._ns(timing[1]);text=text[:timing.start()]
        parsed=shared.CALL.match(text)
        if parsed is None:continue
        returned=shared.RETURN.match(parsed[3])
        if returned is None:continue
        # clone3 and sockaddr decoders may annotate input/output structs with
        # ``} => {``. Under -xx a literal path's '=>' is hex escaped, so this
        # formatting arrow can be removed without evaluating user text.
        try:args=shared._args(parsed[2].replace(' => ',' '))
        except ValueError:continue
        error=re.search(r'\s([A-Z][A-Z0-9_]{1,31})(?:\s|$)',parsed[3][returned.end():])
        result.append({'tid':tid,'time_ns':at,'duration_ns':duration,'name':parsed[1],
            'args':args,'return':shared._integer(returned[1]),'errno':error[1] if error else None})
        if len(result)>=65536:break
    return sorted(result,key=lambda row:row['time_ns'])


def endpoint(args,shared,visible):
    if len(args)<2:return None
    value=args[1]
    family=re.search(r'\bAF_(INET6|INET|UNIX)\b',value)
    if family is None:return None
    description=None
    if family[1]=='INET':
        address=re.search(r'inet_addr\("([^"\n]*)"\)',value)
        port=re.search(r'sin_port=htons\(([0-9]{1,5})\)',value)
        if address and port:
            try:description='AF_INET:'+str(ipaddress.IPv4Address(shared._decode(address[1])))+':'+str(int(port[1]))
            except ValueError:pass
    elif family[1]=='INET6':
        address=re.search(r'inet_pton\(AF_INET6, "([^"\n]*)"',value)
        port=re.search(r'sin6_port=htons\(([0-9]{1,5})\)',value)
        if address and port:
            try:description='AF_INET6:['+str(ipaddress.IPv6Address(shared._decode(address[1])))+']:'+str(int(port[1]))
            except ValueError:pass
    raw=(description or value).encode('utf-8','surrogateescape')
    evidence={'sha256':hashlib.sha256(raw).hexdigest(),'family':'AF_'+family[1],
        'redacted':True,'source':'strace sockaddr metadata','canonical_endpoint_parsed':description is not None}
    if visible and description is not None:evidence.update(value=description[:256],redacted=False)
    return evidence


def parse_environment(raw,profile,elapsed_ns,shared,base_parser):
    base=base_parser(raw.replace(b' => ',b' '),profile,elapsed_ns)
    calls=frames(raw,shared)
    actors={row['tid']:row for row in base['actors']}
    file_events={(row['tid'],row['timestamp_unix_ns'],row['syscall']):row for row in base['events']}
    selected=set(profile['categories']);counts={name:0 for name in profile['categories']}
    unknown_io=0;events=[];total=0;fd_kinds={};endpoints=set()
    generic_io={'read','pread64','readv','preadv','preadv2','write','pwrite64','writev','pwritev','pwritev2'}
    for item in calls:
        tid,name,args,returned=item['tid'],item['name'],item['args'],item['return']
        table=fd_kinds.setdefault(tid,{})
        fd=shared._integer(args[0]) if args else None
        if name in ('fork','vfork','clone','clone3') and returned and returned>0:
            flags=(False,False,False) if name in ('fork','vfork') else shared._clone_flags(args)
            fd_kinds[returned]=table if flags and flags[0] else dict(table) if flags else {}
        if name in ('open','openat','openat2') and returned is not None and returned>=0:table[returned]='file'
        if name in ('socket','accept','accept4') and returned is not None and returned>=0:table[returned]='network'
        if name=='close' and returned==0:table.pop(fd,None)
        if name=='close_range' and returned==0:
            flags=shared._integer(args[2]) if len(args)>2 else 0
            flags=flags or 0
            if 'CLOSE_RANGE_UNSHARE' in ','.join(args) or flags&2:table=dict(table);fd_kinds[tid]=table
            if not ('CLOSE_RANGE_CLOEXEC' in ','.join(args) or flags&4):
                first,last=shared._integer(args[0]),shared._integer(args[1])
                for number in list(table):
                    if first is None or last is None or first<=number<=last:table.pop(number,None)
        if name in ('execve','execveat') and returned==0:fd_kinds[tid]={}
        if name in ('dup','dup2','dup3') and returned is not None and returned>=0:
            if fd in table:table[returned]=table[fd]
        categories=[category for category in profile['categories'] if name in CALLS[category]]
        if not categories:continue
        category=categories[0]
        file_event=file_events.get((tid,item['time_ns'],name))
        if name in generic_io:
            known='file' if file_event and 'path' in file_event else table.get(fd)
            if known in selected:category=known
            elif known is None:category='io_unattributed';unknown_io+=1
            else:continue
        counts[category]=counts.get(category,0)+1;total+=1
        evidence={'source':'pinned strace selected syscall','buffers_decoded':False,
                  'attribution':'recorded_parent_graph' if actors.get(tid,{}).get('pid') is not None else 'tid_only_tgid_unknown'}
        if file_event and 'path' in file_event:evidence['path']=file_event['path']
        if name in ('connect','bind','accept','accept4','getsockname','getpeername'):
            address=endpoint(args,shared,profile.get('show_endpoints',False))
            if address:evidence['endpoint']=address;endpoints.add(address['sha256'])
        if name in ('ioctl','ptrace','prctl'):
            index=1 if name=='ioctl' else 0
            request=shared._integer(args[index]) if len(args)>index else None
            if request is not None:evidence['request_word']=request
        result={'return_value':returned,'errno':item['errno']}
        if name=='ioctl' and returned is not None and returned>0:
            result={'return_value':None,'errno':item['errno'],'successful':True,'device_return_value_redacted':True}
        if len(events)<64:
            events.append({'source_kind':'environment_syscall','seq':total,'tid':tid,
                'pid':actors.get(tid,{}).get('pid'),'category':category,'operation':name,
                'timestamp_unix_ns':item['time_ns'],'duration_ns':item['duration_ns'],
                'result':result,'evidence':evidence})
    return {'source_kind':'environment_syscall','root_pid':base['root_pid'],'actors':base['actors'],
        'events':events,'parse_issues':base['parse_issues'],'root_exit_observed':base['root_exit_observed'],
        'events_truncated':total>len(events),'actors_truncated':base['actors_truncated'],
        'raw_lines':base['raw_lines'],'raw_trace_sha256':hashlib.sha256(raw).hexdigest(),
        'raw_trace_sha256_scope':base['raw_trace_sha256_scope'],
        'summary':{'category_counts':counts,'selected_categories':profile['categories'],
            'observed_events':total,'unattributed_io_calls':unknown_io,'distinct_endpoint_digests':len(endpoints),
            'observed_events_per_second':round(total/max(elapsed_ns/1e9,.001),3)},
        'payloads_captured':False,'file_contents_captured':False,'network_payloads_captured':False,
        'device_output_buffers_captured':False,'directory_entry_buffers_captured':False,
        'supporting_attribution_syscalls_included':True,'hardware_instruction_coverage':False,
        'library_api_coverage':False,'endpoint_data_is_authority':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host-pidfd',type=int,required=True);args=parser.parse_args()
    request=sys.stdin.buffer.readline(65537)
    if len(request)>65536 or not request.endswith(b'\n'):return 2
    try:
        config=json.loads(request);shared=shared_module();base=shared.parse_trace
        selected=set(ATTRIBUTION)
        for category in config['categories']:selected.update(CALLS[category])
        if any(category in config['categories'] for category in ('file','network')):selected.update(IO_SUPPORT)
        shared.SYSCALLS=','.join(sorted(selected));shared.RAW=','.join(sorted(RAW&selected))
        shared.parse_trace=lambda raw,profile,elapsed:parse_environment(raw,profile,elapsed,shared,base)
        result=shared.run(config,args.host_pidfd)
        if result is not None:
            result['limitations']=['Only selected kernel syscalls are observed; libc sysconf and vDSO calls may have no syscall',
                'Direct hardware instructions, user-space caches, mmap accesses and io_uring operations are not full API coverage',
                'Send/recv/read/write/device buffers remain raw; endpoint metadata is available only on decoded sockaddr calls']
            while len(json.dumps(result,ensure_ascii=True,separators=(',',':')).encode())>56000 and result['events']:
                result['events'].pop();result['events_truncated']=True;result['truncated']=True
            print(json.dumps(result,ensure_ascii=True,separators=(',',':')),flush=True)
        return 0
    except Exception:
        print(json.dumps({'status':'unknown','error':'environment_worker_failed','effect_dispatched':True}),flush=True);return 2


if __name__=='__main__':raise SystemExit(main())
