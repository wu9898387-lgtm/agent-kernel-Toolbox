#!/usr/bin/env python3
"""Private bounded angr worker. Only the fixed host adapter writes its request."""
import hashlib
import json
import logging
from pathlib import Path
import sys

logging.disable(logging.CRITICAL)
import angr
from angr.sim_type import SimTypeFunction, SimTypeNum

claripy = angr.claripy


class UnsupportedState(RuntimeError):
    pass


def expression(value):
    text = str(value)
    return {'text': text[:4096], 'sha256': hashlib.sha256(text.encode()).hexdigest(),
            'truncated': len(text) > 4096, 'variables': sorted(value.variables)[:64]}


def execute(request):
    profile = request['profile']
    exporting = request.get('export_ast', False)
    project = angr.Project(request['target'], auto_load_libs=False, use_sim_procedures=False)
    if profile.get('expected_architecture', project.arch.name) != project.arch.name:
        raise UnsupportedState('native_symbolic_architecture_mismatch')
    entry = profile['entry']
    if entry.startswith('0x'):
        entry = int(entry, 16)
    else:
        symbol = project.loader.find_symbol(entry)
        if symbol is None or symbol.owner is not project.loader.main_object:
            raise UnsupportedState('native_symbolic_entry_not_in_binary')
        entry = symbol.rebased_addr
    def region(address):
        main = project.loader.main_object
        return main.find_segment_containing(address) or main.find_section_containing(address)
    segment = region(entry)
    if segment is None or not segment.is_executable:
        raise UnsupportedState('native_symbolic_entry_not_executable')
    sources, domains, input_names, arguments = {}, {}, {}, []
    def source(row):
        name, bits = row['name'], row['bits']
        if 'value' in row:
            domains[name] = {'bits': bits, 'constant': row['value']}
            return claripy.BVV(row['value'], bits)
        symbol = claripy.BVS('source_' + name, bits, explicit_name=True)
        sources[name] = symbol
        input_names.update({variable: name for variable in symbol.variables})
        domains[name] = {'bits': bits, 'minimum': row.get('minimum', 0),
                         'maximum': row.get('maximum', (1 << bits) - 1)}
        return symbol
    for row in profile.get('arguments', []):
        arguments.append(source(row))
    return_bits = profile.get('return_bits', 32)
    prototype = SimTypeFunction([SimTypeNum(row['bits'], signed=False)
        for row in profile.get('arguments', [])], SimTypeNum(return_bits, signed=False)).with_arch(project.arch)
    cc = project.factory.cc()
    if cc is None:
        raise UnsupportedState('native_symbolic_calling_convention_unavailable')
    sentinel = 0x7fff0000
    if project.loader.main_object.contains_addr(sentinel):
        raise UnsupportedState('native_symbolic_return_sentinel_conflict')
    state = project.factory.call_state(entry, *arguments, cc=cc, prototype=prototype, ret_addr=sentinel)
    if exporting and project.arch.name in ('AMD64', 'X86', 'AARCH64', 'ARMEL', 'ARMHF'):
        # VEX's COPY flags operation is zero on these architectures. Incoming
        # ABI-undefined flags are environment state, not known constant zero.
        # Any dependence remaining in a return/guard is rejected below.
        if all(name in project.arch.registers for name in ('cc_op', 'cc_dep1', 'cc_dep2', 'cc_ndep')):
            width = project.arch.registers['cc_dep1'][1] * 8
            state.regs.cc_op = 0
            state.regs.cc_dep1 = claripy.BVS('unmodeled_initial_flags', width, explicit_name=True)
            state.regs.cc_dep2 = 0
            state.regs.cc_ndep = 0
    # SimSolver itself accepts arbitrary attributes; assigning .timeout there
    # silently does nothing. Configure the actual Claripy solver instead.
    state.solver._solver.timeout = profile.get('solver_timeout_ms', 2000)
    stack = state.solver.eval(state.regs.sp)
    def in_main(address, size, writable=False):
        found = region(address)
        return (found is not None and address + size - 1 <= found.max_addr
                and (found.is_writable and not found.is_executable if writable else found.is_readable))
    for row in profile.get('memory', []):
        address = int(row['address'], 16)
        if not in_main(address, row['bits'] // 8, writable=True):
            raise UnsupportedState('native_symbolic_memory_requires_writable_data_segment')
        state.memory.store(address, source(row), endness=project.arch.memory_endness)
    for name, symbol in sources.items():
        state.solver.add(symbol.UGE(domains[name]['minimum']), symbol.ULE(domains[name]['maximum']))
    def concrete(current, value):
        if type(value) is int:
            return value
        values = current.solver.eval_upto(value, 2)
        if len(values) != 1:
            raise UnsupportedState('native_symbolic_symbolic_address_or_size')
        return values[0]
    def memory_guard(current, operation):
        address = concrete(current, getattr(current.inspect, operation + '_address'))
        length = concrete(current, getattr(current.inspect, operation + '_length'))
        if not 0 < length <= 4096:
            raise UnsupportedState('native_symbolic_memory_access_budget')
        # Only simulated ordinary ELF memory and the bounded call stack. This
        # never reads a device or the host process at the requested address.
        on_stack = stack - 65536 <= address and address + length <= stack + 65536
        if not (on_stack or in_main(address, length, writable=operation == 'mem_write')):
            raise UnsupportedState('native_symbolic_memory_outside_model')
        if exporting and not on_stack:
            segment = region(address)
            if operation == 'mem_write':
                raise UnsupportedState('native_translation_nonstack_write')
            if segment is None or segment.is_writable:
                raise UnsupportedState('native_translation_mutable_global_read')
    def trace_memory(current, operation):
        value = getattr(current.inspect, operation + '_expr')
        variables = getattr(value, 'variables', frozenset())
        taint = sorted({input_names[v] for v in variables if v in input_names})
        events = current.globals.get('tainted_memory', ())
        if taint and len(events) < 64:
            current.globals['tainted_memory'] = events + ({'operation': operation,
                'address': hex(concrete(current, getattr(current.inspect, operation + '_address'))),
                'sources': taint},)
        elif taint:
            current.globals['tainted_memory_trace_truncated'] = True
    def exit_trace(current):
        value = current.inspect.exit_guard
        inherited = set(current.globals.get('branch_sources', ()))
        inherited.update(input_names[v] for v in getattr(value, 'variables', ()) if v in input_names)
        current.globals['branch_sources'] = tuple(sorted(inherited))
    state.inspect.b('mem_read', when=angr.BP_BEFORE, action=lambda s: memory_guard(s, 'mem_read'))
    state.inspect.b('mem_read', when=angr.BP_AFTER, action=lambda s: trace_memory(s, 'mem_read'))
    state.inspect.b('mem_write', when=angr.BP_BEFORE, action=lambda s: memory_guard(s, 'mem_write'))
    state.inspect.b('mem_write', when=angr.BP_BEFORE, action=lambda s: trace_memory(s, 'mem_write'))
    state.inspect.b('exit', when=angr.BP_BEFORE, action=exit_trace)
    def reject_syscall(_):
        raise UnsupportedState('native_symbolic_syscall_outside_function_model')
    state.inspect.b('syscall', when=angr.BP_BEFORE, action=reject_syscall)
    manager = project.factory.simulation_manager(state, save_unconstrained=True, save_unsat=True)
    paths, reasons = [], set()
    export_nodes, export_ids, export_paths, export_raw = [], {}, [], []
    def encode_ast(value):
        if not isinstance(value, claripy.ast.Base):
            raise UnsupportedState('native_translation_untyped_ast')
        key = hash(value)
        if key in export_ids:
            # Hash collisions must not merge different expressions.
            index, original = export_ids[key]
            if not value.identical(original):
                raise UnsupportedState('native_translation_ast_hash_collision')
            return index
        if len(export_nodes) >= 2048:
            raise UnsupportedState('native_translation_ast_node_budget')
        arguments = []
        for item in value.args:
            if isinstance(item, claripy.ast.Base): arguments.append({'ref': encode_ast(item)})
            elif type(item) is bool: arguments.append({'bool': item})
            elif type(item) is int: arguments.append({'int': item})
            elif type(item) is str and len(item) <= 128: arguments.append({'string': item})
            else: raise UnsupportedState('native_translation_ast_literal_unsupported')
        if len(export_nodes) >= 2048:
            raise UnsupportedState('native_translation_ast_node_budget')
        index = 'n' + str(len(export_nodes))
        export_nodes.append({'id': index, 'sort': 'bool' if isinstance(value, claripy.ast.Bool) else 'bv',
                             'bits': value.size(), 'op': value.op, 'args': arguments})
        export_ids[key] = (index, value)
        return index
    returned = 0
    step = 0
    while manager.active:
        for current in list(manager.active):
            if current.addr != sentinel:
                if (project.is_hooked(current.addr) or not in_main(current.addr, 1)
                        or not region(current.addr).is_executable):
                    manager.active.remove(current)
                    reasons.add('native_symbolic_external_call_or_execution')
                elif exporting:
                    # CPUID, RDTSC and other environment/device helpers may
                    # otherwise become concrete model values. They cannot be
                    # frozen into a supposedly pure portable integer function.
                    block = project.factory.block(current.addr, num_inst=32).vex
                    if any(item.tag == 'Ist_Dirty' for item in block.statements):
                        manager.active.remove(current)
                        reasons.add('native_translation_dirty_environment_operation')
                continue
            manager.active.remove(current)
            returned += 1
            output = cc.return_val(prototype.returnty).get_value(current)
            constraints = list(current.solver.constraints)
            unknown = set(output.variables).union(*(set(c.variables) for c in constraints)) - set(input_names)
            if unknown:
                reasons.add('native_symbolic_unmodeled_state_in_result_or_constraints')
                continue
            if request['expected_return'] is not None:
                current.solver.add(output == request['expected_return'])
            if not current.solver.satisfiable():
                continue
            witness = {name: current.solver.eval(symbol) for name, symbol in sources.items()}
            witness.update({name: row['constant'] for name, row in domains.items() if 'constant' in row})
            paths.append({'return_expression': expression(output),
                'path_constraints': [expression(c) for c in current.solver.constraints[:32]],
                'path_constraints_truncated': len(current.solver.constraints) > 32,
                'data_taint_sources': sorted({input_names[v] for v in output.variables if v in input_names}),
                'control_taint_sources': list(current.globals.get('branch_sources', ())),
                'tainted_memory': list(current.globals.get('tainted_memory', ())),
                'tainted_memory_trace_truncated': current.globals.get('tainted_memory_trace_truncated', False),
                'witness_inputs': witness, 'witness_return': current.solver.eval(output),
                'basic_blocks': current.history.block_count})
            if exporting:
                conditions = list(current.solver.constraints)
                export_paths.append({'return': encode_ast(output),
                                     'constraints': [encode_ast(item) for item in conditions]})
                export_raw.append((claripy.And(*conditions), output))
            if len(paths) >= profile.get('max_paths', 16):
                if manager.active:
                    reasons.add('native_symbolic_path_budget')
                break
        if reasons & {'native_symbolic_path_budget'}:
            break
        if not manager.active:
            break
        if step >= profile.get('max_steps', 256):
            reasons.add('native_symbolic_step_budget')
            break
        if len(manager.active) > profile.get('max_states', 128):
            reasons.add('native_symbolic_state_budget')
            break
        try:
            manager.step(num_inst=32)
        except UnsupportedState as error:
            reasons.add(str(error))
            break
        except Exception as error:
            reasons.add('native_symbolic_engine_exception_' + type(error).__name__[:40])
            break
        step += 1
        if manager.errored:
            reasons.add('native_symbolic_engine_errored_path')
            manager.errored.clear()
        if manager.unconstrained:
            reasons.add('native_symbolic_unconstrained_execution')
            manager.unconstrained.clear()
        if manager.deadended:
            reasons.add('native_symbolic_unexpected_termination')
            manager.deadended.clear()
        manager.unsat.clear()
    complete = not reasons and not manager.active
    status = ('analyzed' if complete else 'unknown') if request['expected_return'] is None else (
        'sat' if paths else 'unsat' if complete else 'unknown')
    result = {'engine': 'angr', 'angr_version': angr.__version__, 'IR': 'VEX',
        'architecture': project.arch.name, 'bits': project.arch.bits,
        'byte_order': str(project.arch.memory_endness), 'calling_convention': type(cc).__name__,
        'solver_timeout_ms': state.solver._solver.timeout,
        'entry': hex(entry), 'execution_scope': 'native_function_with_reported_initial_state',
        'input_domains': domains, 'solver_status': status, 'complete_exploration': complete,
        'incomplete_reasons': sorted(reasons), 'returned_paths': returned, 'exploration_steps': step,
        'paths': paths, 'taint_semantics': 'symbolic_AST_data_and_observed_branch_dependencies',
        'universal_native_program_proof': False, 'host_or_live_memory_access': False}
    if exporting:
        coverage, consistent = False, False
        if complete and export_raw and request['expected_return'] is None:
            # Use a fresh solver with the same explicit input domains. It does
            # not include a particular returned path's conditions.
            proof = claripy.Solver(timeout=profile.get('solver_timeout_ms', 2000))
            proof.add([bound for name, symbol in sources.items() for bound in (
                symbol.UGE(domains[name]['minimum']), symbol.ULE(domains[name]['maximum']))])
            coverage = not proof.satisfiable(extra_constraints=[claripy.Not(claripy.Or(*(c for c, _ in export_raw)))])
            consistent = True
            for index, (condition, output) in enumerate(export_raw):
                for other_condition, other_output in export_raw[index + 1:]:
                    if proof.satisfiable(extra_constraints=[condition, other_condition, output != other_output]):
                        consistent = False
        full_domains = (not profile.get('memory') and all('value' not in row
            and row.get('minimum', 0) == 0 and row.get('maximum', (1 << row['bits']) - 1) == (1 << row['bits']) - 1
            for row in profile.get('arguments', [])))
        result['ast_export'] = {'schema_version': 1, 'nodes': export_nodes, 'paths': export_paths,
            'source_arguments': [{'name': row['name'], 'symbol': 'source_' + row['name'], 'bits': row['bits']}
                                 for row in profile.get('arguments', [])],
            'full_unsigned_argument_domains': full_domains,
            'complete_return_coverage': coverage, 'overlapping_returns_consistent': consistent,
            'pure_function_checked': complete and coverage and consistent and full_domains,
            'effects_model': 'call_stack_and_immutable_binary_data_only'}
    return result


def verify_ir(request):
    """Independently rebuild native AST and SSA in SMT, then seek a mismatch.

    Native shifts use Claripy's bitvector semantics. SSA shifts explicitly use
    count modulo the SSA word width. This intentionally does not reuse lowering
    code, so width/shift/sign-extension defects produce counterexamples.
    """
    exported, module, arguments = request['ast_export'], request['module'], request['arguments']
    sources = {'source_' + row['name']: claripy.BVS('source_' + row['name'], row['bits'], explicit_name=True)
               for row in arguments}
    native = {}
    def argument(value):
        if set(value) == {'ref'}: return native[value['ref']]
        if set(value) == {'int'} and type(value['int']) is int: return value['int']
        if set(value) == {'bool'} and type(value['bool']) is bool: return value['bool']
        if set(value) == {'string'} and type(value['string']) is str: return value['string']
        raise UnsupportedState('native_translation_verifier_literal')
    def fold(values, function):
        result = values[0]
        for value in values[1:]: result = function(result, value)
        return result
    for node in exported['nodes']:
        values = [argument(value) for value in node['args']]
        op = node['op']
        if op == 'BVS':
            value = sources[values[0]]
            if value.size() != values[1]: raise UnsupportedState('native_translation_verifier_source_width')
        elif op == 'BVV': value = claripy.BVV(*values)
        elif op == 'BoolV': value = claripy.BoolV(*values)
        elif op == '__add__': value = fold(values, lambda a, b: a + b)
        elif op == '__sub__': value = values[0] - values[1]
        elif op == '__mul__': value = fold(values, lambda a, b: a * b)
        elif op == '__and__': value = fold(values, lambda a, b: a & b)
        elif op == '__or__': value = fold(values, lambda a, b: a | b)
        elif op == '__xor__': value = fold(values, lambda a, b: a ^ b)
        elif op == '__neg__': value = -values[0]
        elif op == '__invert__': value = ~values[0]
        elif op == '__lshift__': value = values[0] << values[1]
        elif op == '__rshift__': value = values[0] >> values[1]
        elif op == 'LShR': value = claripy.LShR(*values)
        elif op == '__eq__': value = values[0] == values[1]
        elif op == '__ne__': value = values[0] != values[1]
        elif op in ('ULT', 'ULE', 'UGT', 'UGE', 'SLT', 'SLE', 'SGT', 'SGE',
                    'And', 'Or', 'Not', 'If', 'Extract', 'Concat', 'ZeroExt', 'SignExt', 'Reverse'):
            value = getattr(claripy, op)(*values)
        elif op == 'Xor': value = fold(values, lambda a, b: a != b)
        else: raise UnsupportedState('native_translation_verifier_unsupported_ast')
        if value.size() != node['bits']:
            raise UnsupportedState('native_translation_verifier_node_width')
        native[node['id']] = value
    width = module['width']
    words = {row['name']: claripy.ZeroExt(width - row['bits'], sources['source_' + row['name']])
             for row in arguments}
    zero, one = claripy.BVV(0, width), claripy.BVV(1, width)
    for instruction in module['instructions']:
        op = instruction['op']
        values = [words[name] for name in instruction.get('args', [])]
        if op == 'const': value = claripy.BVV(instruction['value'], width)
        elif op == 'add': value = values[0] + values[1]
        elif op == 'sub': value = values[0] - values[1]
        elif op == 'mul': value = values[0] * values[1]
        elif op == 'and': value = values[0] & values[1]
        elif op == 'or': value = values[0] | values[1]
        elif op == 'xor': value = values[0] ^ values[1]
        elif op == 'not': value = ~values[0]
        elif op == 'neg': value = -values[0]
        elif op == 'shl': value = values[0] << (values[1] & claripy.BVV(width - 1, width))
        elif op == 'lshr': value = claripy.LShR(values[0], values[1] & claripy.BVV(width - 1, width))
        elif op == 'eq': value = claripy.If(values[0] == values[1], one, zero)
        elif op == 'ult': value = claripy.If(claripy.ULT(*values), one, zero)
        elif op == 'slt': value = claripy.If(claripy.SLT(*values), one, zero)
        elif op == 'select': value = claripy.If(values[0] != zero, values[1], values[2])
        else: raise UnsupportedState('native_translation_verifier_unsupported_ssa')
        words[instruction['id']] = value
    output = words[module['result']]
    conditions, mismatches = [], []
    for path in exported['paths']:
        condition = claripy.And(*(native[name] for name in path['constraints']))
        returned = native[path['return']]
        conditions.append(condition)
        mismatches.append(claripy.And(condition, output != claripy.ZeroExt(width - returned.size(), returned)))
    solver = claripy.Solver(timeout=request['solver_timeout_ms'])
    if solver.satisfiable(extra_constraints=[claripy.Not(claripy.Or(*conditions))]):
        return {'equivalent': False, 'reason': 'native_return_coverage_incomplete'}
    mismatch = claripy.Or(*mismatches)
    if solver.satisfiable(extra_constraints=[mismatch]):
        solver.add([mismatch])
        return {'equivalent': False, 'reason': 'counterexample',
                'counterexample': {row['name']: solver.eval(sources['source_' + row['name']], 1)[0] for row in arguments}}
    def digest(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
            allow_nan=False, separators=(',', ':')).encode()).hexdigest()
    return {'schema_version': 1, 'equivalent': True, 'return_coverage_proven': True,
        'scope': 'full_unsigned_argument_domains_under_checked_native_function_model',
        'ast_sha256': digest(exported), 'ir_sha256': digest(module),
        'solver_timeout_ms': request['solver_timeout_ms'], 'engine': 'angr_Claripy',
        'engine_version': angr.__version__}


def main():
    if sys.argv[1:] == ['--inspect']:
        print(json.dumps({'engine': 'angr', 'angr_version': angr.__version__,
            'IR': 'VEX', 'solver_frontend': claripy.__name__,
            'supported_operation': 'bounded_native_function_symbolic_execution',
            'live_process_control': False}))
        return 0
    if len(sys.argv) == 3 and sys.argv[1] == '--verify-ir':
        try:
            raw = Path(sys.argv[2]).read_bytes()
            if len(raw) > 512 * 1024: raise UnsupportedState('native_translation_verifier_request_budget')
            result = verify_ir(json.loads(raw))
        except Exception as error:
            result = {'equivalent': False, 'reason': str(error) if isinstance(error, UnsupportedState)
                      else 'native_translation_equivalence_unknown_' + type(error).__name__[:40]}
        print(json.dumps(result, ensure_ascii=True, allow_nan=False, separators=(',', ':')))
        return 0
    try:
        raw = Path(sys.argv[1]).read_bytes()
        if len(raw) > 65536:
            raise ValueError('native_symbolic_request_budget')
        request = json.loads(raw)
        result = execute(request)
    except Exception as error:
        result = {'engine': 'angr', 'angr_version': angr.__version__, 'solver_status': 'unknown',
            'complete_exploration': False, 'paths': [],
            'incomplete_reasons': [str(error) if isinstance(error, UnsupportedState)
                else 'native_symbolic_worker_exception_' + type(error).__name__[:40]]}
    encoded = json.dumps(result, ensure_ascii=True, allow_nan=False, separators=(',', ':'))
    if len(encoded) > 240000:
        encoded = json.dumps({'engine': 'angr', 'solver_status': 'unknown', 'complete_exploration': False,
                              'paths': [], 'incomplete_reasons': ['native_symbolic_result_budget']})
    print(encoded)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
