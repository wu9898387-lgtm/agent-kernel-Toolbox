#!/usr/bin/env python3
"""Check installed toolbox files and optionally exercise isolated stdio MCP fixtures."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def protocol_passed(report, exit_code, protocol, server_info):
    """Require the selected release and every promised fixture on the actual wire."""
    if type(report) is not dict:
        return False
    checked = report.get('tools_checked')
    required = ('runtime.status', 'runtime.capabilities', 'build.inspect', 'snapshot.summary',
                'snapshot.scalars', 'replay.open', 'replay.fork', 'replay.run', 'replay.compare',
                'replay.release', 'ir.evaluate_replay')
    return (exit_code == 0 and report.get('passed') is True
            and report.get('protocol_negotiated') == protocol
            and report.get('server_info') == server_info
            and report.get('catalog_checked') is True and report.get('diagnostics_checked') == 3
            and report.get('snapshot_handoff') == 'typed_reference' and report.get('replay_fixture') == 'passed'
            and type(checked) is dict and all(checked.get(name) == 'passed' for name in required))


def load_verifier():
    spec = importlib.util.spec_from_file_location('toolbox_integrity', ROOT / 'verify-runtime.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    return verifier


def check(with_mcp=False, verifier=None):
    if verifier is None:
        verifier = load_verifier()
    integrity = verifier.verify_directory(ROOT)
    sys.path.insert(0, str(ROOT / 'runtime-access.pyz'))
    from observation_extension.runtime_catalog import SPECS
    from observation_extension.advanced_tools import CONFIG_KEYS
    from observation_extension.runtime_mcp import VERSIONS
    from observation_extension.version import PACKAGE_ID, PACKAGE_NAME, VERSION
    from observation_extension.translation import target_catalog
    manifest = json.loads((ROOT / 'runtime-manifest.json').read_text())
    if (manifest['id'], manifest['name'], manifest['version']) != (PACKAGE_ID, PACKAGE_NAME, VERSION):
        raise ValueError('runtime_identity_mismatch')
    if (manifest['tool_count'] != len(SPECS)
            or manifest['tool_families'] != len({name.split('.')[0] for name in SPECS})
            or manifest['mcp_protocol_versions'] != list(VERSIONS)
            or manifest['extension_sections'] != sorted(CONFIG_KEYS)):
        raise ValueError('runtime_catalog_mismatch')
    if manifest.get('compile_target_count') != len(target_catalog()):
        raise ValueError('runtime_target_catalog_mismatch')
    result = {'passed': True, 'name': PACKAGE_NAME, 'version': VERSION,
              'integrity': integrity, 'tools': len(SPECS),
              'tool_families': manifest['tool_families'],
              'python': sys.version.split()[0],
              'optional_commands_found': {name: shutil.which(name) is not None
                  for name in ('node', 'gcc', 'clang', 'cargo', 'java', 'strace')},
              'mcp_checked': with_mcp, 'all_backends_verified': False}
    if with_mcp:
        inspector = ROOT / 'skills/agent-kernel-toolbox/scripts/inspect_mcp.py'
        protocols = []
        for protocol in VERSIONS:
            exit_code = -1
            try:
                completed = subprocess.run([sys.executable, '-I', str(inspector), '--entry',
                    str(ROOT / 'runtime-access.pyz'), '--protocol', protocol, '--replay-self-test'],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=100)
                exit_code = completed.returncode
                report = json.loads(completed.stdout)
            except subprocess.TimeoutExpired:
                report = {'error': 'mcp_inspection_timeout'}
            except OSError as error:
                report = {'error': 'mcp_inspection_start_failed', 'reason': str(error)}
            except (ValueError, RecursionError):
                report = None
            if type(report) is not dict:
                report = {'error': 'invalid_mcp_inspection_output'}
            checked = report.get('tools_checked', {})
            passed = protocol_passed(report, exit_code, protocol, {'name': PACKAGE_NAME, 'version': VERSION})
            protocols.append({'protocol': protocol, 'passed': passed,
                              'scope': report.get('scope'), 'server_info': report.get('server_info'),
                              'successful_receipts_verified': report.get('successful_receipts_verified'),
                              'tools_checked': checked,
                              'snapshot_handoff': report.get('snapshot_handoff'),
                              'replay_fixture': report.get('replay_fixture')})
            if not passed:
                protocols[-1]['failure'] = report
                result.update(passed=False, mcp_failure=report)
        result['mcp_protocols'] = protocols
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mcp', action='store_true',
                        help='Check both MCP protocols with generated snapshots, branched record replay and a pure IR module')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    report = None
    try:
        verifier = load_verifier()
        if args.report is not None:
            destination = args.report.resolve()
            exists = destination.exists()
            for name in verifier.ARCHIVE_FILES | {'CONTENTS.json'}:
                member = ROOT / name
                if destination == member.resolve() or (exists and member.exists() and destination.samefile(member)):
                    parser.error('--report must be separate from installed toolbox files')
            report = args.report
        result = check(args.mcp, verifier)
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, AttributeError,
            ImportError, subprocess.SubprocessError) as error:
        result = {'passed': False, 'error': str(error), 'all_backends_verified': False}
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if report is not None:
        try:
            report.write_text(encoded, encoding='utf-8')
        except OSError as error:
            print(encoded, end='')
            print(json.dumps({'error': 'installation_report_write_failed', 'reason': str(error)}),
                  file=sys.stderr)
            return 1
    print(encoded, end='')
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
