package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const tableCap = 2 << 20
const fdCap = 4096
const connectionCap = 128

func signalPIDFD(fd int, sig syscall.Signal) error {
	// Linux's common syscall allocation; MIPS retains its ABI base.
	number := uintptr(424)
	switch runtime.GOARCH {
	case "mips", "mipsle":
		number += 4000
	case "mips64", "mips64le":
		number += 5000
	case "386", "amd64", "arm", "arm64", "riscv64", "ppc64", "ppc64le", "s390x", "loong64":
	default:
		return errors.New("unsupported_pidfd_abi")
	}
	_, _, errno := syscall.Syscall6(number, uintptr(fd), uintptr(sig), 0, 0, 0, 0)
	if errno != 0 {
		return errno
	}
	return nil
}

func watchdog(pidfd, control int) error {
	pipe := os.NewFile(uintptr(control), "control")
	defer pipe.Close()
	commands := make(chan byte, 2)
	go func() {
		defer close(commands)
		var b [1]byte
		for {
			if _, err := io.ReadFull(pipe, b[:]); err != nil {
				return
			}
			commands <- b[0]
		}
	}()
	if _, err := os.Stdout.Write([]byte{'A'}); err != nil {
		return err
	}
	select {
	case command, ok := <-commands:
		if !ok || command != 'S' {
			return nil
		}
	case <-time.After(time.Second):
		return errors.New("watchdog_arm_deadline")
	}
	// Only this worker issues STOP. A delayed controller cannot stop a target
	// after its watchdog lease has already expired.
	if err := signalPIDFD(pidfd, syscall.SIGSTOP); err != nil {
		return err
	}
	resumeOwed := true
	defer func() {
		if resumeOwed {
			_ = signalPIDFD(pidfd, syscall.SIGCONT)
		}
	}()
	if _, err := os.Stdout.Write([]byte{'S'}); err != nil {
		return err
	}
	select {
	case command, ok := <-commands:
		// D follows the controller's verified resume. EOF and other bytes resume.
		if ok && command == 'D' {
			resumeOwed = false
		}
	case <-time.After(3 * time.Second):
	}
	return nil
}

type endpoint struct {
	Address string `json:"address"`
	Port    uint16 `json:"port"`
}
type connection struct {
	Protocol   string    `json:"protocol"`
	Inode      string    `json:"socket_inode"`
	FDs        []int     `json:"fds"`
	State      string    `json:"state"`
	Local      *endpoint `json:"local,omitempty"`
	Remote     *endpoint `json:"remote,omitempty"`
	PathSHA256 string    `json:"path_sha256,omitempty"`
}
type connectionResult struct {
	Connections  []connection `json:"connections"`
	Namespace    string       `json:"network_namespace"`
	Descriptors  int          `json:"descriptors_examined"`
	SocketInodes int          `json:"socket_inodes_observed"`
	Unresolved   int          `json:"unresolved_socket_inodes"`
	Truncated    bool         `json:"truncated"`
	Unavailable  []string     `json:"unavailable_tables"`
	TableBytes   int          `json:"table_bytes_read"`
}

func readBounded(path string, limit int) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, int64(limit)+1))
	if err != nil || len(data) > limit {
		return nil, errors.New("native_probe_input_limit")
	}
	return data, nil
}

func address(raw string, v6 bool) (*endpoint, error) {
	parts := strings.Split(raw, ":")
	width := 8
	if v6 {
		width = 32
	}
	if len(parts) != 2 || len(parts[0]) != width || len(parts[1]) != 4 {
		return nil, errors.New("invalid_socket_address")
	}
	ip := make(net.IP, width/2)
	for at := 0; at < len(parts[0]); at += 8 {
		word, err := strconv.ParseUint(parts[0][at:at+8], 16, 32)
		if err != nil {
			return nil, err
		}
		binary.NativeEndian.PutUint32(ip[at/2:at/2+4], uint32(word))
	}
	port, err := strconv.ParseUint(parts[1], 16, 16)
	if err != nil {
		return nil, err
	}
	return &endpoint{Address: ip.String(), Port: uint16(port)}, nil
}

var tcpStates = map[string]string{"01": "ESTABLISHED", "02": "SYN_SENT", "03": "SYN_RECV", "04": "FIN_WAIT1", "05": "FIN_WAIT2", "06": "TIME_WAIT", "07": "CLOSE", "08": "CLOSE_WAIT", "09": "LAST_ACK", "0A": "LISTEN", "0B": "CLOSING", "0C": "NEW_SYN_RECV"}

func parseInet(raw []byte, protocol string, sockets map[string][]int) ([]connection, error) {
	rows := []connection{}
	for index, line := range strings.Split(string(raw), "\n") {
		if index == 0 || strings.TrimSpace(line) == "" {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 10 {
			return nil, errors.New("invalid_socket_table")
		}
		fds, present := sockets[fields[9]]
		if !present {
			continue
		}
		local, err := address(fields[1], strings.HasSuffix(protocol, "6"))
		if err != nil {
			return nil, err
		}
		remote, err := address(fields[2], strings.HasSuffix(protocol, "6"))
		if err != nil {
			return nil, err
		}
		state := tcpStates[fields[3]]
		if state == "" {
			state = "0x" + fields[3]
		}
		if strings.HasPrefix(protocol, "udp") {
			state = "kernel_0x" + fields[3]
		}
		rows = append(rows, connection{Protocol: protocol, Inode: fields[9], FDs: fds, State: state, Local: local, Remote: remote})
		if len(rows) == connectionCap+1 {
			break
		}
	}
	return rows, nil
}

func parseUnix(raw []byte, sockets map[string][]int) ([]connection, error) {
	rows := []connection{}
	for index, line := range strings.Split(string(raw), "\n") {
		if index == 0 || strings.TrimSpace(line) == "" {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 7 {
			return nil, errors.New("invalid_socket_table")
		}
		fds, present := sockets[fields[6]]
		if !present {
			continue
		}
		row := connection{Protocol: "unix", Inode: fields[6], FDs: fds, State: "kernel_0x" + fields[5]}
		if len(fields) > 7 {
			// The digest is a correlator, not anonymization of guessable paths.
			name := strings.Join(fields[7:], " ")
			digest := sha256.Sum256([]byte(name))
			row.PathSHA256 = hex.EncodeToString(digest[:])
		}
		rows = append(rows, row)
		if len(rows) == connectionCap+1 {
			break
		}
	}
	return rows, nil
}

func connections(procfd int) (*connectionResult, error) {
	root := fmt.Sprintf("/proc/self/fd/%d", procfd)
	proc := os.NewFile(uintptr(procfd), "target-proc")
	defer proc.Close()
	info, err := proc.Stat()
	if err != nil || !info.IsDir() {
		return nil, errors.New("invalid_proc_descriptor")
	}
	stat, err := readBounded(root+"/stat", 16384)
	if err != nil || len(stat) == 0 {
		return nil, errors.New("invalid_proc_descriptor")
	}
	directory, err := os.Open(root + "/fd")
	if err != nil {
		return nil, err
	}
	names, err := directory.Readdirnames(fdCap + 1)
	directory.Close()
	if err != nil && err != io.EOF {
		return nil, err
	}
	if len(names) > fdCap {
		return nil, errors.New("descriptor_limit")
	}
	sockets := map[string][]int{}
	for _, name := range names {
		fd, err := strconv.Atoi(name)
		if err != nil {
			continue
		}
		link, err := os.Readlink(root + "/fd/" + name)
		if err != nil {
			continue
		}
		if !strings.HasPrefix(link, "socket:[") || !strings.HasSuffix(link, "]") {
			continue
		}
		inode := link[8 : len(link)-1]
		if _, err := strconv.ParseUint(inode, 10, 64); err != nil {
			return nil, err
		}
		sockets[inode] = append(sockets[inode], fd)
	}
	for inode := range sockets {
		sort.Ints(sockets[inode])
	}
	namespace, _ := os.Readlink(root + "/ns/net")
	result := &connectionResult{Connections: []connection{}, Namespace: namespace, Descriptors: len(names), SocketInodes: len(sockets), Unavailable: []string{}}
	resolved := map[string]bool{}
	for _, protocol := range []string{"tcp", "tcp6", "udp", "udp6", "unix"} {
		raw, err := readBounded(root+"/net/"+protocol, tableCap)
		if err != nil {
			result.Unavailable = append(result.Unavailable, protocol)
			continue
		}
		result.TableBytes += len(raw)
		var rows []connection
		if protocol == "unix" {
			rows, err = parseUnix(raw, sockets)
		} else {
			rows, err = parseInet(raw, protocol, sockets)
		}
		if err != nil {
			return nil, err
		}
		for _, row := range rows {
			if len(result.Connections) >= connectionCap {
				result.Truncated = true
				break
			}
			result.Connections = append(result.Connections, row)
			resolved[row.Inode] = true
		}
	}
	result.Unresolved = len(sockets) - len(resolved)
	return result, nil
}
