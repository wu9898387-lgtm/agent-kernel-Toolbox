module runtime-access/native-worker

go 1.23
