// A bounded native worker. Its authority consists only of inherited descriptors.
package main

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"runtime/debug"
	"strconv"
)

func descriptor(raw string) (int, error) {
	n, err := strconv.Atoi(raw)
	if err != nil || n < 3 || n > 65535 {
		return 0, fmt.Errorf("invalid_descriptor")
	}
	return n, nil
}

func main() {
	runtime.GOMAXPROCS(1)
	debug.SetMemoryLimit(32 << 20) // Soft GC limit; explicit input/output caps remain authoritative.
	if len(os.Args) < 3 {
		os.Exit(2)
	}
	fd, err := descriptor(os.Args[2])
	if err != nil {
		os.Exit(2)
	}
	switch os.Args[1] {
	case "watchdog":
		if len(os.Args) != 4 {
			os.Exit(2)
		}
		control, err := descriptor(os.Args[3])
		if err != nil {
			os.Exit(2)
		}
		if watchdog(fd, control) != nil {
			os.Exit(1)
		}
	case "connections":
		if len(os.Args) != 3 {
			os.Exit(2)
		}
		result, err := connections(fd)
		if err != nil {
			_ = json.NewEncoder(os.Stdout).Encode(map[string]string{"error": "native_connection_probe_failed"})
			os.Exit(1)
		}
		if json.NewEncoder(os.Stdout).Encode(result) != nil {
			os.Exit(1)
		}
	default:
		os.Exit(2)
	}
}
