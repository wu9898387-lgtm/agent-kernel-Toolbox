//go:build !linux

package main

import "errors"

func watchdog(int, int) error      { return errors.New("linux_pidfd_required") }
func connections(int) (any, error) { return nil, errors.New("linux_procfs_required") }
