#include "probe.h"
#if defined(__GNUC__) || defined(__clang__)
#define RA_EXPORT __attribute__((noinline,used,visibility("default"),patchable_function_entry(16,0)))
#define RA_PUBLISH(...) __asm__ __volatile__("" : : __VA_ARGS__ : "memory")
#else
#error "Build publication functions with a compiler providing a retained call barrier"
#endif
RA_EXPORT void ra_probe_object(uint64_t id, void *address, size_t size,
                               uint64_t generation, uint32_t type_slot) {
    RA_PUBLISH("r"(id),"r"(address),"r"(size),"r"(generation),"r"(type_slot));
}
RA_EXPORT void ra_probe_move(uint64_t id, void *address, size_t size, uint64_t generation) {
    RA_PUBLISH("r"(id),"r"(address),"r"(size),"r"(generation));
}
RA_EXPORT void ra_probe_retire(uint64_t id, uint64_t generation) {
    RA_PUBLISH("r"(id),"r"(generation));
}
