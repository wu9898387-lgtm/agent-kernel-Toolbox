#ifndef RUNTIME_PROBE_SDK_H
#define RUNTIME_PROBE_SDK_H
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Observational publication points. These do not allocate, copy, or mutate an
 * object. The application owns synchronization and must publish define/move
 * before using its new location, and retire before ending its lifetime.
 * type_slot binds to a compiler-derived layout in the installation profile.
 * generation identifies one object lifetime and stays stable across moves.
 * Reusing an ID for a new lifetime requires a larger generation. The monitor
 * tracks observed location epochs separately. IDs are not addresses. */
void ra_probe_object(uint64_t id, void *address, size_t size,
                     uint64_t generation, uint32_t type_slot);
void ra_probe_move(uint64_t id, void *address, size_t size, uint64_t generation);
void ra_probe_retire(uint64_t id, uint64_t generation);
#ifdef __cplusplus
}
#endif
#endif
