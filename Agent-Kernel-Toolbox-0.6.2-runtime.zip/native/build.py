#!/usr/bin/env python3
"""Compile the optional OpenGL interposer for this Linux host; never installs it globally."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('libagent_kernel_render.so'))
    args = parser.parse_args()
    compiler = shutil.which('c++') or shutil.which('g++')
    if compiler is None:
        parser.error('C++ compiler required')
    target = args.output.absolute()
    if target.exists() or target.is_symlink():
        parser.error('output must not already exist')
    source = Path(__file__).with_name('render_filter.cpp').resolve()
    with tempfile.TemporaryDirectory(prefix='ak-render-build-', dir=target.parent) as directory:
        output = Path(directory) / 'filter.so'
        subprocess.run([compiler, '-std=c++17', '-shared', '-fPIC', '-O2', '-Wall', '-Wextra', '-Werror',
                        str(source), '-o', str(output), '-ldl', '-pthread'], check=True, timeout=60)
        # Hard-link gives no-clobber publication of the fully compiled output.
        os.link(output, target)
    print(target)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
