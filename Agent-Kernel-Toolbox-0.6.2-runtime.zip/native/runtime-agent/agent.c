#define _POSIX_C_SOURCE 200809L
#include "agent.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <unistd.h>

#ifndef RA_BUILD_ID
#define RA_BUILD_ID "0000000000000000000000000000000000000000000000000000000000000000"
#endif
static const unsigned char magic[8] = {'R','A','0','5','5','E','N','V'};
static void put32(unsigned char *p, uint32_t v) {
    for (unsigned i=0; i<4u; ++i) p[i]=(unsigned char)(v >> (i*8u));
}
static void put64(unsigned char *p, uint64_t v) {
    for (unsigned i=0; i<8u; ++i) p[i]=(unsigned char)(v >> (i*8u));
}
static uint32_t get32(const unsigned char *p) {
    uint32_t v=0; for (unsigned i=0; i<4u; ++i) v |= (uint32_t)p[i] << (i*8u); return v;
}
static uint64_t get64(const unsigned char *p) {
    uint64_t v=0; for (unsigned i=0; i<8u; ++i) v |= (uint64_t)p[i] << (i*8u); return v;
}
static int hex(char c) {
    if (c>='0' && c<='9') return c-'0';
    if (c>='a' && c<='f') return c-'a'+10;
    return -1;
}
static int lock_agent(RAAgent *a) {
    int r; do { r=flock(a->fd, LOCK_EX); } while (r<0 && errno==EINTR); return r;
}
static int unlock_agent(RAAgent *a) { return flock(a->fd, LOCK_UN); }
static _Thread_local RAAgent *callback_agent;
static int enter_agent(RAAgent *a) {
    if(atomic_flag_test_and_set_explicit(&a->operation_gate,memory_order_acquire)) {errno=EBUSY;return -1;}
    return 0;
}
static int leave_agent(RAAgent *a,int result) {
    int saved=errno;atomic_flag_clear_explicit(&a->operation_gate,memory_order_release);errno=saved;return result;
}
static int try_lock_agent(RAAgent *a) { return flock(a->fd,LOCK_EX|LOCK_NB); }
static uint64_t process_start_ticks(void) {
    char text[4096];int fd=open("/proc/self/stat",O_RDONLY|O_CLOEXEC);
    if(fd<0) return 0;
    ssize_t count=read(fd,text,sizeof(text)-1u);(void)close(fd);
    if(count<=0) return 0;
    text[(size_t)count]='\0';char *part=strrchr(text,')');
    if(!part) return 0;
    ++part;
    for(unsigned field=3u;field<=22u;++field) {
        while(*part==' ') ++part;
        if(*part=='\0') return 0;
        if(field==22u) {char *end=NULL;errno=0;unsigned long long value=strtoull(part,&end,10);
            return (errno==0 && end!=part && (*end==' ' || *end=='\0'))?(uint64_t)value:0;}
        while(*part!=' ' && *part!='\0') ++part;
    }
    return 0;
}
int ra_agent_open(RAAgent *a, const char *path, const char *session_hex) {
    *a=(RAAgent){.operation_gate=ATOMIC_FLAG_INIT,.fd=-1};
    if (strlen(session_hex)!=32u) { errno=EINVAL; return -1; }
    for (size_t i=0;i<16u;++i) {
        int h=hex(session_hex[i*2u]), l=hex(session_hex[i*2u+1u]);
        if (h<0 || l<0) { errno=EINVAL; return -1; }
        a->session[i]=(unsigned char)((h<<4)|l);
    }
    if (getrandom(&a->epoch,sizeof(a->epoch),0)!=(ssize_t)sizeof(a->epoch)) return -1;
    if (a->epoch==0) a->epoch=1;
    a->process_start_ticks=process_start_ticks();if(a->process_start_ticks==0) {errno=EPROTO;return -1;}
    a->fd=open(path,O_RDWR|O_CREAT|O_EXCL|O_CLOEXEC|O_NOFOLLOW,0600);
    if (a->fd<0) return -1;
    if (ftruncate(a->fd,(off_t)RA_ENV_SIZE)<0) goto failure;
    a->block=mmap(NULL,RA_ENV_SIZE,PROT_READ|PROT_WRITE,MAP_SHARED,a->fd,0);
    if (a->block==MAP_FAILED) { a->block=NULL; goto failure; }
    if (lock_agent(a)<0) goto failure;
    memcpy(a->block,magic,8); put32(a->block+8,RA_ABI_VERSION); put32(a->block+12,RA_ENV_SIZE);
    memcpy(a->block+16,a->session,16); put64(a->block+32,a->epoch);
    put64(a->block+40,(uint64_t)getpid());put64(a->block+240,a->process_start_ticks); put32(a->block+164,(uint32_t)sizeof(void *));
    put32(a->block+172,0); memcpy(a->block+176,RA_BUILD_ID,64);
    if (unlock_agent(a)<0) goto failure;
    return 0;
failure:
    { int saved=errno; if(a->block) { (void)munmap(a->block,RA_ENV_SIZE); a->block=NULL; }
      (void)close(a->fd); a->fd=-1; (void)unlink(path); errno=saved; return -1; }
}
static int register_locked(RAAgent *a, uint32_t slot, uint32_t flags, RACallback cb, void *context) {
    if (slot==0u || cb==NULL || (flags!=1u && flags!=2u) || a->callback_count>=RA_MAX_CALLBACKS) {errno=EINVAL;return -1;}
    if (try_lock_agent(a)<0) return -1;
    for (size_t i=0;i<a->callback_count;++i) if(a->callbacks[i].slot==slot) { (void)unlock_agent(a);errno=EINVAL;return -1; }
    if (get64(a->block+48)!=get64(a->block+56)) { (void)unlock_agent(a);errno=EBUSY;return -1; }
    size_t i=a->callback_count;
    a->callbacks[i]=(RALocalCallback){slot,flags,cb,context};
    unsigned char *p=a->block+256u+i*16u;
    put32(p,slot);put32(p+4,flags);put32(p+8,1);put32(p+12,0);
    ++a->callback_count;put32(a->block+160,(uint32_t)a->callback_count);
    return unlock_agent(a);
}
static int object_locked(RAAgent *a,uint64_t id,uint64_t generation,uint64_t location,const void *address,
                    size_t size,size_t offset,int64_t value) {
    if (size>UINT32_MAX || offset>size || size-offset<sizeof(value) || generation==0 || id==0) {errno=EINVAL;return -1;}
    /* Both the process-local gate and cross-process file lock are held. */
    a->object_id=id;a->object_generation=generation;
    put64(a->block+112,id);put64(a->block+120,generation);put64(a->block+128,(uint64_t)value);
    put32(a->block+144,(uint32_t)size);put32(a->block+148,(uint32_t)offset);
    put64(a->block+152,(uint64_t)(uintptr_t)address);put64(a->block+136,location);
    return 0;
}
static int ready_locked(RAAgent *a) {
    if (try_lock_agent(a)<0) return -1;
    if (a->callback_count==0 || get64(a->block+120)==0) {(void)unlock_agent(a);errno=EINVAL;return -1;}
    put32(a->block+172,1);return unlock_agent(a);
}
static int poll_locked(RAAgent *a) {
    /* An external controller stopped while owning the lock must never stop the
       application. Try again at the next cooperative safe point instead. */
    if (flock(a->fd,LOCK_EX|LOCK_NB)<0) {
        if (errno==EWOULDBLOCK || errno==EAGAIN || errno==EINTR) return 0;
        return -1;
    }
    unsigned char *p=a->block;
    if (memcmp(p,magic,8)!=0 || get32(p+8)!=RA_ABI_VERSION || get32(p+12)!=RA_ENV_SIZE ||
        memcmp(p+16,a->session,16)!=0 || get64(p+32)!=a->epoch || get64(p+40)!=(uint64_t)getpid() || get64(p+240)!=a->process_start_ticks ||
        get64(p+112)!=a->object_id || get64(p+120)!=a->object_generation ||
        memcmp(p+176,RA_BUILD_ID,64)!=0 || get32(p+160)!=(uint32_t)a->callback_count) {
        (void)unlock_agent(a);errno=EPROTO;return -1;
    }
    for (size_t i=0;i<a->callback_count;++i) {
        const unsigned char *entry=p+256u+i*16u;
        if(get32(entry)!=a->callbacks[i].slot || get32(entry+4)!=a->callbacks[i].flags ||
           get32(entry+8)!=1u || get32(entry+12)!=0u) { (void)unlock_agent(a);errno=EPROTO;return -1; }
    }
    uint64_t sequence=get64(p+48), previous=get64(p+56);
    if (sequence==previous) return unlock_agent(a);
    RAResult result={(int64_t)get64(p+128),get64(p+120)};
    uint32_t status=RA_UNKNOWN_SLOT;
    if (previous==UINT64_MAX || sequence!=previous+1u || get32(p+68)!=1u) status=RA_CALLBACK_FAILED;
    else {
        uint32_t slot=get32(p+64);
        RARequest request={get64(p+72),(int64_t)get64(p+80),(int64_t)get64(p+88)};
        if (request.object_generation!=get64(p+120)) status=RA_STALE_HANDLE;
        else for (size_t i=0;i<a->callback_count;++i) if(a->callbacks[i].slot==slot) {
            RAAgent *previous_callback=callback_agent;callback_agent=a;
            status=a->callbacks[i].callback(a->callbacks[i].context,&request,&result);
            callback_agent=previous_callback;break;
        }
    }
    if (status<RA_OK || status>RA_CALLBACK_FAILED) status=RA_CALLBACK_FAILED;
    put64(p+96,(uint64_t)result.value);put64(p+104,result.generation);put32(p+68,status);put64(p+56,sequence);
    return unlock_agent(a);
}
int ra_agent_register(RAAgent *a,uint32_t slot,uint32_t flags,RACallback cb,void *context) {
    if(enter_agent(a)<0) return -1;
    return leave_agent(a,register_locked(a,slot,flags,cb,context));
}
int ra_agent_object(RAAgent *a,uint64_t id,uint64_t generation,uint64_t location,const void *address,
                    size_t size,size_t offset,int64_t value) {
    if(callback_agent==a) return object_locked(a,id,generation,location,address,size,offset,value);
    if(enter_agent(a)<0) return -1;
    if(try_lock_agent(a)<0) return leave_agent(a,-1);
    int result=object_locked(a,id,generation,location,address,size,offset,value);
    int saved=errno;if(unlock_agent(a)<0 && result==0) {result=-1;saved=errno;}
    errno=saved;return leave_agent(a,result);
}
int ra_agent_ready(RAAgent *a) {
    if(enter_agent(a)<0) return -1;
    return leave_agent(a,ready_locked(a));
}
int ra_agent_poll(RAAgent *a) {
    /* flock belongs to the open file description, so it does not exclude other
       threads using this same fd. Keep this gate through callback, ACK and unlock. */
    if(enter_agent(a)<0) return 0;
    return leave_agent(a,poll_locked(a));
}
void ra_agent_close(RAAgent *a) {
    if (a->block) {
        if (flock(a->fd,LOCK_EX|LOCK_NB)==0) { put32(a->block+172,0); (void)unlock_agent(a); }
        (void)munmap(a->block,RA_ENV_SIZE);a->block=NULL;
    }
    if(a->fd>=0) {(void)close(a->fd);a->fd=-1;}
}
