//! Cooperative, slot-addressed controller. No process memory API or foreign function
//! pointers are accepted. Wire bytes are explicitly little endian; callbacks execute
//! at application-owned safe points, protected by the same advisory file lock.
use std::fs::{File, OpenOptions};
use std::io::{self, BufRead, Read, Write};
use std::os::unix::fs::{FileExt, MetadataExt, OpenOptionsExt};
use std::path::Path;
use std::thread;
use std::time::{Duration, Instant};

const SIZE: usize = 4096;
const MAGIC: &[u8; 8] = b"RA055ENV";
const MAX_CALLBACKS: usize = 8;
const O_NOFOLLOW: i32 = 0o400000;

type Result<T> = std::result::Result<T, Failure>;
#[derive(Debug)]
struct Failure {
    code: &'static str,
    dispatched: bool,
}
impl Failure {
    fn new(code: &'static str) -> Self {
        Self {
            code,
            dispatched: false,
        }
    }
    fn json(&self) -> String {
        format!(
            "{{\"ok\":false,\"error\":\"{}\",\"dispatched\":{}}}",
            self.code, self.dispatched
        )
    }
}
fn io_failure(_: io::Error) -> Failure {
    Failure::new("semantic_io_failed")
}
fn u32_at(bytes: &[u8; SIZE], at: usize) -> u32 {
    u32::from_le_bytes(bytes[at..at + 4].try_into().expect("fixed wire offset"))
}
fn u64_at(bytes: &[u8; SIZE], at: usize) -> u64 {
    u64::from_le_bytes(bytes[at..at + 8].try_into().expect("fixed wire offset"))
}
fn i64_at(bytes: &[u8; SIZE], at: usize) -> i64 {
    i64::from_le_bytes(bytes[at..at + 8].try_into().expect("fixed wire offset"))
}
fn session_bytes(text: &str) -> Result<[u8; 16]> {
    if text.len() != 32
        || !text
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err(Failure::new("semantic_invalid_session"));
    }
    let mut result = [0; 16];
    for (index, part) in result.iter_mut().enumerate() {
        *part = u8::from_str_radix(&text[index * 2..index * 2 + 2], 16)
            .map_err(|_| Failure::new("semantic_invalid_session"))?;
    }
    Ok(result)
}
fn read_block(file: &File) -> Result<[u8; SIZE]> {
    let mut bytes = [0; SIZE];
    file.read_exact_at(&mut bytes, 0).map_err(io_failure)?;
    Ok(bytes)
}
fn lock_until(file: &File, deadline: Instant) -> Result<()> {
    loop {
        match file.try_lock() {
            Ok(()) => return Ok(()),
            Err(std::fs::TryLockError::WouldBlock) if Instant::now() < deadline => {
                thread::sleep(Duration::from_millis(1));
            }
            Err(std::fs::TryLockError::WouldBlock) => {
                return Err(Failure::new("semantic_lock_timeout"))
            }
            Err(std::fs::TryLockError::Error(_)) => {
                return Err(Failure::new("semantic_lock_failed"))
            }
        }
    }
}
fn locked<T>(file: &File, deadline: Instant, operation: impl FnOnce() -> Result<T>) -> Result<T> {
    lock_until(file, deadline)?;
    let result = operation();
    file.unlock().map_err(io_failure)?;
    result
}
fn validate(bytes: &[u8; SIZE], session: &[u8; 16]) -> Result<()> {
    if &bytes[..8] != MAGIC || u32_at(bytes, 8) != 1 || u32_at(bytes, 12) != SIZE as u32 {
        return Err(Failure::new("semantic_abi_mismatch"));
    }
    if &bytes[16..32] != session || u64_at(bytes, 32) == 0 {
        return Err(Failure::new("semantic_session_mismatch"));
    }
    let count = u32_at(bytes, 160) as usize;
    if count == 0
        || count > MAX_CALLBACKS
        || !matches!(u32_at(bytes, 164), 4 | 8)
        || u64_at(bytes, 112) == 0
        || u64_at(bytes, 120) == 0
        || !bytes[176..240]
            .iter()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(b))
    {
        return Err(Failure::new("semantic_metadata_invalid"));
    }
    let requested = u64_at(bytes, 48);
    let acknowledged = u64_at(bytes, 56);
    if acknowledged > requested || requested - acknowledged > 1 || u32_at(bytes, 68) > 6 {
        return Err(Failure::new("semantic_sequence_invalid"));
    }
    let mut slots = [0; MAX_CALLBACKS];
    for index in 0..count {
        let at = 256 + index * 16;
        let slot = u32_at(bytes, at);
        if slot == 0
            || slots[..index].contains(&slot)
            || !matches!(u32_at(bytes, at + 4), 1 | 2)
            || u32_at(bytes, at + 8) != 1
            || u32_at(bytes, at + 12) != 0
        {
            return Err(Failure::new("semantic_callback_table_invalid"));
        }
        slots[index] = slot;
    }
    if u32_at(bytes, 172) != 1 {
        return Err(Failure::new("semantic_agent_inactive"));
    }
    Ok(())
}
fn validate_process(bytes: &[u8; SIZE]) -> Result<()> {
    let pid = u64_at(bytes, 40);
    if pid == 0 || pid >= 1_u64 << 31 {
        return Err(Failure::new("semantic_process_identity_changed"));
    }
    let text = std::fs::read_to_string(format!("/proc/{pid}/stat"))
        .map_err(|_| Failure::new("semantic_process_unavailable"))?;
    let (_, fields) = text
        .rsplit_once(')')
        .ok_or_else(|| Failure::new("semantic_process_identity_changed"))?;
    let tokens = fields.split_ascii_whitespace().collect::<Vec<_>>();
    if tokens.len() < 20
        || matches!(tokens[0], "Z" | "X")
        || tokens[19].parse::<u64>().ok() != Some(u64_at(bytes, 240))
    {
        return Err(Failure::new("semantic_process_identity_changed"));
    }
    Ok(())
}
fn open_environment(path: &Path) -> Result<File> {
    let file = OpenOptions::new()
        .read(true)
        .write(true)
        .custom_flags(O_NOFOLLOW)
        .open(path)
        .map_err(io_failure)?;
    let metadata = file.metadata().map_err(io_failure)?;
    let current_uid = std::fs::metadata("/proc/self").map_err(io_failure)?.uid();
    if !metadata.is_file()
        || metadata.len() != SIZE as u64
        || metadata.mode() & 0o077 != 0
        || metadata.uid() != current_uid
    {
        return Err(Failure::new("semantic_environment_not_private"));
    }
    Ok(file)
}
fn snapshot(file: &File, session: &[u8; 16], deadline: Instant) -> Result<[u8; SIZE]> {
    locked(file, deadline, || {
        let bytes = read_block(file)?;
        validate(&bytes, session)?;
        validate_process(&bytes)?;
        Ok(bytes)
    })
}
fn status_json(bytes: &[u8; SIZE]) -> String {
    let build = std::str::from_utf8(&bytes[176..240]).expect("validated ASCII build ID");
    let callbacks = (0..u32_at(bytes, 160) as usize)
        .map(|index| {
            let at = 256 + index * 16;
            format!(
                "{{\"slot\":{},\"access\":\"{}\",\"schema\":1}}",
                u32_at(bytes, at),
                if u32_at(bytes, at + 4) == 1 {
                    "read"
                } else {
                    "write"
                }
            )
        })
        .collect::<Vec<_>>()
        .join(",");
    format!(
        concat!(
            "{{\"ok\":true,\"backend\":\"rust_cooperative_shared_memory\",",
            "\"abi\":1,\"epoch\":{},\"pid\":{},\"request_seq\":{},\"ack_seq\":{},",
            "\"pending\":{},\"object_id\":{},\"object_generation\":{},\"value\":{},",
            "\"location_epoch\":{},\"object_size\":{},\"field_offset\":{},",
            "\"address\":{},\"pointer_bytes\":{},\"build_id\":\"{}\",\"callbacks\":[{}]}}"
        ),
        u64_at(bytes, 32),
        u64_at(bytes, 40),
        u64_at(bytes, 48),
        u64_at(bytes, 56),
        u64_at(bytes, 48) != u64_at(bytes, 56),
        u64_at(bytes, 112),
        u64_at(bytes, 120),
        i64_at(bytes, 128),
        u64_at(bytes, 136),
        u32_at(bytes, 144),
        u32_at(bytes, 148),
        u64_at(bytes, 152),
        u32_at(bytes, 164),
        build,
        callbacks
    )
}
#[derive(Debug)]
struct Call {
    epoch: u64,
    sequence: u64,
    generation: u64,
    slot: u32,
    expected: i64,
    argument: i64,
    timeout: Duration,
}
fn number<T: std::str::FromStr>(value: &str) -> Result<T> {
    value
        .parse()
        .map_err(|_| Failure::new("semantic_invalid_argument"))
}
fn parse_call(arguments: &[&str]) -> Result<Call> {
    if arguments.len() != 7 {
        return Err(Failure::new("semantic_invalid_arguments"));
    }
    let milliseconds: u64 = number(arguments[6])?;
    if !(1..=1000).contains(&milliseconds) {
        return Err(Failure::new("semantic_invalid_timeout"));
    }
    Ok(Call {
        epoch: number(arguments[0])?,
        sequence: number(arguments[1])?,
        generation: number(arguments[2])?,
        slot: number(arguments[3])?,
        expected: number(arguments[4])?,
        argument: number(arguments[5])?,
        timeout: Duration::from_millis(milliseconds),
    })
}
fn call(file: &File, session: &[u8; 16], request: &Call) -> Result<String> {
    let deadline = Instant::now() + request.timeout;
    let mut dispatched = false;
    let result = (|| {
        locked(file, deadline, || {
            let bytes = read_block(file)?;
            validate(&bytes, session)?;
            validate_process(&bytes)?;
            if u64_at(&bytes, 32) != request.epoch {
                return Err(Failure::new("semantic_stale_epoch"));
            }
            if u64_at(&bytes, 120) != request.generation {
                return Err(Failure::new("semantic_stale_handle"));
            }
            if u64_at(&bytes, 48) != u64_at(&bytes, 56) {
                return Err(Failure::new("semantic_outcome_unresolved"));
            }
            if u64_at(&bytes, 48).checked_add(1) != Some(request.sequence) {
                return Err(Failure::new("semantic_stale_sequence"));
            }
            if !(0..u32_at(&bytes, 160) as usize)
                .any(|index| u32_at(&bytes, 256 + index * 16) == request.slot)
            {
                return Err(Failure::new("semantic_unknown_slot"));
            }
            let mut payload = [0; 32];
            payload[..4].copy_from_slice(&request.slot.to_le_bytes());
            payload[4..8].copy_from_slice(&1_u32.to_le_bytes());
            payload[8..16].copy_from_slice(&request.generation.to_le_bytes());
            payload[16..24].copy_from_slice(&request.expected.to_le_bytes());
            payload[24..32].copy_from_slice(&request.argument.to_le_bytes());
            // Once writes begin, every I/O failure is conservatively unknown.
            dispatched = true;
            file.write_all_at(&payload, 64).map_err(io_failure)?;
            file.write_all_at(&request.sequence.to_le_bytes(), 48)
                .map_err(io_failure)?;
            file.sync_data().map_err(io_failure)?;
            Ok(())
        })?;
        loop {
            if Instant::now() >= deadline {
                return Err(Failure::new("semantic_outcome_unknown"));
            }
            let bytes = snapshot(file, session, deadline)?;
            if u64_at(&bytes, 32) != request.epoch {
                return Err(Failure::new("semantic_stale_epoch"));
            }
            if u64_at(&bytes, 48) != request.sequence {
                return Err(Failure::new("semantic_sequence_changed"));
            }
            if u64_at(&bytes, 56) == request.sequence {
                let code = u32_at(&bytes, 68);
                let error = match code {
                    2 => "",
                    3 => "semantic_state_conflict",
                    4 => "semantic_stale_handle",
                    5 => "semantic_unknown_slot",
                    _ => "semantic_callback_failed",
                };
                return Ok(format!(concat!("{{\"ok\":{},\"dispatched\":true,\"request_seq\":{},",
                    "\"value\":{},\"object_generation\":{},\"location_epoch\":{},\"error\":\"{}\"}}"),
                    code==2,request.sequence,i64_at(&bytes,96),u64_at(&bytes,104),u64_at(&bytes,136),error));
            }
            thread::sleep(Duration::from_millis(1));
        }
    })();
    result.map_err(|mut failure| {
        failure.dispatched = dispatched;
        failure
    })
}
fn execute(file: &File, session: &[u8; 16], command: &[&str]) -> Result<String> {
    match command {
        ["status"] => Ok(status_json(&snapshot(
            file,
            session,
            Instant::now() + Duration::from_secs(1),
        )?)),
        ["call", rest @ ..] => call(file, session, &parse_call(rest)?),
        _ => Err(Failure::new("semantic_invalid_command")),
    }
}
fn run() -> Result<()> {
    let arguments = std::env::args().skip(1).collect::<Vec<_>>();
    if arguments.len() < 3 || arguments.iter().any(|value| value.len() > 4096) {
        return Err(Failure::new("semantic_invalid_arguments"));
    }
    let session = session_bytes(&arguments[2])?;
    let file = open_environment(Path::new(&arguments[1]))?;
    if arguments[0] == "serve" {
        if arguments.len() != 3 {
            return Err(Failure::new("semantic_invalid_arguments"));
        }
        // Limit input before allocating a complete line; no unbounded lines().
        let stdin = io::stdin();
        let mut input = stdin.lock();
        let mut line = Vec::new();
        loop {
            line.clear();
            let mut limited = (&mut input).take(513);
            let count = limited.read_until(b'\n', &mut line).map_err(io_failure)?;
            if count == 0 {
                break;
            }
            if count > 512 || line.last() != Some(&b'\n') {
                return Err(Failure::new("semantic_line_limit"));
            }
            let text =
                std::str::from_utf8(&line).map_err(|_| Failure::new("semantic_invalid_command"))?;
            let words = text.split_ascii_whitespace().collect::<Vec<_>>();
            match execute(&file, &session, &words) {
                Ok(value) => println!("{value}"),
                Err(error) => println!("{}", error.json()),
            }
            io::stdout().flush().map_err(io_failure)?;
        }
    } else {
        let mut command = vec![arguments[0].as_str()];
        command.extend(arguments[3..].iter().map(String::as_str));
        println!("{}", execute(&file, &session, &command)?);
    }
    Ok(())
}
fn main() {
    if let Err(error) = run() {
        println!("{}", error.json());
        std::process::exit(2);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn block() -> [u8; SIZE] {
        let mut bytes = [0; SIZE];
        bytes[..8].copy_from_slice(MAGIC);
        bytes[8..12].copy_from_slice(&1_u32.to_le_bytes());
        bytes[12..16].copy_from_slice(&(SIZE as u32).to_le_bytes());
        for at in [32, 112, 120] {
            bytes[at..at + 8].copy_from_slice(&1_u64.to_le_bytes());
        }
        for (at, value) in [
            (160, 1_u32),
            (164, 8),
            (172, 1),
            (256, 1),
            (260, 1),
            (264, 1),
        ] {
            bytes[at..at + 4].copy_from_slice(&value.to_le_bytes());
        }
        bytes[176..240].fill(b'0');
        bytes
    }
    #[test]
    fn rejects_corrupt_wire_and_stale_callback_metadata() {
        let base = block();
        assert!(validate(&base, &[0; 16]).is_ok());
        for at in [0, 8, 12, 16, 160, 164, 172, 176, 260, 264] {
            let mut bytes = base;
            bytes[at] ^= 0xff;
            assert!(validate(&bytes, &[0; 16]).is_err(), "offset {at}");
        }
        let mut zero_slot = base;
        zero_slot[256..260].fill(0);
        assert!(validate(&zero_slot, &[0; 16]).is_err());
        let mut pending = base;
        pending[48..56].copy_from_slice(&2_u64.to_le_bytes());
        assert!(validate(&pending, &[0; 16]).is_err());
    }
    #[test]
    fn validates_session_and_bounded_call() {
        assert!(session_bytes("00112233445566778899aabbccddeeff").is_ok());
        assert!(session_bytes("00112233445566778899AABBCCDDEEFF").is_err());
        assert!(parse_call(&["1", "1", "1", "2", "7", "-2", "1000"]).is_ok());
        assert!(parse_call(&["1", "1", "1", "2", "7", "-2", "1001"]).is_err());
    }
}
