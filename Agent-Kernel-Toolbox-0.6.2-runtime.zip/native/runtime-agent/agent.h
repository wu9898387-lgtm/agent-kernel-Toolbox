#ifndef RUNTIME_ACCESS_AGENT_H
#define RUNTIME_ACCESS_AGENT_H
#include <stddef.h>
#include <stdint.h>
#include <stdatomic.h>

#define RA_ENV_SIZE 4096u
#define RA_MAX_CALLBACKS 8u
#define RA_ABI_VERSION 1u
#define RA_OK 2u
#define RA_CONFLICT 3u
#define RA_STALE_HANDLE 4u
#define RA_UNKNOWN_SLOT 5u
#define RA_CALLBACK_FAILED 6u

/* Callbacks run inside the application's cooperative safe point under flock.
 * Every application writer must participate in that safe point. Shared table
 * entries contain slot IDs and schemas; function pointers stay in this process. */
typedef struct {
    uint64_t object_generation;
    int64_t expected;
    int64_t argument;
} RARequest;
typedef struct {
    int64_t value;
    uint64_t generation;
} RAResult;
typedef uint32_t (*RACallback)(void *context, const RARequest *request, RAResult *result);
typedef struct {
    uint32_t slot;
    uint32_t flags;
    RACallback callback;
    void *context;
} RALocalCallback;
typedef struct {
    atomic_flag operation_gate;
    int fd;
    unsigned char *block;
    uint64_t epoch;
    unsigned char session[16];
    uint64_t process_start_ticks;
    uint64_t object_id;
    uint64_t object_generation;
    size_t callback_count;
    RALocalCallback callbacks[RA_MAX_CALLBACKS];
} RAAgent;

/* open/close are lifecycle operations: call open before publishing this handle,
 * stop/join every polling or registration thread before close, and never close
 * from a callback. Do not copy an initialized RAAgent. poll/register/ready/object
 * share a nonblocking process-local atomic gate in addition to cross-process flock.
 * A busy poll is a no-op (return 0); busy registration/publication returns EBUSY.
 * object publication is also allowed from the active callback and reuses its locks.
 * The application must still synchronize all its own object writers/safe points. */
int ra_agent_open(RAAgent *agent, const char *path, const char *session_hex);
int ra_agent_register(RAAgent *agent, uint32_t slot, uint32_t flags,
                      RACallback callback, void *context);
int ra_agent_object(RAAgent *agent, uint64_t object_id, uint64_t generation,
                    uint64_t location_epoch, const void *address, size_t size,
                    size_t field_offset, int64_t field_value);
int ra_agent_ready(RAAgent *agent);
int ra_agent_poll(RAAgent *agent);
void ra_agent_close(RAAgent *agent);
#endif
