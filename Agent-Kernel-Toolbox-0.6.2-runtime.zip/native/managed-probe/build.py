#!/usr/bin/env python3
"""Build the JVMTI 1.2 ABI agent with fixed, dependency-free C flags."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

FLAGS=['-std=c11','-O2','-fPIC','-shared','-pthread','-Wall','-Wextra','-Werror',
       '-Wl,-z,relro,-z,now','-Wl,--no-undefined']

def build(java_home,output):
    home=Path(java_home).resolve();output=Path(output).resolve()
    include=home/'include'
    if not (include/'jvmti.h').is_file() or not (include/'linux/jni_md.h').is_file():
        raise ValueError('managed_probe_JDK_headers_required')
    compiler=shutil.which('gcc')
    if compiler is None:raise ValueError('managed_probe_gcc_required')
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    target=output/'libmanaged_probe.so'
    source=Path(__file__).with_name('managed_probe.c')
    subprocess.run([compiler,*FLAGS,'-I'+str(include),'-I'+str(include/'linux'),
                    str(source),'-o',str(target)],check=True,timeout=30)
    metadata={'agent':str(target),'agent_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
              'compiler':compiler,'flags':FLAGS,'jvmti_abi':'1.2','header_home':str(home),
              'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
    (output/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
    return metadata

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--java-home',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();print(json.dumps(build(args.java_home,args.output),indent=2))
