package runtimeaccess.probe;

/** Explicit application cooperation; object tags are not physical addresses. */
public final class RuntimeProbe {
    private RuntimeProbe() {}
    public static native long tag(Object object);
    public static native long identity(Object object);
    public static native void event(Object object, int eventCode, int stateCode);
    /** Starts the operator-configured JVMTI allocation sampler at this call. */
    public static native boolean startAllocationSampling(long intervalBytes);
}
