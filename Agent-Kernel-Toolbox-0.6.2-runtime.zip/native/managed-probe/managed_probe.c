/* JVMTI 1.2 agent. Bounded metadata/events, no object contents or addresses. */
#define _GNU_SOURCE
#include <jni.h>
#include <jvmti.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <time.h>

#define MAX_TAGS 2048
static jvmtiEnv *ti;
static FILE *output;
static pthread_mutex_t event_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t tag_lock=PTHREAD_MUTEX_INITIALIZER;
static uint64_t sequence, retained;
static long written;
static jlong next_tag=1;
static unsigned budget;
static char class_prefix[129];
static int finished;
static pthread_mutex_t sampling_lock=PTHREAD_MUTEX_INITIALIZER;
static int sampling_configured,sampling_supported,sampling_started,sampling_error;
static long long sampling_interval=-1,sampling_started_ns;
static const char *sampling_support="not_requested";

static void quoted_limit(FILE *file,const char *value,unsigned limit) {
    fputc('"',file);
    for(unsigned n=0;value && value[n] && n<limit;n++) {
        unsigned char c=(unsigned char)value[n];
        if(c=='"'||c=='\\'){fputc('\\',file);fputc(c,file);}
        else if(c<32)fprintf(file,"\\u%04x",c);
        else if((c&0xe0)==0xc0 && value[n+1] && n+1<limit) {
            unsigned unit=((c&31)<<6)|((unsigned char)value[n+1]&63);n++;
            fprintf(file,"\\u%04x",unit);
        } else if((c&0xf0)==0xe0 && value[n+1] && value[n+2] && n+2<limit) {
            unsigned unit=((c&15)<<12)|(((unsigned char)value[n+1]&63)<<6)|((unsigned char)value[n+2]&63);n+=2;
            fprintf(file,"\\u%04x",unit);
        } else if(c>=128)break; /* Do not split a bounded modified-UTF8 unit. */
        else fputc(c,file);
    }
    fputc('"',file);
}
static void quoted(FILE *file,const char *value){quoted_limit(file,value,256);}

/* No JVMTI calls while event_lock is held: GC/free callbacks can use it. */
static int begin(const char *kind,jlong tag) {
    pthread_mutex_lock(&event_lock);
    if(finished){pthread_mutex_unlock(&event_lock);return 0;}
    sequence++;
    if(retained>=budget || written>8*1024*1024-32768){pthread_mutex_unlock(&event_lock);return 0;}
    retained++;
    fprintf(output,"{\"seq\":%llu,\"kind\":",(unsigned long long)sequence);
    quoted(output,kind);
    if(tag)fprintf(output,",\"tag\":%lld",(long long)tag);
    return 1;
}
static void end(void){fputs("}\n",output);fflush(output);written=ftell(output);pthread_mutex_unlock(&event_lock);}
static void simple(const char *kind,jlong tag){if(begin(kind,tag))end();}

static int allowed(jclass klass,char **signature) {
    if((*ti)->GetClassSignature(ti,klass,signature,NULL)!=JVMTI_ERROR_NONE)return 0;
    const char *element=*signature;
    while(*element=='[')element++;
    if(strncmp(element,class_prefix,strlen(class_prefix))==0)return 1;
    (*ti)->Deallocate(ti,(unsigned char *)*signature);*signature=NULL;return 0;
}
static jlong ensure_tag(jobject object) {
    jlong tag=0;
    pthread_mutex_lock(&tag_lock);
    if((*ti)->GetTag(ti,object,&tag)==JVMTI_ERROR_NONE && !tag && next_tag<=MAX_TAGS) {
        tag=next_tag++;
        if((*ti)->SetTag(ti,object,tag)!=JVMTI_ERROR_NONE)tag=0;
    }
    pthread_mutex_unlock(&tag_lock);
    return tag;
}

static void metadata(jclass klass,jlong tag,const char *signature) {
    jint count=0; jfieldID *fields=NULL;
    struct {char *name,*signature; jint modifiers;} rows[32];
    memset(rows,0,sizeof(rows));
    jvmtiError error=(*ti)->GetClassFields(ti,klass,&count,&fields);
    int kept=error==JVMTI_ERROR_NONE?(count<32?count:32):0;
    int strings_truncated=strlen(signature)>256;
    for(int i=0;i<kept;i++) {
        (void)(*ti)->GetFieldName(ti,klass,fields[i],&rows[i].name,&rows[i].signature,NULL);
        (void)(*ti)->GetFieldModifiers(ti,klass,fields[i],&rows[i].modifiers);
        if((rows[i].name && strlen(rows[i].name)>128) || (rows[i].signature && strlen(rows[i].signature)>128))strings_truncated=1;
    }
    if(begin("class_metadata",tag)) {
        fputs(",\"class_signature\":",output);quoted(output,signature);
        fputs(",\"source\":\"JVMTI_class_signature_and_declared_field_metadata\",\"fields\":[",output);
        for(int i=0;i<kept;i++) {
            if(i)fputc(',',output);
            fputs("{\"name\":",output);quoted_limit(output,rows[i].name,128);
            fputs(",\"signature\":",output);quoted_limit(output,rows[i].signature,128);
            fprintf(output,",\"modifiers\":%d}",rows[i].modifiers);
        }
        fprintf(output,"],\"fields_truncated\":%s,\"strings_truncated\":%s,\"metadata_error\":%d",count>32?"true":"false",strings_truncated?"true":"false",error);end();
    }
    for(int i=0;i<kept;i++) {
        if(rows[i].name)(*ti)->Deallocate(ti,(unsigned char *)rows[i].name);
        if(rows[i].signature)(*ti)->Deallocate(ti,(unsigned char *)rows[i].signature);
    }
    if(fields)(*ti)->Deallocate(ti,(unsigned char *)fields);
}

static jlong JNICALL explicit_tag(JNIEnv *env,jclass self,jobject object) {
    (void)self;
    if(!object)return 0;
    jclass klass=(*env)->GetObjectClass(env,object);char *signature=NULL;
    if(!allowed(klass,&signature)) {
        (*env)->DeleteLocalRef(env,klass);
        jclass error=(*env)->FindClass(env,"java/lang/IllegalArgumentException");
        if(error)(*env)->ThrowNew(env,error,"managed_probe_class_not_registered");
        return 0;
    }
    jlong tag=ensure_tag(object);
    if(tag){metadata(klass,tag,signature);simple("explicit_tag",tag);}
    else simple("tag_capacity_exhausted",0);
    (*ti)->Deallocate(ti,(unsigned char *)signature);
    (*env)->DeleteLocalRef(env,klass);return tag;
}
static jlong JNICALL identity(JNIEnv *env,jclass self,jobject object) {
    (void)env;(void)self;jlong tag=0;
    if(object)(void)(*ti)->GetTag(ti,object,&tag);
    return tag;
}
static void JNICALL semantic_event(JNIEnv *env,jclass self,jobject object,jint code,jint state) {
    jlong tag=identity(env,self,object);
    if(!tag) {
        jclass error=(*env)->FindClass(env,"java/lang/IllegalStateException");
        if(error)(*env)->ThrowNew(env,error,"managed_probe_object_not_tagged");
        return;
    }
    if(begin("semantic",tag)){fprintf(output,",\"event_code\":%d,\"state_code\":%d",code,state);end();}
}

static jboolean JNICALL start_sampling(JNIEnv *env,jclass self,jlong interval) {
    (void)self;
    if(!sampling_configured || interval!=sampling_interval) {
        jclass error=(*env)->FindClass(env,sampling_configured?"java/lang/IllegalArgumentException":"java/lang/IllegalStateException");
        if(error)(*env)->ThrowNew(env,error,"managed_probe_sampling_interval_not_configured");
        return JNI_FALSE;
    }
    pthread_mutex_lock(&sampling_lock);
    if(!sampling_supported){pthread_mutex_unlock(&sampling_lock);return JNI_FALSE;}
    if(sampling_started){pthread_mutex_unlock(&sampling_lock);return JNI_TRUE;}
    sampling_error=(*ti)->SetHeapSamplingInterval(ti,(jint)interval);
    struct timespec now;
    if(!sampling_error && clock_gettime(CLOCK_MONOTONIC,&now)==0) {
        sampling_started_ns=(long long)now.tv_sec*1000000000LL+now.tv_nsec;
        sampling_error=(*ti)->SetEventNotificationMode(ti,JVMTI_ENABLE,JVMTI_EVENT_SAMPLED_OBJECT_ALLOC,NULL);
        if(!sampling_error) {
            sampling_started=1;
            if(begin("allocation_sampling_started",0)) {
                fprintf(output,",\"interval_bytes\":%lld,\"started_monotonic_ns\":%lld",sampling_interval,sampling_started_ns);end();
            }
        }
    }
    jboolean result=sampling_started?JNI_TRUE:JNI_FALSE;
    pthread_mutex_unlock(&sampling_lock);return result;
}

static void JNICALL prepared(jvmtiEnv *jti,JNIEnv *env,jthread thread,jclass klass) {
    (void)jti;(void)thread;char *signature=NULL;
    if((*ti)->GetClassSignature(ti,klass,&signature,NULL)!=JVMTI_ERROR_NONE)return;
    if(strcmp(signature,"Lruntimeaccess/probe/RuntimeProbe;")==0) {
        JNINativeMethod methods[]={
            {"tag","(Ljava/lang/Object;)J",(void *)explicit_tag},
            {"identity","(Ljava/lang/Object;)J",(void *)identity},
            {"event","(Ljava/lang/Object;II)V",(void *)semantic_event}};
        if((*env)->RegisterNatives(env,klass,methods,3)==0)simple("jni_bridge_ready",0);
        /* Old pinned bridges remain valid when sampling is off. */
        JNINativeMethod sampling_method={"startAllocationSampling","(J)Z",(void *)start_sampling};
        if((*env)->RegisterNatives(env,klass,&sampling_method,1)!=0)(*env)->ExceptionClear(env);
    }
    (*ti)->Deallocate(ti,(unsigned char *)signature);
}
static void allocation(const char *kind,jobject object,jclass klass,jlong size) {
    char *signature=NULL;
    if(!allowed(klass,&signature))return;
    jlong tag=ensure_tag(object);
    if(tag && begin(kind,tag)) {
        fputs(",\"class_signature\":",output);quoted(output,signature);
        fprintf(output,",\"class_signature_truncated\":%s,\"allocation_size\":%lld",strlen(signature)>256?"true":"false",(long long)size);end();
    } else if(!tag)simple("tag_capacity_exhausted",0);
    (*ti)->Deallocate(ti,(unsigned char *)signature);
}
static void JNICALL allocated(jvmtiEnv *jti,JNIEnv *env,jthread thread,jobject object,jclass klass,jlong size) {
    (void)jti;(void)env;(void)thread;allocation("vm_object_alloc",object,klass,size);
}
static void JNICALL sampled(jvmtiEnv *jti,JNIEnv *env,jthread thread,jobject object,jclass klass,jlong size) {
    (void)jti;(void)env;(void)thread;allocation("sampled_object_alloc",object,klass,size);
}
static void JNICALL freed(jvmtiEnv *jti,jlong tag){(void)jti;simple("object_free",tag);}
static void JNICALL gc_start(jvmtiEnv *jti){(void)jti;simple("gc_start",0);}
static void JNICALL gc_finish(jvmtiEnv *jti){(void)jti;simple("gc_finish",0);}
static void JNICALL death(jvmtiEnv *jti,JNIEnv *env) {
    (void)jti;(void)env;
    pthread_mutex_lock(&sampling_lock);
    pthread_mutex_lock(&tag_lock);jlong assigned=next_tag-1;pthread_mutex_unlock(&tag_lock);
    pthread_mutex_lock(&event_lock);
    if(!finished) {
        finished=1;
        fprintf(output,"{\"kind\":\"summary\",\"generated\":%llu,\"retained\":%llu,\"lost\":%llu,\"tag_limit\":%d,\"tags_assigned\":%lld",
            (unsigned long long)sequence,(unsigned long long)retained,
            (unsigned long long)(sequence-retained),MAX_TAGS,(long long)assigned);
        if(sampling_configured) {
            fprintf(output,",\"allocation_sampling\":{\"requested_interval_bytes\":%lld,\"capability_supported\":%s,\"support_status\":",
                sampling_interval,sampling_supported?"true":"false");quoted(output,sampling_support);
            fprintf(output,",\"started\":%s,\"started_monotonic_ns\":%lld,\"jvmti_error\":%d}",sampling_started?"true":"false",sampling_started_ns,sampling_error);
        }
        fputs("}\n",output);
        fflush(output);
    }
    pthread_mutex_unlock(&event_lock);
    pthread_mutex_unlock(&sampling_lock);
}

JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *vm,char *options,void *reserved) {
    (void)reserved;
    char path[4096],prefix[129],extra;
    if(!options)return JNI_ERR;
    if(sscanf(options,"path=%4095[^,],budget=%u,prefix=%128[^,],sampling=%lld%c",path,&budget,prefix,&sampling_interval,&extra)==4) {
        if(sampling_interval<0 || sampling_interval>2147483647LL)return JNI_ERR;
        sampling_configured=1;
    }else if(sscanf(options,"path=%4095[^,],budget=%u,prefix=%128[^,]%c",path,&budget,prefix,&extra)!=3)return JNI_ERR;
    if(budget<1 || budget>2048 || prefix[0]!='L')return JNI_ERR;
    memcpy(class_prefix,prefix,strlen(prefix)+1);
    output=fopen(path,"wx");if(!output)return JNI_ERR;
    int modern=sampling_configured && (*vm)->GetEnv(vm,(void **)&ti,JVMTI_VERSION_11)==JNI_OK;
    if(!modern && (*vm)->GetEnv(vm,(void **)&ti,JVMTI_VERSION_1_2)!=JNI_OK){fclose(output);return JNI_ERR;}
    jvmtiCapabilities caps;memset(&caps,0,sizeof(caps));
    caps.can_tag_objects=1;caps.can_generate_object_free_events=1;
    caps.can_generate_garbage_collection_events=1;caps.can_generate_vm_object_alloc_events=1;
    if((*ti)->AddCapabilities(ti,&caps)!=JVMTI_ERROR_NONE)return JNI_ERR;
    if(sampling_configured) {
        sampling_support="unsupported_JVMTI_version";
        if(modern) {
            jvmtiCapabilities potential;memset(&potential,0,sizeof(potential));
            sampling_error=(*ti)->GetPotentialCapabilities(ti,&potential);
            sampling_support="sampled_allocation_capability_unavailable";
            if(!sampling_error && potential.can_generate_sampled_object_alloc_events) {
                memset(&caps,0,sizeof(caps));caps.can_generate_sampled_object_alloc_events=1;
                sampling_error=(*ti)->AddCapabilities(ti,&caps);
                if(!sampling_error) {
                    memset(&caps,0,sizeof(caps));sampling_error=(*ti)->GetCapabilities(ti,&caps);
                    sampling_supported=!sampling_error && caps.can_generate_sampled_object_alloc_events;
                    sampling_support=sampling_supported?"available":"capability_not_granted";
                }else sampling_support="capability_request_failed";
            }
        }
    }
    jvmtiEventCallbacks cb;memset(&cb,0,sizeof(cb));
    cb.ClassPrepare=prepared;cb.VMObjectAlloc=allocated;cb.ObjectFree=freed;
    if(modern)cb.SampledObjectAlloc=sampled;
    cb.GarbageCollectionStart=gc_start;cb.GarbageCollectionFinish=gc_finish;cb.VMDeath=death;
    if((*ti)->SetEventCallbacks(ti,&cb,sizeof(cb))!=JVMTI_ERROR_NONE)return JNI_ERR;
    const jvmtiEvent events[]={JVMTI_EVENT_CLASS_PREPARE,JVMTI_EVENT_VM_OBJECT_ALLOC,JVMTI_EVENT_OBJECT_FREE,
        JVMTI_EVENT_GARBAGE_COLLECTION_START,JVMTI_EVENT_GARBAGE_COLLECTION_FINISH,JVMTI_EVENT_VM_DEATH};
    for(unsigned i=0;i<sizeof(events)/sizeof(events[0]);i++)
        if((*ti)->SetEventNotificationMode(ti,JVMTI_ENABLE,events[i],NULL)!=JVMTI_ERROR_NONE)return JNI_ERR;
    simple("agent_ready",0);return JNI_OK;
}
JNIEXPORT void JNICALL Agent_OnUnload(JavaVM *vm){(void)vm;if(output){fclose(output);output=NULL;}}
