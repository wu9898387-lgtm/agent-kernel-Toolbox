// Optional, explicit LD_PRELOAD OpenGL command filter for a user-launched app.
// No address-space attachment, shader rewriting, network or privilege changes.
// Program IDs are OpenGL object IDs, not semantic labels; a host must inspect
// evidence and select them. Identically numbered programs in all contexts match.
#define _GNU_SOURCE 1
#include <atomic>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <fcntl.h>
#include <mutex>
#include <pthread.h>
#include <signal.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

using GLenum = unsigned int;
using GLuint = unsigned int;
using GLint = int;
using GLsizei = int;
using GLbitfield = unsigned int;
using GLintptr = intptr_t;
using Proc = void (*)();

namespace {
std::mutex lock;
uint64_t draw_number = 0, blocked = 0, dropped = 0, invalid_policy = 0;
uint64_t program_rules[64] = {}, draw_rules[64] = {};
size_t program_count = 0, draw_count = 0;
uint64_t last_policy_ns = 0;
int report_fd = -2;
dev_t report_device = 0;
ino_t report_inode = 0;
constexpr uint64_t MAX_EVENTS = 1024;

void *real_symbol(const char *name) {
    void *result = dlsym(RTLD_NEXT, name);
    if (result) return result;
    auto egl = reinterpret_cast<Proc (*)(const char *)>(dlsym(RTLD_NEXT, "eglGetProcAddress"));
    if (egl) result = reinterpret_cast<void *>(egl(name));
    if (result) return result;
    auto glx = reinterpret_cast<Proc (*)(const unsigned char *)>(dlsym(RTLD_NEXT, "glXGetProcAddressARB"));
    return glx ? reinterpret_cast<void *>(glx(reinterpret_cast<const unsigned char *>(name))) : nullptr;
}

uint64_t now_ns() {
    timespec ts{};
    if (clock_gettime(CLOCK_MONOTONIC, &ts)) return 0;
    return uint64_t(ts.tv_sec) * 1000000000ULL + uint64_t(ts.tv_nsec);
}

bool parse_number(const char *text, uint64_t *value) {
    if (!text[0]) return false;
    uint64_t n = 0;
    for (const char *p = text; *p; ++p) {
        if (*p < '0' || *p > '9' || n > (UINT64_MAX - uint64_t(*p - '0')) / 10) return false;
        n = n * 10 + uint64_t(*p - '0');
    }
    *value = n;
    return true;
}

void load_policy() {
    const uint64_t now = now_ns();
    // Bound filesystem overhead. A replacement becomes visible at the first
    // intercepted command at least 10 ms after the preceding policy poll.
    if (last_policy_ns && now >= last_policy_ns && now - last_policy_ns < 10000000ULL) return;
    last_policy_ns = now;
    const char *path = getenv("AK_RENDER_POLICY");
    if (!path || path[0] != '/' || strnlen(path, 4097) > 4096) return;
    int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) { ++invalid_policy; return; }
    struct stat st{};
    char buffer[4097]{};
    ssize_t count = -1;
    if (!fstat(fd, &st) && S_ISREG(st.st_mode) && st.st_uid == geteuid() &&
        !(st.st_mode & 0022) && st.st_size > 0 && st.st_size <= 4096) {
        count = read(fd, buffer, 4096);
    }
    close(fd);
    if (count != st.st_size || count < 6 || std::memcmp(buffer, "AKRF1\n", 6) ||
        std::memchr(buffer, '\0', size_t(count)) || buffer[count - 1] != '\n') {
        ++invalid_policy; return;
    }
    uint64_t next_programs[64]{}, next_draws[64]{};
    size_t np = 0, nd = 0;
    char *line = buffer + 6;
    while (*line) {
        char *end = std::strchr(line, '\n');
        if (!end) { ++invalid_policy; return; }
        *end = '\0';
        uint64_t number;
        if (!std::strncmp(line, "program=", 8)) {
            if (np == 64 || !parse_number(line + 8, &number) || number > UINT32_MAX) { ++invalid_policy; return; }
            next_programs[np++] = number;
        } else if (!std::strncmp(line, "draw=", 5)) {
            if (nd == 64 || !parse_number(line + 5, &number) || !number || number > INT64_MAX) { ++invalid_policy; return; }
            next_draws[nd++] = number;
        } else { ++invalid_policy; return; }
        line = end + 1;
    }
    std::memcpy(program_rules, next_programs, sizeof(next_programs));
    std::memcpy(draw_rules, next_draws, sizeof(next_draws));
    program_count = np;
    draw_count = nd;
}

int reporting_fd() {
    if (report_fd >= 0) {
        struct stat current{};
        int flags = fcntl(report_fd, F_GETFL);
        if (flags < 0 || !(flags & O_NONBLOCK) || fstat(report_fd, &current) ||
            !S_ISFIFO(current.st_mode) || current.st_dev != report_device ||
            current.st_ino != report_inode) {
            // The application may close/reuse descriptors. A reused descriptor
            // belongs to it; do not close or write that unrelated object.
            report_fd = -1;
        }
        return report_fd;
    }
    if (report_fd != -2) return -1;
    report_fd = -1;
    const char *raw = getenv("AK_RENDER_REPORT_FD");
    uint64_t value;
    if (!raw || !parse_number(raw, &value) || value > INT32_MAX) return -1;
    struct stat st{};
    int fd = int(value), flags = fcntl(fd, F_GETFL);
    // The parent creates a nonblocking pipe. Never write an arbitrary file.
    if (flags >= 0 && (flags & O_NONBLOCK) && !fstat(fd, &st) && S_ISFIFO(st.st_mode)) {
        int owned = fcntl(fd, F_DUPFD_CLOEXEC, 64);
        struct stat duplicate{};
        if (owned >= 0 && !fstat(owned, &duplicate) && S_ISFIFO(duplicate.st_mode) &&
            duplicate.st_dev == st.st_dev && duplicate.st_ino == st.st_ino) {
            report_fd = owned;
            report_device = st.st_dev;
            report_inode = st.st_ino;
        } else if (owned >= 0) close(owned);
    }
    return report_fd;
}

ssize_t report(int fd, const char *data, size_t size) {
    // Duplicate first, then validate the actual reference about to be written.
    // An accidental close/reuse of the cached FD cannot redirect this write.
    int current = fcntl(fd, F_DUPFD_CLOEXEC, 64);
    struct stat st{};
    if (current < 0) { report_fd = -1; return -1; }
    int flags = fcntl(current, F_GETFL);
    if (flags < 0 || !(flags & O_NONBLOCK) || fstat(current, &st) ||
        !S_ISFIFO(st.st_mode) || st.st_dev != report_device || st.st_ino != report_inode) {
        close(current);
        report_fd = -1;
        return -1;
    }
    // A host may close its read end while the app continues. Never let this
    // optional diagnostic pipe terminate the application through SIGPIPE.
    sigset_t one, old, pending;
    sigemptyset(&one);
    sigaddset(&one, SIGPIPE);
    if (pthread_sigmask(SIG_BLOCK, &one, &old)) { close(current); return -1; }
    sigpending(&pending);
    bool already_pending = sigismember(&pending, SIGPIPE) == 1;
    ssize_t result = write(current, data, size);
    if (result < 0 && errno == EPIPE && !already_pending) {
        timespec zero{};
        sigtimedwait(&one, nullptr, &zero);
    }
    pthread_sigmask(SIG_SETMASK, &old, nullptr);
    close(current);
    return result;
}

bool intercept(const char *api, bool uses_program = true) {
    GLint program = 0;
    static auto get_integer = reinterpret_cast<void (*)(GLenum, GLint *)>(real_symbol("glGetIntegerv"));
    if (uses_program && get_integer) get_integer(0x8B8D, &program); // GL_CURRENT_PROGRAM
    static auto egl_context = reinterpret_cast<void *(*)()>(dlsym(RTLD_NEXT, "eglGetCurrentContext"));
    static auto glx_context = reinterpret_cast<void *(*)()>(dlsym(RTLD_NEXT, "glXGetCurrentContext"));
    void *context = egl_context ? egl_context() : nullptr;
    if (!context && glx_context) context = glx_context();
    std::lock_guard<std::mutex> guard(lock);
    load_policy();
    ++draw_number;
    bool deny = false;
    if (uses_program) for (size_t i = 0; i < program_count; ++i) deny |= program_rules[i] == GLuint(program);
    for (size_t i = 0; i < draw_count; ++i) deny |= draw_rules[i] == draw_number;
    if (deny) ++blocked;
    int fd = reporting_fd();
    if (fd >= 0 && (draw_number <= MAX_EVENTS || draw_number % 256 == 0)) {
        char event[384];
        int bytes = std::snprintf(event, sizeof(event),
            "{\"kind\":\"gl_command\",\"pid\":%d,\"sequence\":\"%llu\",\"api\":\"%s\",\"program\":%u,\"context\":\"%p\",\"blocked\":%s,\"blocked_total\":\"%llu\",\"invalid_policy\":\"%llu\",\"dropped_events\":\"%llu\"}\n",
            int(getpid()), (unsigned long long)draw_number, api, GLuint(program), context,
            deny ? "true" : "false", (unsigned long long)blocked,
            (unsigned long long)invalid_policy, (unsigned long long)dropped);
        if (bytes <= 0 || size_t(bytes) >= sizeof(event) || report(fd, event, size_t(bytes)) != bytes) ++dropped;
    }
    return deny;
}
}

// Each symbol forwards unchanged unless the selected command is denied.
#define AK_DRAW(name, parameters, arguments) \
extern "C" void name parameters { \
    static auto real = reinterpret_cast<decltype(&name)>(real_symbol(#name)); \
    if (!intercept(#name) && real) real arguments; \
}

AK_DRAW(glDrawArrays, (GLenum mode, GLint first, GLsizei count), (mode, first, count))
AK_DRAW(glDrawElements, (GLenum mode, GLsizei count, GLenum type, const void *indices), (mode, count, type, indices))
AK_DRAW(glDrawRangeElements, (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const void *indices), (mode, start, end, count, type, indices))
AK_DRAW(glDrawArraysInstanced, (GLenum mode, GLint first, GLsizei count, GLsizei instances), (mode, first, count, instances))
AK_DRAW(glDrawElementsInstanced, (GLenum mode, GLsizei count, GLenum type, const void *indices, GLsizei instances), (mode, count, type, indices, instances))
AK_DRAW(glDrawElementsBaseVertex, (GLenum mode, GLsizei count, GLenum type, const void *indices, GLint base), (mode, count, type, indices, base))
AK_DRAW(glDrawRangeElementsBaseVertex, (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const void *indices, GLint base), (mode, start, end, count, type, indices, base))
AK_DRAW(glDrawElementsInstancedBaseVertex, (GLenum mode, GLsizei count, GLenum type, const void *indices, GLsizei instances, GLint base), (mode, count, type, indices, instances, base))
AK_DRAW(glDrawArraysInstancedBaseInstance, (GLenum mode, GLint first, GLsizei count, GLsizei instances, GLuint base), (mode, first, count, instances, base))
AK_DRAW(glDrawElementsInstancedBaseInstance, (GLenum mode, GLsizei count, GLenum type, const void *indices, GLsizei instances, GLuint base), (mode, count, type, indices, instances, base))
AK_DRAW(glDrawElementsInstancedBaseVertexBaseInstance, (GLenum mode, GLsizei count, GLenum type, const void *indices, GLsizei instances, GLint vertex, GLuint base), (mode, count, type, indices, instances, vertex, base))
AK_DRAW(glDrawArraysIndirect, (GLenum mode, const void *indirect), (mode, indirect))
AK_DRAW(glDrawElementsIndirect, (GLenum mode, GLenum type, const void *indirect), (mode, type, indirect))
AK_DRAW(glMultiDrawArrays, (GLenum mode, const GLint *first, const GLsizei *counts, GLsizei drawcount), (mode, first, counts, drawcount))
AK_DRAW(glMultiDrawElements, (GLenum mode, const GLsizei *counts, GLenum type, const void *const *indices, GLsizei drawcount), (mode, counts, type, indices, drawcount))
AK_DRAW(glMultiDrawElementsBaseVertex, (GLenum mode, const GLsizei *counts, GLenum type, const void *const *indices, GLsizei drawcount, const GLint *bases), (mode, counts, type, indices, drawcount, bases))
AK_DRAW(glMultiDrawArraysIndirect, (GLenum mode, const void *indirect, GLsizei drawcount, GLsizei stride), (mode, indirect, drawcount, stride))
AK_DRAW(glMultiDrawElementsIndirect, (GLenum mode, GLenum type, const void *indirect, GLsizei drawcount, GLsizei stride), (mode, type, indirect, drawcount, stride))
AK_DRAW(glDrawTransformFeedback, (GLenum mode, GLuint id), (mode, id))
AK_DRAW(glDrawTransformFeedbackStream, (GLenum mode, GLuint id, GLuint stream), (mode, id, stream))
AK_DRAW(glDrawTransformFeedbackInstanced, (GLenum mode, GLuint id, GLsizei instances), (mode, id, instances))
AK_DRAW(glDrawTransformFeedbackStreamInstanced, (GLenum mode, GLuint id, GLuint stream, GLsizei instances), (mode, id, stream, instances))

extern "C" void glClear(GLbitfield mask) {
    static auto real = reinterpret_cast<decltype(&glClear)>(real_symbol("glClear"));
    if (!intercept("glClear", false) && real) real(mask);
}
extern "C" void glBlitFramebuffer(GLint x0, GLint y0, GLint x1, GLint y1,
                                  GLint dx0, GLint dy0, GLint dx1, GLint dy1,
                                  GLbitfield mask, GLenum filter) {
    static auto real = reinterpret_cast<decltype(&glBlitFramebuffer)>(real_symbol("glBlitFramebuffer"));
    if (!intercept("glBlitFramebuffer", false) && real) real(x0,y0,x1,y1,dx0,dy0,dx1,dy1,mask,filter);
}

namespace {
Proc replacement(const char *name) {
#define AK_MATCH(symbol) if (!std::strcmp(name, #symbol)) return reinterpret_cast<Proc>(&symbol)
    AK_MATCH(glDrawArrays); AK_MATCH(glDrawElements); AK_MATCH(glDrawRangeElements);
    AK_MATCH(glDrawArraysInstanced); AK_MATCH(glDrawElementsInstanced);
    AK_MATCH(glDrawElementsBaseVertex); AK_MATCH(glDrawRangeElementsBaseVertex);
    AK_MATCH(glDrawElementsInstancedBaseVertex); AK_MATCH(glDrawArraysInstancedBaseInstance);
    AK_MATCH(glDrawElementsInstancedBaseInstance); AK_MATCH(glDrawElementsInstancedBaseVertexBaseInstance);
    AK_MATCH(glDrawArraysIndirect); AK_MATCH(glDrawElementsIndirect);
    AK_MATCH(glMultiDrawArrays); AK_MATCH(glMultiDrawElements); AK_MATCH(glMultiDrawElementsBaseVertex);
    AK_MATCH(glMultiDrawArraysIndirect); AK_MATCH(glMultiDrawElementsIndirect);
    AK_MATCH(glDrawTransformFeedback); AK_MATCH(glDrawTransformFeedbackStream);
    AK_MATCH(glDrawTransformFeedbackInstanced); AK_MATCH(glDrawTransformFeedbackStreamInstanced);
    AK_MATCH(glClear); AK_MATCH(glBlitFramebuffer);
#undef AK_MATCH
    return nullptr;
}
}

extern "C" Proc eglGetProcAddress(const char *name) {
    static auto real = reinterpret_cast<Proc (*)(const char *)>(dlsym(RTLD_NEXT, "eglGetProcAddress"));
    Proc result = real ? real(name) : nullptr;
    Proc hook = result && name ? replacement(name) : nullptr;
    return hook ? hook : result;
}
extern "C" Proc glXGetProcAddress(const unsigned char *name) {
    static auto real = reinterpret_cast<Proc (*)(const unsigned char *)>(dlsym(RTLD_NEXT, "glXGetProcAddress"));
    Proc result = real ? real(name) : nullptr;
    Proc hook = result && name ? replacement(reinterpret_cast<const char *>(name)) : nullptr;
    return hook ? hook : result;
}
extern "C" Proc glXGetProcAddressARB(const unsigned char *name) {
    static auto real = reinterpret_cast<Proc (*)(const unsigned char *)>(dlsym(RTLD_NEXT, "glXGetProcAddressARB"));
    Proc result = real ? real(name) : nullptr;
    Proc hook = result && name ? replacement(reinterpret_cast<const char *>(name)) : nullptr;
    return hook ? hook : result;
}
