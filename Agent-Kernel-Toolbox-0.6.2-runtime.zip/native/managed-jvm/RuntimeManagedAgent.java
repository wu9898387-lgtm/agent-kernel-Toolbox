import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Fixed JDI operations for a launched, cooperative JVM. No expression evaluator. */
public final class RuntimeManagedAgent {
    private VirtualMachine vm;
    private Process process;
    private ReferenceType type;
    private ThreadReference thread;
    private Location safePoint;
    private final Set<String> fields;
    private final Set<String> methods;
    private final String rootField;
    private final Path patches;
    private long classEpoch;
    private boolean effectStarted;
    private final Capture output = new Capture();
    private final Capture errors = new Capture();

    private RuntimeManagedAgent(String[] args) {
        rootField = args[5];
        patches = Path.of(args[9]);
        fields = new LinkedHashSet<>(Arrays.asList(args[6].split(",")));
        methods = new LinkedHashSet<>();
        if (!args[7].isEmpty()) methods.addAll(Arrays.asList(args[7].split(",")));
    }

    private static final class Capture implements Runnable {
        InputStream stream;
        final ByteArrayOutputStream prefix = new ByteArrayOutputStream();
        long bytes;
        public void run() {
            byte[] buffer = new byte[1024];
            try {
                int count;
                while ((count = stream.read(buffer)) >= 0) {
                    synchronized (this) {
                        bytes += count;
                        int keep = Math.min(count, 4096 - prefix.size());
                        if (keep > 0) prefix.write(buffer, 0, keep);
                    }
                }
            } catch (IOException ignored) { }
        }
        synchronized Object describe() {
            return obj("prefix", prefix.toString(StandardCharsets.UTF_8), "bytes", bytes,
                       "truncated", bytes > prefix.size());
        }
    }

    private void launch(String[] args) throws Exception {
        LaunchingConnector connector = Bootstrap.virtualMachineManager().defaultConnector();
        Map<String, Connector.Argument> settings = connector.defaultArguments();
        settings.get("main").setValue(args[1]);
        settings.get("options").setValue("-Xms16m -Xmx64m -Duser.home=\"" + args[8]
            + "\" -Djava.io.tmpdir=\"" + args[8] + "\" -cp \"" + args[0] + "\"");
        settings.get("suspend").setValue("true");
        vm = connector.launch(settings);
        process = vm.process();
        output.stream = process.getInputStream();
        errors.stream = process.getErrorStream();
        for (Capture capture : List.of(output, errors)) {
            Thread drain = new Thread(capture, "managed-target-output");
            drain.setDaemon(true);
            drain.start();
        }
        ClassPrepareRequest prepare = vm.eventRequestManager().createClassPrepareRequest();
        prepare.addClassFilter(args[2]);
        prepare.setSuspendPolicy(EventRequest.SUSPEND_ALL);
        prepare.enable();
        waitForSafePoint(args[2], args[3], args[4], 8000);
    }

    private void waitForSafePoint(String className, String methodName, String signature,
                                  long timeout) throws Exception {
        long deadline = System.nanoTime() + timeout * 1_000_000L;
        while (System.nanoTime() < deadline) {
            long remaining = Math.max(1L, (deadline - System.nanoTime()) / 1_000_000L);
            EventSet events = vm.eventQueue().remove(remaining);
            if (events == null) continue;
            boolean held = false;
            for (Event event : events) {
                if (event instanceof ClassPrepareEvent prepared) {
                    if (!prepared.referenceType().name().equals(className)) continue;
                    type = prepared.referenceType();
                    List<Method> matching = type.methodsByName(methodName, signature);
                    if (matching.size() != 1 || matching.get(0).isNative())
                        throw new IllegalStateException("managed_safe_point_missing");
                    safePoint = matching.get(0).location();
                    installBreakpoint();
                    vm.eventRequestManager().deleteEventRequest(prepared.request());
                } else if (event instanceof BreakpointEvent stopped) {
                    thread = stopped.thread();
                    held = true;
                    vm.eventRequestManager().deleteEventRequest(stopped.request());
                } else if (event instanceof VMDeathEvent || event instanceof VMDisconnectEvent) {
                    throw new IllegalStateException("managed_target_exited");
                }
            }
            if (held) return;
            events.resume();
        }
        throw new IllegalStateException("managed_safe_point_timeout");
    }

    private void installBreakpoint() {
        BreakpointRequest request = vm.eventRequestManager().createBreakpointRequest(safePoint);
        request.setSuspendPolicy(EventRequest.SUSPEND_ALL);
        request.enable();
    }

    private ObjectReference root() {
        Field field = type.fieldByName(rootField);
        if (field == null || !field.isStatic()) throw new IllegalStateException("managed_root_missing");
        Value value = type.getValue(field);
        if (!(value instanceof ObjectReference reference)) throw new IllegalStateException("managed_root_not_object");
        return reference;
    }

    private ObjectReference checkedRoot(String expected) {
        ObjectReference reference = root();
        if (!Long.toString(reference.uniqueID()).equals(expected))
            throw new IllegalStateException("managed_stale_object_handle");
        return reference;
    }

    private Field checkedField(ObjectReference reference, String name) {
        if (!fields.contains(name)) throw new IllegalStateException("managed_field_not_allowed");
        Field field = reference.referenceType().fieldByName(name);
        if (field == null || field.isStatic()) throw new IllegalStateException("managed_field_missing");
        return field;
    }

    private static Object value(Value value) {
        if (value == null) return null;
        if (value instanceof IntegerValue v) return v.value();
        if (value instanceof LongValue v) return v.value();
        if (value instanceof BooleanValue v) return v.value();
        if (value instanceof ShortValue v) return (int) v.value();
        if (value instanceof ByteValue v) return (int) v.value();
        if (value instanceof StringReference v) {
            String text = v.value();
            return text.length() <= 256 ? text : text.substring(0, 256);
        }
        if (value instanceof ObjectReference v)
            return obj("object_id", Long.toString(v.uniqueID()), "type", v.referenceType().name());
        return obj("type", value.type().name(), "readable", false);
    }

    private Map<String, Object> snapshot() throws Exception {
        ObjectReference reference = root();
        Map<String, Object> values = new LinkedHashMap<>();
        List<Object> metadata = new ArrayList<>();
        for (String name : fields) {
            Field field = checkedField(reference, name);
            values.put(name, value(reference.getValue(field)));
            metadata.add(obj("name", name, "signature", field.signature(),
                "declaring_type", field.declaringType().name(), "volatile", field.isVolatile(),
                "final", field.isFinal(), "location_source", "JVM_runtime_field_metadata"));
        }
        return obj("ok", true, "state", "stopped_at_registered_safe_point", "pid", process.pid(),
            "object_id", Long.toString(reference.uniqueID()), "type", reference.referenceType().name(),
            "class_signature", reference.referenceType().signature(), "values", values,
            "class_loader_id", reference.referenceType().classLoader() == null ? "0"
                : Long.toString(reference.referenceType().classLoader().uniqueID()),
            "layout", metadata, "vm_name", vm.name(), "vm_version", vm.version(),
            "thread_id", Long.toString(thread.uniqueID()), "thread_name", thread.name(),
            "location", obj("method", thread.frame(0).location().method().name(),
                "code_index", thread.frame(0).location().codeIndex(), "line", thread.frame(0).location().lineNumber()),
            "physical_address_known", false, "class_epoch", classEpoch,
            "class_redefinition_supported", vm.canRedefineClasses(),
            "stdout", output.describe(), "stderr", errors.describe());
    }

    private Object set(String[] args) throws Exception {
        ObjectReference reference = checkedRoot(args[1]);
        Field field = checkedField(reference, args[2]);
        if (field.isFinal()) throw new IllegalStateException("managed_final_field_write_denied");
        long expected = Long.parseLong(args[3]);
        long replacement = Long.parseLong(args[4]);
        Value before = reference.getValue(field);
        Value after;
        long observed;
        if (before instanceof IntegerValue v) {
            observed = v.value();
            if (replacement < Integer.MIN_VALUE || replacement > Integer.MAX_VALUE)
                throw new IllegalStateException("managed_value_out_of_range");
            after = vm.mirrorOf((int) replacement);
        } else if (before instanceof LongValue v) {
            observed = v.value(); after = vm.mirrorOf(replacement);
        } else if (before instanceof BooleanValue v) {
            observed = v.value() ? 1 : 0;
            if (replacement != 0 && replacement != 1) throw new IllegalStateException("managed_value_out_of_range");
            after = vm.mirrorOf(replacement == 1);
        } else throw new IllegalStateException("managed_field_write_type_unsupported");
        if (observed != expected) return obj("ok", false, "status", "rejected",
            "error", "managed_precondition_mismatch", "observed", observed, "dispatched", false);
        try {
            effectStarted = true;
            reference.setValue(field, after);
            if (!reference.getValue(field).equals(after)) throw new IllegalStateException("managed_readback_mismatch");
        } catch (Exception error) {
            boolean restored = false;
            try { reference.setValue(field, before); restored = reference.getValue(field).equals(before); }
            catch (Exception ignored) { }
            return obj("ok", false, "status", restored ? "rolled_back" : "unknown",
                       "rollback_verified", restored, "dispatched", true);
        }
        return obj("ok", true, "status", "verified", "dispatched", true, "snapshot", snapshot());
    }

    private Object invoke(String[] args) throws Exception {
        ObjectReference reference = checkedRoot(args[1]);
        if (!methods.contains(args[2])) throw new IllegalStateException("managed_method_not_allowed");
        List<Method> matching = reference.referenceType().methodsByName(args[2], "(I)I");
        if (matching.size() != 1 || matching.get(0).isNative() || matching.get(0).isStatic())
            throw new IllegalStateException("managed_method_signature_unsupported");
        Value state = reference.getValue(checkedField(reference, fields.iterator().next()));
        if (!(state instanceof PrimitiveValue primitive) || primitive.longValue() != Long.parseLong(args[3]))
            return obj("ok", false, "status", "rejected", "error", "managed_precondition_mismatch", "dispatched", false);
        int argument = Integer.parseInt(args[4]);
        try {
            effectStarted = true;
            Value result = reference.invokeMethod(thread, matching.get(0), List.of(vm.mirrorOf(argument)),
                                                  ObjectReference.INVOKE_SINGLE_THREADED);
            return obj("ok", true, "status", "returned", "dispatched", true,
                       "value", value(result), "snapshot", snapshot());
        } catch (Exception error) {
            return obj("ok", false, "status", "unknown", "dispatched", true,
                       "error", "managed_method_outcome_unknown");
        }
    }

    private Object advance() throws Exception {
        effectStarted = true;
        installBreakpoint();
        try { vm.resume(); waitForSafePoint(type.name(), "", "", 2000); }
        catch (Exception error) { return obj("ok", false, "status", "unknown", "dispatched", true,
                                            "error", "managed_safe_point_outcome_unknown"); }
        return snapshot();
    }

    private Object redefine(String[] args) throws Exception {
        ObjectReference reference = checkedRoot(args[1]);
        if (Long.parseLong(args[2]) != classEpoch)
            throw new IllegalStateException("managed_stale_class_epoch");
        if (!args[3].matches("[A-Za-z0-9_-]{1,64}")) throw new IllegalStateException("managed_invalid_patch");
        Value state = reference.getValue(checkedField(reference, fields.iterator().next()));
        if (!(state instanceof PrimitiveValue primitive) || primitive.longValue() != Long.parseLong(args[4]))
            return obj("ok", false, "status", "rejected", "error", "managed_precondition_mismatch", "dispatched", false);
        if (!vm.canRedefineClasses()) throw new IllegalStateException("managed_redefinition_unavailable");
        Path patch = patches.resolve(args[3] + ".class");
        if (!Files.isRegularFile(patch) || Files.size(patch) > 262144)
            throw new IllegalStateException("managed_invalid_patch");
        byte[] bytes = Files.readAllBytes(patch);
        try {
            effectStarted = true;
            vm.redefineClasses(Map.of(reference.referenceType(), bytes));
        } catch (UnsupportedOperationException | VerifyError | ClassFormatError | NoClassDefFoundError error) {
            return obj("ok", false, "status", "rejected", "error", "managed_class_schema_change_denied", "dispatched", false);
        } catch (RuntimeException error) {
            return obj("ok", false, "status", "unknown", "error", "managed_redefinition_outcome_unknown", "dispatched", true);
        }
        classEpoch++;
        return obj("ok", true, "status", "redefined", "dispatched", true,
            "class_epoch", classEpoch, "snapshot", snapshot(), "existing_frames_may_use_old_bytecode", true);
    }

    private static String readLine(Reader source) throws IOException {
        StringBuilder line = new StringBuilder();
        int character;
        while ((character = source.read()) != -1) {
            if (character == '\n') return line.toString();
            if (line.length() >= 1024) throw new IOException("managed_command_budget");
            line.append((char) character);
        }
        return line.length() == 0 ? null : line.toString();
    }

    private boolean close() {
        try { if (vm != null) vm.exit(0); } catch (RuntimeException ignored) { }
        if (process == null) return true;
        try {
            if (!process.waitFor(1000, TimeUnit.MILLISECONDS)) process.destroyForcibly();
            return process.waitFor(1000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException error) { Thread.currentThread().interrupt(); return false; }
    }

    private static Map<String, Object> obj(Object... values) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (int index = 0; index < values.length; index += 2)
            result.put((String) values[index], values[index + 1]);
        return result;
    }

    private static String json(Object value) {
        if (value == null) return "null";
        if (value instanceof Number || value instanceof Boolean) return value.toString();
        if (value instanceof Map<?, ?> map) {
            List<String> items = new ArrayList<>();
            for (Map.Entry<?, ?> item : map.entrySet()) items.add(json(item.getKey()) + ":" + json(item.getValue()));
            return "{" + String.join(",", items) + "}";
        }
        if (value instanceof Collection<?> list) {
            List<String> items = new ArrayList<>();
            for (Object item : list) items.add(json(item));
            return "[" + String.join(",", items) + "]";
        }
        String text = value.toString();
        StringBuilder encoded = new StringBuilder("\"");
        for (int index = 0; index < text.length(); index++) {
            char character = text.charAt(index);
            if (character == '\\' || character == '"') encoded.append('\\').append(character);
            else if (character < 32 || character > 126) encoded.append(String.format("\\u%04x", (int) character));
            else encoded.append(character);
        }
        return encoded.append('"').toString();
    }

    private static void emit(Object value) { System.out.println(json(value)); System.out.flush(); }

    public static void main(String[] args) {
        if (args.length != 10) { emit(obj("ok", false, "error", "managed_invalid_profile")); return; }
        RuntimeManagedAgent agent = new RuntimeManagedAgent(args);
        try {
            agent.launch(args);
            emit(obj("ok", true, "event", "ready", "snapshot", agent.snapshot()));
            BufferedReader source = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII));
            String line;
            while ((line = readLine(source)) != null) {
                String[] command = line.split("\t", -1);
                agent.effectStarted = false;
                try {
                    if (command[0].equals("snapshot") && command.length == 1) emit(agent.snapshot());
                    else if (command[0].equals("set") && command.length == 5) emit(agent.set(command));
                    else if (command[0].equals("invoke") && command.length == 5) emit(agent.invoke(command));
                    else if (command[0].equals("redefine") && command.length == 5) emit(agent.redefine(command));
                    else if (command[0].equals("advance") && command.length == 1) emit(agent.advance());
                    else if (command[0].equals("close") && command.length == 1) {
                        agent.effectStarted = true;
                        emit(obj("ok", true, "target_exit_confirmed", agent.close())); return;
                    } else emit(obj("ok", false, "error", "managed_invalid_command", "dispatched", false));
                } catch (Exception error) {
                    String code = error.getMessage();
                    if (code == null || !code.matches("managed_[a-z_]+")) code = "managed_operation_failed";
                    emit(obj("ok", false, "error", code, "dispatched", agent.effectStarted,
                        "status", agent.effectStarted ? "unknown" : "rejected"));
                }
            }
        } catch (Exception error) { emit(obj("ok", false, "error", "managed_launch_or_transport_failed")); }
        finally { agent.close(); }
    }
}
