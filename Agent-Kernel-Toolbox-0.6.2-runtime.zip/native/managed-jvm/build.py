#!/usr/bin/env python3
"""Compile the dependency-free JDI controller with the selected JDK."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
ENTRY = ROOT / 'runtime-access.pyz'
sys.path.insert(0, str(ENTRY if ENTRY.is_file() else ROOT / 'src'))
from observation_extension.managed_jvm import classpath_sha256


def build(java, output):
    output = Path(output).resolve()
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    subprocess.run([str(java), 'com.sun.tools.javac.Main', '--add-modules', 'jdk.jdi',
                    '-g', '-encoding', 'UTF-8', '-d', str(output),
                    str(Path(__file__).with_name('RuntimeManagedAgent.java'))], check=True, timeout=30)
    return {'helper_directory': str(output), 'helper_sha256': classpath_sha256(output)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--java', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.java, args.output), indent=2))
