#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/audit.h>
#include <linux/bpf.h>
#include <linux/filter.h>
#include <linux/landlock.h>
#include <linux/perf_event.h>
#include <linux/seccomp.h>
#include <poll.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#ifndef LANDLOCK_ACCESS_FS_REFER
#define LANDLOCK_ACCESS_FS_REFER (1ULL<<13)
#endif
#ifndef LANDLOCK_ACCESS_FS_TRUNCATE
#define LANDLOCK_ACCESS_FS_TRUNCATE (1ULL<<14)
#endif
static unsigned long long now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (unsigned long long)t.tv_sec*1000000000ULL+t.tv_nsec;}
static int number(const char *s,long min,long max,long *out){char *end;errno=0;long v=strtol(s,&end,10);if(errno||!s[0]||*end||v<min||v>max)return -1;*out=v;return 0;}
static int blocked(const char *op){int e=errno;printf("{\"status\":\"blocked\",\"operation\":\"%s\",\"errno\":%d}\n",op,e);return 77;}
static int seccomp_install(void){
#if defined(__x86_64__)
#define NATIVE_AUDIT AUDIT_ARCH_X86_64
#elif defined(__aarch64__)
#define NATIVE_AUDIT AUDIT_ARCH_AARCH64
#else
    errno=ENOTSUP;return -1;
#endif
#ifdef NATIVE_AUDIT
#define DENY(nr) BPF_JUMP(BPF_JMP|BPF_JEQ|BPF_K,nr,0,1), BPF_STMT(BPF_RET|BPF_K,SECCOMP_RET_ERRNO|EPERM)
    struct sock_filter filter[]={
        BPF_STMT(BPF_LD|BPF_W|BPF_ABS,offsetof(struct seccomp_data,arch)),
        BPF_JUMP(BPF_JMP|BPF_JEQ|BPF_K,NATIVE_AUDIT,1,0),
        BPF_STMT(BPF_RET|BPF_K,SECCOMP_RET_KILL_PROCESS),
        BPF_STMT(BPF_LD|BPF_W|BPF_ABS,offsetof(struct seccomp_data,nr)),
#if defined(__x86_64__)
        BPF_JUMP(BPF_JMP|BPF_JSET|BPF_K,0x40000000,0,1),
        BPF_STMT(BPF_RET|BPF_K,SECCOMP_RET_KILL_PROCESS),
#endif
        DENY(__NR_ptrace),DENY(__NR_bpf),DENY(__NR_mount),DENY(__NR_umount2),
        DENY(__NR_reboot),DENY(__NR_kexec_load),DENY(__NR_process_vm_writev),
        DENY(__NR_open_by_handle_at),DENY(__NR_unshare),DENY(__NR_setns),
        BPF_STMT(BPF_RET|BPF_K,SECCOMP_RET_ALLOW)
    };
    struct sock_fprog prog={(unsigned short)(sizeof(filter)/sizeof(filter[0])),filter};
    if(prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0))return -1;
    return prctl(PR_SET_SECCOMP,SECCOMP_MODE_FILTER,&prog);
#endif
}
static int landlock_install(int count,char **paths){
#ifdef __NR_landlock_create_ruleset
    int abi=syscall(__NR_landlock_create_ruleset,NULL,0,LANDLOCK_CREATE_RULESET_VERSION);
    if(abi<1)return -1;
    /* Earlier ABIs do not restrict truncate/ftruncate, so cannot promise read-only. */
    if(abi<3){errno=EOPNOTSUPP;return -1;}
    uint64_t handled=(1ULL<<13)-1;
    if(abi>=2)handled|=LANDLOCK_ACCESS_FS_REFER;
    if(abi>=3)handled|=LANDLOCK_ACCESS_FS_TRUNCATE;
    struct landlock_ruleset_attr rules={.handled_access_fs=handled};
    int fd=syscall(__NR_landlock_create_ruleset,&rules,sizeof(rules),0);
    if(fd<0)return -1;
    for(int i=0;i<count;i++){
        /* argv paths are fixed read-only allowlist entries plus the private workdir. */
        int p=open(paths[i],O_PATH|O_CLOEXEC);if(p<0){close(fd);return -1;}
        struct stat st;if(fstat(p,&st)){close(p);close(fd);return -1;}
        uint64_t access=LANDLOCK_ACCESS_FS_READ_FILE|LANDLOCK_ACCESS_FS_EXECUTE;
        if(S_ISDIR(st.st_mode))access|=LANDLOCK_ACCESS_FS_READ_DIR;
        struct landlock_path_beneath_attr rule={.allowed_access=access,.parent_fd=p};
        int r=syscall(__NR_landlock_add_rule,fd,LANDLOCK_RULE_PATH_BENEATH,&rule,0);
        close(p);if(r){close(fd);return -1;}
    }
    int r=prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0);
    if(!r)r=syscall(__NR_landlock_restrict_self,fd,0);
    int e=errno;close(fd);errno=e;return r;
#else
    (void)count;(void)paths;errno=ENOSYS;return -1;
#endif
}
/* Fixed ring-buffer BPF programs assembled from the public Linux instruction ABI. */
static int bpf_call(enum bpf_cmd cmd,union bpf_attr *a){return syscall(__NR_bpf,cmd,a,sizeof(*a));}
static struct bpf_insn ins(unsigned char code,unsigned char dst,unsigned char src,short off,int imm){return (struct bpf_insn){.code=code,.dst_reg=dst,.src_reg=src,.off=off,.imm=imm};}
#define EMIT(c,d,s,o,i) code[n++]=ins(c,d,s,o,i)
#define MOVI(d,i) EMIT(BPF_ALU64|BPF_MOV|BPF_K,d,0,0,i)
#define MOVR(d,s) EMIT(BPF_ALU64|BPF_MOV|BPF_X,d,s,0,0)
#define CALL(i) EMIT(BPF_JMP|BPF_CALL,0,0,0,i)
#define MAP(d,fd) do{EMIT(BPF_LD|BPF_DW|BPF_IMM,d,BPF_PSEUDO_MAP_FD,0,fd);EMIT(0,0,0,0,0);}while(0)
#define IMM64(d,value) do{uint64_t v=(value);EMIT(BPF_LD|BPF_DW|BPF_IMM,d,0,0,(uint32_t)v);EMIT(0,0,0,0,v>>32);}while(0)
static int event_program(int ring,int losses,int pid,int event,uint64_t nsdev,uint64_t nsino,char *log,size_t logsize){
    struct bpf_insn code[64];int n=0;
    MOVR(6,1);IMM64(1,nsdev);IMM64(2,nsino);MOVR(3,10);
    EMIT(BPF_ALU64|BPF_ADD|BPF_K,3,0,0,-16);MOVI(4,8);
    EMIT(BPF_ST|BPF_MEM|BPF_DW,10,0,-16,0);
    CALL(BPF_FUNC_get_ns_current_pid_tgid);
    int bad_ns=n;EMIT(BPF_JMP|BPF_JNE|BPF_K,0,0,0,0);
    EMIT(BPF_LDX|BPF_MEM|BPF_W,7,10,-16,0);
    EMIT(BPF_LDX|BPF_MEM|BPF_W,0,10,-12,0);
    MOVR(9,0);EMIT(BPF_ALU64|BPF_LSH|BPF_K,9,0,0,32);
    EMIT(BPF_ALU64|BPF_OR|BPF_X,7,9,0,0);
    int skip=n;EMIT(BPF_JMP|BPF_JNE|BPF_K,0,0,0,pid);
    MAP(1,ring);MOVI(2,32);MOVI(3,0);CALL(BPF_FUNC_ringbuf_reserve);
    int lost=n;EMIT(BPF_JMP|BPF_JEQ|BPF_K,0,0,0,0);
    MOVR(8,0);CALL(BPF_FUNC_ktime_get_ns);
    EMIT(BPF_STX|BPF_MEM|BPF_DW,8,0,0,0);
    EMIT(BPF_STX|BPF_MEM|BPF_DW,8,7,8,0);
    EMIT(BPF_ST|BPF_MEM|BPF_DW,8,0,16,event);
    if(event==1){EMIT(BPF_LDX|BPF_MEM|BPF_DW,0,6,8,0);EMIT(BPF_STX|BPF_MEM|BPF_DW,8,0,24,0);}
    else EMIT(BPF_ST|BPF_MEM|BPF_DW,8,0,24,0);
    MOVR(1,8);MOVI(2,0);CALL(BPF_FUNC_ringbuf_submit);
    int done=n;EMIT(BPF_JMP|BPF_JA,0,0,0,0);
    int fail=n;MAP(1,losses);MOVR(2,10);EMIT(BPF_ALU64|BPF_ADD|BPF_K,2,0,0,-4);
    EMIT(BPF_ST|BPF_MEM|BPF_W,10,0,-4,0);CALL(BPF_FUNC_map_lookup_elem);
    int no_map=n;EMIT(BPF_JMP|BPF_JEQ|BPF_K,0,0,0,0);
    MOVI(1,1);EMIT(BPF_STX|BPF_ATOMIC|BPF_DW,0,1,0,BPF_ADD);
    int finish=n;MOVI(0,0);EMIT(BPF_JMP|BPF_EXIT,0,0,0,0);
    code[bad_ns].off=finish-bad_ns-1;code[skip].off=finish-skip-1;code[lost].off=fail-lost-1;
    code[done].off=finish-done-1;code[no_map].off=finish-no_map-1;
    union bpf_attr a={0};a.prog_type=event==3?BPF_PROG_TYPE_KPROBE:BPF_PROG_TYPE_TRACEPOINT;
    a.insn_cnt=n;a.insns=(uint64_t)(uintptr_t)code;a.license=(uint64_t)(uintptr_t)"GPL";
    a.log_buf=(uint64_t)(uintptr_t)log;a.log_size=logsize;a.log_level=1;
    return bpf_call(BPF_PROG_LOAD,&a);
}
static int perf_attach(int prog,int pid,int type,unsigned long long config,const char *binary,unsigned long long offset){
    struct perf_event_attr a={0};a.size=sizeof(a);a.type=type;a.config=config;a.disabled=1;
    a.sample_period=1;a.wakeup_events=1;
    if(binary){a.config1=(uint64_t)(uintptr_t)binary;a.config2=offset;}
    int fd=syscall(__NR_perf_event_open,&a,pid,-1,-1,PERF_FLAG_FD_CLOEXEC);
    if(fd<0)return -1;
    if(ioctl(fd,PERF_EVENT_IOC_SET_BPF,prog)||ioctl(fd,PERF_EVENT_IOC_ENABLE,0)){int e=errno;close(fd);errno=e;return -1;}
    return fd;
}
static int capture(int argc,char **argv){
    /* pid duration_ms syscall_tp_id exit_tp_id max_events tid_csv nsdev nsino [uprobe_type binary offset] */
    if(argc!=10&&argc!=13)return 2;
    long pid,ms,enterid,exitid,maxevents,nsdev,nsino;
    if(number(argv[2],1,2147483647,&pid)||number(argv[3],1,5000,&ms)||number(argv[4],1,2147483647,&enterid)||number(argv[5],1,2147483647,&exitid)||number(argv[6],1,512,&maxevents))return 2;
    if(number(argv[8],0,0x7fffffffffffffffL,&nsdev)||number(argv[9],1,0x7fffffffffffffffL,&nsino))return 2;
    int fds[1024],count=0,status=77;void *consumer=MAP_FAILED,*producer=MAP_FAILED;long page=sysconf(_SC_PAGESIZE);
    int ring=-1,losses=-1,programs[3]={-1,-1,-1};unsigned long long seen=0,discard=0;
    union bpf_attr a={0};a.map_type=BPF_MAP_TYPE_RINGBUF;a.max_entries=65536;ring=bpf_call(BPF_MAP_CREATE,&a);
    if(ring<0)return blocked("BPF_MAP_CREATE_ringbuf");
    memset(&a,0,sizeof(a));a.map_type=BPF_MAP_TYPE_ARRAY;a.key_size=4;a.value_size=8;a.max_entries=1;losses=bpf_call(BPF_MAP_CREATE,&a);
    if(losses<0){blocked("BPF_MAP_CREATE_losses");goto cleanup;}
    consumer=mmap(NULL,page,PROT_READ|PROT_WRITE,MAP_SHARED,ring,0);
    producer=mmap(NULL,page+131072,PROT_READ,MAP_SHARED,ring,page);
    if(consumer==MAP_FAILED||producer==MAP_FAILED){blocked("mmap_ringbuf");goto cleanup;}
    char log[16384]={0};
    for(int i=0;i<(argc==13?3:2);i++){
        programs[i]=event_program(ring,losses,pid,i+1,nsdev,nsino,log,sizeof(log));
        if(programs[i]<0){blocked("BPF_PROG_LOAD_fixed_event");goto cleanup;}
    }
    char *tids=strdup(argv[7]);if(!tids){errno=ENOMEM;blocked("tid_copy");goto cleanup;}
    char *save=NULL,*part=strtok_r(tids,",",&save);int tidcount=0;
    while(part){long tid;if(number(part,1,2147483647,&tid)||++tidcount>256){free(tids);status=2;goto cleanup;}
        for(int i=0;i<(argc==13?3:2);i++){
            long utype=0,off=0;
            if(i==2&&(number(argv[10],1,2147483647,&utype)||number(argv[12],0,2147483647,&off))){free(tids);status=2;goto cleanup;}
            int fd=perf_attach(programs[i],tid,i==2?utype:PERF_TYPE_TRACEPOINT,i==0?enterid:i==1?exitid:0,i==2?argv[11]:NULL,off);
            if(fd<0){free(tids);blocked(i==2?"uprobe_attach":"tracepoint_attach");goto cleanup;}
            fds[count++]=fd;
        }part=strtok_r(NULL,",",&save);
    }free(tids);
    printf("{\"type\":\"attached\",\"attachments\":%d,\"threads\":%d,\"transport\":\"bpf_ringbuf\"}\n",count,tidcount);fflush(stdout);
    unsigned long long deadline=now_ns()+ms*1000000ULL;int finishing=0;
    for(;;){
        if(!finishing&&now_ns()>=deadline){
            for(int i=0;i<count;i++)if(ioctl(fds[i],PERF_EVENT_IOC_DISABLE,0)){blocked("perf_disable");goto cleanup;}
            finishing=1;
        }
        unsigned long cons=__atomic_load_n((unsigned long*)consumer,__ATOMIC_RELAXED);
        unsigned long prod=__atomic_load_n((unsigned long*)producer,__ATOMIC_ACQUIRE);
        while(cons<prod){
            unsigned char *record=(unsigned char*)producer+page+(cons&65535);
            unsigned int length=__atomic_load_n((unsigned int*)record,__ATOMIC_ACQUIRE);
            if(length&(1U<<31))break;
            unsigned int size=length&((1U<<30)-1);
            if(size!=32){errno=EPROTO;blocked("ringbuf_record_size");goto cleanup;}
            if(length&(1U<<30))discard++;
            else {
                unsigned long long fields[4];memcpy(fields,record+8,32);seen++;
                if(seen<=(unsigned long long)maxevents)printf("{\"type\":\"event\",\"time_ns\":%llu,\"pid\":%llu,\"tid\":%llu,\"kind\":%llu,\"value\":%llu}\n",fields[0],fields[1]>>32,fields[1]&0xffffffffULL,fields[2],fields[3]);
            }
            cons+=(size+15)&~7UL;__atomic_store_n((unsigned long*)consumer,cons,__ATOMIC_RELEASE);
        }
        if(finishing){
            if(cons==prod)break;
            if(now_ns()>deadline+100000000ULL){errno=EBUSY;blocked("ringbuf_final_drain");goto cleanup;}
        }
        struct pollfd p={.fd=ring,.events=POLLIN};poll(&p,1,10);
    }
    unsigned key=0;unsigned long long lost=0;memset(&a,0,sizeof(a));a.map_fd=losses;a.key=(uint64_t)(uintptr_t)&key;a.value=(uint64_t)(uintptr_t)&lost;
    if(bpf_call(BPF_MAP_LOOKUP_ELEM,&a)){blocked("loss_map_read");goto cleanup;}
    printf("{\"type\":\"summary\",\"seen\":%llu,\"kernel_reserve_failures\":%llu,\"discarded_records\":%llu,\"budget_dropped_events\":%llu}\n",seen,lost,discard,seen>(unsigned long long)maxevents?seen-maxevents:0);
    status=0;
cleanup:
    for(int i=0;i<count;i++)close(fds[i]);
    for(int i=0;i<3;i++)if(programs[i]>=0)close(programs[i]);
    if(consumer!=MAP_FAILED)munmap(consumer,page);
    if(producer!=MAP_FAILED)munmap(producer,page+131072);
    if(losses>=0)close(losses);
    if(ring>=0)close(ring);
    return status;
}
int main(int argc,char **argv){
    struct rlimit zero={0,0};setrlimit(RLIMIT_CORE,&zero);
    if(argc<2)return 2;
    if(!strcmp(argv[1],"capture"))return capture(argc,argv);
    if(!strcmp(argv[1],"run")&&argc>=7){
        long sec,land,count;if(number(argv[2],0,1,&sec)||number(argv[3],0,1,&land)||number(argv[4],0,16,&count)||argc<7+count||strcmp(argv[5+count],"--"))return 2;
        if(land&&landlock_install(count,argv+5))return blocked("landlock_restrict_self");
        if(sec&&seccomp_install())return blocked("seccomp_install");
        fprintf(stderr,"MONITOR_GUARD:{\"seccomp\":%s,\"landlock\":%s,\"no_new_privs\":%d,\"filter_mode\":%d}\n",sec?"true":"false",land?"true":"false",prctl(PR_GET_NO_NEW_PRIVS,0,0,0,0),prctl(PR_GET_SECCOMP,0,0,0,0));fflush(stderr);
        execv(argv[6+count],argv+6+count);return blocked("guard_execv");
    }
    return 2;
}
