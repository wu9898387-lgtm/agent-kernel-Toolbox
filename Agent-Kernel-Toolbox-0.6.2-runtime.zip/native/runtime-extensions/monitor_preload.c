#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/random.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
/* A fixed launch-time model. No injection into an existing process. */
static long epoch;
static unsigned int seed;
static const char *model_path, *model_file, *hostname;
static unsigned long sequence;
static int api_value;
__attribute__((constructor)) static void model_init(void) {
    const char *s=getenv("MONITOR_MODEL_EPOCH"); epoch=s?strtol(s,0,10):1700000000;
    s=getenv("MONITOR_MODEL_BYTE"); seed=s?(unsigned)strtoul(s,0,10):42;
    model_path=getenv("MONITOR_MODEL_PATH"); model_file=getenv("MONITOR_MODEL_FILE");
    hostname=getenv("MONITOR_MODEL_HOSTNAME");
    s=getenv("MONITOR_MODEL_API"); api_value=s?(int)strtol(s,0,10):0;
    const char marker[]="MONITOR_SHIM:{\"loaded\":true,\"version\":1}\n";
    write(2,marker,sizeof(marker)-1);
}
time_t time(time_t *p) { if(p)*p=epoch; return epoch; }
int clock_gettime(clockid_t id, struct timespec *p) {
    if(id==CLOCK_REALTIME || id==CLOCK_MONOTONIC || id==CLOCK_BOOTTIME) {
        p->tv_sec=epoch; p->tv_nsec=0; return 0;
    }
    int (*real)(clockid_t,struct timespec*)=dlsym(RTLD_NEXT,"clock_gettime");
    return real(id,p);
}
int gettimeofday(struct timeval *p, void *z) { (void)z; p->tv_sec=epoch;p->tv_usec=0;return 0; }
ssize_t getrandom(void *p,size_t n,unsigned flags) {
    if(flags & ~(GRND_NONBLOCK|GRND_RANDOM)) {errno=EINVAL;return -1;}
    unsigned long start=__atomic_fetch_add(&sequence,n,__ATOMIC_RELAXED);
    for(size_t i=0;i<n;i++)((unsigned char*)p)[i]=(unsigned char)(seed+start+i);
    return (ssize_t)n;
}
int rand(void){return (int)(seed & 0x7fffffff);}
long random(void){return (long)(seed & 0x7fffffff);}
void srand(unsigned int value){(void)value;}
void srandom(unsigned int value){(void)value;}
int gethostname(char *p,size_t n) {
    if(!hostname){errno=ENOSYS;return -1;}
    size_t len=strlen(hostname);
    if(n<=len){if(n)memcpy(p,hostname,n);errno=ENAMETOOLONG;return -1;}
    memcpy(p,hostname,len+1);return 0;
}
int monitor_model_api(void){return api_value;}
static const char *mapped(const char *p,int flags) {
    if(model_path && model_file && p && strcmp(p,model_path)==0) {
        if((flags&O_ACCMODE)!=O_RDONLY || (flags&(O_CREAT|O_TRUNC|O_APPEND))) {errno=EACCES;return 0;}
        return model_file;
    }
    return p;
}
#define OPEN_WRAPPER(name) \
int name(const char *p,int flags,...) { \
    mode_t mode=0; if((flags&O_CREAT)||((flags&O_TMPFILE)==O_TMPFILE)){va_list ap;va_start(ap,flags);mode=va_arg(ap,int);va_end(ap);} \
    const char *q=mapped(p,flags);if(!q)return -1; \
    int (*real)(const char*,int,...)=dlsym(RTLD_NEXT,#name);return real(q,flags,mode); \
}
OPEN_WRAPPER(open)
OPEN_WRAPPER(open64)
#define OPENAT_WRAPPER(name) \
int name(int fd,const char *p,int flags,...) { \
    mode_t mode=0;if((flags&O_CREAT)||((flags&O_TMPFILE)==O_TMPFILE)){va_list ap;va_start(ap,flags);mode=va_arg(ap,int);va_end(ap);} \
    const char *q=mapped(p,flags);if(!q)return -1; \
    int (*real)(int,const char*,int,...)=dlsym(RTLD_NEXT,#name);return real(fd,q,flags,mode); \
}
OPENAT_WRAPPER(openat)
OPENAT_WRAPPER(openat64)
#define FOPEN_WRAPPER(name) \
FILE *name(const char *p,const char *mode) { \
    if(model_path && p && !strcmp(p,model_path) && strcmp(mode,"r") && strcmp(mode,"rb")){errno=EACCES;return 0;} \
    const char *q=mapped(p,O_RDONLY);if(!q)return 0; \
    FILE *(*real)(const char*,const char*)=dlsym(RTLD_NEXT,#name);return real(q,mode); \
}
FOPEN_WRAPPER(fopen)
FOPEN_WRAPPER(fopen64)
