#ifndef TOOLBOX_HARDENING_SDK_H
#define TOOLBOX_HARDENING_SDK_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct hardening_region hardening_region;
enum { HARDENING_NONE = 0, HARDENING_READ = 1, HARDENING_READ_WRITE = 3 };
/* Cooperative regions from the initializing leader only. MPK rights are thread-local. */
hardening_region *hardening_alloc(size_t bytes);
void *hardening_data(hardening_region *region);
size_t hardening_size(hardening_region *region);
int hardening_protect(hardening_region *region, int access);
int hardening_free(hardening_region *region);
int hardening_cet_status(unsigned long *features);
void hardening_cet_violate(void);
void hardening_cfi_violate(void);
#ifdef __cplusplus
}
#endif
#endif
