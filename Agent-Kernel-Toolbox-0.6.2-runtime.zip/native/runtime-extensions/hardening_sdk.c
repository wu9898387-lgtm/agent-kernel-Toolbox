#define _GNU_SOURCE
#include "hardening_sdk.h"
#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>
#if defined(__x86_64__)
#include <cpuid.h>
#endif
#ifndef HARDENING_MODE
#error fixed HARDENING_MODE is required
#endif
#define HK_MAGIC 0x484b5631U
struct hk_event { uint32_t magic,type,mode,pid; int32_t status,detail; uint64_t address,length,extra; };
struct hardening_region { void *data,*mapping; size_t size,total; int key,access; };
static hardening_region *regions[32];
static size_t retained;
static int event_fd=-1;
static int ack_fd=-1;
static long owner_tid;
static void event(unsigned type,int status,int detail,uintptr_t address,size_t length,uint64_t extra){
    struct hk_event e={HK_MAGIC,type,HARDENING_MODE,(uint32_t)getpid(),status,detail,(uint64_t)address,length,extra};
    if(event_fd>=0){ ssize_t n;do{n=write(event_fd,&e,sizeof(e));}while(n<0&&errno==EINTR);if(n!=(ssize_t)sizeof(e))_exit(78); }
    if(type>=2&&type<=4){
        char approved=0;ssize_t n;do{n=read(ack_fd,&approved,1);}while(n<0&&errno==EINTR);
        if(n!=1||approved!='G')_exit(77);
    }
}
static int descriptor(const char *name){
    const char *s=getenv(name);char *end=NULL;if(!s||!s[0])return -1;
    errno=0;long n=strtol(s,&end,10);if(errno||*end||n<3||n>1023)return -1;return (int)n;
}
int hardening_cet_status(unsigned long *features){
    if(!features){errno=EINVAL;return -1;}*features=0;
#if defined(__x86_64__)
    return (int)syscall(SYS_arch_prctl,0x5005,features);
#else
    errno=ENOTSUP;return -1;
#endif
}
static void fault(int signo,siginfo_t *info,void *context){
    (void)context;
    event(5,signo,info?info->si_code:0,(uintptr_t)(info?info->si_addr:NULL),0,0);
    /* SA_RESETHAND restores the default before this handler runs. */
    syscall(SYS_tgkill,getpid(),syscall(SYS_gettid),signo);
}
__attribute__((constructor(101))) static void initialize(void){
    owner_tid=syscall(SYS_gettid);
    event_fd=descriptor("HARDENING_EVENT_FD");ack_fd=descriptor("HARDENING_ACK_FD");
    if(event_fd<0||ack_fd<0)_exit(78);
    unsigned long features=0;int error=0;
    if(HARDENING_MODE==2&&hardening_cet_status(&features))error=errno;
    event(1,error,(int)features,0,0,0);
    char response=0;ssize_t n;do{n=read(ack_fd,&response,1);}while(n<0&&errno==EINTR);
    if(n!=1||response!='G')_exit(77);
    struct sigaction action;memset(&action,0,sizeof(action));
    action.sa_sigaction=fault;action.sa_flags=SA_SIGINFO|SA_RESETHAND;sigemptyset(&action.sa_mask);
    if(sigaction(SIGSEGV,&action,NULL))_exit(78);
}
static int index_of(hardening_region *r){
    if(syscall(SYS_gettid)!=owner_tid){errno=ENOTSUP;return -1;}
    for(int i=0;i<32;i++)if(regions[i]==r&&r)return i;errno=EINVAL;return -1;
}
static int pkru_supported(void){
#if defined(__x86_64__)
    unsigned a,b,c,d;if(__get_cpuid_max(0,NULL)<7)return 0;__cpuid_count(7,0,a,b,c,d);
    return (c&(1U<<3))&&(c&(1U<<4));
#else
    return 0;
#endif
}
static int set_key(int key,int access){
#if defined(__x86_64__)
    if(!pkru_supported()){errno=ENOTSUP;return -1;}
    unsigned a,d;__asm__ volatile("rdpkru":"=a"(a),"=d"(d):"c"(0));
    unsigned rights=access==HARDENING_NONE?3U:access==HARDENING_READ?2U:0U;
    a=(a&~(3U<<(key*2)))|(rights<<(key*2));
    __asm__ volatile("wrpkru"::"a"(a),"c"(0),"d"(0):"memory");return 0;
#else
    (void)key;(void)access;errno=ENOTSUP;return -1;
#endif
}
hardening_region *hardening_alloc(size_t bytes){
    if(syscall(SYS_gettid)!=owner_tid){errno=ENOTSUP;return NULL;}
    if(HARDENING_MODE!=3&&HARDENING_MODE!=4){errno=ENOTSUP;return NULL;}
    long page=sysconf(_SC_PAGESIZE);if(page<=0||!bytes||bytes>1048576){errno=EINVAL;return NULL;}
    int slot=-1;for(int i=0;i<32;i++)if(!regions[i]){slot=i;break;}
    size_t size=(bytes+(size_t)page-1)&~((size_t)page-1),total=size+2*(size_t)page;
    if(slot<0||retained+total>16777216){errno=ENOMEM;return NULL;}
    int key=-1;
    if(HARDENING_MODE==4){
#if defined(__x86_64__) && defined(SYS_pkey_alloc)
        if(!pkru_supported()){errno=ENOTSUP;event(2,errno,0,0,0,0);return NULL;}
        key=(int)syscall(SYS_pkey_alloc,0,0);if(key<0){event(2,errno,0,0,0,0);return NULL;}
#else
        errno=ENOTSUP;event(2,errno,0,0,0,0);return NULL;
#endif
    }
    void *mapping=mmap(NULL,total,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(mapping==MAP_FAILED)goto fail_key;
    void *data=(char*)mapping+page;
    if(HARDENING_MODE==4){
#if defined(SYS_pkey_mprotect)
        if(syscall(SYS_pkey_mprotect,data,size,PROT_READ|PROT_WRITE,key))goto fail_mapping;
#else
        errno=ENOTSUP;goto fail_mapping;
#endif
    }else if(mprotect(data,size,PROT_READ|PROT_WRITE))goto fail_mapping;
    {
        hardening_region *r=(hardening_region*)calloc(1,sizeof(*r));if(!r)goto fail_mapping;
        r->data=data;r->mapping=mapping;r->size=size;r->total=total;r->key=key;r->access=HARDENING_READ_WRITE;
        regions[slot]=r;retained+=total;
        event(2,0,r->access,(uintptr_t)data,size,HARDENING_MODE==4?(uint64_t)key:(uint64_t)page);return r;
    }
fail_mapping:
    {int saved=errno;munmap(mapping,total);errno=saved;}
fail_key:
    {int saved=errno;
#if defined(SYS_pkey_free)
    if(key>=0)syscall(SYS_pkey_free,key);
#endif
    event(2,saved,0,0,0,0);errno=saved;return NULL;}
}
void *hardening_data(hardening_region *r){return index_of(r)<0?NULL:r->data;}
size_t hardening_size(hardening_region *r){return index_of(r)<0?0:r->size;}
int hardening_protect(hardening_region *r,int access){
    if(index_of(r)<0)return -1;
    if(access!=HARDENING_NONE&&access!=HARDENING_READ&&access!=HARDENING_READ_WRITE){errno=EINVAL;return -1;}
    int result=HARDENING_MODE==4?set_key(r->key,access):mprotect(r->data,r->size,access==HARDENING_NONE?PROT_NONE:access==HARDENING_READ?PROT_READ:PROT_READ|PROT_WRITE);
    int saved=result?errno:0;if(!result)r->access=access;
    event(3,saved,access,(uintptr_t)r->data,r->size,(uint64_t)r->key);errno=saved;return result;
}
int hardening_free(hardening_region *r){
    int slot=index_of(r);if(slot<0)return -1;
    if(munmap(r->mapping,r->total))return -1;
    int result=0;
#if defined(SYS_pkey_free)
    if(r->key>=0){set_key(r->key,HARDENING_READ_WRITE);result=(int)syscall(SYS_pkey_free,r->key);}
#endif
    event(4,result?errno:0,0,(uintptr_t)r->data,r->size,0);
    retained-=r->total;regions[slot]=NULL;free(r);return result;
}
void hardening_cet_violate(void){
#if defined(__x86_64__)
    /* Requires loader-enabled SHSTK; no activation across existing C frames. */
    __asm__ volatile("lea 1f(%%rip),%%rax;push %%rax;ret;1:":::"rax","memory");
#else
    errno=ENOTSUP;
#endif
}
__attribute__((noinline)) static int cfi_wrong_signature(int value){return value+1;}
__attribute__((noinline,used,visibility("default"))) void hardening_cfi_violate(void){
    int (*volatile wrong)(void)=(int(*)(void))cfi_wrong_signature;
    volatile int result=wrong();(void)result;
}
