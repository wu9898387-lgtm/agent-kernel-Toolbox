#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <detours.h>
#include <cerrno>
#include <cwchar>
#include <string>

#if !defined(_M_X64)
#error This model DLL requires the x64 Windows SDK toolchain.
#endif

static ULONGLONG (WINAPI *real_ticks)() = GetTickCount64;
static BOOL (WINAPI *real_name)(LPWSTR, LPDWORD) = GetComputerNameW;
static ULONGLONG fixed_ticks;
static std::wstring fixed_name, pipe_name, nonce;
static bool attached;

static ULONGLONG WINAPI model_ticks() { return fixed_ticks; }
static BOOL WINAPI model_name(LPWSTR buffer, LPDWORD length) {
    if (!length) { SetLastError(ERROR_INVALID_PARAMETER); return FALSE; }
    const DWORD needed = static_cast<DWORD>(fixed_name.size() + 1);
    if (!buffer || *length < needed) {
        *length = needed; SetLastError(ERROR_BUFFER_OVERFLOW); return FALSE;
    }
    memcpy(buffer, fixed_name.c_str(), needed * sizeof(wchar_t));
    *length = needed - 1;
    return TRUE;
}

static std::wstring environment(const wchar_t *key) {
    wchar_t value[1024];
    DWORD size = GetEnvironmentVariableW(key, value, 1024);
    return size && size < 1024 ? std::wstring(value, size) : std::wstring();
}

static bool configure() {
    nonce = environment(L"TOOLBOX_DETOURS_NONCE");
    pipe_name = environment(L"TOOLBOX_DETOURS_PIPE");
    fixed_name = environment(L"TOOLBOX_DETOURS_COMPUTER_NAME");
    const std::wstring ticks = environment(L"TOOLBOX_DETOURS_TICK_COUNT64");
    if (environment(L"TOOLBOX_DETOURS_MODEL") != L"clock_hostname_v1" ||
        nonce.size() != 32 || pipe_name != L"\\\\.\\pipe\\toolbox-detours-" + nonce ||
        fixed_name.empty() || fixed_name.size() > 15 || ticks.empty() || ticks.size() > 20) return false;
    for (wchar_t c : nonce) if (!((c >= L'0' && c <= L'9') || (c >= L'a' && c <= L'f'))) return false;
    for (wchar_t c : fixed_name) if (!((c >= L'A' && c <= L'Z') || (c >= L'a' && c <= L'z') ||
                                      (c >= L'0' && c <= L'9') || c == L'_' || c == L'-')) return false;
    for (wchar_t c : ticks) if (c < L'0' || c > L'9') return false;
    errno = 0;
    wchar_t *end = nullptr;
    fixed_ticks = _wcstoui64(ticks.c_str(), &end, 10);
    return errno != ERANGE && end && *end == 0;
}

static DWORD WINAPI report(LPVOID) {
    // This thread runs after loader-lock release. Verify calls through the real
    // exported API entries, then report only the two fixed primitive results.
    wchar_t name[16] = {};
    DWORD length = 16;
    const ULONGLONG observed = GetTickCount64();
    const bool active = GetComputerNameW(name, &length) && observed == fixed_ticks &&
                        std::wstring(name, length) == fixed_name;
    std::string n(nonce.begin(), nonce.end()), computer(fixed_name.begin(), fixed_name.end());
    std::string message = "{\"schema_version\":1,\"nonce\":\"" + n +
        "\",\"hooks_active\":" + (active ? "true" : "false") +
        ",\"tick_count64\":" + std::to_string(observed) +
        ",\"computer_name\":\"" + computer + "\"}\n";
    HANDLE pipe = CreateFileW(pipe_name.c_str(), GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    if (pipe != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        WriteFile(pipe, message.data(), static_cast<DWORD>(message.size()), &written, nullptr);
        CloseHandle(pipe);
    }
    return 0;
}

extern "C" __declspec(dllexport) void CALLBACK ToolboxDetoursOrdinal1(
    HWND window, HINSTANCE instance, LPSTR command, int show) {
    DetourFinishHelperProcess(window, instance, command, show);
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    if (DetourIsHelperProcess()) return TRUE;
    if (reason == DLL_PROCESS_ATTACH) {
        DetourRestoreAfterWith();
        if (!configure() || DetourTransactionBegin() != NO_ERROR) return FALSE;
        if (DetourUpdateThread(GetCurrentThread()) != NO_ERROR ||
            DetourAttach(reinterpret_cast<PVOID *>(&real_ticks), reinterpret_cast<PVOID>(model_ticks)) != NO_ERROR ||
            DetourAttach(reinterpret_cast<PVOID *>(&real_name), reinterpret_cast<PVOID>(model_name)) != NO_ERROR) {
            DetourTransactionAbort(); return FALSE;
        }
        if (DetourTransactionCommit() != NO_ERROR) return FALSE;
        attached = true;
        HANDLE thread = CreateThread(nullptr, 0, report, nullptr, 0, nullptr);
        if (!thread) return FALSE;
        CloseHandle(thread);
    } else if (reason == DLL_PROCESS_DETACH && !reserved && attached) {
        if (DetourTransactionBegin() == NO_ERROR) {
            DetourUpdateThread(GetCurrentThread());
            DetourDetach(reinterpret_cast<PVOID *>(&real_ticks), reinterpret_cast<PVOID>(model_ticks));
            DetourDetach(reinterpret_cast<PVOID *>(&real_name), reinterpret_cast<PVOID>(model_name));
            DetourTransactionCommit();
        }
    }
    (void)instance;
    return TRUE;
}
