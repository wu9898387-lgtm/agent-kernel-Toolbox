#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ptrace.h>
#include <sys/sysmacros.h>
#include <sys/uio.h>
#if defined(__x86_64__)
#include <sys/user.h>
#include <cpuid.h>
#endif
#include <unistd.h>
struct hk_event { uint32_t magic,type,mode,pid; int32_t status,detail; uint64_t address,length,extra; };
static int kernel_shstk(pid_t pid){
    char path[80],line[1024];snprintf(path,sizeof(path),"/proc/%ld/status",(long)pid);
    FILE *file=fopen(path,"r");if(!file)return -1;int found=-1;
    while(fgets(line,sizeof(line),file))if(!strncmp(line,"x86_Thread_features:",20)){
        found=0;char *save=NULL,*word=strtok_r(line+20," \t\n",&save);
        while(word){if(!strcmp(word,"shstk"))found=1;word=strtok_r(NULL," \t\n",&save);}break;
    }fclose(file);return found;
}
static int fault_mapping(pid_t pid,uint64_t address,int *access,int *key){
    char path[80],line[1024];snprintf(path,sizeof(path),"/proc/%ld/smaps",(long)pid);
    FILE *file=fopen(path,"r");if(!file)return -1;int selected=0,found=0,count=0;
    while(fgets(line,sizeof(line),file)&&++count<=16384){
        unsigned long long start,end;char permissions[5];
        if(sscanf(line,"%llx-%llx %4s",&start,&end,permissions)==3){
            selected=address>=start&&address<end;
            if(selected){found=1;*access=(permissions[0]=='r'?1:0)|(permissions[1]=='w'?2:0)|(permissions[2]=='x'?4:0);}
        }else if(selected&&sscanf(line,"ProtectionKey: %d",key)==1)break;
    }fclose(file);return found;
}
static unsigned long long image_bias(pid_t pid,const struct stat *image){
    char path[80],line[1024];snprintf(path,sizeof(path),"/proc/%ld/maps",(long)pid);
    FILE *file=fopen(path,"r");if(!file)return 0;unsigned long long found=0;int count=0;
    while(fgets(line,sizeof(line),file)&&++count<=16384){
        unsigned long long start,end,offset,inode;unsigned maj,min;char permissions[5];
        if(sscanf(line,"%llx-%llx %4s %llx %x:%x %llu",&start,&end,permissions,&offset,&maj,&min,&inode)==7&&
           !offset&&inode==(unsigned long long)image->st_ino&&maj==major(image->st_dev)&&min==minor(image->st_dev)){found=start;break;}
    }fclose(file);return found;
}
static int pkru_value(pid_t pid,unsigned *value){
#if defined(__x86_64__)
    unsigned a,b,c,d;if(__get_cpuid_max(0,NULL)<13)return 0;__cpuid_count(13,9,a,b,c,d);
    if(a<4||b>65532)return 0;
    unsigned char raw[65536];struct iovec data={raw,sizeof(raw)};
    if(ptrace(PTRACE_GETREGSET,pid,(void*)0x202,&data)<0||data.iov_len<b+4||data.iov_len<576||
       /* Ptrace's software-reserved XCR0 mask at 464, not a signal-frame magic. */
       !(raw[465]&2)||(raw[527]&128))return 0;
    memcpy(value,raw+b,4);return 1;
#else
    (void)pid;(void)value;return 0;
#endif
}
static int validate_region(pid_t pid,int mode,const struct hk_event *event){
    int access=-1,key=-1;int mapped=fault_mapping(pid,event->address,&access,&key);
    if(event->type==4)return mapped==0;
    if(mapped!=1)return 0;
    if(mode==3){
        if(access!=event->detail)return 0;
        if(event->type==2){int left=-1,right=-1,ignored=-1;
            if(!event->extra||event->extra>1048576||event->address<event->extra)return 0;
            if(!fault_mapping(pid,event->address-1,&left,&ignored)||!fault_mapping(pid,event->address+event->length,&right,&ignored)||left||right)return 0;
        }return 1;
    }
    if(mode==4){unsigned rights;int expected=event->detail==0?3:event->detail==1?2:event->detail==3?0:-1;
        return expected>=0&&key>0&&key<16&&key==(int)event->extra&&access==3&&pkru_value(pid,&rights)&&((rights>>(key*2))&3U)==(unsigned)expected;
    }return 0;
}
int main(int argc,char **argv){
    if(argc<5||strlen(argv[1])!=1||argv[1][0]<'1'||argv[1][0]>'4')return 2;
    int mode=argv[1][0]-'0',events[2],ack[2];
    char *end=NULL;errno=0;unsigned long long cfi_start=strtoull(argv[2],&end,16);if(errno||!argv[2][0]||*end)return 2;
    unsigned long long cfi_size=strtoull(argv[3],&end,16);if(errno||!argv[3][0]||*end||cfi_size>1048576||cfi_start+cfi_size<cfi_start)return 2;
    if(pipe2(events,O_CLOEXEC)||pipe2(ack,O_CLOEXEC))return 77;
    struct stat expected;if(stat(argv[4],&expected))return 77;
    pid_t child=fork();if(child<0)return 77;
    if(!child){
        close(events[0]);close(ack[1]);fcntl(events[1],F_SETFD,0);fcntl(ack[0],F_SETFD,0);
        char fd[32];snprintf(fd,sizeof(fd),"%d",events[1]);setenv("HARDENING_EVENT_FD",fd,1);
        snprintf(fd,sizeof(fd),"%d",ack[0]);setenv("HARDENING_ACK_FD",fd,1);
        /* Reserve stdout for the parent's attestation, keep target output on stderr. */
        if(dup2(STDERR_FILENO,STDOUT_FILENO)<0)_exit(77);
        execv(argv[4],argv+4);_exit(77);
    }
    close(events[1]);close(ack[0]);
    int initialized=0,protocol=1,kernel=-1,status=0,records=0,allocations=0,protects=0,frees=0,failures=0,init_error=0,init_features=0,last_error=0;
    int fault_code=0,fault_signal=0,fault_region=0,live=0,dead=0,approved=0;
    int traced=0,trace_errno=0,kernel_fault=0,map_found=0,map_access=-1,map_key=-1,cfi_witness=0;
    uint64_t fault_address=0;
    struct hk_event active[32];memset(active,0,sizeof(active));
    struct hk_event event;size_t used=0;
    while(1){
        struct pollfd p={events[0],POLLIN|POLLHUP,0};int polled=poll(&p,1,50);
        if(polled<0){if(errno==EINTR)continue;protocol=0;break;}
        if(polled){
            ssize_t n=read(events[0],(char*)&event+used,sizeof(event)-used);
            if(n<0){if(errno==EINTR)continue;protocol=0;break;}
            if(!n){if(used)protocol=0;break;}
            used+=(size_t)n;if(used!=sizeof(event))continue;used=0;
            if(++records>256||event.magic!=0x484b5631U||event.pid!=(uint32_t)child||event.mode!=(uint32_t)mode||event.type<1||event.type>5){protocol=0;break;}
            if(!initialized){
                if(event.type!=1){protocol=0;break;}initialized=1;init_error=event.status;init_features=event.detail;
                char proc[80];struct stat image;snprintf(proc,sizeof(proc),"/proc/%ld/exe",(long)child);
                approved=!event.status&&stat(proc,&image)==0&&image.st_dev==expected.st_dev&&image.st_ino==expected.st_ino;
                if(mode==2){kernel=kernel_shstk(child);approved=approved&&(event.detail&1)&&kernel==1;}
                if(approved){
                    if(ptrace(PTRACE_SEIZE,child,NULL,(void*)(uintptr_t)PTRACE_O_EXITKILL)<0){trace_errno=errno;approved=0;}
                    else{
                        traced=1;int stopped=0;
                        if(ptrace(PTRACE_INTERRUPT,child,NULL,NULL)<0||waitpid(child,&stopped,__WALL)!=child||!WIFSTOPPED(stopped)){trace_errno=errno;approved=0;}
                    }
                }
                char go=approved?'G':'B';if(write(ack[1],&go,1)!=1)protocol=0;
                if(traced&&ptrace(PTRACE_CONT,child,NULL,NULL)<0){trace_errno=errno;approved=0;kill(child,SIGKILL);}
            }else if(event.type==1){protocol=0;break;}
            else if(event.type==2){
                if(event.status){failures++;last_error=event.status;char go='G';if(write(ack[1],&go,1)!=1)protocol=0;continue;}int slot=-1;
                for(int i=0;i<32;i++)if(!active[i].address){slot=i;break;}
                if(slot<0||!event.address||!event.length||event.length>1048576){protocol=0;break;}
                active[slot]=event;allocations++;live++;
            }else if(event.type==3){
                if(event.status){failures++;last_error=event.status;char go='G';if(write(ack[1],&go,1)!=1)protocol=0;continue;}int matched=0;
                for(int i=0;i<32;i++)if(active[i].address==event.address&&active[i].length==event.length){active[i].detail=event.detail;matched=1;}
                if(!matched){protocol=0;break;}protects++;
            }else if(event.type==4){
                if(event.status){failures++;last_error=event.status;char go='G';if(write(ack[1],&go,1)!=1)protocol=0;continue;}int matched=0;
                for(int i=0;i<32;i++)if(active[i].address==event.address){active[i].address=0;live--;matched=1;}
                if(!matched){protocol=0;break;}frees++;
            } /* SDK type-5 fault claims are never used as kernel evidence. */
            if(event.type>=2&&event.type<=4){
                int stopped=0,valid=traced&&ptrace(PTRACE_INTERRUPT,child,NULL,NULL)==0&&waitpid(child,&stopped,__WALL)==child&&WIFSTOPPED(stopped)&&(stopped>>16)==PTRACE_EVENT_STOP;
                if(valid)valid=validate_region(child,mode,&event);
                char go=valid?'G':'B';if(write(ack[1],&go,1)!=1)valid=0;
                if(ptrace(PTRACE_CONT,child,NULL,NULL)<0)valid=0;
                if(!valid){protocol=0;break;}
            }
        }
        if(!dead){
            pid_t waited=waitpid(child,&status,WNOHANG|__WALL);
            if(waited==child&&WIFSTOPPED(status)){
                int sig=WSTOPSIG(status),deliver=(status>>16)?0:sig;
                if(!kernel_fault&&(sig==SIGSEGV||sig==SIGILL)){
                    siginfo_t information;memset(&information,0,sizeof(information));
                    if(ptrace(PTRACE_GETSIGINFO,child,NULL,&information)<0){protocol=0;break;}
                    kernel_fault=1;fault_signal=sig;fault_code=information.si_code;fault_address=(uintptr_t)information.si_addr;
                    map_found=fault_mapping(child,fault_address,&map_access,&map_key);
#if defined(__x86_64__)
                    if(mode==1&&sig==SIGILL&&information.si_code>0&&cfi_size){
                        struct user_regs_struct registers;unsigned long long bias=image_bias(child,&expected);
                        if(bias&&ptrace(PTRACE_GETREGS,child,NULL,&registers)==0&&registers.rip>=bias+cfi_start&&registers.rip<bias+cfi_start+cfi_size){
                            errno=0;long instruction=ptrace(PTRACE_PEEKTEXT,child,(void*)(uintptr_t)registers.rip,NULL);
                            unsigned long op=(unsigned long)instruction;
                            cfi_witness=!errno&&(op&255)==15&&(((op>>8)&255)==11||((op>>8)&255)==185);
                        }
                    }
#endif
                }
                if(ptrace(PTRACE_CONT,child,NULL,(void*)(intptr_t)deliver)<0){protocol=0;break;}
            }else if(waited==child)dead=1;
            else if(waited<0&&errno!=EINTR){protocol=0;break;}
        }
    }
    if(!protocol||!initialized||!approved)kill(child,SIGKILL);
    if(!dead){while(waitpid(child,&status,__WALL)<0)if(errno!=EINTR){protocol=0;break;}}
    for(int i=0;i<32;i++)if(active[i].address&&map_found&&kernel_fault){
        uint64_t a=active[i].address,b=a+active[i].length;
        if(mode==3&&fault_code==2&&!(map_access&2)&&((fault_address>=a&&fault_address<b&&active[i].detail!=3)||
            (active[i].extra<=1048576&&a>=active[i].extra&&fault_address>=a-active[i].extra&&fault_address<a)||
            (active[i].extra<=1048576&&fault_address>=b&&fault_address<b+active[i].extra)))fault_region=1;
        if(mode==4&&fault_code==4&&map_key>0&&map_key==(int)active[i].extra&&fault_address>=a&&fault_address<b&&active[i].detail!=3)fault_region=1;
    }
    close(events[0]);if(ack[1]>=0)close(ack[1]);
    printf("{\"hardening_runner\":1,\"mode\":%d,\"pid\":%ld,\"protocol_valid\":%s,\"initialized\":%s,\"approved\":%s,\"kernel_shstk\":%d,\"initial_status_errno\":%d,\"initial_shstk_features\":%d,\"records\":%d,\"allocations\":%d,\"protects\":%d,\"frees\":%d,\"live_regions_at_exit\":%d,\"sdk_failures\":%d,\"last_sdk_errno\":%d,\"fault_signal\":%d,\"fault_code\":%d,\"fault_matches_region\":%s,\"target_exit_code\":%d,\"target_signal\":%d,\"ptrace_attached\":%s,\"ptrace_errno\":%d,\"kernel_fault_observed\":%s,\"kernel_fault_address\":%llu,\"kernel_map_access\":%d,\"kernel_map_pkey\":%d,\"cfi_sdk_trap_verified\":%s}\n",
        mode,(long)child,protocol?"true":"false",initialized?"true":"false",approved?"true":"false",kernel,init_error,init_features,records,allocations,protects,frees,live,failures,last_error,fault_signal,fault_code,fault_region?"true":"false",WIFEXITED(status)?WEXITSTATUS(status):-1,WIFSIGNALED(status)?WTERMSIG(status):0,traced?"true":"false",trace_errno,kernel_fault?"true":"false",(unsigned long long)fault_address,map_access,map_key,cfi_witness?"true":"false");
    return protocol?0:77;
}
