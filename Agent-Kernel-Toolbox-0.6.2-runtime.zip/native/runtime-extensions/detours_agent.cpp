#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <psapi.h>
#include <detours.h>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

#if !defined(_M_X64)
#error This agent requires the x64 Windows SDK toolchain.
#endif

struct Handle {
    HANDLE value = INVALID_HANDLE_VALUE;
    Handle() = default;
    explicit Handle(HANDLE h) : value(h) {}
    Handle(const Handle &) = delete;
    Handle &operator=(const Handle &) = delete;
    ~Handle() { close(); }
    bool valid() const { return value && value != INVALID_HANDLE_VALUE; }
    bool close() {
        if (!valid()) return true;
        HANDLE old = value; value = INVALID_HANDLE_VALUE;
        return CloseHandle(old) != FALSE;
    }
};
static void require(bool value, const char *code) { if (!value) throw std::runtime_error(code); }

// A bounded parser for this protocol's object/array/string/unsigned-integer/bool
// values. There is no executable expression, generic command or PID operation.
struct Json {
    enum Kind { Object, Array, String, Number, Boolean } kind = Object;
    std::map<std::string, Json> object;
    std::vector<Json> array;
    std::string text;
    uint64_t number = 0;
    bool boolean = false;
    const Json &at(const std::string &key) const {
        require(kind == Object && object.count(key), "request_field_missing");
        return object.at(key);
    }
    std::string string() const { require(kind == String, "request_string_required"); return text; }
    uint64_t integer(uint64_t low, uint64_t high) const {
        require(kind == Number && number >= low && number <= high, "request_integer_outside_budget"); return number;
    }
    void keys(std::initializer_list<const char *> names) const {
        require(kind == Object && object.size() == names.size(), "request_object_schema");
        for (const char *key : names) require(object.count(key) != 0, "request_object_schema");
    }
};
struct Parser {
    const std::string &raw;
    size_t pos = 0, nodes = 0;
    explicit Parser(const std::string &s) : raw(s) {}
    void whitespace() { while (pos < raw.size() && (raw[pos] == ' ' || raw[pos] == '\t' || raw[pos] == '\n' || raw[pos] == '\r')) ++pos; }
    char get() { require(pos < raw.size(), "request_truncated"); return raw[pos++]; }
    unsigned hex4() {
        unsigned result = 0;
        for (unsigned i = 0; i < 4; ++i) {
            char c = get(); unsigned v;
            if (c >= '0' && c <= '9') v = c - '0';
            else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
            else throw std::runtime_error("request_unicode_invalid");
            result = result * 16 + v;
        }
        return result;
    }
    static void utf8(std::string &s, unsigned c) {
        if (c < 0x80) s += static_cast<char>(c);
        else if (c < 0x800) { s += static_cast<char>(0xc0 | (c >> 6)); s += static_cast<char>(0x80 | (c & 63)); }
        else if (c < 0x10000) { s += static_cast<char>(0xe0 | (c >> 12)); s += static_cast<char>(0x80 | ((c >> 6) & 63)); s += static_cast<char>(0x80 | (c & 63)); }
        else { s += static_cast<char>(0xf0 | (c >> 18)); s += static_cast<char>(0x80 | ((c >> 12) & 63)); s += static_cast<char>(0x80 | ((c >> 6) & 63)); s += static_cast<char>(0x80 | (c & 63)); }
    }
    std::string string() {
        require(get() == '"', "request_string_required");
        std::string result;
        for (;;) {
            unsigned char c = static_cast<unsigned char>(get());
            if (c == '"') break;
            require(c >= 32, "request_control_character");
            if (c != '\\') result += static_cast<char>(c);
            else {
                char escape = get();
                if (escape == '"' || escape == '\\' || escape == '/') result += escape;
                else if (escape == 'n') result += '\n';
                else if (escape == 'r') result += '\r';
                else if (escape == 't') result += '\t';
                else if (escape == 'b') result += '\b';
                else if (escape == 'f') result += '\f';
                else if (escape == 'u') {
                    unsigned cp = hex4();
                    if (cp >= 0xd800 && cp <= 0xdbff) {
                        require(get() == '\\' && get() == 'u', "request_unicode_invalid");
                        unsigned low = hex4(); require(low >= 0xdc00 && low <= 0xdfff, "request_unicode_invalid");
                        cp = 0x10000 + ((cp - 0xd800) << 10) + low - 0xdc00;
                    } else require(cp < 0xdc00 || cp > 0xdfff, "request_unicode_invalid");
                    utf8(result, cp);
                } else throw std::runtime_error("request_escape_invalid");
            }
            require(result.size() <= 4096, "request_string_budget");
        }
        return result;
    }
    Json value(unsigned depth = 0) {
        require(++nodes <= 256 && depth <= 12, "request_structure_budget");
        whitespace(); require(pos < raw.size(), "request_truncated");
        Json result;
        if (raw[pos] == '{') {
            ++pos; result.kind = Json::Object; whitespace();
            if (pos < raw.size() && raw[pos] == '}') { ++pos; return result; }
            for (;;) {
                whitespace(); std::string key = string(); whitespace(); require(get() == ':', "request_colon_required");
                require(!result.object.count(key), "request_duplicate_key");
                result.object.emplace(key, value(depth + 1)); whitespace(); char c = get();
                if (c == '}') break; require(c == ',', "request_separator_required");
            }
        } else if (raw[pos] == '[') {
            ++pos; result.kind = Json::Array; whitespace();
            if (pos < raw.size() && raw[pos] == ']') { ++pos; return result; }
            for (;;) { result.array.push_back(value(depth + 1)); whitespace(); char c = get(); if (c == ']') break; require(c == ',', "request_separator_required"); }
        } else if (raw[pos] == '"') { result.kind = Json::String; result.text = string(); }
        else if (raw.compare(pos, 4, "true") == 0) { pos += 4; result.kind = Json::Boolean; result.boolean = true; }
        else if (raw.compare(pos, 5, "false") == 0) { pos += 5; result.kind = Json::Boolean; }
        else {
            result.kind = Json::Number;
            require(raw[pos] >= '0' && raw[pos] <= '9', "request_unsigned_integer_required");
            bool leading_zero = raw[pos] == '0'; size_t start = pos;
            while (pos < raw.size() && raw[pos] >= '0' && raw[pos] <= '9') {
                unsigned digit = raw[pos++] - '0';
                require(result.number <= (UINT64_MAX - digit) / 10, "request_integer_overflow");
                result.number = result.number * 10 + digit;
            }
            require(!leading_zero || pos == start + 1, "request_integer_encoding");
        }
        return result;
    }
    Json parse() { Json result = value(); whitespace(); require(pos == raw.size(), "request_trailing_data"); return result; }
};
static std::string quote(const std::string &s) {
    std::string result = "\"";
    static const char *hex = "0123456789abcdef";
    for (unsigned char c : s) {
        if (c == '\\' || c == '"') { result += '\\'; result += static_cast<char>(c); }
        else if (c < 32) { result += "\\u00"; result += hex[c >> 4]; result += hex[c & 15]; }
        else result += static_cast<char>(c);
    }
    return result + '"';
}
static std::wstring wide(const std::string &s) {
    require(s.find('\0') == std::string::npos, "request_embedded_nul");
    if (s.empty()) return {};
    int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s.data(), static_cast<int>(s.size()), nullptr, 0);
    require(count > 0, "request_utf8_invalid"); std::wstring result(count, L'\0');
    require(MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s.data(), static_cast<int>(s.size()), result.data(), count) == count, "request_utf8_invalid");
    return result;
}
static std::string narrow(const std::wstring &s) {
    if (s.empty()) return {};
    int count = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, s.data(), static_cast<int>(s.size()), nullptr, 0, nullptr, nullptr);
    require(count > 0, "windows_path_encoding"); std::string result(count, '\0');
    require(WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, s.data(), static_cast<int>(s.size()), result.data(), count, nullptr, nullptr) == count, "windows_path_encoding");
    return result;
}
static bool digest_string(const std::string &s) {
    if (s.size() != 64) return false;
    return std::all_of(s.begin(), s.end(), [](char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'); });
}
static std::wstring path(const Json &value) {
    std::wstring result = wide(value.string());
    require(result.size() >= 3 && result.size() <= 1024 && result[1] == L':' && result[2] == L'\\' &&
            ((result[0] >= L'A' && result[0] <= L'Z') || (result[0] >= L'a' && result[0] <= L'z')), "artifact_local_drive_path_required");
    require(result.find(L"\\..\\") == std::wstring::npos && result.substr(result.size() - 3) != L"\\..", "artifact_parent_path_denied");
    for (wchar_t c : result) require(c >= 32 && c != L'"' && c != L'|' && c != L'<' && c != L'>', "artifact_path_invalid");
    return result;
}
static std::string hash_file(HANDLE file) {
    LARGE_INTEGER zero = {}; require(SetFilePointerEx(file, zero, nullptr, FILE_BEGIN), "artifact_seek_failed");
    BCRYPT_ALG_HANDLE algorithm = nullptr; BCRYPT_HASH_HANDLE hash = nullptr;
    std::vector<UCHAR> object;
    require(BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) == 0, "sha256_unavailable");
    try {
        DWORD length = 0, returned = 0;
        require(BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH, reinterpret_cast<PUCHAR>(&length), sizeof(length), &returned, 0) == 0 && length <= 65536, "sha256_property_failed");
        object.resize(length);
        require(BCryptCreateHash(algorithm, &hash, object.data(), length, nullptr, 0, 0) == 0, "sha256_create_failed");
        BYTE buffer[16384]; DWORD count = 0; uint64_t total = 0;
        for (;;) {
            require(ReadFile(file, buffer, sizeof(buffer), &count, nullptr), "artifact_read_failed");
            if (!count) break;
            total += count; require(total <= 128 * 1024 * 1024, "artifact_byte_budget");
            require(BCryptHashData(hash, buffer, count, 0) == 0, "sha256_update_failed");
        }
        BYTE bytes[32]; require(BCryptFinishHash(hash, bytes, sizeof(bytes), 0) == 0, "sha256_finish_failed");
        BCryptDestroyHash(hash); hash = nullptr; BCryptCloseAlgorithmProvider(algorithm, 0); algorithm = nullptr;
        std::string result; const char *hex = "0123456789abcdef";
        for (BYTE byte : bytes) { result += hex[byte >> 4]; result += hex[byte & 15]; }
        return result;
    } catch (...) {
        if (hash) BCryptDestroyHash(hash); if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0); throw;
    }
}
struct Artifact {
    Handle handle;
    std::wstring final_path;
    std::string digest;
    Artifact(const std::wstring &requested, const std::string &expected) {
        require(digest_string(expected), "artifact_digest_required");
        handle.value = CreateFileW(requested.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING,
                                   FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_SEQUENTIAL_SCAN, nullptr);
        require(handle.valid() && GetFileType(handle.value) == FILE_TYPE_DISK, "artifact_unavailable");
        FILE_ATTRIBUTE_TAG_INFO tag = {}; LARGE_INTEGER size = {};
        require(GetFileInformationByHandleEx(handle.value, FileAttributeTagInfo, &tag, sizeof(tag)) &&
                !(tag.FileAttributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_REPARSE_POINT)) &&
                GetFileSizeEx(handle.value, &size) && size.QuadPart > 0 && size.QuadPart <= 128 * 1024 * 1024, "artifact_type_or_budget");
        wchar_t canonical[32768]; DWORD count = GetFinalPathNameByHandleW(handle.value, canonical, 32768, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
        require(count && count < 32768, "artifact_canonical_path_unavailable"); final_path.assign(canonical, count);
        require(final_path.size() >= 7 && final_path.substr(0, 4) == L"\\\\?\\" &&
                ((final_path[4] >= L'A' && final_path[4] <= L'Z') || (final_path[4] >= L'a' && final_path[4] <= L'z')) &&
                final_path[5] == L':' && final_path[6] == L'\\', "artifact_canonical_local_drive_required");
        digest = hash_file(handle.value); require(digest == expected, "artifact_digest_changed");
        require(SetFilePointer(handle.value, 0, nullptr, FILE_BEGIN) != INVALID_SET_FILE_POINTER || GetLastError() == NO_ERROR, "artifact_seek_failed");
        IMAGE_DOS_HEADER dos = {}; DWORD got = 0;
        require(ReadFile(handle.value, &dos, sizeof(dos), &got, nullptr) && got == sizeof(dos) &&
                dos.e_magic == IMAGE_DOS_SIGNATURE && dos.e_lfanew >= static_cast<LONG>(sizeof(dos)) && dos.e_lfanew <= size.QuadPart - 24, "artifact_pe_required");
        LARGE_INTEGER offset = {}; offset.QuadPart = dos.e_lfanew;
        require(SetFilePointerEx(handle.value, offset, nullptr, FILE_BEGIN), "artifact_seek_failed");
        DWORD signature = 0; IMAGE_FILE_HEADER header = {};
        require(ReadFile(handle.value, &signature, sizeof(signature), &got, nullptr) && got == sizeof(signature) && signature == IMAGE_NT_SIGNATURE &&
                ReadFile(handle.value, &header, sizeof(header), &got, nullptr) && got == sizeof(header) && header.Machine == IMAGE_FILE_MACHINE_AMD64, "artifact_x64_pe_required");
    }
};
static std::wstring command_argument(const std::wstring &value) {
    std::wstring result = L"\""; unsigned slashes = 0;
    for (wchar_t c : value) {
        if (c == L'\\') { ++slashes; continue; }
        if (c == L'"') { result.append(slashes * 2 + 1, L'\\'); result += c; }
        else { result.append(slashes, L'\\'); result += c; }
        slashes = 0;
    }
    result.append(slashes * 2, L'\\'); return result + L'"';
}
struct Receipt {
    std::string nonce, agent, dll, target, name, error = "request_not_executed";
    uint64_t ticks = 0, observed_ticks = 0;
    std::string observed_name;
    bool started = false, loaded = false, hooks = false, exhausted = false;
    bool job_done = false, reaped = false, pipe_closed = false, handles_closed = false;
    DWORD exit_code = 0;
    std::string json() const {
        auto b = [](bool value) { return value ? "true" : "false"; };
        return "{\"schema_version\":1,\"nonce\":" + quote(nonce) +
            ",\"platform\":\"windows\",\"architecture\":\"x86_64\",\"agent_sha256\":" + quote(agent) +
            ",\"dll_sha256\":" + quote(dll) + ",\"target_sha256\":" + quote(target) +
            ",\"model\":{\"name\":\"clock_hostname_v1\",\"tick_count64\":" + std::to_string(ticks) + ",\"computer_name\":" + quote(name) +
            "},\"status\":" + quote(error.empty() ? "completed" : (started ? "unknown" : "blocked")) +
            ",\"target_started\":" + b(started) + ",\"dll_loaded\":" + b(loaded) + ",\"hooks_active\":" + b(hooks) +
            ",\"observed_tick_count64\":" + std::to_string(observed_ticks) + ",\"observed_computer_name\":" + quote(observed_name) +
            ",\"exit_code\":" + std::to_string(exit_code) + ",\"wall_budget_exhausted\":" + b(exhausted) +
            ",\"cleanup\":{\"job_terminated\":" + b(job_done) + ",\"process_reaped\":" + b(reaped) +
            ",\"pipe_closed\":" + b(pipe_closed) + ",\"handles_closed\":" + b(handles_closed) + "},\"error\":" + quote(error) + "}\n";
    }
};
static bool module_loaded(HANDLE process, const std::wstring &dll) {
    HMODULE modules[256]; DWORD needed = 0;
    if (!EnumProcessModulesEx(process, modules, sizeof(modules), &needed, LIST_MODULES_64BIT) || needed > sizeof(modules)) return false;
    for (DWORD i = 0; i < needed / sizeof(HMODULE); ++i) {
        wchar_t filename[32768]; DWORD size = GetModuleFileNameExW(process, modules[i], filename, 32768);
        if (!size || size >= 32768) continue;
        Handle file(CreateFileW(filename, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
        if (!file.valid()) continue;
        wchar_t canonical[32768]; DWORD count = GetFinalPathNameByHandleW(file.value, canonical, 32768, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
        if (count && count < 32768 && _wcsicmp(std::wstring(canonical, count).c_str(), dll.c_str()) == 0) return true;
    }
    return false;
}
static Receipt run(const Json &request) {
    Receipt result;
    Handle pipe, connected, read_event, process, thread, job, null_output;
    bool job_assigned = false, connection_pending = false, read_pending = false;
    OVERLAPPED connection = {}, read = {};
    char report[4096] = {};
    std::vector<BYTE> attribute_storage;
    bool attributes_ready = false;
    HANDLE inherited_handles[1] = {INVALID_HANDLE_VALUE};
    try {
        request.keys({"schema_version", "operation", "nonce", "agent_sha256", "dll", "target", "model", "limits"});
        request.at("schema_version").integer(1, 1); require(request.at("operation").string() == "run", "request_operation_denied");
        result.nonce = request.at("nonce").string(); require(result.nonce.size() == 32, "request_nonce_invalid");
        for (char c : result.nonce) require((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'), "request_nonce_invalid");
        request.at("dll").keys({"path", "sha256"}); request.at("target").keys({"path", "sha256", "arguments"});
        request.at("model").keys({"name", "tick_count64", "computer_name"});
        request.at("limits").keys({"wall_ms", "cpu_ms", "memory_bytes", "max_processes"});
        const Json &model = request.at("model"), &limits = request.at("limits");
        require(model.at("name").string() == "clock_hostname_v1", "request_model_denied");
        result.ticks = model.at("tick_count64").integer(0, UINT64_MAX); result.name = model.at("computer_name").string();
        require(!result.name.empty() && result.name.size() <= 15, "request_computer_name_invalid");
        for (char c : result.name) require((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-', "request_computer_name_invalid");
        DWORD wall = static_cast<DWORD>(limits.at("wall_ms").integer(100, 10000));
        uint64_t cpu = limits.at("cpu_ms").integer(1, 10000), memory = limits.at("memory_bytes").integer(16 * 1024 * 1024, 1024 * 1024 * 1024);
        limits.at("max_processes").integer(1, 1);
        wchar_t self[32768]; DWORD self_size = GetModuleFileNameW(nullptr, self, 32768); require(self_size && self_size < 32768, "agent_path_unavailable");
        Artifact agent(std::wstring(self, self_size), request.at("agent_sha256").string());
        Artifact dll(path(request.at("dll").at("path")), request.at("dll").at("sha256").string());
        Artifact target(path(request.at("target").at("path")), request.at("target").at("sha256").string());
        result.agent = agent.digest; result.dll = dll.digest; result.target = target.digest;
        std::string dll_ascii = narrow(dll.final_path); require(dll_ascii.size() < MAX_PATH, "dll_detours_path_budget"); for (unsigned char c : dll_ascii) require(c < 128, "dll_ascii_path_required");
        const Json &arguments = request.at("target").at("arguments"); require(arguments.kind == Json::Array && arguments.array.size() <= 32, "request_arguments_budget");
        std::wstring command = command_argument(target.final_path);
        for (const Json &arg : arguments.array) { std::wstring value = wide(arg.string()); require(value.size() <= 2048, "request_argument_budget"); command += L" " + command_argument(value); }
        require(command.size() <= 16000, "request_command_budget");
        const std::wstring nonce = wide(result.nonce), pipe_name = L"\\\\.\\pipe\\toolbox-detours-" + nonce;
        pipe.value = CreateNamedPipeW(pipe_name.c_str(), PIPE_ACCESS_INBOUND | FILE_FLAG_OVERLAPPED | FILE_FLAG_FIRST_PIPE_INSTANCE,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS, 1, 4096, 4096, 0, nullptr);
        require(pipe.valid(), "model_pipe_create_failed");
        connected.value = CreateEventW(nullptr, TRUE, FALSE, nullptr); read_event.value = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        require(connected.valid() && read_event.valid(), "model_pipe_event_failed");
        connection.hEvent = connected.value;
        BOOL connected_now = ConnectNamedPipe(pipe.value, &connection); DWORD connect_error = GetLastError();
        require(connected_now || connect_error == ERROR_IO_PENDING || connect_error == ERROR_PIPE_CONNECTED, "model_pipe_connect_failed");
        connection_pending = !connected_now && connect_error == ERROR_IO_PENDING;
        if (connected_now || connect_error == ERROR_PIPE_CONNECTED) SetEvent(connected.value);
        job.value = CreateJobObjectW(nullptr, nullptr); require(job.valid(), "job_create_failed");
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION policy = {};
        policy.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_ACTIVE_PROCESS |
            JOB_OBJECT_LIMIT_PROCESS_MEMORY | JOB_OBJECT_LIMIT_PROCESS_TIME | JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION;
        policy.BasicLimitInformation.ActiveProcessLimit = 1;
        policy.BasicLimitInformation.PerProcessUserTimeLimit.QuadPart = cpu * 10000;
        policy.ProcessMemoryLimit = static_cast<SIZE_T>(memory);
        require(SetInformationJobObject(job.value, JobObjectExtendedLimitInformation, &policy, sizeof(policy)), "job_limits_failed");
        require(SetEnvironmentVariableW(L"TOOLBOX_DETOURS_NONCE", nonce.c_str()) &&
            SetEnvironmentVariableW(L"TOOLBOX_DETOURS_PIPE", pipe_name.c_str()) &&
            SetEnvironmentVariableW(L"TOOLBOX_DETOURS_MODEL", L"clock_hostname_v1") &&
            SetEnvironmentVariableW(L"TOOLBOX_DETOURS_COMPUTER_NAME", wide(result.name).c_str()) &&
            SetEnvironmentVariableW(L"TOOLBOX_DETOURS_TICK_COUNT64", std::to_wstring(result.ticks).c_str()), "model_environment_failed");
        SECURITY_ATTRIBUTES inheritable = {sizeof(SECURITY_ATTRIBUTES), nullptr, TRUE};
        null_output.value = CreateFileW(L"NUL", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                       &inheritable, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        require(null_output.valid(), "target_stdio_failed");
        SIZE_T attribute_bytes = 0;
        InitializeProcThreadAttributeList(nullptr, 1, 0, &attribute_bytes);
        require(attribute_bytes > 0 && attribute_bytes <= 65536, "target_handle_list_budget");
        attribute_storage.resize(attribute_bytes);
        auto attributes = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(attribute_storage.data());
        require(InitializeProcThreadAttributeList(attributes, 1, 0, &attribute_bytes), "target_handle_list_failed");
        attributes_ready = true; inherited_handles[0] = null_output.value;
        require(UpdateProcThreadAttribute(attributes, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, inherited_handles, sizeof(inherited_handles), nullptr, nullptr), "target_handle_list_failed");
        STARTUPINFOEXW startup = {}; startup.StartupInfo.cb = sizeof(startup);
        startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES; startup.lpAttributeList = attributes;
        startup.StartupInfo.hStdInput = startup.StartupInfo.hStdOutput = startup.StartupInfo.hStdError = null_output.value;
        PROCESS_INFORMATION child = {};
        require(DetourCreateProcessWithDllExW(target.final_path.c_str(), command.data(), nullptr, nullptr, TRUE,
            CREATE_SUSPENDED | CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT, nullptr, nullptr, &startup.StartupInfo, &child, dll_ascii.c_str(), nullptr), "detours_owned_launch_failed");
        process.value = child.hProcess; thread.value = child.hThread; result.started = true;
        require(AssignProcessToJobObject(job.value, process.value), "target_job_assignment_failed"); job_assigned = true;
        require(ResumeThread(thread.value) != static_cast<DWORD>(-1), "target_resume_failed");
        const ULONGLONG deadline = GetTickCount64() + wall;
        auto remaining = [&]() -> DWORD { ULONGLONG now = GetTickCount64(); return now < deadline ? static_cast<DWORD>(deadline - now) : 0; };
        require(WaitForSingleObject(connected.value, remaining()) == WAIT_OBJECT_0, "model_pipe_deadline");
        if (connection_pending) {
            DWORD transferred = 0; require(GetOverlappedResult(pipe.value, &connection, &transferred, FALSE), "model_pipe_connect_failed");
            connection_pending = false;
        }
        ULONG client_pid = 0;
        require(GetNamedPipeClientProcessId(pipe.value, &client_pid) && client_pid == child.dwProcessId, "model_pipe_process_identity_mismatch");
        DWORD count = 0; read.hEvent = read_event.value;
        BOOL read_now = ReadFile(pipe.value, report, sizeof(report), &count, &read);
        if (!read_now) {
            read_pending = GetLastError() == ERROR_IO_PENDING;
            require(read_pending && WaitForSingleObject(read_event.value, remaining()) == WAIT_OBJECT_0 &&
                    GetOverlappedResult(pipe.value, &read, &count, FALSE), "model_pipe_read_failed");
            read_pending = false;
        }
        require(count > 0 && count < sizeof(report), "model_report_budget");
        Json observed = Parser(std::string(report, count)).parse();
        observed.keys({"schema_version", "nonce", "hooks_active", "tick_count64", "computer_name"});
        observed.at("schema_version").integer(1, 1); require(observed.at("nonce").string() == result.nonce, "model_nonce_mismatch");
        result.observed_ticks = observed.at("tick_count64").integer(0, UINT64_MAX); result.observed_name = observed.at("computer_name").string();
        result.hooks = observed.at("hooks_active").kind == Json::Boolean && observed.at("hooks_active").boolean &&
                       result.observed_ticks == result.ticks && result.observed_name == result.name;
        result.loaded = module_loaded(process.value, dll.final_path);
        require(result.hooks && result.loaded, "detours_model_not_verified");
        DWORD wait = WaitForSingleObject(process.value, remaining());
        require(wait == WAIT_OBJECT_0 || wait == WAIT_TIMEOUT, "target_wait_failed");
        result.exhausted = wait == WAIT_TIMEOUT;
        result.error.clear();
    } catch (const std::exception &error) { result.error = error.what(); }
    // The target was created suspended. Even an assignment failure leaves it
    // owned and explicitly terminated; no arbitrary process is ever attached.
    if (result.started) {
        result.job_done = job_assigned ? TerminateJobObject(job.value, result.exhausted ? ERROR_TIMEOUT : 0) != FALSE : false;
        if (!job_assigned) TerminateProcess(process.value, ERROR_PROCESS_ABORTED);
        result.reaped = WaitForSingleObject(process.value, 1000) == WAIT_OBJECT_0;
        if (result.reaped && !GetExitCodeProcess(process.value, &result.exit_code)) result.error = "target_exit_code_unavailable";
    }
    if (pipe.valid()) {
        CancelIoEx(pipe.value, nullptr);
        DWORD transferred = 0;
        if (connection_pending) GetOverlappedResult(pipe.value, &connection, &transferred, TRUE);
        if (read_pending) GetOverlappedResult(pipe.value, &read, &transferred, TRUE);
        DisconnectNamedPipe(pipe.value);
    }
    result.pipe_closed = pipe.close();
    if (attributes_ready) DeleteProcThreadAttributeList(reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(attribute_storage.data()));
    bool closed = connected.close(); closed = read_event.close() && closed;
    closed = thread.close() && closed; closed = null_output.close() && closed;
    closed = process.close() && closed; closed = job.close() && closed; result.handles_closed = closed;
    if (result.started && (!result.job_done || !result.reaped || !result.pipe_closed || !closed)) result.error = "owned_cleanup_unresolved";
    return result;
}

static DWORD WINAPI watchdog(LPVOID) {
    Sleep(45000); TerminateProcess(GetCurrentProcess(), ERROR_TIMEOUT); return 0;
}

int main(int argc, char **) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    Handle guardian(CreateThread(nullptr, 0, watchdog, nullptr, 0, nullptr));
    if (!guardian.valid()) return 2;
    guardian.close();
    Receipt result;
    try {
        require(argc == 1, "agent_arguments_denied");
        std::string line;
        for (;;) {
            int c = std::cin.get(); require(c != EOF, "request_line_missing");
            if (c == '\n') break;
            require(line.size() < 65536, "request_byte_budget"); line += static_cast<char>(c);
        }
        result = run(Parser(line).parse());
    } catch (const std::exception &error) { result.error = error.what(); }
    std::cout << result.json();
    return std::cout.good() ? 0 : 2;
}
