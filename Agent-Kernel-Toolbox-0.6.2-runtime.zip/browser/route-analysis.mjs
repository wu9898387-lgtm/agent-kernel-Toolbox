/** Bounded, non-executing JS string-literal analysis. Results never grant authority. */
import {createHash} from 'node:crypto';
import {open} from 'node:fs/promises';
import {constants} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';

export const SOURCE_BYTE_LIMIT=262144, CANDIDATE_LIMIT=128;
export function safeURL(value,base){
  if(typeof value!=='string'||value.length>8192||/[\u0000-\u0020\u007f]/u.test(value))return null;
  try{
    const u=new URL(value,base);
    if(!['http:','https:'].includes(u.protocol)||u.username||u.password)return null;
    const routeFragment=u.hash.startsWith('#/'),fragmentQuery=routeFragment&&u.hash.includes('?');
    const opaqueFragment=Boolean(u.hash)&&!routeFragment;
    const fragment=routeFragment?u.hash.split('?')[0]:'';
    if(u.pathname.length>2048||fragment.length>512)return null;
    return {url:u.origin+u.pathname+fragment,origin:u.origin,queryRedacted:Boolean(u.search)||fragmentQuery,fragmentRedacted:opaqueFragment,replayable:!u.search&&!fragmentQuery&&!opaqueFragment};
  }catch{return null;}
}
function quoted(source,start){
  const quote=source[start];let value='',dynamic=false,oversize=false,i=start+1;
  for(;i<source.length;i++){
    const c=source[i];
    if(c===quote)return {end:i+1,value,usable:!dynamic&&!oversize};
    if(quote==='`'&&c==='$'&&source[i+1]==='{')dynamic=true;
    if(c==='\\'){
      const next=source[++i];if(next===undefined)break;
      if(next==='\n')continue;if(next==='\r'){if(source[i+1]==='\n')i++;continue;}
      let decoded=({'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','v':'\v','0':'\0'})[next]??next;
      if(next==='x'){
        const hex=source.slice(i+1,i+3);if(!/^[0-9a-f]{2}$/iu.test(hex))return {end:i+1,value:'',usable:false};
        decoded=String.fromCharCode(parseInt(hex,16));i+=2;
      }else if(next==='u'){
        const brace=source[i+1]==='{',end=brace?source.indexOf('}',i+2):i+5;
        const hex=source.slice(i+(brace?2:1),end);
        if((brace?!/^[0-9a-f]{1,6}$/iu.test(hex):!/^[0-9a-f]{4}$/iu.test(hex))||parseInt(hex,16)>0x10ffff)return {end:i+1,value:'',usable:false};
        decoded=String.fromCodePoint(parseInt(hex,16));i=brace?end:i+4;
      }
      if(value.length+decoded.length<=8192)value+=decoded;else oversize=true;
    }else if(value.length<8192)value+=c;else oversize=true;
  }
  return {end:i,value:'',usable:false};
}
function contextKind(before,literal){
  if(/\bfetch\s*\(\s*$/u.test(before))return 'fetch_argument';
  if(/\.open\s*\(\s*['"](?:GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)['"]\s*,\s*$/iu.test(before))return 'xhr_url_argument';
  if(/\b(?:get|post|put|patch|delete|request)\s*\(\s*$/u.test(before))return 'request_call_argument_candidate';
  if(/\b(?:pushState|replaceState)\s*\([\s\S]*,\s*$/u.test(before))return 'history_url_argument_candidate';
  if(/\b(?:path|route)\s*:\s*$/u.test(before))return 'route_property_candidate';
  if(/\b(?:navigate|push|replace)\s*\(\s*$/u.test(before))return 'navigation_call_argument_candidate';
  if(/^(?:https?:\/\/|\/|#\/)/u.test(literal))return 'url_literal_candidate';
  return null;
}
function position(offset,lineStarts){
  let lo=0,hi=lineStarts.length;while(lo+1<hi){const mid=(lo+hi)>>1;if(lineStarts[mid]<=offset)lo=mid;else hi=mid;}
  return {lineNumber:lo,columnNumber:offset-lineStarts[lo]};
}
export function analyzeJavaScript(source,{baseURL,allowedOrigins=[],sourceStartLine=0,sourceStartColumn=0}={}){
  if(typeof source!=='string'||Buffer.byteLength(source)>SOURCE_BYTE_LIMIT)throw Error('script_source_budget');
  const base=safeURL(baseURL);if(!base)throw Error('invalid_analysis_base');
  if(!Array.isArray(allowedOrigins)||allowedOrigins.length>64)throw Error('invalid_allowed_origins');
  if(!Number.isSafeInteger(sourceStartLine)||sourceStartLine<0||!Number.isSafeInteger(sourceStartColumn)||sourceStartColumn<0)throw Error('invalid_source_position');
  const allowed=new Set(allowedOrigins),lineStarts=[0];
  for(let i=0;i<source.length;i++)if(source[i]==='\n')lineStarts.push(i+1);
  const candidates=[],seen=new Set();let skippedDynamic=0,literals=0,truncated=false;
  for(let i=0;i<source.length;){
    if(source.startsWith('//',i)){const end=source.indexOf('\n',i+2);i=end<0?source.length:end+1;continue;}
    if(source.startsWith('/*',i)){const end=source.indexOf('*/',i+2);i=end<0?source.length:end+2;continue;}
    if(!['"',"'",'`'].includes(source[i])){i++;continue;}
    const start=i,token=quoted(source,i);i=Math.max(i+1,token.end);
    if(++literals>8192){truncated=true;break;}
    if(!token.usable){skippedDynamic++;continue;}
    const kind=contextKind(source.slice(Math.max(0,start-160),start),token.value);if(!kind)continue;
    const url=safeURL(token.value,base.url);if(!url)continue;
    const local=position(start,lineStarts),key=kind+'\0'+url.url+'\0'+local.lineNumber+'\0'+local.columnNumber;
    if(seen.has(key))continue;seen.add(key);
    if(candidates.length>=CANDIDATE_LIMIT){truncated=true;break;}
    candidates.push({candidateId:`candidate-${candidates.length+1}`,kind,url:url.url,queryRedacted:url.queryRedacted,fragmentRedacted:url.fragmentRedacted,
      originAllowed:allowed.has(url.origin),sourcePosition:local,
      resourcePosition:{lineNumber:sourceStartLine+local.lineNumber,columnNumber:local.columnNumber+(local.lineNumber===0?sourceStartColumn:0)},
      resolutionAssumption:'current_document_url',runtimeVerified:false,executionAuthorized:false});
  }
  return {kind:'static_javascript_candidates',analysis:'bounded_string_literal_heuristics',sourceUtf8SHA256:createHash('sha256').update(source,'utf8').digest('hex'),
    sourceBytes:Buffer.byteLength(source),candidates,skippedDynamicOrMalformedLiterals:skippedDynamic,truncated,
    runtimeVerified:false,executionAuthorized:false,limitations:['no_ast_or_control_flow_proof','dynamic_templates_not_resolved','no_implicit_source_map_or_network_fetch']};
}
export async function analyzeFile(path,options){
  const fd=await open(path,constants.O_RDONLY|constants.O_NOFOLLOW|constants.O_NONBLOCK);
  try{
    const stat=await fd.stat();if(!stat.isFile()||stat.size>SOURCE_BYTE_LIMIT)throw Error('script_source_budget');
    const bytes=Buffer.alloc(SOURCE_BYTE_LIMIT+1);let count=0;
    while(count<bytes.length){const r=await fd.read(bytes,count,bytes.length-count,count);if(!r.bytesRead)break;count+=r.bytesRead;}
    if(count>SOURCE_BYTE_LIMIT)throw Error('script_source_budget');
    const source=new TextDecoder('utf-8',{fatal:true}).decode(bytes.subarray(0,count));
    return analyzeJavaScript(source,options);
  }finally{await fd.close();}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const args=process.argv.slice(2);
  if(args.length!==4||args[0]!=='--file'||args[2]!=='--base-url'){
    process.stderr.write('usage: node route-analysis.mjs --file FILE --base-url HTTP_ORIGIN\n');process.exitCode=1;
  }else{
    const base=safeURL(args[3]);
    analyzeFile(args[1],{baseURL:args[3],allowedOrigins:base?[base.origin]:[]}).then(r=>process.stdout.write(JSON.stringify(r)+'\n'),()=>{process.stderr.write('analysis_failed\n');process.exitCode=1;});
  }
}
