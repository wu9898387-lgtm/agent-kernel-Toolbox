import {validatePolicy,compileRules,cleanOrigin} from './rules.mjs';
let serial=Promise.resolve();
const contentId='agent-kernel-selected-runtime';
async function state(){const s=await chrome.storage.session.get('activeTabs');return s.activeTabs??{};}
async function selected(tabId,site){
  if(!Number.isSafeInteger(tabId)||tabId<0)throw Error('invalid_tab');
  const tab=await chrome.tabs.get(tabId), current=new URL(tab.url);
  if(!['http:','https:'].includes(current.protocol)||current.origin!==cleanOrigin(site))throw Error('tab_origin_changed');
  return tab;
}
async function content(tabId,command,site){
  const expectedOrigin=cleanOrigin(site);
  const injected=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},files:['content.js'],world:'ISOLATED'});
  const document=injected?.length===1&&injected[0];
  if(!document||document.frameId!==0||typeof document.documentId!=='string'||!document.documentId||document.documentId.length>128
      ||typeof document.result?.documentToken!=='string'||!document.result.documentToken||document.result.documentToken.length>128)throw Error('document_identity_unavailable');
  if(document.result.origin!==expectedOrigin)throw Error('tab_origin_changed');
  // Bind the send to the injected document, not whichever document later owns the tab.
  // The isolated content script also checks origin/token synchronously before any effect.
  const result=await chrome.tabs.sendMessage(tabId,{...command,source:'agent-kernel-runtime',expectedOrigin,
    documentToken:document.result.documentToken},{documentId:document.documentId});
  if(result?.error)throw Error(result.error);return result;
}
async function syncScripts(active){
  const scripts=await chrome.scripting.getRegisteredContentScripts({ids:[contentId]});
  const matches=[...new Set(Object.values(active).map(p=>{const u=new URL(p.site);return `${u.protocol}//${u.hostname}/*`;}))];
  if(!matches.length){if(scripts.length)await chrome.scripting.unregisterContentScripts({ids:[contentId]});return;}
  if(scripts.length)await chrome.scripting.updateContentScripts([{id:contentId,matches}]);
  else await chrome.scripting.registerContentScripts([{id:contentId,matches,js:['content.js'],runAt:'document_start',world:'ISOLATED',persistAcrossSessions:false}]);
}
async function apply(tabId,raw,reload){
  const policy=validatePolicy(raw);await selected(tabId,policy.site);
  const active=await state();active[tabId]=policy;
  if(Object.keys(active).length>64)throw Error('active_tab_budget');
  const {policies={}}=await chrome.storage.local.get('policies');policies[policy.site]=policy;
  if(Object.keys(policies).length>128)throw Error('saved_policy_budget');
  const rules=await chrome.declarativeNetRequest.getSessionRules();
  const previous=rules.filter(r=>r.condition.tabIds?.includes(tabId));
  const keep=rules.filter(r=>!r.condition.tabIds?.includes(tabId));
  if(keep.length+policy.blockedRequests.length>4096)throw Error('session_rule_budget');
  const addRules=compileRules(policy,tabId,keep);
  // Rules are committed before reloading, so the next load's matched requests never dispatch.
  await chrome.declarativeNetRequest.updateSessionRules({removeRuleIds:previous.map(r=>r.id),addRules});
  await chrome.storage.local.set({policies});await chrome.storage.session.set({activeTabs:active});
  await syncScripts(active);
  await content(tabId,{operation:'cosmetics',selectors:policy.cosmeticSelectors,reload:Boolean(reload)},policy.site);
  return {active:true,tabId,rules:addRules.length,saved:true,reloadRequested:Boolean(reload),scope:'selected_tab_session'};
}
async function deactivate(tabId){
  if(!Number.isSafeInteger(tabId)||tabId<0)throw Error('invalid_tab');
  const active=await state(),policy=active[tabId];delete active[tabId];
  const rules=await chrome.declarativeNetRequest.getSessionRules();
  await chrome.declarativeNetRequest.updateSessionRules({removeRuleIds:rules.filter(r=>r.condition.tabIds?.includes(tabId)).map(r=>r.id)});
  await chrome.storage.session.set({activeTabs:active});
  await syncScripts(active);
  if(policy)try{await content(tabId,{operation:'clear'},policy.site);}catch{}
  return {active:false,tabId};
}
async function handle(message,sender){
  if(sender.id!==chrome.runtime.id)throw Error('sender_denied');
  if(message?.operation==='getTabPolicy'&&sender.tab){
    const policy=(await state())[sender.tab.id];
    return policy&&new URL(sender.url).origin===policy.site?{policy}: {policy:null};
  }
  if(sender.url!==chrome.runtime.getURL('control.html'))throw Error('controller_required');
  if(!message||typeof message!=='object'||Array.isArray(message))throw Error('invalid_message');
  if(message.operation==='apply')return apply(message.tabId,message.policy,Boolean(message.reload));
  if(message.operation==='deactivate')return deactivate(message.tabId);
  if(message.operation==='saved'){
    await selected(message.tabId,message.site);
    const {policies={}}=await chrome.storage.local.get('policies');
    return {policy:policies[message.site]??{site:message.site,blockedRequests:[],cosmeticSelectors:[]},active:Boolean((await state())[message.tabId])};
  }
  if(!['read','navigate','hide','restore'].includes(message.operation))throw Error('unknown_operation');
  const policy=(await state())[message.tabId];if(!policy)throw Error('tab_not_enabled');
  await selected(message.tabId,policy.site);
  return content(message.tabId,message,policy.site);
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  // One serialized writer avoids lost updates across popup windows and tab removal.
  const task=serial.then(()=>handle(message,sender));serial=task.catch(()=>{});
  task.then(reply,e=>reply({error:/^[a-z_]{1,80}$/u.test(e.message)?e.message:'operation_failed'}));return true;
});
chrome.tabs.onRemoved.addListener(tabId=>{serial=serial.then(()=>deactivate(tabId)).catch(()=>{});});
