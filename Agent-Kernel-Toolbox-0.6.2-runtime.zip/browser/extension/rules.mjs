const resourceTypes = ['main_frame','sub_frame','stylesheet','script','image','font','object','xmlhttprequest','ping','csp_report','media','websocket','other'];
export function cleanOrigin(value) {
  if(typeof value!=='string'||value.length>2048)throw Error('invalid_origin');
  const u=new URL(value);
  if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('invalid_origin');
  return u.origin;
}
export function validatePolicy(value) {
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['site','blockedRequests','cosmeticSelectors'].includes(k)))throw Error('invalid_policy');
  const site=cleanOrigin(value.site), blockedRequests=value.blockedRequests??[], cosmeticSelectors=value.cosmeticSelectors??[];
  if(!Array.isArray(blockedRequests)||blockedRequests.length>64||!Array.isArray(cosmeticSelectors)||cosmeticSelectors.length>64)throw Error('policy_budget');
  return {site,blockedRequests:blockedRequests.map(r=>{
    if(!r||typeof r!=='object'||Array.isArray(r)||Object.keys(r).some(k=>!['origin','pathPrefix','resourceTypes'].includes(k)))throw Error('invalid_rule');
    const origin=cleanOrigin(r.origin),pathPrefix=r.pathPrefix??'/';
    if(typeof pathPrefix!=='string'||pathPrefix.length>512||!pathPrefix.startsWith('/')||/[\x00-\x20\x7f?#]/u.test(pathPrefix))throw Error('invalid_path_prefix');
    const types=r.resourceTypes??resourceTypes;
    if(!Array.isArray(types)||!types.length||types.length>resourceTypes.length||types.some(t=>!resourceTypes.includes(t)))throw Error('invalid_resource_types');
    return {origin,pathPrefix,resourceTypes:[...new Set(types)]};
  }),cosmeticSelectors:cosmeticSelectors.map(s=>{
    if(typeof s!=='string'||s.length>512||!s.trim()||/[\x00-\x1f{};]/u.test(s)||['*','html','body',':root'].includes(s.trim()))throw Error('invalid_selector');
    return s;
  })};
}
function escapeRegex(s){return s.replace(/[.*+?^${}()|[\]\\]/gu,'\\$&');}
export function compileRules(policy,tabId,existingRules) {
  if(!Number.isSafeInteger(tabId)||tabId<0)throw Error('invalid_tab');
  const used=new Set(existingRules.map(r=>r.id));let next=1;
  return policy.blockedRequests.map(r=>{
    while(used.has(next))next++;if(next>2147483647)throw Error('rule_id_budget');
    const id=next++;used.add(id);
    return {id,priority:1,action:{type:'block'},condition:{tabIds:[tabId],regexFilter:'^'+escapeRegex(r.origin)+escapeRegex(r.pathPrefix),isUrlFilterCaseSensitive:true,resourceTypes:r.resourceTypes}};
  });
}
