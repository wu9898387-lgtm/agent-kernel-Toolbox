/** Bounded dispatch policy for one owned browser context, not an OS firewall. */
import {performance} from 'node:perf_hooks';

const GROUP=/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/u;
function fail(code){throw new Error(code);}
function integer(value,minimum,maximum){return Number.isSafeInteger(value)&&value>=minimum&&value<=maximum;}
function canonicalOrigin(value){
  if(typeof value!=='string'||value.length>4096||/[\u0000-\u0020\u007f]/u.test(value))fail('invalid_traffic_origin');
  let url;try{url=new URL(value);}catch{fail('invalid_traffic_origin');}
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.pathname!=='/'||url.search||url.hash)fail('invalid_traffic_origin');
  return url.origin;
}

export function validateTrafficPolicy(value,allowedOrigins=[]){
  if(value===undefined)return undefined;
  const keys=['maxRequests','maxConcurrent','maxQueued','queueTimeoutMs','defaultCooldownMs','maxCooldownMs','origins'];
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(key=>!keys.includes(key))||
     !integer(value.maxRequests,1,100000)||!Array.isArray(value.origins)||!value.origins.length||value.origins.length>64)fail('invalid_traffic_policy');
  const result={maxRequests:value.maxRequests,maxConcurrent:value.maxConcurrent??8,maxQueued:value.maxQueued??64,
    queueTimeoutMs:value.queueTimeoutMs??5000,defaultCooldownMs:value.defaultCooldownMs??1000,
    maxCooldownMs:value.maxCooldownMs??60000,origins:[]};
  if(!integer(result.maxConcurrent,1,128)||!integer(result.maxQueued,0,512)||!integer(result.queueTimeoutMs,1,30000)||
     !integer(result.defaultCooldownMs,0,300000)||!integer(result.maxCooldownMs,0,300000)||
     result.defaultCooldownMs>result.maxCooldownMs)fail('invalid_traffic_policy_limits');
  const seen=new Set(),groups=new Map();
  for(const item of value.origins){
    if(!item||typeof item!=='object'||Array.isArray(item)||Object.keys(item).some(key=>!['origin','group','minIntervalMs','maxConcurrent','maxRequests'].includes(key))||
       !integer(item.minIntervalMs,0,60000)||!integer(item.maxConcurrent,1,16)||!integer(item.maxRequests,1,value.maxRequests)||
       item.group!==undefined&&(typeof item.group!=='string'||!GROUP.test(item.group)))fail('invalid_traffic_origin_limits');
    const origin=canonicalOrigin(item.origin);
    if(seen.has(origin))fail('duplicate_traffic_origin');
    seen.add(origin);
    const limits={minIntervalMs:item.minIntervalMs,maxConcurrent:item.maxConcurrent,maxRequests:item.maxRequests};
    const key=item.group===undefined?'origin:'+origin:'group:'+item.group;
    if(groups.has(key)&&JSON.stringify(groups.get(key))!==JSON.stringify(limits))fail('inconsistent_traffic_group_limits');
    groups.set(key,limits);
    result.origins.push(Object.freeze({origin,...limits,...item.group!==undefined?{group:item.group}:{}}));
  }
  if(allowedOrigins.some(origin=>!seen.has(canonicalOrigin(origin))))fail('traffic_document_origin_not_configured');
  result.origins=Object.freeze(result.origins);
  return Object.freeze(result);
}

export function retryAfterMilliseconds(value,{now=Date.now(),fallback=1000,maximum=60000}={}){
  if(typeof value!=='string'||value.length>128||/[\u0000-\u001f\u007f]/u.test(value))return Math.min(fallback,maximum);
  const text=value.trim();
  if(/^\d{1,10}$/u.test(text))return Math.min(Number(text)*1000,maximum);
  // Accept the standard IMF-fixdate form only; arbitrary date-like application
  // strings do not become a scheduler instruction.
  if(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2} GMT$/u.test(text)){
    const date=Date.parse(text);if(Number.isFinite(date))return Math.min(Math.max(0,date-now),maximum);
  }
  return Math.min(fallback,maximum);
}

/**
 * context.route is the only admission counter. Page/CDP handlers retain their
 * existing permission decisions but must not create a second dispatch ticket.
 * Redirect hops bypass Playwright route handlers, so runtime.mjs blocks 3xx in
 * a Chromium Fetch response-stage guard before a redirect can be followed.
 */
export class TrafficPolicy {
  constructor(configuration,{record=()=>{},ownsRequest=()=>true,onFault=()=>{}}={}){
    this.config=validateTrafficPolicy(configuration);this.record=record;this.ownsRequest=ownsRequest;this.onFault=onFault;
    this.origins=new Map();this.groups=new Map();
    for(const item of this.config.origins){
      const key=item.group===undefined?'origin:'+item.origin:'group:'+item.group;
      let group=this.groups.get(key);
      if(!group){group={key,...item,origins:[],admitted:0,active:0,lastStart:-Infinity,cooldownUntil:0};this.groups.set(key,group);}
      group.origins.push(item.origin);this.origins.set(item.origin,group);
    }
    this.queue=[];this.active=new Map();this.requests=new WeakMap();this.seen=new WeakSet();
    this.closed=false;this.faulted=false;this.contextClosed=false;this.timer=null;
    this.counts={seen:0,admitted:0,denied:0,queuedPeak:0,activePeak:0,finished:0,failed:0,
      queueTimeouts:0,queueOverflows:0,budgetDenials:0,cooldowns:0,redirectsBlocked:0,
      websocketsBlocked:0,unregisteredTargetsBlocked:0,duplicatesBlocked:0,canceledBeforeAdmission:0};
  }
  event(reason,origin=null,extra={}){this.record({kind:'traffic_policy',reason,origin,...extra});}
  _origin(url){try{const parsed=new URL(url);return ['http:','https:'].includes(parsed.protocol)&&!parsed.username&&!parsed.password?parsed.origin:null;}catch{return null;}}
  snapshot(){
    const now=performance.now();
    return {enabled:true,closed:this.closed,faulted:this.faulted,contextClosed:this.contextClosed,
      coverage:{mode:'owned_chromium_context_routed_http_https',redirects:'all_3xx_blocked_before_follow',
        websocket:'browser_context_route_blocked',serviceWorkers:'blocked',workers:'page_constructors_blocked_and_unregistered_requests_refused',
        nonHttpAPIs:'worker/webtransport/webrtc constructors disabled in initialized page realms; no OS network-firewall claim',
        browserInternalConnectionsCovered:false,automaticRetries:false,runtimeAutomaticRetries:false,
        automaticRetryScope:'policy never retries; browser transport retries are not controlled',browserTransportRetriesControlled:false,
        minIntervalScope:'dispatch admission; server arrival timing can differ by transport latency',
        requestBudgetScope:'context HTTP(S) route admissions, not browser transport attempts',
        cooldownScope:'future admissions only; already in-flight requests are not canceled or replayed',CDPAttachedTargetsSupported:false},
      limits:{maxRequests:this.config.maxRequests,maxConcurrent:this.config.maxConcurrent,maxQueued:this.config.maxQueued,
        queueTimeoutMs:this.config.queueTimeoutMs,maxCooldownMs:this.config.maxCooldownMs},
      counts:{...this.counts,active:this.active.size,queued:this.queue.length,remainingRequests:Math.max(0,this.config.maxRequests-this.counts.admitted)},
      groups:[...this.groups.values()].map(group=>({origins:[...group.origins],group:group.group??null,
        admitted:group.admitted,active:group.active,queued:this.queue.filter(item=>item.group===group).length,
        minIntervalMs:group.minIntervalMs,maxConcurrent:group.maxConcurrent,maxRequests:group.maxRequests,
        cooldownRemainingMs:Math.max(0,Math.ceil(group.cooldownUntil-now))}))};
  }
  async handle(route){
    const request=route.request();
    if(this.seen.has(request)){this.counts.duplicatesBlocked++;return this._abort(route,'duplicate_interception',null);}
    this.seen.add(request);this.counts.seen++;
    const origin=this._origin(request.url()),group=this.origins.get(origin);
    if(this.closed)return this._abort(route,'closed',origin);
    if(!origin||!group)return this._abort(route,'origin_not_configured',origin);
    if(!this.ownsRequest(request)){this.counts.unregisteredTargetsBlocked++;return this._abort(route,'unregistered_target_or_worker',origin);}
    if(this.counts.admitted>=this.config.maxRequests||group.admitted>=group.maxRequests){this.counts.budgetDenials++;return this._abort(route,'request_budget',origin);}
    const now=performance.now();
    const immediatelyReady=this.queue.length===0&&this.active.size<this.config.maxConcurrent&&group.active<group.maxConcurrent&&
      now>=Math.max(group.lastStart+group.minIntervalMs,group.cooldownUntil);
    if(!immediatelyReady&&this.queue.length>=this.config.maxQueued){this.counts.queueOverflows++;return this._abort(route,'queue_capacity',origin);}
    let resolve;const finished=new Promise(done=>{resolve=done;});
    const item={route,request,origin,group,deadline:now+this.config.queueTimeoutMs,resolve,state:'queued'};
    this.requests.set(request,item);this.queue.push(item);
    this._drain();this.counts.queuedPeak=Math.max(this.counts.queuedPeak,this.queue.length);await finished;
  }
  async _abort(route,reason,origin){
    this.counts.denied++;this.event(reason,origin);
    try{await route.abort('blockedbyclient');}catch{if(!this.closed)this.fault('abort_resolution_unknown');}
  }
  _deny(item,reason){
    if(item.state!=='queued')return;
    item.state='denied';this.requests.delete(item.request);
    const index=this.queue.indexOf(item);if(index>=0)this.queue.splice(index,1);
    this._abort(item.route,reason,item.origin).finally(item.resolve);
  }
  _drain(){
    if(this.timer){clearTimeout(this.timer);this.timer=null;}
    if(this.closed)return;
    const now=performance.now();
    for(const item of [...this.queue]){
      if(now>=item.deadline){this.counts.queueTimeouts++;this._deny(item,'queue_deadline');}
      else if(this.counts.admitted>=this.config.maxRequests||item.group.admitted>=item.group.maxRequests){this.counts.budgetDenials++;this._deny(item,'request_budget');}
    }
    for(const item of [...this.queue]){
      if(this.active.size>=this.config.maxConcurrent)break;
      const group=item.group;
      if(this.counts.admitted>=this.config.maxRequests||group.admitted>=group.maxRequests){this.counts.budgetDenials++;this._deny(item,'request_budget');continue;}
      if(item.state!=='queued'||group.active>=group.maxConcurrent||now<Math.max(group.lastStart+group.minIntervalMs,group.cooldownUntil))continue;
      this.queue.splice(this.queue.indexOf(item),1);item.state='active';
      group.admitted++;group.active++;group.lastStart=performance.now();
      this.counts.admitted++;this.active.set(item.request,item);this.counts.activePeak=Math.max(this.counts.activePeak,this.active.size);
      this.event('admitted',item.origin,{admission:this.counts.admitted});
      // This continues the browser's one intercepted request. It never calls
      // fetch, retries a request, or sends POST/form data a second time.
      (async()=>{try{await item.route.continue();}catch{if(!this.closed)this.fault('continue_resolution_unknown');}
        finally{item.resolve();}})();
    }
    let next=Infinity;
    for(const item of this.queue){
      next=Math.min(next,item.deadline);
      if(this.active.size<this.config.maxConcurrent&&item.group.active<item.group.maxConcurrent)
        next=Math.min(next,Math.max(item.group.lastStart+item.group.minIntervalMs,item.group.cooldownUntil));
    }
    if(next!==Infinity)this.timer=setTimeout(()=>this._drain(),Math.max(1,Math.ceil(next-performance.now())));
  }
  finished(request,failed=false){
    const item=this.requests.get(request);if(!item)return;
    this.requests.delete(request);
    if(item.state==='queued'){
      const index=this.queue.indexOf(item);if(index>=0)this.queue.splice(index,1);
      item.state='canceled';this.counts.canceledBeforeAdmission++;item.resolve();
      this.event('request_canceled_in_queue',item.origin);
    }else if(item.state==='active'){
      this.active.delete(request);item.group.active--;item.state='finished';this.counts[failed?'failed':'finished']++;
    }
    this._drain();
  }
  response(response){
    const item=this.requests.get(response.request());if(!item||item.state!=='active'||this.closed)return;
    const status=response.status();if(status!==429&&status!==503)return;
    let value;try{value=response.headers()['retry-after'];}catch{value=undefined;}
    const delay=retryAfterMilliseconds(value,{fallback:this.config.defaultCooldownMs,maximum:this.config.maxCooldownMs});
    item.group.cooldownUntil=Math.max(item.group.cooldownUntil,performance.now()+delay);this.counts.cooldowns++;
    this.event('response_cooldown',item.origin,{status,cooldownMs:delay});this._drain();
  }
  blockRedirect(url){this.counts.redirectsBlocked++;this.event('redirect_response_blocked',this._origin(url));}
  blockWebSocket(url){this.counts.websocketsBlocked++;let origin=null;try{origin=new URL(url).origin;}catch{}this.event('websocket_blocked',origin);}
  fault(reason){
    if(this.closed||this.faulted||this.contextClosed)return;this.faulted=true;this.event(reason);
    this.close().then(()=>this.onFault()).catch(()=>{});
  }
  async close(){
    this.closed=true;if(this.timer){clearTimeout(this.timer);this.timer=null;}
    const queued=[...this.queue];this.queue=[];
    await Promise.allSettled(queued.map(async item=>{
      if(item.state!=='queued')return;item.state='denied';this.requests.delete(item.request);
      try{await this._abort(item.route,'context_closing',item.origin);}finally{item.resolve();}
    }));
  }
  contextDidClose(){
    this.contextClosed=true;this.close();
    for(const item of this.active.values()){item.group.active--;item.state='finished';item.resolve();this.counts.failed++;}
    this.active.clear();
  }
}

/** Defense in page realms; context routing remains the actual HTTP gate. */
export function installTrafficTransportGuards(){
  const blocked=function(){throw new DOMException('Transport disabled by owned-browser traffic policy','SecurityError');};
  for(const name of ['Worker','SharedWorker','WebTransport','RTCPeerConnection','webkitRTCPeerConnection']){
    if(name in globalThis){try{Object.defineProperty(globalThis,name,{value:blocked,writable:false,configurable:false});}catch{}}
  }
}
