#!/usr/bin/env node
/** Bounded JSON-lines transport. Host-owned config is never supplied by page data. */
import {open} from 'node:fs/promises';
import {constants} from 'node:fs';
import {RuntimeBrowser,ObservedControlRefusal} from './runtime.mjs';
import {RouteNavigationRefusal} from './route-evidence.mjs';
import {TextInputRefusal} from './text-input.mjs';

const MAX_LINE = 65536;
const METHODS = {
  open:['url'], targets:[], snapshot:['pageId'], activate:['pageId','snapshotId','nodeId'],
  query:['pageId','options'],
  fields:['pageId','query','limit'],setText:['pageId','snapshotId','nodeId','value'],
  controls:['pageId','query','role','limit'],
  invoke:['pageId','snapshotId','nodeId'],
  capabilities:[],
  navigate:['pageId','url'], metrics:['pageId'], addBlockRule:['rule'], networkEvents:[],
  hide:['pageId','selector'], restore:['hideId'], closeTarget:['targetId'], close:[],
  routeEvidence:['pageId','limit'],analyzeScript:['pageId','scriptHandle'],navigateObserved:['pageId','routeHandle'],
};
function output(value) {
  const encoded=JSON.stringify(value);
  if(Buffer.byteLength(encoded)>1048576)throw Error('response_budget');
  process.stdout.write(encoded+'\n');
}
function errorCode(e) { return typeof e.message === 'string' && /^[a-z][a-z0-9_]{1,80}$/u.test(e.message) ? e.message : 'operation_failed'; }
async function readConfig(path) {
  const fd = await open(path,constants.O_RDONLY|constants.O_NOFOLLOW);
  try {
    const stat = await fd.stat(); if (!stat.isFile() || stat.size > MAX_LINE) throw Error('config_budget');
    const buffer = Buffer.alloc(MAX_LINE+1), result = await fd.read(buffer,0,buffer.length,0);
    if (result.bytesRead > MAX_LINE) throw Error('config_budget');
    return JSON.parse(buffer.subarray(0,result.bytesRead).toString('utf8'));
  } finally { await fd.close(); }
}
async function run() {
  if (process.argv.length !== 4 || process.argv[2] !== '--config') throw Error('usage_node_cli_mjs_config_path');
  const config = await readConfig(process.argv[3]);
  if (!['launch','connect'].includes(config.mode ?? 'launch')) throw Error('invalid_mode');
  const runtime = await RuntimeBrowser[config.mode ?? 'launch'](config);
  let pending = Buffer.alloc(0), quit = false;
  output({event:'ready',schemaVersion:1});
  try {
    for await (const chunk of process.stdin) {
      pending = Buffer.concat([pending,chunk]);
      let end;
      while ((end=pending.indexOf(10)) !== -1) {
        const line = pending.subarray(0,end); pending = pending.subarray(end+1);
        if (line.length > MAX_LINE) throw Error('request_budget');
        let request, id = null;
        try {
          request = JSON.parse(line.toString('utf8')); id = request.id;
          if (!request || typeof request !== 'object' || Array.isArray(request) || Object.keys(request).some(k=>!['id','method','args'].includes(k)) || (typeof id !== 'string' && !Number.isSafeInteger(id)) || (typeof id === 'string' && id.length>128)) throw Error('invalid_request');
          if (!Object.hasOwn(METHODS,request.method)) throw Error('unknown_method');
          const keys=METHODS[request.method], args=request.args ?? {};
          if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some(k=>!keys.includes(k)) || keys.some(k=>!Object.hasOwn(args,k))) throw Error('invalid_arguments');
          const result = await runtime[request.method](...keys.map(k=>args[k]));
          output({id,result:result ?? null});
          if (request.method === 'close') { quit=true; break; }
        } catch (e) {
          output({id,error:{code:errorCode(e),...(e instanceof RouteNavigationRefusal?{navigationDispatched:false}:{}),
            ...(e instanceof TextInputRefusal||e instanceof ObservedControlRefusal?{effectDispatched:false}:{})}});
        }
      }
      if (quit) break;
      if (pending.length > MAX_LINE) throw Error('request_budget');
    }
    if (!quit && pending.length) throw Error('unterminated_request');
  } finally { await runtime.close(); }
}
run().catch(e=>{output({error:{code:errorCode(e)}});process.exitCode=1;});
