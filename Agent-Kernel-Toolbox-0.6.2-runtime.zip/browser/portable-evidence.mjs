/** Playwright events for Firefox/WebKit. URL replay is explicit, never CDP history. */
import {randomUUID,createHash} from 'node:crypto';
import {safeURL,analyzeJavaScript,SOURCE_BYTE_LIMIT} from './route-analysis.mjs';
import {RouteNavigationRefusal} from './route-evidence.mjs';
const digest=value=>createHash('sha256').update(value).digest('hex');
const refuse=code=>{throw new RouteNavigationRefusal(code);};
const fail=code=>{throw Error(code);};

function scriptsInDocument(){
  const result=[];let bytes=0;
  for(let index=0;index<Math.min(document.scripts.length,128);index++){
    const script=document.scripts[index];
    if(script.src){result.push({index,url:script.src,source:null});continue;}
    const source=script.textContent.slice(0,262145),size=new TextEncoder().encode(source).length;
    if(size>262144||bytes+size>1048576){result.push({index,url:location.href,source:null});continue;}
    bytes+=size;result.push({index,url:location.href,source});
  }
  return result;
}

export class PortableEvidence {
  constructor({page,allowedOrigins}){
    this.page=page;this.allowed=new Set(allowedOrigins);this.routes=[];this.requests=[];
    this.requestIds=new Map();this.scripts=new Map();this.routeHandles=new Map();this.listeners=[];
    this.sequence=0;this.version=0;this.sourceBytes=0;this.dropped={routes:0,requests:0};this.closed=false;
  }
  permitted(value){const u=safeURL(value);return u&&this.allowed.has(u.origin)?u:null;}
  listen(name,fn){this.page.on(name,fn);this.listeners.push([name,fn]);}
  addRoute(url){
    this.version++;this.routeHandles.clear();this.scripts.clear();
    const u=this.permitted(url);if(!u)return;
    this.routes.push({eventId:`route-${++this.sequence}`,sequence:this.sequence,kind:'playwright_main_frame_navigation',
      ...u,observedAt:new Date().toISOString()});
    if(this.routes.length>128){this.routes.shift();this.dropped.routes++;}
  }
  async start(){
    this.addRoute(this.page.url());
    this.listen('framenavigated',frame=>{if(frame===this.page.mainFrame())this.addRoute(frame.url());});
    this.listen('request',request=>{
      try{if(request.frame()!==this.page.mainFrame())return;}catch{return;}
      const document=this.permitted(this.page.url()),u=safeURL(request.url());if(!document||!u)return;
      const method=request.method();
      const item={eventId:`request-${++this.sequence}`,sequence:this.sequence,url:u.url,queryRedacted:u.queryRedacted,
        documentURL:document.url,method:/^[A-Z]{1,16}$/u.test(method)?method:'OTHER',resourceType:request.resourceType(),
        responseObserved:false,loadingFinished:false,failureObserved:false,serverEffectConfirmed:false,
        association:{kind:'observed_document_url',causalityProven:false},
        initiator:{available:false,reason:'cdp_initiator_stack_unavailable'},observedAt:new Date().toISOString()};
      this.requests.push(item);this.requestIds.set(request,item);
      if(this.requests.length>128){const old=this.requests.shift();for(const [key,value]of this.requestIds)if(value===old)this.requestIds.delete(key);this.dropped.requests++;}
    });
    this.listen('response',response=>{const item=this.requestIds.get(response.request());if(item){item.responseObserved=true;item.status=response.status();}});
    this.listen('requestfinished',request=>{const item=this.requestIds.get(request);if(item)item.loadingFinished=true;});
    this.listen('requestfailed',request=>{const item=this.requestIds.get(request);if(item)item.failureObserved=true;});
  }
  async collectScripts(){
    const values=await this.page.evaluate(scriptsInDocument),records=[];
    for(const value of values){
      const u=this.permitted(value.url);if(!u)continue;
      const hash=value.source===null?null:digest(value.source);
      const old=[...this.scripts.values()].find(s=>s.index===value.index&&s.sourceUtf8SHA256===hash);
      const record={scriptHandle:hash?(old?.scriptHandle??randomUUID()):null,index:value.index,url:u.url,
        sourceUtf8SHA256:hash,length:value.source===null?null:Buffer.byteLength(value.source),
        sourceReadable:hash!==null,sourceAccessReason:hash?'observed_inline_script':'external_or_oversized_script_source_unavailable',
        sourceAuthenticated:false,version:this.version};
      if(record.scriptHandle)this.scripts.set(record.scriptHandle,record);
      records.push(record);
    }
    // Changed inline scripts cannot keep old read authority.
    const current=new Set(records.map(r=>r.scriptHandle));for(const id of this.scripts.keys())if(!current.has(id))this.scripts.delete(id);
    return records;
  }
  async evidence(limit=64){
    if(!Number.isSafeInteger(limit)||limit<1||limit>128)fail('invalid_evidence_limit');
    if(!this.permitted(this.page.url()))fail('origin_not_allowed');
    const version=this.version,scripts=await this.collectScripts();
    if(version!==this.version)fail('page_changed_during_evidence');
    this.routeHandles.clear();
    const currentHash=digest(this.page.url());
    const routes=this.routes.slice(-limit).map(route=>{
      if(!route.replayable)return {...route,routeHandle:null,navigationUnavailableReason:'redacted_url_not_replayable'};
      const routeHandle=randomUUID();this.routeHandles.set(routeHandle,{url:route.url,version,created:Date.now(),currentHash});
      return {...route,routeHandle,navigationMode:'observed_url_reload',historyEntryAvailable:false};
    });
    return {schemaVersion:1,observationOnly:true,sourceAuthenticated:false,executionAuthorized:false,
      routes,requests:this.requests.slice(-limit),scripts:scripts.slice(-limit),scriptsStatus:'inline_only',
      dropped:{...this.dropped},sourceBytesRead:this.sourceBytes,sourceByteBudget:1048576,
      navigationMode:'observed_url_reload',initiatorStacksAvailable:false,queryHeaderBodyStored:false};
  }
  async analyze(scriptHandle){
    const record=this.scripts.get(scriptHandle);
    if(!record||record.version!==this.version)fail('stale_script_handle');
    if(!this.permitted(this.page.url()))fail('origin_not_allowed');
    const values=await this.page.evaluate(scriptsInDocument),current=values.find(s=>s.index===record.index);
    if(!current||current.source===null||digest(current.source)!==record.sourceUtf8SHA256||record.version!==this.version)fail('stale_script_handle');
    const bytes=Buffer.byteLength(current.source);
    if(bytes>SOURCE_BYTE_LIMIT||this.sourceBytes+bytes>1048576)fail('script_session_budget');
    this.sourceBytes+=bytes;
    const result=analyzeJavaScript(current.source,{baseURL:this.page.url(),allowedOrigins:[...this.allowed]});
    return {...result,script:record,implicitNetworkFetch:false,
      candidates:result.candidates.map(c=>({...c,observedRouteURLMatches:this.routes.filter(r=>r.url===c.url).slice(-8).map(r=>r.eventId),
        observedRequestURLMatches:this.requests.filter(r=>r.url===c.url).slice(-8).map(r=>r.eventId),correspondenceProvesImplementation:false}))};
  }
  async navigate(routeHandle){
    const handle=this.routeHandles.get(routeHandle);
    if(!handle||handle.version!==this.version||Date.now()-handle.created>30000||digest(this.page.url())!==handle.currentHash)refuse('stale_route_handle');
    if(!this.permitted(this.page.url())||!this.permitted(handle.url))refuse('origin_not_allowed');
    this.routeHandles.clear();
    const response=await this.page.goto(handle.url,{waitUntil:'domcontentloaded'});
    if(!this.permitted(this.page.url()))fail('origin_not_allowed');
    return {dispatched:true,navigationCompleted:true,businessEffectConfirmed:false,mode:'observed_url_reload',
      url:safeURL(this.page.url())?.url,status:response?.status()??null};
  }
  close(){this.closed=true;for(const [name,fn]of this.listeners)this.page.off(name,fn);this.listeners=[];this.routeHandles.clear();this.scripts.clear();this.requestIds.clear();}
}
