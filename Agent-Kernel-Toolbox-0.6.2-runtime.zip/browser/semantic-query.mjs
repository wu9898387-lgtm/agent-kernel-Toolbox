/** Fixed, read-only DOM inspection. No page-supplied code is evaluated. */
export function validateQuery(options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options) ||
      Object.keys(options).some(k=>!['query','selector','maxNodes','maxTextBytes'].includes(k))) throw Error('invalid_query_options');
  const {query='',selector='a[href],button,[role],[aria-label],h1,h2,h3,h4,h5,h6,label,summary,p,li,td,th,output',maxNodes=64,maxTextBytes=8192}=options;
  if (typeof query!=='string'||query.length>256||typeof selector!=='string'||!selector||selector.length>512||
      !Number.isSafeInteger(maxNodes)||maxNodes<1||maxNodes>128||
      !Number.isSafeInteger(maxTextBytes)||maxTextBytes<128||maxTextBytes>32768) throw Error('invalid_query_options');
  return {query,selector,maxNodes,maxTextBytes};
}

// This function is serialized by Playwright; keep all helpers inside it.
export function captureQuery({query,selector,maxNodes,maxTextBytes}) {
  try { document.documentElement.matches(selector); } catch { throw Error('invalid_query_selector'); }
  const privateSelector='input,textarea,select,[contenteditable]:not([contenteditable="false"]),[data-sensitive],[data-private],[aria-hidden="true"],[hidden],script,style,noscript,template';
  const encoder=new TextEncoder(), rows=[], roots=[document.documentElement];
  let visited=0,textVisited=0,bytes=0,truncated=false,shadowRoots=0;
  const forbidden=el=>{
    while(el){if(el.closest(privateSelector))return true;el=el.getRootNode().host;}
    return false;
  };
  const visible=el=>{
    const css=getComputedStyle(el);
    return css.display!=='none'&&css.visibility!=='hidden'&&css.visibility!=='collapse'&&el.getClientRects().length>0;
  };
  const readableText=el=>{
    const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),parts=[];
    let chars=0;
    while(walker.nextNode()){
      if(++textVisited>20000){truncated=true;break;}
      const p=walker.currentNode.parentElement;
      if(!p||forbidden(p)||!visible(p))continue;
      const part=walker.currentNode.nodeValue.slice(0,2048).replace(/\s+/gu,' ').trim();
      if(part){parts.push(part);chars+=part.length;}
      if(chars>=512)break;
    }
    return parts.join(' ').slice(0,512);
  };
  while(roots.length){
    const root=roots.shift(),walker=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT);
    let el=root.nodeType===Node.ELEMENT_NODE?root:walker.nextNode();
    if(!el)continue;
    do {
      if(++visited>5000){truncated=true;break;}
      if(forbidden(el))continue;
      if(el.shadowRoot){roots.push(el.shadowRoot);shadowRoots++;}
      if(!el.matches(selector)||!visible(el))continue;
      const label=el.getAttribute('aria-label');
      const name=(label||readableText(el)).replace(/\s+/gu,' ').trim().slice(0,512);
      const tag=el.tagName.toLowerCase();
      const role=(el.getAttribute('role')||(tag==='a'?'link':tag==='button'?'button':/^h[1-6]$/u.test(tag)?'heading':'generic')).slice(0,64);
      const states={disabled:el.matches(':disabled')||el.getAttribute('aria-disabled')==='true'};
      for(const state of ['selected','checked','expanded','pressed','busy','current']){
        const value=el.getAttribute(`aria-${state}`);
        if(value!==null&&/^(?:true|false|mixed|page|step|location|date|time)$/u.test(value))states[state]=value;
      }
      if(!`${name} ${role} ${tag} ${Object.entries(states).map(([k,v])=>`${k}=${v}`).join(' ')}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()))continue;
      let boundedName='';
      for(const char of name){const count=encoder.encode(char).length;if(bytes+count>maxTextBytes){truncated=true;break;}boundedName+=char;bytes+=count;}
      const href=tag==='a'?el.href:null;
      rows.push({tag,role,name:boundedName,states,href:href&&href.length<=8192?href:null});
      if(rows.length>=maxNodes||bytes>=maxTextBytes){truncated=true;break;}
    } while((el=walker.nextNode()));
    if(truncated)break;
  }
  return {nodes:rows,visited,textBytes:bytes,shadowRoots,truncated,atomicSnapshot:false};
}
