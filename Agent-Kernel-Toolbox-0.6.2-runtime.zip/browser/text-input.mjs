/** Fixed plain-text field inspection; no caller selectors or page scripts. */
export class TextInputRefusal extends Error {}

export function describeTextField(el) {
  const tag=el.tagName.toLowerCase(),type=tag==='input'?el.type:'textarea';
  if(!(tag==='textarea'||tag==='input'&&['text','search','email','url','tel'].includes(type))||!el.isConnected)return null;
  const privateSelector='[data-sensitive],[data-private],[aria-hidden="true"],[hidden],script,style,noscript,template';
  const forbidden=node=>{while(node){if(node.closest(privateSelector))return true;node=node.getRootNode().host;}return false;};
  if(forbidden(el)||/(?:password|one-time-code|cc-)/iu.test(el.getAttribute('autocomplete')||el.autocomplete))return null;
  const css=getComputedStyle(el);
  if(css.display==='none'||css.visibility==='hidden'||!el.getClientRects().length)return null;
  const readable=label=>{
    if(!label||forbidden(label))return '';
    const walker=document.createTreeWalker(label,NodeFilter.SHOW_TEXT),parts=[];let visited=0,size=0;
    while(walker.nextNode()&&visited++<256){const node=walker.currentNode,parent=node.parentElement;
      if(!parent||forbidden(parent)||parent.closest('input,textarea,select,[contenteditable]'))continue;
      const part=node.nodeValue.slice(0,512);parts.push(part);size+=part.length;if(size>=512)break;}
    return parts.join(' ').replace(/\s+/gu,' ').trim().slice(0,512);
  };
  const root=el.getRootNode(),ids=(el.getAttribute('aria-labelledby')??'').split(/\s+/u).filter(Boolean).slice(0,8);
  const labels=Array.from(el.labels??[]).slice(0,8).map(readable).filter(Boolean);
  const named=ids.map(id=>readable(root.getElementById?.(id))).filter(Boolean).join(' ');
  const name=(el.getAttribute('aria-label')||named||labels.join(' ')||el.placeholder||'').slice(0,512);
  const value=el.value;
  if(value.length>2048||new TextEncoder().encode(value).length>2048)return null;
  return {tag,type,name,labels,value,disabled:el.matches(':disabled')||el.getAttribute('aria-disabled')==='true',readOnly:el.readOnly===true};
}
