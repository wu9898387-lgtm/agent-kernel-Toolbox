/** Selected-target browser evidence. CDP observations and static hypotheses stay separate. */
import {randomUUID,createHash} from 'node:crypto';
import {safeURL,analyzeJavaScript,SOURCE_BYTE_LIMIT} from './route-analysis.mjs';

const MAX_ROUTES=128,MAX_REQUESTS=128,MAX_SCRIPTS=128,MAX_STACK_FRAMES=8;
const TOTAL_SOURCE_BYTES=1048576,HANDLE_TTL=30000;
const RESPONSE_GROUP_BYTES=196608;
const number=v=>Number.isSafeInteger(v)&&v>=0?v:null;
const digest=s=>createHash('sha256').update(s).digest('hex');
function fail(code){throw Error(code);}
// Only explicit checks before the history command may carry this receipt.
export class RouteNavigationRefusal extends Error {}
function refuseNavigation(code){throw new RouteNavigationRefusal(code);}
function identifier(value,max=128){return typeof value==='string'&&value.length<=max&&!/[\x00-\x1f\x7f]/u.test(value)?value:null;}
function functionName(value){return typeof value==='string'&&/^[A-Za-z0-9_$.<> -]{0,128}$/u.test(value)?value:'[name omitted]';}
function boundedRecent(items){
  const result=[];let bytes=0;
  for(let i=items.length-1;i>=0;i--){const n=Buffer.byteLength(JSON.stringify(items[i]))+1;if(bytes+n>RESPONSE_GROUP_BYTES)break;result.unshift(items[i]);bytes+=n;}
  return result;
}

export class RouteEvidence {
  constructor({session,page,allowedOrigins}){
    this.session=session;this.page=page;this.allowed=new Set(allowedOrigins);
    this.routes=[];this.requests=[];this.requestIds=new Map();this.scripts=new Map();this.scriptHandles=new Map();this.routeHandles=new Map();
    this.sequence=0;this.version=0;this.documentEpoch=0;this.mainFrameId=null;this.sourceBytes=0;
    this.dropped={routes:0,requests:0,scripts:0,scriptScope:0};this.listeners=[];this.debugBusy=false;this.debugTainted=false;this.closed=false;
  }
  permitted(value){const parsed=safeURL(value);return parsed&&this.allowed.has(parsed.origin)?parsed:null;}
  listen(name,fn){this.session.on(name,fn);this.listeners.push([name,fn]);}
  async start(){
    const {frameTree}=await this.session.send('Page.getFrameTree');this.mainFrameId=frameTree.frame.id;
    this.addRoute(frameTree.frame.url,'initial_snapshot');
    this.listen('Page.frameNavigated',event=>{
      if(event.frame.parentId)return;
      this.mainFrameId=event.frame.id;this.documentEpoch++;this.sourceBytes=0;
      this.scripts.clear();this.scriptHandles.clear();this.routeHandles.clear();
      this.addRoute(event.frame.url,'document_navigation');
    });
    this.listen('Page.navigatedWithinDocument',event=>{
      if(event.frameId===this.mainFrameId)this.addRoute(event.url,['historyApi','fragment','other'].includes(event.navigationType)?event.navigationType:'other');
    });
    this.listen('Network.requestWillBeSent',event=>this.addRequest(event));
    this.listen('Network.responseReceived',event=>{
      const r=this.requestIds.get(event.requestId);if(!r)return;
      r.responseObserved=true;r.status=number(event.response.status);
      r.fromDiskCache=Boolean(event.response.fromDiskCache);r.fromServiceWorker=Boolean(event.response.fromServiceWorker);
    });
    this.listen('Network.loadingFinished',event=>{const r=this.requestIds.get(event.requestId);if(r)r.loadingFinished=true;});
    this.listen('Network.loadingFailed',event=>{
      const r=this.requestIds.get(event.requestId);if(!r)return;
      r.failureObserved=true;r.canceled=Boolean(event.canceled);
      r.blockedReason=typeof event.blockedReason==='string'&&/^[a-zA-Z_-]{1,64}$/u.test(event.blockedReason)?event.blockedReason:null;
    });
  }
  addRoute(value,kind){
    this.version++;this.routeHandles.clear();
    const parsed=this.permitted(value);if(!parsed)return;
    const previous=this.routes.at(-1);
    const event={eventId:`route-${++this.sequence}`,sequence:this.sequence,kind,url:parsed.url,
      queryRedacted:parsed.queryRedacted,fragmentRedacted:parsed.fragmentRedacted,replayable:parsed.replayable,
      previousEventId:previous?.eventId??null,documentEpoch:this.documentEpoch,observedAt:new Date().toISOString()};
    this.routes.push(event);if(this.routes.length>MAX_ROUTES){this.routes.shift();this.dropped.routes++;}
  }
  stack(initiator){
    const frames=[];let stack=initiator?.stack,depth=0,truncated=false;
    while(stack&&depth++<3){
      for(const f of (Array.isArray(stack.callFrames)?stack.callFrames:[])){
        if(frames.length>=MAX_STACK_FRAMES){truncated=true;break;}
        const url=safeURL(f.url);if(!url)continue;
        const scriptId=identifier(f.scriptId),script=this.scripts.get(scriptId);
        frames.push({functionName:functionName(f.functionName),url:url.url,queryRedacted:url.queryRedacted,
          scriptId,lineNumber:number(f.lineNumber),columnNumber:number(f.columnNumber),
          capturedContentSHA256:script?.cdpContentSHA256??null,capturedSourceUtf8SHA256:script?.sourceUtf8SHA256??null});
      }
      if(frames.length>=MAX_STACK_FRAMES){truncated=Boolean(stack.parent)||truncated;break;}
      stack=stack.parent;
    }
    return {type:['parser','script','preload','preflight','signedExchange','other'].includes(initiator?.type)?initiator.type:'other',frames,truncated:truncated||Boolean(stack?.parent)};
  }
  addRequest(event){
    if(event.frameId!==this.mainFrameId)return;
    const document=this.permitted(event.documentURL),url=safeURL(event.request?.url);
    if(!document||!url)return;
    const prior=this.requestIds.get(event.requestId);
    if(prior&&event.redirectResponse){prior.responseObserved=true;prior.status=number(event.redirectResponse.status);prior.redirected=true;}
    const matched=[...this.routes].reverse().find(r=>r.url===document.url);
    const r={eventId:`request-${++this.sequence}`,sequence:this.sequence,url:url.url,queryRedacted:url.queryRedacted,
      documentURL:document.url,documentQueryRedacted:document.queryRedacted,
      method:typeof event.request.method==='string'&&/^[A-Z]{1,16}$/u.test(event.request.method)?event.request.method:'OTHER',
      resourceType:typeof event.type==='string'&&/^[A-Za-z]{1,32}$/u.test(event.type)?event.type:'Other',
      initiator:this.stack(event.initiator),association:{kind:matched?'sanitized_document_url_match':'document_url_only',routeEventId:matched?.eventId??null,causalityProven:false},
      responseObserved:false,loadingFinished:false,failureObserved:false,serverEffectConfirmed:false,documentEpoch:this.documentEpoch,observedAt:new Date().toISOString()};
    this.requests.push(r);this.requestIds.set(event.requestId,r);
    if(this.requests.length>MAX_REQUESTS){const old=this.requests.shift();for(const [key,value]of this.requestIds)if(value===old)this.requestIds.delete(key);this.dropped.requests++;}
  }
  parsedScript(event){
    const frame=event.executionContextAuxData?.frameId;
    if(frame!==this.mainFrameId||event.executionContextAuxData?.isDefault!==true||event.scriptLanguage==='WebAssembly')return;
    const url=this.permitted(event.url),scriptId=identifier(event.scriptId);
    if(!url||!scriptId){this.dropped.scriptScope++;return;}
    let old=this.scripts.get(scriptId);
    const hash=typeof event.hash==='string'&&/^[0-9a-f]{64}$/iu.test(event.hash)?event.hash.toLowerCase():null;
    if(old&&old.cdpContentSHA256!==hash){this.scriptHandles.delete(old.scriptHandle);this.scripts.delete(scriptId);old=null;}
    if(!old&&this.scripts.size>=MAX_SCRIPTS){this.dropped.scripts++;return;}
    const sourceURLLabel=Boolean(event.hasSourceURL);
    if(sourceURLLabel&&old?.scriptHandle)this.scriptHandles.delete(old.scriptHandle);
    const record={scriptId,scriptHandle:sourceURLLabel?null:old?.scriptHandle??randomUUID(),url:url.url,queryRedacted:url.queryRedacted,
      cdpContentSHA256:hash,sourceUtf8SHA256:old?.sourceUtf8SHA256??null,
      length:number(event.length),startLine:number(event.startLine)??0,startColumn:number(event.startColumn)??0,
      endLine:number(event.endLine),endColumn:number(event.endColumn),sourceURLLabel,isModule:Boolean(event.isModule),
      documentEpoch:this.documentEpoch,observedAt:new Date().toISOString()};
    this.scripts.set(scriptId,record);if(record.scriptHandle)this.scriptHandles.set(record.scriptHandle,record);
  }
  async debuggerRead(fn){
    if(this.debugTainted)fail('debugger_cleanup_unknown');
    if(this.debugBusy)fail('script_collection_busy');if(this.closed)fail('route_collector_closed');
    this.debugBusy=true;let debug,enabled=false,detached=false;
    const epoch=this.documentEpoch;
    try{
      debug=await this.page.context().newCDPSession(this.page);
      debug.on('Debugger.scriptParsed',event=>this.parsedScript(event));
      await debug.send('Debugger.enable',{maxScriptsCacheSize:TOTAL_SOURCE_BYTES});enabled=true;
      if(this.documentEpoch!==epoch)fail('page_changed_during_script_read');
      const result=await fn(debug);
      if(this.documentEpoch!==epoch)fail('page_changed_during_script_read');
      return result;
    }finally{
      if(debug){
        if(enabled)await debug.send('Debugger.disable').catch(()=>{});
        await debug.detach().then(()=>{detached=true;},()=>{});
      }
      this.debugBusy=false;
      if(debug&&!detached){this.debugTainted=true;fail('debugger_cleanup_unknown');}
    }
  }
  exportedScript(record){
    return {scriptHandle:record.scriptHandle,url:record.url,queryRedacted:record.queryRedacted,cdpContentSHA256:record.cdpContentSHA256,sourceUtf8SHA256:record.sourceUtf8SHA256,
      length:record.length,sourceURLLabel:record.sourceURLLabel,isModule:record.isModule,
      sourceReadable:!record.sourceURLLabel&&Number.isSafeInteger(record.length)&&record.length<=SOURCE_BYTE_LIMIT,
      sourceAccessReason:record.sourceURLLabel?'untrusted_source_url_label':!Number.isSafeInteger(record.length)?'source_length_unavailable':record.length<=SOURCE_BYTE_LIMIT?'observed_default_realm_script':'source_budget',
      resourcePosition:{startLine:record.startLine,startColumn:record.startColumn,endLine:record.endLine,endColumn:record.endColumn},
      sourceAuthenticated:false,documentEpoch:record.documentEpoch};
  }
  async evidence(limit=64){
    if(!Number.isSafeInteger(limit)||limit<1||limit>128)fail('invalid_evidence_limit');
    if(!this.permitted(this.page.url()))fail('origin_not_allowed');
    const version=this.version;let scriptsStatus='available';
    try{await this.debuggerRead(async()=>{});}catch(e){if(e.message==='debugger_cleanup_unknown')throw e;scriptsStatus='unavailable';}
    const history=await this.session.send('Page.getNavigationHistory');
    if(version!==this.version)fail('page_changed_during_evidence');
    const current=history.entries[history.currentIndex];if(!current)fail('history_unavailable');
    const currentHash=digest(current.url),routes=this.routes.slice(-limit),requests=this.requests.slice(-limit);
    this.routeHandles.clear();
    const routesWithHandles=routes.map(route=>{
      const matches=history.entries.filter(entry=>{const u=this.permitted(entry.url);return u?.replayable&&u.url===route.url&&route.replayable;});
      if(matches.length!==1)return {...route,routeHandle:null,historyEntryAvailable:matches.length>0,navigationUnavailableReason:matches.length>1?'ambiguous_history_entry':'no_unique_replayable_history_entry'};
      const [available]=matches;
      const routeHandle=randomUUID();this.routeHandles.set(routeHandle,{historyId:available.id,url:route.url,version:this.version,created:Date.now(),currentHistoryId:current.id,currentHash});
      return {...route,routeHandle,historyEntryAvailable:true,navigationMode:'browser_history_entry'};
    });
    const exportedRequests=requests.map(r=>({...r,initiator:{...r.initiator,frames:r.initiator.frames.map(frame=>{
      const script=r.documentEpoch===this.documentEpoch?this.scripts.get(frame.scriptId):null;
      const {scriptId,capturedContentSHA256,capturedSourceUtf8SHA256,...safe}=frame;
      const sameHash=!capturedContentSHA256||capturedContentSHA256===script?.cdpContentSHA256;
      return {...safe,scriptHandle:sameHash?script?.scriptHandle??null:null,
        cdpContentSHA256:capturedContentSHA256??script?.cdpContentSHA256??null,
        sourceUtf8SHA256:capturedSourceUtf8SHA256??(sameHash?script?.sourceUtf8SHA256??null:null),
        hashAssociation:capturedContentSHA256?'captured_at_request':script?'current_script_id_lookup':'unavailable',sourceURLLabel:script?.sourceURLLabel??null};
    })}}));
    const exportedScripts=[...this.scripts.values()].slice(-limit).map(s=>this.exportedScript(s));
    const boundedRoutes=boundedRecent(routesWithHandles),boundedRequests=boundedRecent(exportedRequests),boundedScripts=boundedRecent(exportedScripts);
    const retained=new Set(boundedRoutes.map(r=>r.routeHandle));for(const handle of this.routeHandles.keys())if(!retained.has(handle))this.routeHandles.delete(handle);
    return {schemaVersion:1,observationOnly:true,sourceAuthenticated:false,executionAuthorized:false,
      routes:boundedRoutes,requests:boundedRequests,scripts:boundedScripts,scriptsStatus,
      omittedFromResponse:{routes:this.routes.length-boundedRoutes.length,requests:this.requests.length-boundedRequests.length,scripts:this.scripts.size-boundedScripts.length},
      dropped:{...this.dropped},sourceBytesRead:this.sourceBytes,sourceByteBudget:TOTAL_SOURCE_BYTES,
      linkage:'browser_document_url_and_initiator_location; not causal proof',queryHeaderBodyStored:false};
  }
  async analyze(scriptHandle){
    if(typeof scriptHandle!=='string'||scriptHandle.length>128)fail('invalid_script_handle');
    if(!this.permitted(this.page.url()))fail('origin_not_allowed');
    const record=this.scriptHandles.get(scriptHandle);
    if(!record||record.documentEpoch!==this.documentEpoch)fail('stale_script_handle');
    if(!Number.isSafeInteger(record.length)||record.length>SOURCE_BYTE_LIMIT)fail('script_source_budget');
    if(this.sourceBytes+record.length>TOTAL_SOURCE_BYTES)fail('script_session_budget');
    return await this.debuggerRead(async debug=>{
      const current=this.scriptHandles.get(scriptHandle);
      if(!current||current.cdpContentSHA256!==record.cdpContentSHA256)fail('stale_script_handle');
      const {scriptSource}=await debug.send('Debugger.getScriptSource',{scriptId:current.scriptId});
      if(this.scriptHandles.get(scriptHandle)!==current)fail('stale_script_handle');
      if(typeof scriptSource!=='string')fail('script_source_unavailable');
      const bytes=Buffer.byteLength(scriptSource);this.sourceBytes+=bytes;
      if(bytes>SOURCE_BYTE_LIMIT||this.sourceBytes>TOTAL_SOURCE_BYTES)fail('script_source_budget');
      const result=analyzeJavaScript(scriptSource,{baseURL:this.page.url(),allowedOrigins:[...this.allowed],sourceStartLine:current.startLine,sourceStartColumn:current.startColumn});
      current.sourceUtf8SHA256=result.sourceUtf8SHA256;
      return {...result,script:this.exportedScript(current),
        candidates:result.candidates.map(c=>({...c,observedRouteURLMatches:this.routes.filter(r=>r.url===c.url).slice(-8).map(r=>r.eventId),
          observedRequestURLMatches:this.requests.filter(r=>r.url===c.url).slice(-8).map(r=>r.eventId),
          correspondenceProvesImplementation:false})),implicitNetworkFetch:false};
    });
  }
  async navigate(routeHandle){
    if(this.debugTainted)fail('debugger_cleanup_unknown');
    if(typeof routeHandle!=='string'||routeHandle.length>128)refuseNavigation('invalid_route_handle');
    const handle=this.routeHandles.get(routeHandle);
    if(!handle||handle.version!==this.version||Date.now()-handle.created>HANDLE_TTL)refuseNavigation('stale_route_handle');
    if(!this.permitted(this.page.url()))refuseNavigation('origin_not_allowed');
    const history=await this.session.send('Page.getNavigationHistory');
    const current=history.entries[history.currentIndex],target=history.entries.find(e=>e.id===handle.historyId),parsed=target&&this.permitted(target.url);
    if(this.routeHandles.get(routeHandle)!==handle||Date.now()-handle.created>HANDLE_TTL||!current||current.id!==handle.currentHistoryId||digest(current.url)!==handle.currentHash||!parsed?.replayable||parsed.url!==handle.url||handle.version!==this.version)refuseNavigation('stale_route_handle');
    // A URL match cannot prove that a same-URL history traversal committed.
    // Current-entry requests do not traverse at all; refuse both before dispatch.
    if(target.id===current.id)refuseNavigation('history_entry_already_current');
    if(target.url===current.url)refuseNavigation('ambiguous_history_navigation');
    // Recheck after the awaited read, then consume this observation before dispatch.
    // Sibling handles cannot replay an attempt whose acknowledgment was lost.
    this.routeHandles.clear();
    // Arm the read before the single write: the CDP receipt precedes document
    // replacement. The configured Playwright navigation timeout bounds this wait.
    // Use an exact predicate: a literal '*' in a URL must not become a glob.
    const ready=this.page.waitForURL(url=>url.href===target.url,{waitUntil:'domcontentloaded'});
    await Promise.all([ready,this.session.send('Page.navigateToHistoryEntry',{entryId:handle.historyId})]);
    if(!this.permitted(this.page.url())||this.page.url()!==target.url)fail('history_navigation_unconfirmed');
    return {dispatched:true,navigationCompleted:true,waitUntil:'domcontentloaded',
      businessEffectConfirmed:false,mode:'browser_history_entry',url:handle.url};
  }
  close(){this.closed=true;for(const [name,fn]of this.listeners)this.session.off(name,fn);this.listeners=[];this.routeHandles.clear();this.scriptHandles.clear();this.scripts.clear();this.requestIds.clear();}
}
