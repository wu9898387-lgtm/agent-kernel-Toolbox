#!/usr/bin/env python3
"""Build a deterministic release using the shared runtime resource policy."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent


def archive(files, policy):
    if len(files) > policy.MAX_ENTRIES or sum(map(len, files.values())) > policy.MAX_EXPANDED_BYTES:
        raise ValueError('runtime_expanded_size_or_member_budget')
    result = io.BytesIO()
    with zipfile.ZipFile(result, 'w') as package:
        for name, raw in sorted(files.items()):
            # Fixed modes, timestamps and order make builds independent of the checkout.
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            package.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    if result.tell() > policy.MAX_ARCHIVE_BYTES:
        raise ValueError('runtime_archive_size_budget')
    return result.getvalue()


def load_verifier(root):
    spec = importlib.util.spec_from_file_location('toolbox_build_verifier', root / 'verify-runtime.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    return verifier


def read_files(directory, names, policy):
    files = {}
    total = 0
    for name in sorted(names):
        raw = policy.read_regular(directory, name)
        total += len(raw)
        if total > policy.MAX_EXPANDED_BYTES:
            raise ValueError('runtime_expanded_size_budget')
        files[name] = raw
    return files


def hashes(files):
    return {name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()}


def build(root=ROOT, source_dir=None, *, expected_version=None):
    root = Path(root).resolve()
    policy = load_verifier(root)
    if source_dir is None and (root / 'src').is_dir():
        source_dir = root / 'src'
    if source_dir is None:
        inner = policy.installed_sources(root)
    else:
        inner = read_files(Path(source_dir).resolve(), policy.PYTHON_FILES, policy)
        policy.validate_python_sources(inner)
    outer = read_files(root, policy.EXTERNAL_FILES, policy)
    outer['runtime-access.pyz'] = archive(inner, policy)
    manifest = policy.json_object(outer['runtime-manifest.json'])
    if expected_version is not None and manifest.get('version') != expected_version:
        raise ValueError('requested_release_version_mismatch')
    inventory = {
        'schema_version': 1, 'package_id': manifest['id'],
        'package_name': manifest['name'], 'package_version': manifest['version'],
        'files': hashes(outer), 'python_files': hashes(inner),
    }
    outer['CONTENTS.json'] = (json.dumps(inventory, sort_keys=True, indent=2) + '\n').encode()
    policy.verify_members(outer)
    return archive(outer, policy)


def publish(raw, output):
    # Publish a complete file exclusively, including when two builders race.
    fd, temp_path = tempfile.mkstemp(dir=output.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temp_path, output)
    finally:
        os.unlink(temp_path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--source-dir', type=Path, help='Explicit source tree. Defaults to src or the verified zipapp.')
    parser.add_argument('--expected-version', help='Require this exact release version before publishing.')
    args = parser.parse_args()
    try:
        raw = build(source_dir=args.source_dir, expected_version=args.expected_version)
        publish(raw, args.output)
    except (ValueError, KeyError, OSError) as error:
        reason = str(error) if isinstance(error, ValueError) else type(error).__name__
        print(json.dumps({'error': 'toolbox_build_failed', 'reason': reason}), file=sys.stderr)
        return 2
    print(json.dumps({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
