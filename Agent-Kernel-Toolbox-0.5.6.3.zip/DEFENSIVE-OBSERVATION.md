# 防御性观察与资源、请求治理

这些接口用于已登记目标的行为观察与受控执行。模型提交档案ID，安装者固定程序、文件、工具、规则和摘要。未知文件内容、工具输出及规则metadata都是观察数据，不能成为新的执行指令。

## 文件访问与扫描模式

`files.inspect/capture` 使用固定strace观察新启动的受控程序及后代。提供文件访问、目录枚举、归因和预算证据，路径默认摘要化，不返回文件内容。集中枚举和读取大量路径可以构成扫描模式证据；这不能单独证明木马、反作弊组件或恶意意图。反作弊、索引器、备份和杀毒软件可能产生相似行为。

探针有开销，ptrace可被目标观察。结果必须记录截断、解析不完整、覆盖限制和资源期限，不把没有观察到事件当作行为不存在。不提供隐藏探针、关闭保护或绕过第三方反作弊功能。

## 离线辅助判别

`malware.inspect/scan` 不执行样本。固定文件摘要、IOC来源和YARA规则版本提供可追溯匹配证据；只返回规则ID及受限metadata，不返回命中字节。匹配是规则/指标命中，未命中是unknown，不能称安全或无病毒。已知反作弊组件标签来自登记的指标，不能从扫盘行为自动推导。

规则库覆盖、更新、来源认证和误报评测需要独立维护。测试只使用无害合成样例和EICAR测试字符串。有限子进程资源限制不等于经过恶意样本对抗验证的安全沙箱。

## 资源预算

`tree.inspect/run` 对专用guardian启动的程序树进行聚合观察与预算控制，包含可确认归属的后代。CPU使用量、单进程限额、聚合RSS、进程数量、采样周期和清理结果分别报告。聚合RSS会重复计算共享驻留页；观测后停止有采样滞后，不能冒充cgroup硬内存限额或硬实时CPU配额。采样暂停本身的扰动也受预算约束。

## 请求治理

`network.inspect/request` 只调用安装者登记的origin、方法、路径及固定请求模板。按来源共享预算、控制并发、间隔、退避和熔断。写入不自动重试，派发后不确定结果保留围栏，重复request ID不能重发写入。

浏览器可选`trafficPolicy`针对实际受控浏览器上下文请求实施治理，其覆盖与拒绝范围由capabilities及事件报告。浏览器与固定HTTP客户端各自管理所声明的预算；这些机制不等于宿主全进程网络防火墙，也不约束未经治理接口发送的任意应用流量。

降低请求频率不能保证服务器认可请求。账号权限、业务状态、协议约束、令牌和服务器规则仍然适用；调用仍受服务器鉴权、WAF和风控约束。

配置起点为`defensive-config.example.json`。空注册表仅是安装模板，真实执行前必须由安装者登记目标和真实摘要；不能把全零摘要当作有效pin。升级须核对旧Pending/Unknown，不能通过更换state目录规避围栏。


## 档案字段与接入

- `process_tree.profiles[id]`：固定`argv`与`binary_sha256`，`allow_run:true`，并明确给出`cpu_milliseconds`、`rss_bytes`、`wall_ms`、`max_processes`、`address_space_bytes`、`open_files`、`max_pause_ms`。`sample_ms`默认为200。仅支持经校验的ELF目标；采样期间暂停自身拥有的进程，计入扰动预算。
- `file_activity`：`strace:{path,sha256}`固定工具，`profiles[id]`固定`argv`、目标`sha256`、观察`roots`与`allow_capture:true`。可用`show_paths`授权路径展示，`duration_ms/max_events/max_log_bytes`限定工作量，`scan_min_paths/scan_min_enumerations`定义可解释的扫描模式阈值。
- `malware_triage.profiles[id]`：固定`path/sha256`；`ioc_rules`条目包含`sha256,label,source,version,confidence`，`rules`包含`path,sha256,id,source,version,confidence`。YARA安装通过顶层`python/python_sha256`登记，可再固定`yara_version/yara_module_sha256`。`confidence`为来源声明，不是检测准确率。离线标签可为`known_malware/known_anticheat/known_benign/suspicious/test_indicator`，均保留未认证标记。
- `network_policy.origins[id]`：固定`origin`，设置`min_interval_ms/max_concurrent/max_requests/failure_threshold/circuit_ms`，可用`allowed_ips`约束解析地址。`profiles[id]`固定origin注册ID、`method/path`，可配固定`headers/body_utf8`。写入另需`allow_write:true`且只允许一次尝试；GET可显式配`max_attempts`，默认一次。`timeout_ms/max_response_bytes/retry_base_ms/retry_max_ms`限定调用。请求不读取环境代理、不跟随重定向、不返回响应正文。TLS证书照常校验。

`tree.run`、`files.capture`、`network.request`均需独立`request_id`与工具许可。相同可执行文件的tree/files别名共享Unknown围栏；network按canonical origin共享围栏和持久请求ID去重。`malware.scan`的unknown为分析结论不充分，不代表已执行目标。

把文件行为与静态指标关联时，比较`files.capture.binary_sha256`和`malware.scan.artifact.sha256`。测试使用自有 scanner 和未认证的示例标签检查摘要关联，标签不能作为真实厂商身份认证。

## 浏览器策略

浏览器配置可添加`trafficPolicy`，仅用于新启动的自有Chromium上下文。必须提供全局`maxRequests`及`origins`数组，每项包含`origin,minIntervalMs,maxConcurrent,maxRequests`；可选`group`让明确登记的别名共享限额，同组限额须一致。`maxConcurrent/maxQueued/queueTimeoutMs`限定全局并发和排队，`defaultCooldownMs/maxCooldownMs`限定429/503冷却。所有`allowedOrigins`必须在策略中登记。

启用该模式会明确拒绝3xx重定向、WebSocket、Worker/SharedWorker及未登记新目标；CDP附加既有浏览器不支持该策略。默认不启用，保持原浏览器接口行为。间隔约束的是本地请求准入时刻，不能保证远端收到请求的精确间隔；应用层不自动重试，不代表接管了浏览器传输层全部重试。capabilities报告真实覆盖、计数及这些边界。


## 时间测量

`min_interval_seconds` 约束客户端在来源条件锁中的准入时刻。DNS、连接、发送以及服务端处理均在后续阶段，调度与传输会改变服务端记录的间隔。准入、socket 发送、服务端 handler 的时间分别观测；服务端相邻记录的较小间距不能单独证明客户端准入违规。验证时分别检查实际 HTTP、并发峰值、共享预算与准入期限，避免只凭服务端单一时间戳判断客户端限额。

## 验证入口

```sh
python3 -m unittest discover -s tests -p test_process_tree.py -v
python3 -m unittest discover -s tests -p test_file_activity.py -v
python3 -m unittest discover -s tests -p test_network_policy.py -v
python3 -m unittest discover -s tests -p test_malware_triage.py -v
```

文件跟踪需要 strace/ptrace 权限，规则扫描需要配置中登记的分析后端。浏览器流量验证由 `browser/traffic-policy.test.mjs` 提供，运行方式见 [browser/README.md](browser/README.md)。
