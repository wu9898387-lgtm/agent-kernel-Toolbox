# 平台、对象格式与验证范围

Toolbox 根据所选后端提供运行时操作、离线格式解析或模拟执行。需要的工具、设备、系统权限由实际部署环境提供；`runtime.capabilities` 和对应调用的回执共同确定当前可用范围。

## 能力与运行条件

| 路径 | 当前实现 | 运行条件或检查入口 |
| --- | --- | --- |
| Linux 进程、内存、CPU 和限额 | procfs、pidfd、ptrace、rlimit；受约束数据写入与恢复 | Linux 内核权限；`tests/test_native_control.py`、`tests/test_lifecycle.py` |
| Linux 原生控件 | AT-SPI 角色、状态、标签、一次性动作与文本读回 | 应用导出 AT-SPI；[LIVE_CHECKS.md](LIVE_CHECKS.md) |
| Chromium | DOM/ARIA、表单、路由、网络、脚本与 CDP | Playwright 或显式选择的 CDP 目标；`browser/` 测试 |
| Firefox、WebKit | Playwright DOM/ARIA、表单、请求与便携路由证据 | 对应浏览器与系统库；无 Chromium CDP 发起栈 |
| x86、ARM32、AArch64、RISC-V | 目标 ABI、字节序、整数/指针解码及部分寄存器布局 | 原生 ptrace 与 QEMU 格式检查须分别验证 |
| LoongArch64、MIPS、PowerPC | 相应 ELF/内存格式识别，含大端路径 | `tools/check_cross_architecture.py`；无通用原生寄存器适配承诺 |
| PE32/PE32+、Mach-O32/64 | ABI 头解析；radare2 字符串/指令引用分析 | 离线格式检查不要求在该目标系统执行 |
| Android APK | 文本/二进制 Manifest 中的声明路由 | 固定文件和摘要；`tests/test_app_routes.py` |
| Apple plist、Windows Appx、Electron package、desktop entry | 声明 scheme/协议检索 | 固定文件和摘要；不安装或运行应用 |
| Windows、macOS、Android、iOS 控件 | 固定 Appium 原生驱动和已登记设备/应用 | 目标端服务、权限及实际设备；[CROSS_PLATFORM.md](CROSS_PLATFORM.md) |
| LLDB | 固定原生代理，线程/内存/寄存器与受约束修改 | 目标平台兼容的 LLDB/Python SDK 与调试权限 |
| JSHookMCP | 固定本地 AST 操作 | `tools/reverse_mcp/` 的锁定依赖与已登记 artifact |
| radare2 | ELF/PE/Mach-O 字符串、指令引用和一层调用者 | 固定后端；[native/REVERSE.md](native/REVERSE.md) |
| 纯整数 IR 对象编译 | Linux ELF、macOS Mach-O、Windows COFF 的登记目标 | 固定 GCC/Clang/Zig；[PORTABLE-BUILD.md](PORTABLE-BUILD.md) |
| OpenGL | 显式预加载的 draw/clear/blit 过滤 | Linux C++ 组件和匹配驱动；不覆盖 Vulkan/Direct3D/Metal |
| 物理内存、DMA、显存 | 无通用控制后端 | 进程虚拟内存接口不能替代设备驱动 |

Firefox/WebKit 引擎在某个宿主上启动不代表所有操作系统版本均可运行。Electron/CEF 显式提供回环 CDP 与目标 ID 时可以使用 Chromium 连接路径；关闭 Shadow DOM、自绘控件和物理 GPU 仍需具体目标适配。

## ABI 与不同内存

`process.abi` 从身份固定的目标可执行文件读取 ELF class、machine、字节序、ARM 浮点 ABI 标志和指针宽度；不再按宿主 CPU 猜目标布局。脚本 APP 的有效 ABI 是解释器的 ABI。QEMU/Wine/JVM 内部的另一层 ABI 不会自动从宿主进程推断。

`process.read_value` 只解释显式地址范围，支持有符号/无符号 8/16/32/64/128 位整数、32/64 位指针、float32/64、UTF-8/16/32。默认用目标字节序，也可明确指定 `little` 或 `big`。整数用十进制字符串、指针用十六进制，避免 JavaScript 丢失精度。不跟随指针，不扫描整个进程，不自动还原 Java/.NET 堆、压缩引用、PAC/TBI 标记或任意对象结构。

```json
{"session_id":"已授权会话","address":"0x12340000","size":8,"type":"uint64","byte_order":"target"}
```

`process.search_memory` 支持 `utf16`、`utf32`（目标字节序）及显式 `utf16le/utf16be/utf32le/utf32be`。所有读取仍共用每会话 4 MiB 预算，单次类型化读取最多 32768 字节、最多 256 个数值元素；文本需要完整合法编码，NaN/Infinity 不进入 JSON。

进程路径可读取权限允许的托管堆缓冲、文件映射和匿名映射；跨相邻可读映射保留检索重叠，有不可读洞时在读取前拒绝。DDR 型号和厂商由内核抽象，该接口不控制物理内存控制器或显存驱动。

CPU 寄存器布局覆盖 x86_64、x86、AArch64、ARM32、RISC-V32/64。布局分支的存在不代表每一架构都已在当前目标实机运行；未知布局、长度不符或未经验证的跨字节序寄存器捕获会拒绝。帧指针展开只启用已定义布局的窄路径，其余明确报告 `unsupported_frame_abi`；不声称完整 DWARF 展开。

## 浏览器和 APP 控件

人工配置 `browser.engine` 为 `chromium`、`firefox` 或 `webkit`，默认 Chromium。安装该引擎对应 Playwright 二进制：

```sh
cd browser
npm ci --ignore-scripts --omit=dev --no-audit --no-fund
npx playwright install firefox webkit
```

系统库须由实际运行环境提供。`browser.executablePath` 可选择明确的可执行文件；不接受页面/模型提供的新后端命令。WebKit 启动器与系统库必须匹配实际部署环境，依赖缺失须作为阻碍记录。

`browser.capabilities` 返回实际引擎、版本和能力差异。`browser.routes` 在 Chromium 发放浏览器历史条目句柄，在 Firefox/WebKit 发放当前有效的 `observed_url_reload` 句柄；后者可能重新加载 APP，不恢复任意 history.state。

`browser.invoke` 是**有副作用**工具，默认仍受 `allowed_tools` 白名单控制。它只点击当前快照中的真实 button/tab/menuitem/链接；快照单次使用，动作需要唯一 `request_id`，并沿用 Pending/Unknown 持久隔离。返回 ACK 后必须重新查询业务状态。`browser.activate` 用于导航链接，也支持带 `role=tab` 的 `<a href>`。

快照和查询都检查 Shadow DOM 宿主链上的私有标记，避免影子树绕过敏感子树过滤。关闭 Shadow DOM、自绘纹理、未挂载的虚拟列表仍不可保证读取。

## APP 声明路由检索

配置中增加 `apps`，只登记固定文件和 SHA-256；APK/Appx 最大 64 MiB，manifest 最大 1 MiB，最多返回 128 项。工具不会安装 APP、执行 Exec、发 Intent 或调用新发现的接口。

```json
{
  "apps": {
    "my-app": {"path":"/absolute/my-app.apk","kind":"android_apk","sha256":"审阅文件后取得的64位小写SHA256"}
  }
}
```

允许的 `kind` 为 `android_apk`、`apple_plist`、`windows_appx`、`electron_package`、`desktop_entry`；调用 `app.routes` 的参数是 `{"app":"my-app"}`，且须先把工具加入白名单。

Android 输出组件、intent-filter、action/category 和 data 中的 scheme/host/path 条件，保留来源成员名及过滤器下标。Android 会组合多个 `<data>` 条件，本版保留原声明并标记 `combinedDataSemanticsResolved:false`，不会擅自拼成一个确定可调用 URI。声明、实际运行路由、业务后置状态保持不同证据级别。

可通过 `RUNTIME_ANDROID_APK` 指定自己获准分析的真实 APK。这个可选样例不随工具包下载；声明检索不会展开全部私有 Activity 导航、导航资源表或运行时动态注册路由。

## 复测

```sh
python3 -m unittest discover -s tests -v
cd browser
RUNTIME_TEST_ENGINES=chromium,firefox,webkit npm test
cd ..
python3 tools/run_desktop_checks.py --xvfb /absolute/Xvfb
python3 tools/check_cross_architecture.py --zig /absolute/zig --qemu-directory /absolute/qemu/bin --output /absolute/cross-results.json
```

可选集成测试通过 `RUNTIME_ANDROID_APK`、`RUNTIME_RADARE2`、`RUNTIME_JSHOOK_ENTRY` 选择固定后端/样例；GTK 用专门的隔离运行器。缺少这些条件会显式跳过，不等于通过。宿主内核不支持原生 IA32 时，该项也显式跳过；QEMU 结果单独记录。

每个目标平台需要单独检查固定授权、身份校验、资源预算、未知效果隔离和业务后置状态；模拟协议、格式解析、QEMU 用户态执行与原生实机运行分别报告。


## 原生接入

读取、控制、写入、文本输入与调试是独立授权。原生 C/GTK 工作流的范围、预算和恢复看门狗见 [NATIVE.md](NATIVE.md)。跨设备 Appium 与 LLDB 的部署、iOS/Android 深链和顺序身份检查限制见 [CROSS_PLATFORM.md](CROSS_PLATFORM.md)。
