"""Instruction/object monitoring adapters share the existing authority boundary."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import select
import signal
import struct
import shutil
import subprocess
import sys
import tempfile
import time
import types
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))

from observation_extension.runtime_host import RuntimeHost, SPECS
from observation_extension.policy import MAX_ENDPOINTS

TOOLS = ['probe.inspect', 'probe.open', 'probe.poll', 'probe.close',
         'metadata.inspect', 'metadata.extract', 'coordinated.inspect', 'coordinated.capture',
         'coordinated.patch', 'coordinated.release', 'environment.inspect', 'environment.capture',
         'managed_probe.inspect', 'managed_probe.run', 'managed_probe.poll', 'managed_probe.release', 'managed_probe.close', 'program.inspect', 'program.open',
         'program.poll', 'program.close', 'portable.inspect', 'portable.run']
KINDS = ['native_probe', 'compiler_metadata', 'coordinated_state', 'environment_probe',
         'managed_probe', 'program_monitor', 'portable_emulation']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class BackendError(RuntimeError):
    def __init__(self, code, dispatched=False):
        super().__init__(code)
        self.effect_dispatched = dispatched


class Revision2HostTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.config = {'schema_version': 1, 'state_directory': str(self.root / 'state'),
                       'allowed_tools': TOOLS + ['runtime.status', 'runtime.audit']}

    def host(self, config=None):
        host = RuntimeHost(self.config if config is None else config, bundle_root=ROOT)
        self.addCleanup(host.close)
        return host

    def test_registry_config_and_independent_disabled_defaults(self):
        self.assertLessEqual(len(SPECS), MAX_ENDPOINTS)
        self.config.update({kind: {} for kind in KINDS})
        self.config['allowed_tools'] = ['runtime.status']
        host = self.host()
        for tool in TOOLS:
            self.assertFalse(host.call(tool, {})['ok'])
        self.assertEqual(host.extended_backends, {})
        self.assertTrue(set(KINDS) <= set(host.call('runtime.status', {})['data']['extended_backends_configured']))
        for kind in KINDS:
            with self.subTest(kind=kind), self.assertRaisesRegex(RuntimeError, 'invalid_host_backend_config'):
                self.host({**self.config, kind: []})

    def test_model_events_addresses_scripts_and_patch_bytes_are_not_authority(self):
        host = self.host()
        requests = [
            ('probe.open', {'profile': 'fixed', 'script': 'not-authority'}),
            ('probe.poll', {'probe_session': 'owned', 'events': [{'seq': 1}]}),
            ('program.poll', {'monitor_session': 'owned', 'events': [{'address': '0x1234'}]}),
            ('program.open', {'profile': 'fixed', 'metadata': {'fields': []}}),
            ('coordinated.patch', {'profile': 'fixed', 'snapshot_handle': 'observed', 'patch_id': 'template',
                                   'replacement_hex': 'ff'}),
            ('environment.capture', {'profile': 'fixed', 'argv': ['/not/registered']}),
            ('managed_probe.run', {'profile': 'fixed', 'jvm_arguments': ['-agentpath:untrusted']}),
            ('managed_probe.run', {'profile': 'fixed', 'allocation_sampling_interval_bytes': 0}),
            ('managed_probe.poll', {'capture_handle': 'owned', 'path': '/not/server-issued', 'events': []}),
            ('managed_probe.close', {'target_pid': 1234}),
            ('portable.run', {'profile': 'fixed', 'initial_hex': 'ff', 'address': '0x1000'}),
        ]
        for index, (name, arguments) in enumerate(requests):
            if SPECS[name][3]: arguments['request_id'] = 'untrusted-' + str(index)
            with self.subTest(name=name):
                result = host.call(name, arguments)
                self.assertEqual(result['error'], 'invalid_tool_arguments')
        self.assertEqual(host.state.audit()['effects'], [])
        self.assertEqual(host.extended_backends, {})

    def test_unconfigured_mutations_are_known_preflight_and_readonly_unknown_is_not_effect(self):
        host = self.host()
        calls = [('probe.open', {'profile': 'fixed'}), ('environment.capture', {'profile': 'fixed'}),
                 ('managed_probe.run', {'profile': 'fixed'}), ('managed_probe.close', {}), ('program.open', {'profile': 'fixed'}),
                 ('coordinated.capture', {'profile': 'fixed'})]
        for index, (name, arguments) in enumerate(calls):
            result = host.call(name, {**arguments, 'request_id': 'not-configured-' + str(index)})
            self.assertFalse(result['ok'])
            self.assertFalse(result['effect_unknown'], result)
        class Metadata:
            def extract(self, profile): return {'status': 'unknown', 'target_executed': False}
            def close(self): return {'cleanup_errors': []}
        host.extended_backends['compiler_metadata'] = Metadata()
        result = host.call('metadata.extract', {'profile': 'fixed'})
        self.assertTrue(result['ok'])
        self.assertFalse(result['unknown_effect'])
        self.assertTrue(all(row['status'] == 'done' for row in host.state.audit()['effects']))

    def test_portable_unknown_is_readonly_analysis_and_uses_only_fixed_profile(self):
        host = self.host()
        class Portable:
            def run(self, profile): return {'status': 'unknown', 'target_executed': False, 'live_memory_access': False}
            def close(self): return {'cleanup_errors': []}
        host.extended_backends['portable_emulation'] = Portable()
        result = host.call('portable.run', {'profile': 'owned-buffer-simulation'})
        self.assertTrue(result['ok'])
        self.assertFalse(result['unknown_effect'])
        self.assertEqual(host.state.audit()['effects'], [])
        self.assertEqual([row['phase'] for row in reversed(host.state.audit()['calls'])], ['started', 'returned'])

    def test_native_program_and_environment_aliases_share_unknown_fence_with_cleanup_available(self):
        fixed = 'b' * 64
        self.config.update({
            'native_probe': {'profiles': {'direct': {'sha256': fixed}, 'alias': {'sha256': fixed}}},
            'program_monitor': {'profiles': {'joined': {'probe_profile': 'alias'}}},
            'environment_probe': {'profiles': {'environment': {'sha256': fixed}}},
        })
        host = self.host()
        class Probe:
            opens = 0
            closes = []
            def open(self, profile):
                self.opens += 1
                return {'status': 'unknown', 'probe_session': 'observed-probe'}
            def poll(self, session, cursor=0, max_events=128):
                return {'state': 'observed', 'next_cursor': cursor, 'events': []}
            def close(self, session=None):
                self.closes.append(session)
                return {'status': 'closed', 'cleanup_errors': []}
        class Other:
            calls = 0
            def open(self, profile): self.calls += 1; return {'status': 'completed'}
            capture = open
            def close(self): return {'cleanup_errors': []}
        probe, other = Probe(), Other()
        host.extended_backends.update({'native_probe': probe, 'program_monitor': other, 'environment_probe': other})
        first = host.call('probe.open', {'profile': 'direct', 'request_id': 'uncertain-probe'})
        self.assertTrue(first['unknown_effect'])
        for index, (name, profile) in enumerate([('probe.open', 'alias'), ('program.open', 'joined'),
                                                ('environment.capture', 'environment')]):
            denied = host.call(name, {'profile': profile, 'request_id': 'same-image-' + str(index)})
            self.assertEqual(denied['error'], 'scope_outcome_unresolved')
        self.assertEqual((probe.opens, other.calls), (1, 0))
        self.assertTrue(host.call('probe.poll', {'probe_session': 'observed-probe'})['ok'])
        closed = host.call('probe.close', {'probe_session': 'observed-probe', 'request_id': 'cleanup-probe'})
        self.assertTrue(closed['ok'], closed)
        self.assertEqual(probe.closes, ['observed-probe'])

    def test_coordinated_scope_is_actual_writer_set_and_release_does_not_clear_fence(self):
        self.config['coordinated_state'] = {}
        host = self.host()
        class Coordinator:
            patches = 0
            def instance_scope(self, profile): return 'coordinated:actual-pid-birth-build-set'
            def capture(self, profile, *, request_id=None): return {'snapshot_handle': 'snapshot-one', 'status': 'captured'}
            def patch(self, profile, snapshot_handle, patch_id, *, request_id=None):
                self.patches += 1
                return {'status': 'unknown', 'rollback_verified': False}
            def release(self, snapshot_handle): return {'released': True}
            def close(self): return {'cleanup_errors': []}
        coordinator = Coordinator()
        host.extended_backends['coordinated_state'] = coordinator
        captured = host.call('coordinated.capture', {'profile': 'one', 'request_id': 'capture-state'})
        self.assertTrue(captured['ok'])
        patched = host.call('coordinated.patch', {'profile': 'one', 'snapshot_handle': 'snapshot-one',
                                               'patch_id': 'fixed', 'request_id': 'patch-state'})
        self.assertTrue(patched['unknown_effect'])
        released = host.call('coordinated.release', {'snapshot_handle': 'snapshot-one', 'request_id': 'release-local'})
        self.assertTrue(released['ok'])
        alias = host.call('coordinated.capture', {'profile': 'same-writers-alias', 'request_id': 'capture-alias'})
        self.assertEqual(alias['error'], 'scope_outcome_unresolved')
        self.assertEqual(coordinator.patches, 1)

    def test_managed_classpath_alias_cannot_retry_unknown_run(self):
        self.config['managed_probe'] = {'profiles': {'one': {'class_path_sha256': 'c' * 64},
                                                    'alias': {'class_path_sha256': 'c' * 64}}}
        host = self.host()
        class Managed:
            def run(self, profile): raise BackendError('managed_probe_outcome_unknown', True)
            def close(self): return {'cleanup_errors': []}
        host.extended_backends['managed_probe'] = Managed()
        first = host.call('managed_probe.run', {'profile': 'one', 'request_id': 'managed-one'})
        self.assertTrue(first['effect_unknown'])
        alias = host.call('managed_probe.run', {'profile': 'alias', 'request_id': 'managed-alias'})
        self.assertEqual(alias['error'], 'scope_outcome_unresolved')

    def test_program_factory_uses_real_shared_dependencies_and_closes_dependents_first(self):
        self.config.update({kind: {} for kind in ('native_probe', 'compiler_metadata', 'program_monitor')})
        closed = []
        class Probe:
            def __init__(self, config, directory, bundle_root=None): pass
            def close(self): closed.append('probe'); return {'cleanup_errors': []}
        class Metadata:
            def __init__(self, config, directory, bundle_root=None): pass
            def close(self): closed.append('metadata'); return {'cleanup_errors': []}
        class Program:
            def __init__(self, config, directory, *, native_probe, compiler_metadata=None, bundle_root=None):
                self.probe, self.metadata = native_probe, compiler_metadata
            def inspect(self): return {'observation_only': True}
            def close(self, session=None): closed.append('program'); return {'cleanup_errors': []}
        modules = {'native_probe': types.SimpleNamespace(NativeProbe=Probe),
                   'compiler_metadata': types.SimpleNamespace(CompilerMetadata=Metadata),
                   'program_monitor': types.SimpleNamespace(ProgramMonitor=Program)}
        host = RuntimeHost(self.config, bundle_root=ROOT)
        try:
            with patch('observation_extension.runtime_host.importlib.import_module',
                       side_effect=lambda name, _package: modules[name.lstrip('.')]):
                result = host.call('program.inspect', {})
            self.assertTrue(result['ok'], result)
            program = host.extended_backends['program_monitor']
            self.assertIs(program.probe, host.extended_backends['native_probe'])
            self.assertIs(program.metadata, host.extended_backends['compiler_metadata'])
        finally:
            cleanup = host.close()
        self.assertEqual(cleanup['cleanup_errors'], [])
        self.assertEqual(closed, ['program', 'metadata', 'probe'])

    def test_close_does_not_hide_a_retained_managed_guardian(self):
        host = RuntimeHost(self.config, bundle_root=ROOT)
        class Retained:
            def close(self): return {'cleanup_complete': False, 'guardian_retained': True}
        host.extended_backends['managed_probe'] = Retained()
        result = host.close()
        self.assertIn('managed_probe_cleanup_unresolved', result['cleanup_errors'])

    def test_cleanup_retries_keep_request_dedup_unknown_history_and_target_fences(self):
        """Exercise the actual gate/SQLite control plane with fault receipts."""
        cases = [
            ('probe.open', {'profile': 'owned'}, 'probe.close', {'probe_session': 'owned-handle'}),
            ('program.open', {'profile': 'owned'}, 'program.close', {'monitor_session': 'owned-handle'}),
            ('managed.advance', {'managed_session': 'owned-handle'}, 'managed.close', {'managed_session': 'owned-handle'}),
            ('machine.pause', {'machine_session': 'owned-handle'}, 'machine.close', {'machine_session': 'owned-handle'}),
            ('managed_probe.run', {'profile': 'owned'}, 'managed_probe.release', {'capture_handle': 'owned-handle'}),
            ('managed_probe.run', {'profile': 'owned'}, 'managed_probe.close', {}),
        ]
        for index, (target, target_args, cleanup, cleanup_args) in enumerate(cases):
            config = {**self.config, 'state_directory': str(self.root / ('retry-state-' + str(index))),
                      'allowed_tools': list(SPECS),
                      'native_probe': {'profiles': {'owned': {'sha256': 'd' * 64}}},
                      'program_monitor': {'profiles': {'owned': {'probe_profile': 'owned'}}},
                      'managed_probe': {'profiles': {'owned': {'class_path_sha256': 'e' * 64}}}}
            host = RuntimeHost(config, bundle_root=ROOT)
            calls = []
            def dispatch(name, arguments):
                calls.append(name)
                if name != cleanup:
                    return {'status': 'unknown'}
                return ({'status': 'unknown', 'closed': False, 'cleanup_errors': ['injected_cleanup_failure']}
                        if calls.count(cleanup) == 1 else {'status': 'closed', 'closed': True, 'released': True})
            try:
                with self.subTest(cleanup=cleanup), patch.object(host, '_dispatch', side_effect=dispatch):
                    self.assertTrue(host.call(target, {**target_args, 'request_id': 'uncertain-target'})['unknown_effect'])
                    first = host.call(cleanup, {**cleanup_args, 'request_id': 'cleanup-first'})
                    self.assertTrue(first['unknown_effect'])
                    second = host.call(cleanup, {**cleanup_args, 'request_id': 'cleanup-retry'})
                    self.assertTrue(second['ok'], second)
                    self.assertFalse(second['unknown_effect'])
                    replay = host.call(cleanup, {**cleanup_args, 'request_id': 'cleanup-first'})
                    self.assertEqual(replay['error'], 'request_replay')
                    target_again = host.call(target, {**target_args, 'request_id': 'new-target-attempt'})
                    self.assertEqual(target_again['error'], 'scope_outcome_unresolved')
                    self.assertEqual(calls.count(cleanup), 2)
                effects = {row['request_id']: row for row in host.state.audit()['effects']}
                self.assertEqual({key: row['status'] for key, row in effects.items()},
                                 {'uncertain-target': 'unknown', 'cleanup-first': 'unknown', 'cleanup-retry': 'done'})
                self.assertNotEqual(effects['cleanup-first']['scope'], effects['cleanup-retry']['scope'])
                self.assertNotEqual(effects['cleanup-retry']['scope'], effects['uncertain-target']['scope'])
            finally:
                host.close()

    def compile_c(self, output, *sources, flags=()):
        compiler = shutil.which('gcc')
        if not compiler: self.skipTest('GCC required for the owned native fixture')
        subprocess.run([compiler, '-g', '-O0', *flags, *map(str, sources), '-o', str(output)],
                       check=True, capture_output=True, timeout=20)

    def metadata_config(self, binary, names, variables=()):
        executable = os.environ.get('RUNTIME_PYELFTOOLS_PYTHON')
        if not executable and importlib.util.find_spec('elftools'):
            executable = sys.executable
        if not executable or not Path(executable).is_file():
            self.skipTest('set RUNTIME_PYELFTOOLS_PYTHON for actual compiler metadata')
        # Preserve a venv's invocation path while pinning the interpreter bytes.
        executable = str(Path(executable).absolute())
        engine = json.loads(subprocess.check_output([executable, '-I', '-c',
            'import elftools,hashlib,json;from pathlib import Path;'
            'print(json.dumps({"version":elftools.__version__,"sha256":hashlib.sha256(Path(elftools.__file__).read_bytes()).hexdigest()}))'],
            timeout=10))
        return {'python': executable, 'python_sha256': digest(executable),
                'pyelftools_version': engine['version'], 'pyelftools_module_sha256': engine['sha256'],
                'profiles': {'owned': {'path': str(binary), 'sha256': digest(binary),
                    'types': list(names), 'variables': list(variables), 'timeout_seconds': 10}}}

    def native_program_config(self):
        if sys.platform != 'linux' or platform.machine().lower() not in ('x86_64', 'amd64'):
            self.skipTest('actual native instruction fixture requires Linux x86_64')
        executable = os.environ.get('RUNTIME_FRIDA_PYTHON')
        if not executable and os.environ.get('RUNTIME_FRIDA'):
            candidate = Path(os.environ['RUNTIME_FRIDA']).parent / 'python'
            if candidate.is_file(): executable = str(candidate)
        if not executable or not Path(executable).is_file():
            self.skipTest('set RUNTIME_FRIDA_PYTHON or RUNTIME_FRIDA for actual instruction probing')
        binary = self.root / 'owned-native-probe'
        self.compile_c(binary, ROOT / 'tests/fixtures/recovery/native_probe_target.c',
                       ROOT / 'tests/fixtures/recovery/native_probe_access.S',
                       flags=('-fno-inline', '-fno-builtin', '-rdynamic'))
        sizes = {}
        for line in subprocess.check_output(['nm', '-S', '--defined-only', str(binary)], text=True).splitlines():
            row = line.split()
            if len(row) >= 4 and row[-1] in ('probe_work', 'probe_access'):
                sizes[row[-1]] = int(row[1], 16)
        self.assertEqual(set(sizes), {'probe_work', 'probe_access'})
        oracle = self.root / 'actual-instruction-oracle.json'
        configs = {
            'native_probe': {'python': str(Path(executable).absolute()), 'python_sha256': digest(executable),
                'profiles': {'owned': {'executable': str(binary), 'sha256': digest(binary),
                    'functions': sizes, 'entry_function': 'probe_work', 'argv': [str(oracle), '4', 'hold'],
                    'registration_hooks': {'define': 'ra_probe_object', 'retire': 'ra_probe_retire', 'move': 'ra_probe_move'},
                    'environment_functions': ['clock_gettime'],
                    'lifetime_ms': 8000, 'max_events': 8192, 'max_bytes': 2 * 1024 * 1024,
                    'max_instructions': 20000, 'max_callback_us': 500000}}},
            'compiler_metadata': self.metadata_config(binary, ['ProbeObject'], ['probe_global']),
            'program_monitor': {'profiles': {'owned': {'probe_profile': 'owned', 'metadata_profile': 'owned',
                                                       'type_slots': {'3': 'ProbeObject'}, 'max_records': 1024}}},
        }
        return configs, binary, oracle

    def assert_actual_program_chain(self, call, binary, oracle):
        extracted = call('metadata.extract', {'profile': 'owned'})
        self.assertEqual(extracted['artifact']['sha256'], digest(binary))
        members = [member for item in extracted['types'] if item.get('name') == 'ProbeObject'
                   for member in item.get('members', [])]
        self.assertTrue(any(row['name'] == 'mirrored' and row['byte_offset'] == 8 for row in members))
        opened = call('program.open', {'profile': 'owned', 'request_id': 'actual-monitor-open'})
        self.assertEqual(opened['binary_sha256'], digest(binary))
        session, cursor, records = opened['monitor_session'], 0, []
        deadline = time.monotonic() + 10
        try:
            while time.monotonic() < deadline:
                result = call('program.poll', {'monitor_session': session, 'cursor': cursor, 'max_events': 32})
                records.extend(result['events'])
                cursor = result['next_cursor']
                accesses = [row for row in records if row.get('kind') == 'memory_access'
                            and row.get('allocation') and row.get('object')
                            and any(field['name'] == 'mirrored' for field in row.get('fields', []))]
                if accesses and oracle.exists() and any(row.get('kind') == 'allocation_end' for row in records): break
                time.sleep(.02)
            self.assertTrue(accesses, json.dumps(records)[-12000:])
            self.assertTrue(any(row.get('kind') == 'allocation_end' for row in records),
                            'observed frees must close allocation incarnations')
            actual = json.loads(oracle.read_text())
            self.assertEqual(actual['returned'], 34)
            access = next(row for row in accesses if int(row['address'], 16) == int(actual['first'], 16) + 8
                          and row.get('address_evidence', {}).get('index_register') == 'rsi')
            self.assertFalse(access['committed'], 'pre-instruction observation is not a committed write proof')
            self.assertEqual(access['object']['type_name'], 'ProbeObject')
            self.assertTrue(access['allocation']['allocation_id'])
            self.assertGreaterEqual(access['allocation']['generation'], 1)
            self.assertTrue(any(field['field_offset'] == 8 and field['access_within_field']
                                for field in access['fields']))
            evidence = access['address_evidence']
            self.assertTrue(access['effective_address_arithmetic_verified'])
            self.assertEqual((evidence['base_register'], evidence['index_register'], evidence['scale']), ('rdi', 'rsi', 8))
            self.assertEqual(int(evidence['base_value'], 16), int(actual['first'], 16))
            self.assertEqual(int(evidence['index_value'], 16), 1)
            computed = (int(evidence['base_value'], 16) + int(evidence['index_value'], 16) * evidence['scale']
                        + evidence['disp']) & ((1 << evidence['address_bits']) - 1)
            self.assertEqual(computed, int(access['address'], 16))
            # Read the same server collector's immutable cursor history. No raw
            # event is ever submitted to ProgramMonitor by a caller.
            source, raw_cursor = [], 0
            while time.monotonic() < deadline:
                batch = call('probe.poll', {'probe_session': opened['probe_session'],
                                            'cursor': raw_cursor, 'max_events': 128})
                source.extend(batch['events'])
                next_cursor = batch['next_cursor']
                if next_cursor <= raw_cursor: break
                raw_cursor = next_cursor
            memory = next(row for row in source if row.get('kind') == 'memory'
                          and row.get('instruction_id') == access['instruction_id']
                          and row.get('address') == access['address'])
            self.assertEqual(memory['source'], 'native_probe')
            self.assertEqual(memory['session_id'], opened['probe_session'])
            self.assertEqual(int(memory['address_evidence']['base_value'], 16), int(evidence['base_value'], 16))
            self.assertEqual(int(memory['address_evidence']['index_value'], 16), int(evidence['index_value'], 16))
            self.assertTrue(any(row.get('kind') == 'instruction' and row.get('instruction_id') == memory['instruction_id']
                                for row in source))
            self.assertTrue(any(row.get('kind') == 'allocation' for row in source))
            self.assertTrue(any(row.get('kind') == 'object' for row in source))
            self.assertTrue(any(row.get('kind') == 'environment' and row.get('operation') == 'clock_gettime'
                                and row.get('session_id') == opened['probe_session'] for row in source),
                            'environment evidence must come from the same actual native instance')
            return access, memory, source
        finally:
            closed = call('program.close', {'monitor_session': session, 'request_id': 'actual-monitor-close'})
            self.assertTrue(closed['closed'], closed)
            ended = call('program.poll', {'monitor_session': session, 'cursor': cursor, 'max_events': 32})
            self.assertTrue(ended['closed'])
            self.assertFalse(any(row['state'] == 'live' and row['certain'] for row in ended['object_summary']),
                             'closed source identities must not remain certain/live')

    def test_actual_native_register_EA_allocation_and_compiler_field_through_host(self):
        configs, binary, oracle = self.native_program_config()
        self.config.update(configs)
        host = self.host()
        def call(name, args):
            result = host.call(name, args)
            self.assertTrue(result['ok'], result)
            return result['data']
        self.assert_actual_program_chain(call, binary, oracle)
        self.assertEqual({row['tool'] for row in host.state.audit()['effects']}, {'program.open', 'program.close'})

    def test_actual_owned_native_cleanup_retries_without_reopening_unknown_target(self):
        configs, _binary, _oracle = self.native_program_config()
        for prefix, kind, session_key in [('probe', 'native_probe', 'probe_session'),
                                           ('program', 'program_monitor', 'monitor_session')]:
            host = self.host({**self.config, **configs,
                              'state_directory': str(self.root / ('actual-retry-' + prefix))})
            backend = host._extended_backend(kind)
            original_open, original_close = backend.open, backend.close
            attempts = []
            def uncertain_open(profile): return {**original_open(profile), 'status': 'unknown'}
            def uncertain_first_close(session):
                attempts.append(session)
                if len(attempts) == 1:
                    return {'closed': False, 'status': 'unknown', 'cleanup_errors': ['injected_lost_cleanup_receipt']}
                return original_close(session)
            with self.subTest(prefix=prefix), patch.object(backend, 'open', side_effect=uncertain_open), \
                    patch.object(backend, 'close', side_effect=uncertain_first_close):
                opened = host.call(prefix + '.open', {'profile': 'owned', 'request_id': 'actual-uncertain-open'})
                self.assertTrue(opened['unknown_effect'], opened)
                handle = opened['data'][session_key]
                probe_handle = opened['data']['probe_session']
                native = host.call('probe.inspect', {})['data']
                target_pid = next(row['target_pid'] for row in native['sessions'] if row['probe_session'] == probe_handle)
                descriptor = os.pidfd_open(target_pid)
                try:
                    first = host.call(prefix + '.close', {session_key: handle, 'request_id': 'actual-close-first'})
                    self.assertTrue(first['unknown_effect'], first)
                    self.assertFalse(select.select([descriptor], [], [], 0)[0], 'first fault must leave a real owned target to clean')
                    second = host.call(prefix + '.close', {session_key: handle, 'request_id': 'actual-close-second'})
                    self.assertTrue(second['ok'], second)
                    self.assertTrue(second['data']['closed'], second)
                    self.assertTrue(select.select([descriptor], [], [], 2)[0], 'retried cleanup must actually terminate the owned target')
                finally:
                    os.close(descriptor)
                blocked = host.call(prefix + '.open', {'profile': 'owned', 'request_id': 'actual-target-retry'})
                self.assertEqual(blocked['error'], 'scope_outcome_unresolved')
                replay = host.call(prefix + '.close', {session_key: handle, 'request_id': 'actual-close-first'})
                self.assertEqual(replay['error'], 'request_replay')
                self.assertEqual(attempts, [handle, handle])
            effects = {row['request_id']: row['status'] for row in host.state.audit()['effects']}
            self.assertEqual(effects, {'actual-uncertain-open': 'unknown', 'actual-close-first': 'unknown',
                                       'actual-close-second': 'done'})

    def test_actual_compiler_locations_require_live_module_evidence(self):
        source = self.root / 'compiler-layout.c'
        marker = self.root / 'must-not-execute'
        source.write_text('#include <stdint.h>\n#include <stdio.h>\n'
            'typedef struct CompilerField {uint64_t first;uint32_t second;} CompilerField;\n'
            'CompilerField global_data={7,11};\n'
            'int main(void){FILE *f=fopen(' + json.dumps(str(marker)) + ',"w");if(f)fclose(f);return 0;}\n')
        binary = self.root / 'compiler-layout'
        self.compile_c(binary, source)
        self.config['compiler_metadata'] = self.metadata_config(binary, ['CompilerField'], ['global_data'])
        host = self.host()
        response = host.call('metadata.extract', {'profile': 'owned'})
        self.assertTrue(response['ok'], response)
        self.assertFalse(response['unknown_effect'])
        self.assertFalse(marker.exists(), 'DWARF extraction must not execute the target')
        record = next(item for item in response['data']['types']
                      if item.get('name') == 'CompilerField' and item.get('members'))
        self.assertEqual({member['name']: member['byte_offset'] for member in record['members']},
                         {'first': 0, 'second': 8})
        location = next(item['location'] for item in response['data']['variables'] if item['name'] == 'global_data')
        self.assertTrue(location['load_bias_required'])
        self.assertIsNone(location['live_address'])
        self.assertEqual(host.state.audit()['effects'], [])

    def test_packaged_mcp_actual_instruction_allocation_object_field_chain(self):
        configs, binary, oracle = self.native_program_config()
        self.config.update(configs)
        self.config['managed_probe'] = {'profiles': {}}
        specification = importlib.util.spec_from_file_location('revision2_source_builder', ROOT / 'build-source.py')
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        package = self.root / 'package'
        zipfile.ZipFile(io.BytesIO(builder.build())).extractall(package)
        config_path = self.root / 'mcp-config.json'
        config_path.write_text(json.dumps(self.config))
        with tempfile.TemporaryFile() as errors:
            process = subprocess.Popen([sys.executable, str(package / 'runtime-access.pyz'), 'serve',
                                        '--config', str(config_path)],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors)
            sequence = 0
            def request(method, params):
                nonlocal sequence
                sequence += 1
                payload = {'jsonrpc': '2.0', 'id': sequence, 'method': method, 'params': params}
                process.stdin.write((json.dumps(payload) + '\n').encode())
                process.stdin.flush()
                self.assertTrue(select.select([process.stdout], [], [], 15)[0], 'packaged MCP response deadline')
                raw = process.stdout.readline(1024 * 1024 + 1)
                self.assertLessEqual(len(raw), 1024 * 1024)
                self.assertTrue(raw.endswith(b'\n'), raw[:256])
                return json.loads(raw)
            try:
                initialized = request('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                                                     'clientInfo': {'name': 'revision2-live-check'}})
                self.assertEqual(initialized['result']['serverInfo']['version'], '0.5.6.2')
                process.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
                process.stdin.flush()
                def call(name, args):
                    response = request('tools/call', {'name': name, 'arguments': args})
                    data = response['result']['structuredContent']
                    self.assertTrue(data['ok'], data)
                    return data['data']
                self.assert_actual_program_chain(call, binary, oracle)
                managed_closed = call('managed_probe.close', {'request_id': 'packaged-managed-close'})
                self.assertTrue(managed_closed['cleanup_complete'])
                self.assertEqual(managed_closed['status'], 'closed')
                audit = call('runtime.audit', {})
                self.assertEqual({row['tool'] for row in audit['effects']}, {'program.open', 'program.close', 'managed_probe.close'})
                self.assertTrue(all(row['status'] == 'done' for row in audit['effects']))
            finally:
                process.stdin.close()
                try: process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=3)
                process.stdout.close()
            errors.seek(0)
            self.assertEqual(process.returncode, 0, errors.read(4096).decode('utf8', 'replace'))

    def test_actual_environment_categories_are_observations_not_an_intent_verdict(self):
        strace = os.environ.get('RUNTIME_STRACE') or shutil.which('strace')
        if not strace: self.skipTest('strace required for actual environment interaction tracing')
        binary = self.root / 'owned-environment'
        self.compile_c(binary, ROOT / 'tests/fixtures/environment_probe.c', flags=('-pthread',))
        input_file = self.root / 'private-observed-input'
        input_file.write_bytes(b'PRIVATE_INPUT_MUST_NOT_APPEAR')
        categories = ['file', 'memory', 'process', 'time', 'random', 'system', 'scheduler', 'network', 'debug', 'device']
        self.config['environment_probe'] = {'strace': {'path': str(Path(strace).resolve()), 'sha256': digest(strace)},
            'profiles': {'owned': {'argv': [str(binary), 'normal', str(input_file)], 'sha256': digest(binary),
                                   'categories': categories, 'allow_capture': True}}}
        host = self.host()
        self.assertTrue(host.call('environment.inspect', {})['ok'])
        captured = host.call('environment.capture', {'profile': 'owned', 'request_id': 'actual-environment'})
        self.assertTrue(captured['ok'], captured)
        data = captured['data']
        self.assertEqual(data['binary_sha256'], digest(binary))
        self.assertTrue(all(data['summary']['category_counts'][category] > 0 for category in categories))
        self.assertNotIn('PRIVATE_INPUT_MUST_NOT_APPEAR', json.dumps(data))
        self.assertNotIn('NETWORK_PAYLOAD_MUST_NOT_APPEAR_12b7', json.dumps(data))
        self.assertNotIn('malicious', json.dumps(data))
        self.assertTrue(data['capture_cleanup_confirmed'])

    def test_actual_two_writer_shared_state_capture_template_patch_and_release(self):
        from observation_extension.native_runtime import ProcessSession
        binary = self.root / 'owned-shared-writers'
        self.compile_c(binary, ROOT / 'tests/fixtures/recovery/shared_writer.c', flags=('-pthread',))
        shared = self.root / 'owned-shared-region'
        child = subprocess.Popen([str(binary), str(shared), 'idle'], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        def stop():
            if child.poll() is None:
                child.send_signal(signal.SIGCONT)
                child.terminate()
                try: child.wait(timeout=3)
                except subprocess.TimeoutExpired: child.kill(); child.wait(timeout=3)
            child.stdout.close()
        self.addCleanup(stop)
        self.assertTrue(select.select([child.stdout], [], [], 3)[0])
        observed = json.loads(child.stdout.readline())
        address = int(observed['address'], 16)
        writers, bindings, sessions = {}, {}, []
        for index, pid in enumerate(observed['writers']):
            session = ProcessSession(pid, allow_memory=True)
            sessions.append(session)
            self.addCleanup(session.close)
            writers[str(index)] = {'pid': pid, 'start_ticks': session.identity['start_ticks'],
                                   'exe_sha256': digest(binary), 'allow_pause': True}
            bindings[str(index)] = {'address': hex(address),
                'mapping_fingerprint': session.memory_mapping(address, 16)['mapping_fingerprint']}
        def pair(value): return (((~value & 0xffffffff) << 32) | value).to_bytes(8, 'little')
        profile = {'writers': writers, 'writer_set_complete': True, 'allow_patch': True, 'max_pause_ms': 1500,
            'regions': {'pair': {'size': 16, 'bindings': bindings,
                'fields': {'first': {'offset': 0, 'size': 8, 'byte_order': 'little'},
                           'second': {'offset': 8, 'size': 8, 'byte_order': 'little'}}}},
            'patches': {'update': [{'region': 'pair', 'offset': 0, 'expected_hex': pair(7).hex(), 'replacement_hex': pair(17).hex()},
                                   {'region': 'pair', 'offset': 8, 'expected_hex': pair(11).hex(), 'replacement_hex': pair(21).hex()}]}}
        self.config['coordinated_state'] = {'profiles': {'owned': profile}}
        host = self.host()
        capture = host.call('coordinated.capture', {'profile': 'owned', 'request_id': 'actual-shared-capture'})
        self.assertTrue(capture['ok'], capture)
        self.assertFalse(capture['data']['unknown_writers_or_DMA_quiesced'])
        handle = capture['data']['snapshot_handle']
        patched = host.call('coordinated.patch', {'profile': 'owned', 'snapshot_handle': handle,
                                                'patch_id': 'update', 'request_id': 'actual-shared-patch'})
        self.assertTrue(patched['ok'], patched)
        self.assertEqual(patched['data']['status'], 'verified')
        self.assertEqual(shared.read_bytes()[:16], pair(17) + pair(21))
        self.assertTrue(patched['data']['cleanup']['complete'])
        self.assertTrue(all(not thread['state'].startswith('T') for session in sessions for thread in session.threads()))
        stale = host.call('coordinated.patch', {'profile': 'owned', 'snapshot_handle': handle,
                                               'patch_id': 'update', 'request_id': 'stale-shared-patch'})
        self.assertFalse(stale['ok'])
        self.assertFalse(stale['effect_unknown'])
        second = host.call('coordinated.capture', {'profile': 'owned', 'request_id': 'second-shared-capture'})
        released = host.call('coordinated.release', {'snapshot_handle': second['data']['snapshot_handle'],
                                                    'request_id': 'release-shared-local'})
        self.assertTrue(released['ok'])
        self.assertTrue(released['data']['released'])

    def managed_profile(self, extra_sources=None):
        java = Path(os.environ.get('RUNTIME_JAVA', '/usr/lib/jvm/java-21-openjdk-amd64/bin/java')).resolve()
        headers = [Path(os.environ.get('RUNTIME_JAVA_HOME', str(java.parent.parent))),
                   ROOT.parent / 'toolchains/jdk-25.0.5+8']
        home = next((path for path in headers if (path / 'include/jvmti.h').is_file()), None)
        if not java.is_file() or home is None or not shutil.which('gcc'):
            self.skipTest('JVM runtime, JVMTI headers and GCC required for actual managed probing')
        from observation_extension.managed_jvm import classpath_sha256
        specification = importlib.util.spec_from_file_location('revision2_managed_builder', ROOT / 'native/managed-probe/build.py')
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        agent = builder.build(home, self.root / 'managed-agent')
        classes = self.root / 'managed-classes'
        classes.mkdir()
        sources = [ROOT / 'native/managed-probe/RuntimeProbe.java', ROOT / 'tests/fixtures/recovery/ManagedProbeFixture.java']
        for name, content in (extra_sources or {}).items():
            source = self.root / name
            source.write_text(content)
            sources.append(source)
        subprocess.run([str(java), 'com.sun.tools.javac.Main', '-g', '-d', str(classes), *map(str, sources)],
                       check=True, capture_output=True, timeout=20)
        return {'java': str(java), 'java_sha256': digest(java),
            'agent': agent['agent'], 'agent_sha256': agent['agent_sha256'], 'class_path': str(classes),
            'class_path_sha256': classpath_sha256(classes), 'main_class': 'runtimeaccess.probe.ManagedProbeFixture',
            'allow_run': True, 'event_budget': 1024, 'wall_ms': 5000, 'class_prefix': 'Lruntimeaccess/probe/'}

    def managed_pages(self, host, data):
        events, cursor = [], 0
        for _ in range(65):
            page = host.call('managed_probe.poll', {'capture_handle': data['capture_handle'], 'cursor': cursor,
                                                   'max_events': 32})
            self.assertTrue(page['ok'], page)
            self.assertLessEqual(len(page['data']['events']), 32)
            self.assertEqual(page['data']['capture_sha256'], data['native_event_artifact']['sha256'])
            self.assertEqual(page['data']['summary'], data['summary'])
            events.extend(page['data']['events'])
            cursor = page['data']['next_cursor']
            if page['data']['done']: break
        else: self.fail('bounded managed capture pages did not reach done')
        self.assertEqual(len(events), data['summary']['retained'])
        self.assertEqual([row['seq'] for row in events], list(range(1, len(events) + 1)))
        return events

    def test_actual_managed_cleanup_retries_retained_guardian_without_clearing_run_fence(self):
        profile = self.managed_profile({'HostCleanupProbe.java': '''package runtimeaccess.probe;
public final class HostCleanupProbe {
 public static void main(String[] args) throws Exception {
  System.out.println("PROBE_READY");
  Object value=new HostCleanupProbe();RuntimeProbe.tag(value);
  RuntimeProbe.event(value,1,7);Thread.sleep(30000);
 }
}'''})
        profile = {**profile, 'main_class': 'runtimeaccess.probe.HostCleanupProbe'}
        self.config['managed_probe'] = {'profiles': {'owned': profile, 'alias': dict(profile)}}
        host = self.host()
        backend = host._extended_backend('managed_probe')
        descriptors = []
        try:
            # A controlled failed stop keeps the real JVM, guardian and all
            # cleanup authority alive after the synchronous run times out.
            with patch.object(backend, '_stop', return_value=False) as failed_stop:
                run = host.call('managed_probe.run', {'profile': 'owned', 'request_id': 'managed-retained-run'})
                self.assertFalse(run['ok'], run)
                self.assertTrue(run['effect_unknown'], run)
                retained = backend.active
                self.assertIsNotNone(retained)
                target, guardian = retained['target_pid'], retained['child'].pid
                descriptors = [os.pidfd_open(target), os.pidfd_open(guardian)]
                first = host.call('managed_probe.close', {'request_id': 'managed-cleanup-first'})
                self.assertTrue(first['ok'], first)
                self.assertTrue(first['unknown_effect'], first)
                self.assertFalse(first['data']['cleanup_complete'])
                self.assertTrue(first['data']['guardian_retained'])
                self.assertIs(backend.active, retained)
                self.assertEqual(failed_stop.call_count, 2)
                self.assertFalse(select.select(descriptors, [], [], 0)[0],
                                 'fault must retain a live owned JVM and guardian for retry')
            second = host.call('managed_probe.close', {'request_id': 'managed-cleanup-retry'})
            self.assertTrue(second['ok'], second)
            self.assertFalse(second['unknown_effect'])
            self.assertTrue(second['data']['cleanup_complete'])
            self.assertEqual(second['data']['status'], 'closed')
            self.assertIsNone(backend.active)
            self.assertEqual(len(select.select(descriptors, [], [], 2)[0]), 2)
            self.assertFalse(Path(f'/proc/{target}').exists())
            self.assertFalse(Path(f'/proc/{guardian}').exists())
            replay = host.call('managed_probe.close', {'request_id': 'managed-cleanup-first'})
            self.assertEqual(replay['error'], 'request_replay')
            blocked = host.call('managed_probe.run', {'profile': 'alias', 'request_id': 'managed-after-cleanup'})
            self.assertEqual(blocked['error'], 'scope_outcome_unresolved')
            effects = {row['request_id']: row for row in host.state.audit()['effects']}
            self.assertEqual({key: row['status'] for key, row in effects.items()},
                             {'managed-retained-run': 'unknown', 'managed-cleanup-first': 'unknown',
                              'managed-cleanup-retry': 'done'})
            self.assertNotEqual(effects['managed-cleanup-first']['scope'], effects['managed-cleanup-retry']['scope'])
            self.assertNotEqual(effects['managed-retained-run']['scope'], effects['managed-cleanup-retry']['scope'])
        finally:
            for descriptor in descriptors: os.close(descriptor)

    def test_actual_managed_JVMTI_run_exposes_runtime_identity_without_addresses(self):
        self.config['managed_probe'] = {'profiles': {'owned': self.managed_profile()}}
        host = self.host()
        self.assertTrue(host.call('managed_probe.inspect', {})['ok'])
        response = host.call('managed_probe.run', {'profile': 'owned', 'request_id': 'actual-jvmti-run'})
        self.assertTrue(response['ok'], response)
        data = response['data']
        self.assertEqual(data['status'], 'completed')
        self.assertIn('capture_handle', data)
        events = self.managed_pages(host, data)
        kinds = {event['kind'] for event in events}
        self.assertTrue({'semantic', 'class_metadata', 'object_free', 'gc_start', 'gc_finish'} <= kinds)
        semantic = {event['event_code']: event for event in events if event['kind'] == 'semantic'}
        self.assertEqual(semantic[1]['tag'], semantic[2]['tag'])
        self.assertNotEqual(semantic[1]['tag'], semantic[3]['tag'])
        self.assertFalse(data['physical_addresses_exposed'])
        self.assertFalse(data['object_contents_captured'])
        self.assertTrue(data['cleanup']['target_exited'])
        released = host.call('managed_probe.release', {'capture_handle': data['capture_handle'],
                                                      'request_id': 'actual-jvmti-release'})
        self.assertTrue(released['ok'], released)
        self.assertTrue(released['data']['released'])

    def test_actual_managed_sampling_capture_integrity_pagination_and_release_fence(self):
        extras = {'HostSampledProbe.java': '''package runtimeaccess.probe;
import java.lang.ref.Reference;
public final class HostSampledProbe {
 static volatile Throwable failure;
 static final class Plain {int value=41;}
 public static void main(String[] args)throws Exception {
  Plain historic=new Plain();
  if(!RuntimeProbe.startAllocationSampling(0))return;
  Thread worker=new Thread(()->{try {
   Plain root=new Plain();Plain[] array=new Plain[17];
   long tag=RuntimeProbe.identity(root),arrayTag=RuntimeProbe.identity(array);
   if(tag==0||arrayTag==0||tag==arrayTag)throw new AssertionError();
   RuntimeProbe.event(root,101,41);RuntimeProbe.event(array,104,17);
   System.gc();
   if(RuntimeProbe.identity(root)!=tag)throw new AssertionError();
   RuntimeProbe.event(root,102,42);Reference.reachabilityFence(root);Reference.reachabilityFence(array);
  }catch(Throwable problem){failure=problem;}});
  worker.start();worker.join();if(failure!=null)throw new AssertionError(failure);
  Reference.reachabilityFence(historic);
 }
}''', 'HostManyProbe.java': '''package runtimeaccess.probe;
public final class HostManyProbe {
 public static void main(String[] args) {
  Object value=new HostManyProbe();RuntimeProbe.tag(value);
  for(int index=0;index<1500;index++)RuntimeProbe.event(value,7,index);
 }
}'''}
        base = self.managed_profile(extras)
        many_profile = {**base, 'main_class': 'runtimeaccess.probe.HostManyProbe', 'event_budget': 2048}
        self.config['managed_probe'] = {'profiles': {
            'sampled': {**base, 'main_class': 'runtimeaccess.probe.HostSampledProbe', 'allocation_sampling_interval_bytes': 0},
            'many': many_profile, 'alias': dict(many_profile)}}
        host = self.host()
        sampled = host.call('managed_probe.run', {'profile': 'sampled', 'request_id': 'actual-sampled-run'})
        self.assertTrue(sampled['ok'], sampled)
        data = sampled['data']
        self.assertEqual(data['status'], 'completed')
        sampling = data['allocation_sampling']
        self.assertTrue(sampling['capability_supported'])
        self.assertTrue(sampling['started'])
        self.assertEqual(sampling['requested_interval_bytes'], 0)
        self.assertGreater(sampling['started_monotonic_ns'], 0)
        events = self.managed_pages(host, data)
        allocs = [row for row in events if row['kind'] == 'sampled_object_alloc']
        self.assertTrue(any(row['class_signature'] == 'Lruntimeaccess/probe/HostSampledProbe$Plain;' for row in allocs))
        self.assertTrue(any(row['class_signature'] == '[Lruntimeaccess/probe/HostSampledProbe$Plain;' for row in allocs))
        semantic = {row['event_code']: row for row in events if row['kind'] == 'semantic'}
        self.assertEqual(semantic[101]['tag'], semantic[102]['tag'])
        self.assertFalse(data['all_JVM_allocations_proven'])
        self.assertFalse(data['allocation_history_before_sampling_observed'])
        self.assertTrue(host.call('managed_probe.release', {'capture_handle': data['capture_handle'],
                                                           'request_id': 'release-sampled'})['ok'])
        backend = host._extended_backend('managed_probe')
        original_run = backend.run
        with patch.object(backend, 'run', side_effect=lambda profile: {**original_run(profile), 'status': 'unknown'}):
            response = host.call('managed_probe.run', {'profile': 'many', 'request_id': 'actual-many-lost-receipt'})
        self.assertTrue(response['unknown_effect'])
        many = response['data']
        restored = self.managed_pages(host, many)
        self.assertGreater(len(restored), 1500)
        self.assertGreater(many['transport_events_omitted'], 0)
        self.assertEqual(many['events_lost'], 0)
        self.assertTrue(many['native_capture_complete'])
        self.assertFalse(many['transport_complete'])
        handle = many['capture_handle']
        # Fault-inject corruption in the actual server-owned artifact; no MCP
        # request accepts a filesystem path or raw event bytes.
        artifact = backend.captures[handle]['path']
        artifact.chmod(0o600)
        artifact.write_bytes(b'corrupt-owned-capture')
        corrupt = host.call('managed_probe.poll', {'capture_handle': handle})
        self.assertEqual(corrupt['error'], 'managed_probe_capture_integrity_failed')
        self.assertFalse(corrupt['effect_unknown'])
        released = host.call('managed_probe.release', {'capture_handle': handle, 'request_id': 'release-corrupt'})
        self.assertTrue(released['ok'], released)
        self.assertTrue(released['data']['released'])
        blocked = host.call('managed_probe.run', {'profile': 'alias', 'request_id': 'after-release-target'})
        self.assertEqual(blocked['error'], 'scope_outcome_unresolved')
        gone = host.call('managed_probe.poll', {'capture_handle': handle})
        self.assertEqual(gone['error'], 'managed_probe_capture_unavailable')
        effects = {row['request_id']: row['status'] for row in host.state.audit()['effects']}
        self.assertEqual(effects['actual-many-lost-receipt'], 'unknown')

    def test_actual_portable_private_RAM_integer_and_float_profiles_are_offline(self):
        launcher = os.environ.get('RUNTIME_GHIDRA')
        if not launcher or not Path(launcher).is_file():
            self.skipTest('set RUNTIME_GHIDRA for actual private-RAM p-code emulation')
        compiler = shutil.which('gcc')
        if not compiler: self.skipTest('GCC required for the owned emulation fixture')
        binary = self.root / 'portable-memory.o'
        # Match the bounded owned fixture: -O0's stack spills exhaust the fixed
        # 64-memory-event profile before this loop returns (correctly unknown).
        subprocess.run([compiler, '-O1', '-c', str(ROOT / 'tests/fixtures/recovery/portable_memory.c'),
                        '-o', str(binary)], check=True, capture_output=True, timeout=20)
        image_hash = digest(binary)
        script = ROOT / 'tools/RuntimeAccessEmulateMemory.java'
        common = {'executable': str(Path(launcher).absolute()), 'sha256': digest(launcher),
            'binary': str(binary), 'binary_sha256': image_hash, 'script_sha256': digest(script),
            'abi': 'sysv_amd64_buffer_i32', 'arguments': [{'region': 'buffer', 'offset': 0}, {'i32': 3}],
            'max_steps': 512, 'max_memory_events': 64, 'timeout_seconds': 120}
        self.config['portable_emulation'] = {'profiles': {
            'integers': {**common, 'function': 'portable_array',
                'regions': [{'id': 'buffer', 'address': 0x60000000, 'initial_hex': struct.pack('<3i', 1, -2, 3).hex(),
                             'writable': True}]},
            'floats': {**common, 'function': 'portable_float',
                'regions': [{'id': 'buffer', 'address': 0x60000000, 'initial_hex': struct.pack('<3f', 1.5, -2.0, .25).hex(),
                             'writable': True}]},
        }}
        host = self.host()
        self.assertTrue(host.call('portable.inspect', {})['ok'])
        for profile, expected_return, expected_bytes in [('integers', 26, struct.pack('<3i', 8, 6, 12)),
                                                          ('floats', 3, struct.pack('<3f', 4.0, -3.0, 1.5))]:
            with self.subTest(profile=profile):
                result = host.call('portable.run', {'profile': profile})
                self.assertTrue(result['ok'], result)
                self.assertFalse(result['unknown_effect'])
                self.assertEqual(result['data']['status'], 'completed', result['data'].get('reason'))
                self.assertEqual(result['data']['returned_u32'], expected_return)
                self.assertEqual(result['data']['regions'][0]['final_hex'], expected_bytes.hex())
                self.assertFalse(result['data']['native_target_executed'])
                self.assertFalse(result['data']['host_process_memory_access'])
                self.assertFalse(result['data']['floating_point_AOT_implemented'])
        self.assertEqual(digest(binary), image_hash)
        self.assertEqual(host.state.audit()['effects'], [])


if __name__ == '__main__':
    unittest.main()
