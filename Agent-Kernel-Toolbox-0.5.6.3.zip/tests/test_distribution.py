"""Release compression, integrity and bundled workflow regression coverage."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class DistributionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.builder = load('distribution_builder', 'build-runtime.py')
        cls.verifier = load('distribution_verifier', 'verify-runtime.py')

    def test_compressed_release_is_complete_bounded_and_reproducible(self):
        raw = self.builder.build()
        self.assertEqual(raw, self.builder.build())
        verified = self.verifier.verify(raw)
        self.assertEqual(verified['package_version'], '0.5.6.2')
        self.assertTrue(verified['runtime_sources_verified'])
        self.assertLessEqual(len(raw), self.builder.MAX_ARCHIVE_BYTES)
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            names = archive.namelist()
            self.assertIn('skills/agent-kernel-toolbox/SKILL.md', names)
            self.assertIn('browser/extension.test.mjs', names)
            self.assertIn('browser/route-evidence.test.mjs', names)
            self.assertNotIn('VALIDATION-0.5.5.json', names)
            self.assertNotIn('validation/evidence-0.5.6.zip', names)
            self.assertTrue(all(i.compress_type == zipfile.ZIP_DEFLATED for i in archive.infolist()))
            self.assertFalse(any('/node_modules/' in n or '/__pycache__/' in n for n in names))

    def test_size_budget_fails_instead_of_dropping_files(self):
        with patch.object(self.builder, 'MAX_ARCHIVE_BYTES', 1):
            with self.assertRaisesRegex(ValueError, 'runtime_archive_size_budget'):
                self.builder.build()

    def test_deflated_oversized_member_is_rejected_before_unbounded_expansion(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            info = zipfile.ZipInfo('oversized.txt')
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, b'0' * (2 * 1024 * 1024 + 1), compress_type=zipfile.ZIP_DEFLATED)
        self.assertLess(len(stream.getvalue()), 4096)
        with self.assertRaisesRegex(ValueError, 'invalid_archive_entry'):
            self.verifier.verify(stream.getvalue())

    def test_consistent_outer_manifest_cannot_hide_embedded_source_mismatch(self):
        with zipfile.ZipFile(io.BytesIO(self.builder.build())) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        with zipfile.ZipFile(io.BytesIO(files['runtime-access.pyz'])) as archive:
            source = {name: archive.read(name) for name in archive.namelist()}
        source['observation_extension/version.py'] += b'\n# source-only divergence\n'
        files['runtime-access.pyz'] = self.builder.archive(source)
        manifest = json.loads(files['CONTENTS.json'])
        manifest['files']['runtime-access.pyz'] = hashlib.sha256(files['runtime-access.pyz']).hexdigest()
        files['CONTENTS.json'] = json.dumps(manifest).encode()
        with self.assertRaisesRegex(ValueError, 'member_digest_mismatch'):
            self.verifier.verify(self.builder.archive(files))


if __name__ == '__main__':
    unittest.main()
