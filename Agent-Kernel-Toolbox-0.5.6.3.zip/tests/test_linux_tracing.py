"""Real perf software capture plus strict ABI, limits and unavailable backends.

Protocol fixtures are explicitly synthetic and do not prove kernel hardware,
ftrace or eBPF execution. Real tests use only newly launched owned processes.
"""
import ctypes
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import select
import signal
import shutil
import struct
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from contextlib import contextmanager

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.linux_tracing import (LinuxTracing, TracingError,
    decode_perf_records, perf_aux_metadata, _perf_open, _bounded_tool)
from observation_extension.native_runtime import ProcessSession


def sample(ip=0x401000, pid=31, tid=31, at=1234, period=1000):
    return struct.pack('=IHHQIIQQ', 9, 0, 40, ip, pid, tid, at, period)


def ring_with(payload, size=256, tail=0):
    data = bytearray(size)
    for index, byte in enumerate(payload):
        data[(tail+index) % size] = byte
    return bytes(data)


class PerfDecoderTests(unittest.TestCase):
    def test_samples_loss_and_unknown_records_preserve_information(self):
        lost = struct.pack('=IHHQQ', 2, 0, 24, 7, 9)
        other = struct.pack('=IHHQ', 5, 0, 16, 0)
        raw = sample()+lost+other+sample(ip=0x401004, at=2234)
        result = decode_perf_records(ring_with(raw), len(raw), 0)
        self.assertEqual([row['ip'] for row in result['events']], ['0x401000', '0x401004'])
        self.assertEqual(result['lost_samples'], 9)
        self.assertEqual(result['skipped_records'], 1)
        self.assertEqual(result['throttle_records'], 1)
        self.assertFalse(result['samples_truncated'])

    def test_generated_wraparound_samples_use_monotonic_cursors(self):
        randomizer = random.Random(20261113)
        for _ in range(250):
            tail = randomizer.randrange(0, 100000)
            ip = randomizer.randrange(2**64)
            pid = randomizer.randrange(1, 2**31)
            raw = sample(ip=ip, pid=pid)
            result = decode_perf_records(ring_with(raw, 128, tail), tail+len(raw), tail)
            self.assertEqual(result['events'][0]['ip'], hex(ip))
            self.assertEqual(result['events'][0]['pid'], pid)
            self.assertEqual(result['tail'], tail+40)

    def test_overwrite_and_sample_output_limits_are_explicit(self):
        result = decode_perf_records(bytes(128), 160, 0)
        self.assertTrue(result['ring_overrun'])
        self.assertEqual(result['events'], [])
        self.assertEqual(result['overwritten_bytes_at_least'], 32)
        raw = sample()+sample()+sample()
        result = decode_perf_records(ring_with(raw), 120, 0, max_samples=1)
        self.assertEqual(len(result['events']), 1)
        self.assertTrue(result['samples_truncated'])
        self.assertEqual(result['tail'], 120)

    def test_malformed_record_never_becomes_an_instruction_sample(self):
        for raw in (b'1234', struct.pack('=IHH', 9, 0, 0), struct.pack('=IHH', 9, 0, 80),
                    struct.pack('=IHHQ', 9, 0, 16, 0), struct.pack('=IHHQ', 2, 0, 16, 0)):
            with self.subTest(raw=raw), self.assertRaises(TracingError):
                decode_perf_records(ring_with(raw), len(raw), 0)
        for head, tail in [(True, 0), (1, 2), (-1, 0)]:
            with self.assertRaises(TracingError):
                decode_perf_records(bytes(128), head, tail)

    def test_perf_aux_framing_does_not_call_header_only_file_a_trace(self):
        # Synthetic binary framing tests, not evidence of physical tracing.
        header = bytearray(104)
        header[:8] = b'PERFILE2'
        struct.pack_into('<Q', header, 8, 104)
        struct.pack_into('<QQ', header, 40, 104, 0)
        self.assertFalse(perf_aux_metadata(bytes(header))['hardware_aux_payload_present'])
        aux = struct.pack('<IHHQQQIIII', 71, 0, 48, 4, 0, 0, 0, 31, 0, 0)+b'four'
        struct.pack_into('<QQ', header, 40, 104, len(aux))
        parsed = perf_aux_metadata(bytes(header)+aux)
        self.assertEqual(parsed['auxtrace_bytes'], 4)
        self.assertFalse(parsed['instructions_decoded'])
        with self.assertRaisesRegex(TracingError, 'bounds'):
            perf_aux_metadata(bytes(header)+aux[:-1])


@unittest.skipUnless(platform.system() == 'Linux' and hasattr(os, 'pidfd_open'), 'Linux pidfd required')
class LinuxTracingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.profiles = {
            'counter': {'backend': 'perf_counter', 'event': 'task_clock', 'allow_capture': True},
            'sample': {'backend': 'perf_sample', 'event': 'cpu_clock', 'allow_capture': True,
                       'max_samples': 32, 'perturbation_budget_ns': 32000, 'sample_cost_ns': 1000},
            'ftrace': {'backend': 'ftrace', 'event': 'sched_switch', 'allow_capture': True}}
        self.tracing = LinuxTracing({'profiles': self.profiles}, self.root/'state')

    def owned(self, allow_debug=True):
        process = ProcessSession.launch(['/bin/sh', '-c', 'while :; do :; done'], allow_debug=allow_debug)
        def close():
            if process.child.poll() is None:
                process.terminate_owned()
            process.close()
        self.addCleanup(close)
        return process

    def require_software_perf(self):
        try:
            descriptor = _perf_open(os.getpid(), 'task_clock')
            os.close(descriptor)
        except TracingError as error:
            self.skipTest('real perf_event_open unavailable: '+json.dumps(error.as_dict()))

    def test_real_owned_software_cpu_counter(self):
        self.require_software_perf()
        process = self.owned()
        before = len(os.listdir('/proc/self/fd'))
        result = self.tracing.capture(process, 'counter', duration_ms=80)
        self.assertGreater(result['value'], 0)
        self.assertGreater(result['time_enabled_ns'], 0)
        self.assertFalse(result['instruction_level_hardware_trace'])
        self.assertEqual(result['samples'], [])
        self.assertTrue(result['capture_cleaned_up'])
        self.assertEqual(before, len(os.listdir('/proc/self/fd')))
        self.assertIsNone(process.child.poll())

    def test_real_perf_mmap_instruction_pointer_samples_with_budget(self):
        self.require_software_perf()
        process = self.owned()
        before = len(os.listdir('/proc/self/fd'))
        try:
            result = self.tracing.capture(process, 'sample', duration_ms=100)
        except (OSError, TracingError) as error:
            if isinstance(error, TracingError) and str(error) == 'tracing_atomic_runtime_unavailable':
                self.skipTest(str(error))
            raise
        self.assertGreater(len(result['samples']), 0)
        self.assertLessEqual(len(result['samples']), 32)
        self.assertLessEqual(result['estimated_probe_cost_ns'], 32000)
        self.assertEqual({row['pid'] for row in result['samples']}, {process.pid})
        self.assertEqual({row['tid'] for row in result['samples']}, {process.pid})
        self.assertTrue(all(int(row['ip'], 16) > 0 for row in result['samples']))
        self.assertFalse(result['kernel_execution_included'])
        self.assertFalse(result['instruction_level_hardware_trace'])
        self.assertGreater(result['observer_cpu_ns'], 0)
        self.assertEqual(before, len(os.listdir('/proc/self/fd')))

    def test_owned_debug_grant_and_capture_grant_are_separate(self):
        with self.assertRaisesRegex(TracingError, 'owned_debug_target_required'):
            self.tracing.capture(self.owned(False), 'sample')
        with ProcessSession.attach(os.getpid(), allow_debug=True) as attached:
            with self.assertRaisesRegex(TracingError, 'owned_debug_target_required'):
                self.tracing.capture(attached, 'sample')
        profile = {'profiles': {'denied': {'backend': 'perf_counter', 'event': 'task_clock'}}}
        denied = LinuxTracing(profile, self.root/'denied')
        with self.assertRaisesRegex(TracingError, 'not_authorized'):
            denied.capture(self.owned(), 'denied')

    def test_no_declared_probe_budget_does_not_open_kernel_event(self):
        self.profiles['sample'].update(sample_cost_ns=100, perturbation_budget_ns=99)
        tracing = LinuxTracing({'profiles': self.profiles}, self.root/'budget')
        with patch('observation_extension.linux_tracing._perf_open') as opening:
            with self.assertRaisesRegex(TracingError, 'probe_budget_exhausted'):
                tracing.capture(self.owned(), 'sample')
        opening.assert_not_called()

    def test_unsupported_host_word_size_refuses_before_event_open_or_enable(self):
        process = self.owned()
        with patch('observation_extension.linux_tracing.ctypes.sizeof', return_value=4), \
             patch('observation_extension.linux_tracing._perf_open') as opening, \
             patch('observation_extension.linux_tracing.fcntl.ioctl') as ioctls:
            with self.assertRaisesRegex(TracingError, 'sample_requires_64bit_host'):
                self.tracing.capture(process, 'sample')
        opening.assert_not_called()
        ioctls.assert_not_called()
        # An ABI boundary test, not ARM/RISC-V hardware validation.

    def test_actual_kernel_capabilities_distinguish_load_from_capture(self):
        result = self.tracing.inspect()
        self.assertIn('cpu_clock', result['software_and_pmu_probes'])
        self.assertFalse(result['hardware_execution_trace_observed'])
        self.assertFalse(result['ebpf_load_probe']['capture_permission_proven'])
        self.assertFalse(result['target_permissions_granted'])
        for row in result['software_and_pmu_probes'].values():
            if not row['available']:
                self.assertIn('operation', row)
                self.assertIsInstance(row.get('errno'), (int, type(None)))

    def test_absent_tracefs_refuses_before_global_configuration_writes(self):
        with patch('observation_extension.linux_tracing._tracefs', return_value=None):
            with self.assertRaisesRegex(TracingError, 'tracefs_not_mounted') as raised:
                self.tracing.capture(self.owned(), 'ftrace')
        self.assertEqual(raised.exception.os_errno, errno.ENOENT)
        self.assertFalse(raised.exception.effect_dispatched)
        self.assertEqual(self.tracing.blocked, set())

    def test_hardware_source_absence_is_not_software_trace_success(self):
        launcher = self.root/'unused'
        launcher.write_text('#!/bin/sh\nexit 91\n')
        launcher.chmod(0o700)
        tracing = LinuxTracing({'profiles': {'hardware': {'backend': 'perf_hardware',
            'event': 'intel_pt', 'allow_capture': True, 'executable': str(launcher),
            'sha256': hashlib.sha256(launcher.read_bytes()).hexdigest()}}}, self.root/'hardware')
        if (Path('/sys/bus/event_source/devices')/'intel_pt').is_dir():
            self.skipTest('hardware present; absent-source boundary is specific to this host')
        with self.assertRaisesRegex(TracingError, 'hardware_event_source_absent') as error:
            tracing.capture(self.owned(), 'hardware')
        self.assertEqual(error.exception.os_errno, errno.ENODEV)

    def test_invalid_profiles_do_not_accept_scripts_or_time_unit_confusion(self):
        cases = [
            {'backend': 'perf_sample', 'event': 'cpu_cycles'},
            {'backend': 'bpftrace', 'event': 'sched_switch', 'script': 'BEGIN{system("bad")}'},
            {'backend': 'perf_counter', 'event': 'task_clock', 'max_samples': True},
            {'backend': 'ftrace', 'event': 'sched_switch', 'tracefs': '/fake'},
            {'backend': [], 'event': 'task_clock'},
            {'backend': 'perf_counter', 'event': []},
            {'backend': 'perf_hardware', 'event': 'intel_pt', 'executable': '/bin/true', 'sha256': None}]
        for index, profile in enumerate(cases):
            with self.subTest(profile=profile), self.assertRaises(TracingError):
                LinuxTracing({'profiles': {'invalid': profile}}, self.root/('invalid'+str(index)))

    def test_protocol_bpftrace_has_only_fixed_program_and_pid(self):
        launcher = self.root/'protocol-tool'
        launcher.write_text('''#!/usr/bin/python3
import json,sys
assert sys.argv[1:6] == ['-q','-f','json','-B','line']
assert sys.argv[6] == '-e'
assert 'tracepoint:sched:sched_switch' in sys.argv[7]
assert 'prev_pid == $1 || args->next_pid == $1' in sys.argv[7]
assert len(sys.argv) == 10 and int(sys.argv[8]) > 0
print(json.dumps({'type':'map','data':{'@switches':3}}))
''')
        launcher.chmod(0o700)
        tracing = LinuxTracing({'profiles': {'protocol': {'backend': 'bpftrace',
            'event': 'sched_switch', 'allow_capture': True, 'executable': str(launcher),
            'sha256': hashlib.sha256(launcher.read_bytes()).hexdigest()}}}, self.root/'protocol')
        result = tracing.capture(self.owned(), 'protocol', duration_ms=20)
        self.assertEqual(result['records'][0]['data']['@switches'], 3)
        self.assertIsNone(result['lost_samples'])
        # This explicitly proves invocation protocol only, not real eBPF.

    def test_tool_timeout_and_output_flood_clean_up_and_fence(self):
        for index, source in enumerate(['import time;time.sleep(5)', 'print("x"*200000)']):
            launcher = self.root/('bad-tool'+str(index))
            launcher.write_text('#!/usr/bin/python3\n'+source+'\n')
            launcher.chmod(0o700)
            tracing = LinuxTracing({'profiles': {'protocol': {'backend': 'bpftrace',
                'event': 'sched_switch', 'allow_capture': True, 'executable': str(launcher),
                'sha256': hashlib.sha256(launcher.read_bytes()).hexdigest()}}}, self.root/('bad'+str(index)))
            with self.assertRaises(TracingError) as error:
                tracing.capture(self.owned(), 'protocol', duration_ms=1)
            self.assertTrue(error.exception.effect_dispatched)
            self.assertIn('protocol', tracing.blocked)
            self.assertFalse(any(tracing.directory.glob('tracing-*')))

    def test_observer_exits_when_its_host_is_sigkilled(self):
        observer = self.root/'observer.py'
        pid_file = self.root/'observer-pid'
        observer.write_text('#!/usr/bin/python3\nfrom pathlib import Path\nimport os,time\nPath('+repr(str(pid_file))+').write_text(str(os.getpid()))\ntime.sleep(30)\n')
        observer.chmod(0o700)
        host = self.root/'host.py'
        host.write_text('''import hashlib,json,sys,tempfile
sys.path.insert(0,sys.argv[1])
from observation_extension.linux_tracing import LinuxTracing
from observation_extension.native_runtime import ProcessSession
p=ProcessSession.launch(['/bin/sleep','30'],allow_debug=True)
print(json.dumps({'pid':p.pid}),flush=True)
with tempfile.TemporaryDirectory() as d:
 t=LinuxTracing({'profiles':{'owned':{'backend':'bpftrace','event':'sched_switch','allow_capture':True,
  'executable':sys.argv[2],'sha256':hashlib.sha256(open(sys.argv[2],'rb').read()).hexdigest()}}},d)
 t.capture(p,'owned',duration_ms=100)
''')
        process = subprocess.Popen([sys.executable, '-u', str(host), str(RUNTIME), str(observer)],
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        target_fd = observer_fd = None
        try:
            self.assertTrue(select.select([process.stdout], [], [], 3)[0])
            target_fd = os.pidfd_open(json.loads(process.stdout.readline())['pid'])
            deadline = time.monotonic()+2
            while not pid_file.exists():
                self.assertLess(time.monotonic(), deadline)
                time.sleep(.01)
            observer_fd = os.pidfd_open(int(pid_file.read_text()))
            process.kill(); process.wait(timeout=2)
            self.assertTrue(select.select([observer_fd], [], [], 2)[0], 'observer survived host SIGKILL')
        finally:
            if process.poll() is None:process.kill();process.wait(timeout=2)
            process.stdout.close()
            if target_fd is not None:
                try:signal.pidfd_send_signal(target_fd, signal.SIGKILL)
                except ProcessLookupError:pass
                os.close(target_fd)
            if observer_fd is not None:os.close(observer_fd)

    def test_protocol_ftrace_arms_kernel_close_hook_before_enable(self):
        # A fake tracefs validates FD/control ordering only, never a claim that
        # kernel ftrace or SIGKILL free_buffer behavior ran in this environment.
        tracefs = self.root/'tracefs'
        (tracefs/'instances').mkdir(parents=True)
        process = self.owned()
        events, held_fd = [], []
        original_mkdir, original_open, original_rmdir = Path.mkdir, Path.open, Path.rmdir
        original_os_open, original_close = os.open, os.close
        def mkdir(path, *args, **kwargs):
            result = original_mkdir(path, *args, **kwargs)
            if path.parent == tracefs/'instances':
                for name, value in {'tracing_on':'0','current_tracer':'nop','buffer_size_kb':'64',
                    'free_buffer':'','options/disable_on_free':'0',
                    'events/sched/sched_switch/enable':'0','events/sched/sched_switch/filter':'',
                    'per_cpu/cpu0/stats':'overrun: 0\n',
                    'trace':f' owned-{process.pid} [000] 123.456: sched_switch: prev_pid={process.pid} ==> next_pid=0\n'}.items():
                    target = path/name
                    original_mkdir(target.parent, parents=True, exist_ok=True)
                    with original_open(target, 'w') as stream:stream.write(value)
            return result
        @contextmanager
        def opened(path, *args, **kwargs):
            mode = args[0] if args else kwargs.get('mode', 'r')
            with original_open(path, *args, **kwargs) as stream:
                if mode == 'w' and 'runtime-access-' in str(path):
                    class Written:
                        def write(self, value):
                            events.append(('write', path.name, value));return stream.write(value)
                    yield Written()
                else:yield stream
        def opened_fd(path, *args, **kwargs):
            descriptor = original_os_open(path, *args, **kwargs)
            if str(path).endswith('/free_buffer'):
                self.assertTrue(fcntl.fcntl(descriptor, fcntl.F_GETFD) & fcntl.FD_CLOEXEC)
                events.append(('open_free',));held_fd.append(descriptor)
            return descriptor
        def closed_fd(descriptor):
            if held_fd and descriptor == held_fd[0]:events.append(('close_free',))
            original_close(descriptor)
        def rmdir(path):
            if path.parent == tracefs/'instances':
                events.append(('remove_instance',));shutil.rmtree(path)
            else:original_rmdir(path)
        with patch('observation_extension.linux_tracing._tracefs', return_value=tracefs), \
             patch.object(Path,'mkdir',mkdir), patch.object(Path,'open',opened), \
             patch.object(Path,'rmdir',rmdir), patch('os.open',opened_fd), patch('os.close',closed_fd):
            result = self.tracing.capture(process,'ftrace',duration_ms=1)
        self.assertEqual(len(result['samples']),1)
        self.assertLess(events.index(('open_free',)),events.index(('write','disable_on_free','1')))
        self.assertLess(events.index(('write','disable_on_free','1')),events.index(('write','tracing_on','1')))
        self.assertLess(events.index(('close_free',)),events.index(('remove_instance',)))
        # A missing kernel option must prevent enable, not silently fall back
        # to a Python finally that cannot run after SIGKILL.
        def without_option(path, *args, **kwargs):
            result = mkdir(path, *args, **kwargs)
            if path.parent == tracefs/'instances':
                (path/'options/disable_on_free').unlink()
            return result
        events.clear();held_fd.clear()
        with patch('observation_extension.linux_tracing._tracefs', return_value=tracefs), \
             patch.object(Path,'mkdir',without_option), patch.object(Path,'open',opened), \
             patch.object(Path,'rmdir',rmdir), patch('os.open',opened_fd), patch('os.close',closed_fd):
            with self.assertRaisesRegex(TracingError,'kernel_autocleanup_unavailable'):
                self.tracing.capture(process,'ftrace',duration_ms=1)
        self.assertNotIn(('write','tracing_on','1'),events)


@unittest.skipUnless(os.environ.get('RUNTIME_PERF'), 'set RUNTIME_PERF to a pinned real perf launcher')
class MaturePerfTraceTests(unittest.TestCase):
    def test_real_software_record_decode_binding_release_and_tamper(self):
        with tempfile.TemporaryDirectory() as directory:
            exe = str(Path(os.environ['RUNTIME_PERF']).resolve())
            profile = {'backend':'perf_record','event':'cpu_clock','allow_capture':True,
                       'executable':exe,'sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest(),
                       'max_samples':128}
            tracer = LinuxTracing({'profiles':{'record':profile,'alias':dict(profile)}}, directory)
            p = ProcessSession.launch(['/bin/sh','-c','while :; do :; done'],allow_debug=True)
            try:
                captured = tracer.capture(p,'record',duration_ms=100)
                self.assertEqual(captured['status'],'observed',captured)
                artifact = captured['artifact']
                decoded = tracer.decode('record',artifact)
                self.assertTrue(decoded['capture_decoded'],decoded)
                self.assertGreater(len(decoded['samples']),0)
                self.assertEqual({row['pid'] for row in decoded['samples']},{p.pid})
                self.assertEqual({row['tid'] for row in decoded['samples']},{p.pid})
                self.assertEqual(decoded['reported_lost_samples'],0)
                self.assertFalse(decoded['instructions_decoded'])
                self.assertFalse(decoded['instruction_level_hardware_trace'])
                self.assertFalse(decoded['runtime_code_matches_disk_proven'])
                self.assertIn('recorded_build_ids',decoded)
                with self.assertRaisesRegex(TracingError,'unknown_artifact'):tracer.decode('alias',artifact)
                # Decode uses the recorded incarnation even after target exit.
                p.terminate_owned()
                self.assertTrue(tracer.decode('record',artifact)['capture_decoded'])
                path = Path(directory)/artifact
                path.write_bytes(b'tampered')
                with self.assertRaisesRegex(TracingError,'digest_mismatch'):tracer.decode('record',artifact)
                self.assertTrue(tracer.release(artifact)['released'])
                self.assertFalse(path.exists())
                with self.assertRaisesRegex(TracingError,'unknown_artifact'):tracer.decode('record',artifact)
            finally:
                if p.child.poll() is None:p.terminate_owned()
                p.close()


if __name__ == '__main__':
    unittest.main()
