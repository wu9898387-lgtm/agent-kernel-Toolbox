"""Real native bytes -> angr AST -> common SSA -> compiler native output.

Synthetic typed-DAG tests below check lowering laws only. Native pipeline and
foreign-ISA evidence require installed real engines and independent native/math
oracles; no synthetic node is accepted through the public translation API.
"""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import random
import select
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_translation import NativeTranslation, NativeTranslationError, _Lower
from observation_extension.translation import interpret

PYTHON = os.environ.get('RUNTIME_ANGR_PYTHON')
AS_AARCH64 = os.environ.get('RUNTIME_AARCH64_AS')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(name): return {'ref': name}
def integer(value): return {'int': value}


def typed(arguments, nodes, result):
    return {'schema_version': 1, 'nodes': nodes, 'paths': [{'return': result, 'constraints': []}],
        'source_arguments': [{'name': row['name'], 'symbol': 'source_' + row['name'], 'bits': row['bits']} for row in arguments],
        'full_unsigned_argument_domains': True, 'complete_return_coverage': True,
        'overlapping_returns_consistent': True, 'pure_function_checked': True,
        'effects_model': 'call_stack_and_immutable_binary_data_only'}


def source_node(index, name, bits):
    return {'id': 'n' + str(index), 'sort': 'bv', 'bits': bits, 'op': 'BVS',
            'args': [{'string': 'source_' + name}, integer(bits)]}


class TypedNativeLoweringTests(unittest.TestCase):
    def test_BV_shift_oversize_and_arithmetic_sign_are_not_SSA_modulo_shifts(self):
        for bits in (8, 16, 32, 64):
            arguments = [{'name': 'x', 'bits': bits}, {'name': 'y', 'bits': bits}]
            mask = (1 << bits) - 1
            for operation in ('__lshift__', 'LShR', '__rshift__'):
                nodes = [source_node(0, 'x', bits), source_node(1, 'y', bits),
                         {'id': 'n2', 'sort': 'bv', 'bits': bits, 'op': operation,
                          'args': [ref('n0'), ref('n1')]}]
                module = _Lower(typed(arguments, nodes, 'n2'), {'arguments': arguments, 'return_bits': bits}).module()
                for x in (0, 1, (1 << (bits - 1)) - 1, 1 << (bits - 1), mask):
                    for amount in (0, bits - 1, bits, bits + 1, mask):
                        if operation == '__lshift__': expected = (x << amount) & mask if amount < bits else 0
                        elif operation == 'LShR': expected = x >> amount if amount < bits else 0
                        else:
                            signed = x - (1 << bits) if x & (1 << (bits - 1)) else x
                            expected = (signed >> min(amount, bits)) & mask
                        with self.subTest(bits=bits, operation=operation, x=x, amount=amount):
                            self.assertEqual(interpret(module, {'x': x, 'y': amount}), expected)

    def test_extract_concat_zero_and_sign_extension_keep_native_node_widths(self):
        args = [{'name': 'x', 'bits': 8}, {'name': 'y', 'bits': 8}]
        nodes = [source_node(0, 'x', 8), source_node(1, 'y', 8),
            {'id': 'n2', 'sort': 'bv', 'bits': 16, 'op': 'Concat', 'args': [ref('n0'), ref('n1')]},
            {'id': 'n3', 'sort': 'bv', 'bits': 32, 'op': 'ZeroExt', 'args': [integer(16), ref('n2')]},
            {'id': 'n4', 'sort': 'bv', 'bits': 8, 'op': 'Extract', 'args': [integer(15), integer(8), ref('n2')]},
            {'id': 'n5', 'sort': 'bv', 'bits': 32, 'op': 'SignExt', 'args': [integer(24), ref('n4')]},
            {'id': 'n6', 'sort': 'bv', 'bits': 32, 'op': '__xor__', 'args': [ref('n3'), ref('n5')]}]
        module = _Lower(typed(args, nodes, 'n6'), {'arguments': args, 'return_bits': 32}).module()
        self.assertEqual(module['width'], 32)
        for x in (0, 1, 127, 128, 255):
            for y in (0, 17, 255):
                expected = ((x << 8 | y) ^ ((x - 256 if x >= 128 else x) & 0xffffffff)) & 0xffffffff
                self.assertEqual(interpret(module, {'x': x, 'y': y}), expected)

    def test_unproved_bad_typed_AST_and_instruction_excess_are_refused(self):
        args = [{'name': 'x', 'bits': 32}]
        export = typed(args, [source_node(0, 'x', 32)], 'n0')
        for proof in ('complete_return_coverage', 'pure_function_checked', 'overlapping_returns_consistent'):
            invalid = copy.deepcopy(export); invalid[proof] = False
            with self.subTest(proof=proof), self.assertRaises(NativeTranslationError):
                _Lower(invalid, {'arguments': args, 'return_bits': 32})
        for operation in ('UDiv', '__import__("os").system("bad")'):
            invalid = typed(args, [source_node(0, 'x', 32),
                {'id': 'n1', 'sort': 'bv', 'bits': 32, 'op': operation, 'args': [ref('n0'), ref('n0')]}], 'n1')
            with self.assertRaisesRegex(NativeTranslationError, 'unsupported_ast_operation'):
                _Lower(invalid, {'arguments': args, 'return_bits': 32}).module()
        invalid = copy.deepcopy(export); invalid['nodes'][0]['bits'] = 128
        with self.assertRaises(NativeTranslationError):
            _Lower(invalid, {'arguments': args, 'return_bits': 32})
        nodes = [source_node(0, 'x', 32),
                 {'id': 'n1', 'sort': 'bv', 'bits': 32, 'op': 'BVV', 'args': [integer(1), integer(32)]}]
        for index in range(2, 263):
            nodes.append({'id': 'n' + str(index), 'sort': 'bv', 'bits': 32, 'op': '__add__',
                          'args': [ref('n' + str(index - 1)), ref('n1')]})
        with self.assertRaisesRegex(NativeTranslationError, 'ssa_instruction_budget'):
            _Lower(typed(args, nodes, 'n262'), {'arguments': args, 'return_bits': 32}).module()


@unittest.skipUnless(PYTHON and shutil.which('gcc') and sys.platform == 'linux'
                     and platform.machine().lower() in ('x86_64', 'amd64'),
                     'set RUNTIME_ANGR_PYTHON and a native Linux x86-64 compiler for real lifting/AOT')
class ActualNativeTranslationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name)
        original = (ROOT / 'tests/fixtures/recovery/native_symbolic.c').read_text()
        extra = '''
__attribute__((noinline)) uint32_t owned_wide(uint32_t x, uint32_t y) {
    uint64_t product = (uint64_t)x * (uint64_t)y;
    return (uint32_t)(product >> 32) ^ (uint32_t)product;
}
__attribute__((noinline)) uint32_t owned_signed(uint32_t x, uint32_t y) {
    return (uint32_t)((int32_t)x >> (y & 31));
}
__attribute__((noinline)) uint64_t owned_extend(uint32_t x, uint32_t y) {
    uint64_t packed = ((uint64_t)(uint16_t)x << 48) | ((uint64_t)y << 8);
    return packed ^ (uint64_t)(int64_t)(int16_t)x;
}
__attribute__((noinline)) uint32_t owned_effect(uint32_t x) { owned_cell = x; return x + 1; }
__attribute__((noinline)) uint32_t owned_div(uint32_t x, uint32_t y) { return x / (y | 1); }
__attribute__((noinline)) uint64_t owned_clock(uint32_t x, uint32_t y) {
    uint32_t low, high; (void)x; (void)y;
    __asm__ volatile("rdtsc" : "=a"(low), "=d"(high));
    return ((uint64_t)high << 32) | low;
}
'''
        source = cls.root / 'owned.c'
        source.write_text(original.replace('int main(int argc, char **argv)', extra + '\nint main(int argc, char **argv)')
            .replace('    uint32_t value;', '''    if (argv[1][0] == 'e') { printf("%llu\\n", (unsigned long long)owned_extend(x,y)); return 0; }
    uint32_t value;''')
            .replace("    else return 3;", "    else if (argv[1][0] == 'w') value = owned_wide(x,y);\n"
                "    else if (argv[1][0] == 's') value = owned_signed(x,y);\n"
                "    else return 3;"))
        cls.binary = cls.root / 'owned'
        subprocess.run([shutil.which('gcc'), '-O0', '-g', '-fno-stack-protector', '-no-pie',
                        str(source), '-o', str(cls.binary)], check=True, timeout=20)
        cls.compiler = str(Path(shutil.which('gcc')).resolve())
        def profile(entry, arity=2, return_bits=32, **extra):
            return {'binary': 'owned', 'binary_sha256': digest(cls.binary), 'entry': entry,
                'arguments': [{'name': name, 'bits': 32} for name in ('x', 'y')[:arity]],
                'return_bits': return_bits, 'max_steps': 64, 'timeout_seconds': 30, **extra}
        cls.config = {'symbolic': {'python': PYTHON, 'python_sha256': digest(Path(PYTHON).resolve()), 'profiles': {
            'branch': profile('owned_branch'), 'alias': profile('owned_branch'),
            'wide': profile('owned_wide'), 'signed': profile('owned_signed'),
            'extend': profile('owned_extend', return_bits=64), 'global': profile('owned_memory', 1),
            'effect': profile('owned_effect', 1), 'loop': profile('owned_loop', 1, max_steps=2),
            'external': profile('owned_external', 1), 'division': profile('owned_div'),
            'clock': profile('owned_clock', return_bits=64)}},
            'compiler': cls.compiler, 'compiler_sha256': digest(cls.compiler)}

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def setUp(self):
        self.working = tempfile.TemporaryDirectory(dir=self.root)
        self.addCleanup(self.working.cleanup)
        self.directory = Path(self.working.name)
        self.service = NativeTranslation(self.config, self.directory / 'state', {'owned': str(self.binary)}, bundle_root=ROOT)

    def original(self, mode, x, y):
        result = subprocess.run([self.binary, mode, str(x), str(y)], capture_output=True,
                                text=True, check=True, timeout=2)
        return int(result.stdout)

    def test_real_full_word_native_branch_to_common_SSA_to_cached_native_AOT(self):
        lifted = self.service.lift('branch')
        self.assertEqual(lifted['native_source']['architecture'], 'AMD64')
        self.assertTrue(lifted['typed_ast']['complete_return_coverage'])
        self.assertTrue(lifted['typed_ast']['overlapping_returns_consistent'])
        self.assertTrue(lifted['ssa_equivalence_proven'])
        self.assertTrue(lifted['ssa_equivalence']['equivalent'])
        self.assertEqual(len(lifted['typed_ast']['paths']), 3)
        self.assertLessEqual(len(lifted['module']['instructions']), 256)
        self.assertEqual(lifted['source_word_domains'], {'x': [0, 0xffffffff], 'y': [0, 0xffffffff]})
        self.assertFalse(lifted['output_abi']['original_function_abi_preserved'])
        self.assertEqual(lifted['output_abi']['entry'], 'runtime_ir_eval')
        compiled = self.service.compile('branch')
        self.assertEqual(compiled['source_lift_sha256'], lifted['identity_sha256'])
        randomizer = random.Random(20261113)
        values = [(13, 0), (13, 3), (13, 4), (0, 0), (0xffffffff, 0), (0xffffffff, 0xffffffff),
                  (0x80000000, 0x7fffffff), *[(randomizer.getrandbits(32), randomizer.getrandbits(32)) for _ in range(30)]]
        with patch.object(self.service.symbolic, 'analyze', side_effect=AssertionError('cached run must not re-lift')):
            for x, y in values:
                result = self.service.run('branch', [x, y])
                self.assertEqual(result['value'], self.original('branch', x, y))
                self.assertTrue(result['lift_cache_hit'])
                self.assertTrue(result['oracle_checked'])
        mutated = self.service.lift('branch')
        mutated['module']['instructions'].clear()
        self.assertTrue(self.service.lift('branch')['module']['instructions'])
        self.assertEqual(self.service.lift('alias')['profile'], 'alias')

    def test_native_64bit_intermediates_and_signed_extensions_preserve_each_width(self):
        pairs = [(0, 0), (1, 1), (0xffffffff, 0xffffffff), (0x80000000, 1),
                 (0x7fffffff, 31), (0xffff8000, 63), (0x12345678, 0x9abcdef0)]
        randomizer = random.Random(551)
        pairs += [(randomizer.getrandbits(32), randomizer.getrandbits(32)) for _ in range(12)]
        for profile, mode in [('wide', 'wide'), ('signed', 'signed'), ('extend', 'extend')]:
            lifted = self.service.lift(profile)
            if profile in ('wide', 'extend'):
                self.assertEqual(lifted['module']['width'], 64)
            for x, y in pairs:
                with self.subTest(profile=profile, x=x, y=y):
                    self.assertEqual(self.service.run(profile, {'x': x, 'y': y})['value'], self.original(mode, x, y))

    def test_partial_paths_mutable_globals_external_writes_and_unsupported_AST_never_compile(self):
        for profile in ('global', 'effect', 'loop', 'external', 'division', 'clock'):
            with self.subTest(profile=profile), self.assertRaises(NativeTranslationError) as error:
                self.service.compile(profile)
            self.assertFalse(error.exception.effect_dispatched)
        self.assertIsNone(self.service.compiler)

    def test_injected_lowering_defect_is_rejected_by_full_domain_SMT_before_compile(self):
        original = _Lower.emit
        def defective(instance, operation, arguments):
            return original(instance, 'sub' if operation == 'add' else operation, arguments)
        with patch.object(_Lower, 'emit', defective):
            with self.assertRaisesRegex(NativeTranslationError, 'ir_semantics_mismatch'):
                self.service.compile('branch')
        self.assertIsNone(self.service.compiler)
        self.assertFalse(list((self.directory / 'state').glob('lift-*.json')))

    def test_partial_source_domains_replay_and_memory_profiles_are_refused(self):
        for update in ({'arguments': [{'name': 'x', 'bits': 32, 'maximum': 255}]},
                       {'arguments': [{'name': 'x', 'bits': 32, 'value': 1}]},
                       {'memory': [{'name': 'cell', 'bits': 32, 'address': '0x404000'}]},
                       {'replay': {'allow_execute': True, 'arguments': []}}):
            cfg = copy.deepcopy(self.config)
            cfg['symbolic']['profiles'] = {'bad': {**cfg['symbolic']['profiles']['branch'], **update}}
            with self.subTest(update=update), self.assertRaises(NativeTranslationError):
                NativeTranslation(cfg, self.directory / 'bad', {'owned': str(self.binary)}, bundle_root=ROOT)

    def test_foreign_i686_object_is_generated_from_the_same_native_derived_IR(self):
        lifted = self.service.lift('branch')
        result = self.service.compile('branch', target='i686-linux-gnu', kind='object')
        self.assertEqual(result['artifact_abi']['architecture'], 'x86')
        self.assertEqual(result['artifact_abi']['pointer_bits'], 32)
        self.assertEqual(Path(result['path']).read_bytes()[:5], b'\x7fELF\x01')
        self.assertEqual(result['ir_sha256'], lifted['ir_sha256'])
        self.assertEqual(result['source_lift_sha256'], lifted['identity_sha256'])
        with self.assertRaises(NativeTranslationError):
            self.service.compile('branch', target='i686-linux-gnu', kind='executable')

    def test_source_cache_integrity_input_domains_and_capacity_are_enforced(self):
        self.service.lift('branch')
        for value in ([True, 0], [2**32, 0], [0], {'x': 0, 'other': 0}):
            with self.subTest(value=value), self.assertRaises(NativeTranslationError):
                self.service.run('branch', value)
        with patch('observation_extension.native_translation.MAX_LIFT_CACHE', 1):
            with self.assertRaisesRegex(NativeTranslationError, 'cache_capacity'):
                self.service.lift('wide')
        cached = next((self.directory / 'state').glob('lift-*.json'))
        cached.chmod(0o600); cached.write_text('{}')
        with self.assertRaisesRegex(NativeTranslationError, 'cache_integrity'):
            self.service.lift('branch')

    @unittest.skipUnless(AS_AARCH64, 'set RUNTIME_AARCH64_AS for a real foreign AArch64 input object')
    def test_AArch64_machine_bytes_lift_to_shared_IR_and_x86_native_AOT(self):
        source = self.directory / 'branch-aarch64.S'
        source.write_text('''.text
.global owned_branch
.type owned_branch,%function
owned_branch:
 cmp w0,#13
 b.ne .Ldefault
 cmp w1,#4
 b.hs .Ldefault
 add w0,w0,w0,lsl #1
 add w0,w0,w1
 ret
.Ldefault:
 eor w0,w0,w1
 add w0,w0,#5
 ret
.size owned_branch,.-owned_branch
''')
        binary = self.directory / 'branch-aarch64.o'
        environment = dict(os.environ)
        libraries = os.environ.get('RUNTIME_AARCH64_LIBRARIES',
            str(Path(AS_AARCH64).parent.parent / 'lib/x86_64-linux-gnu'))
        if Path(libraries).is_dir():
            environment['LD_LIBRARY_PATH'] = libraries
        subprocess.run([AS_AARCH64, str(source), '-o', str(binary)], check=True, timeout=10, env=environment)
        config = copy.deepcopy(self.config)
        config['symbolic']['profiles'] = {'foreign': {**config['symbolic']['profiles']['branch'],
            'binary_sha256': digest(binary), 'expected_architecture': 'AARCH64'}}
        service = NativeTranslation(config, self.directory / 'foreign', {'owned': str(binary)}, bundle_root=ROOT)
        lifted = service.lift('foreign')
        self.assertEqual(lifted['native_source']['architecture'], 'AARCH64')
        self.assertEqual(lifted['native_source']['binary_abi']['architecture'], 'aarch64')
        for x, y in [(13, 0), (13, 3), (13, 4), (0, 0), (0xffffffff, 0xffffffff), (0x80000000, 0x7fffffff)]:
            expected = (x * 3 + y if x == 13 and y < 4 else (x ^ y) + 5) & 0xffffffff
            self.assertEqual(service.run('foreign', [x, y])['value'], expected)
            self.assertEqual(self.original('branch', x, y), expected)
        print('NATIVE_FOREIGN_TRANSLATION', {'source_isa': 'AARCH64', 'target_isa': 'x86_64',
            'source_sha256': digest(binary), 'source_foreign_machine_code_executed': False,
            'compiled_shared_IR_executed': True, 'identity_sha256': lifted['identity_sha256']})

    def test_packaged_stdio_lift_compile_and_run_use_real_zipimport_resources(self):
        spec = importlib.util.spec_from_file_location('native_translation_package', ROOT / 'build-source.py')
        builder = importlib.util.module_from_spec(spec); spec.loader.exec_module(builder)
        package = self.directory / 'package'; package.mkdir()
        with zipfile.ZipFile(io.BytesIO(builder.build())) as archive:
            archive.extractall(package)
        config = {'schema_version': 1, 'state_directory': str(self.directory / 'packaged-state'),
            'allowed_tools': ['translate_native.lift', 'translate_native.compile', 'translate_native.run'],
            'binaries': {'owned': str(self.binary)}, 'native_translation': self.config}
        config_file = self.directory / 'config.json'; config_file.write_text(json.dumps(config))
        requests = [{'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
                        'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'native-translation-check'}}},
                    {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
                    {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'translate_native.lift', 'arguments': {'profile': 'branch'}}},
                    {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'translate_native.compile', 'arguments': {'profile': 'branch'}}}]
        pairs = [(13, 0), (13, 3), (13, 4), (0, 0), (1, 2), (0xffffffff, 0),
                 (0xffffffff, 0xffffffff), (0x80000000, 1), (9, 7), (0x12345678, 0x9abcdef0)]
        requests += [{'jsonrpc': '2.0', 'id': 4 + index, 'method': 'tools/call', 'params': {
            'name': 'translate_native.run', 'arguments': {'profile': 'branch', 'inputs': [x, y]}}}
            for index, (x, y) in enumerate(pairs)]
        process = subprocess.run([sys.executable, str(package / 'runtime-access.pyz'), 'serve', '--config', str(config_file)],
            input=('\n'.join(json.dumps(row) for row in requests) + '\n').encode(),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=True)
        replies = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual(replies[0]['result']['serverInfo']['version'], '0.5.6.2')
        for reply in replies[1:]:
            self.assertFalse(reply['result']['isError'], reply)
        lifted = replies[1]['result']['structuredContent']['data']
        self.assertEqual(lifted['output_abi']['entry'], 'runtime_ir_eval')
        for (x, y), reply in zip(pairs, replies[3:]):
            actual = reply['result']['structuredContent']['data']
            self.assertEqual(actual['value'], self.original('branch', x, y))
            self.assertTrue(actual['lift_cache_hit'])


if __name__ == '__main__':
    unittest.main()
