import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0, str(RUNTIME))

from observation_extension.ir_analysis import (
    IRAnalysisError, analyze_ir, record_ir, replay_ir, reverse_ir,
    solve_ir, synthesize_expression, verify_analysis,
)
from observation_extension.translation import TranslationError, interpret


def module(instructions, result, inputs=None, width=8):
    return {"schema_version": 1, "width": width, "inputs": ["x", "y"] if inputs is None else inputs,
            "instructions": instructions, "result": result}


class IRAnalysisTests(unittest.TestCase):
    def test_symbolic_slice_and_conservative_taint_provenance(self):
        source = module([
            {"id": "dead", "op": "mul", "args": ["x", "y"]},
            {"id": "zero", "op": "const", "value": 0},
            {"id": "cancel", "op": "xor", "args": ["x", "x"]},
            {"id": "r", "op": "select", "args": ["y", "cancel", "zero"]},
        ], "r")
        analysis = analyze_ir(source)
        self.assertEqual(analysis["result_sources"], ["x", "y"])
        self.assertEqual(analysis["provenance"]["zero"]["sources"], [])
        self.assertEqual(analysis["provenance"]["r"]["parents"], ["y", "cancel", "zero"])
        self.assertNotIn("dead", [ins["id"] for ins in analysis["symbolic_expression"]["instructions"]])
        for x in range(16):
            for y in range(16):
                self.assertEqual(interpret(source, {"x": x, "y": y}),
                                 interpret(analysis["symbolic_expression"], {"x": x, "y": y}))
        self.assertEqual(analyze_ir(source, taint_sources=["x"])["result_sources"], ["x"])
        self.assertTrue(verify_analysis(source, analysis)["verified"])
        analysis["provenance"]["r"]["sources"] = []
        with self.assertRaisesRegex(IRAnalysisError, "analysis_mismatch"):
            verify_analysis(source, analysis)

    def test_solver_reports_witness_and_precise_proof_scope(self):
        source = module([{"id": "r", "op": "add", "args": ["x", "y"]}], "r")
        sat = solve_ir(source, [{"name": "r", "op": "eq", "value": 5}], input_bits=3)
        self.assertEqual(sat["status"], "sat")
        self.assertEqual(interpret(source, sat["inputs"]), 5)
        unsat = solve_ir(source, [{"name": "r", "op": "ugt", "value": 14}], input_bits=3)
        self.assertEqual(unsat["status"], "unsat")
        self.assertTrue(unsat["exhaustive"])
        self.assertEqual(unsat["checked_cases"], 64)
        self.assertFalse(unsat["full_word_domain"])
        self.assertEqual(unsat["input_domains"], {"x": [0, 7], "y": [0, 7]})
        unknown = solve_ir(source, [{"name": "r", "op": "eq", "value": 5}], max_cases=1)
        self.assertEqual(unknown["status"], "unknown")
        self.assertFalse(unknown["exhaustive"])

    def test_full_word_unsigned_wrap_and_multiple_constraints(self):
        source = module([{"id": "one", "op": "const", "value": 1},
                         {"id": "r", "op": "add", "args": ["x", "one"]}], "r", ["x"])
        found = solve_ir(source, [{"name": "r", "op": "eq", "value": 0},
                                 {"name": "x", "op": "uge", "value": 200}], input_bits=8)
        self.assertEqual(found["inputs"], {"x": 255})
        self.assertTrue(found["full_word_domain"])
        self.assertTrue(found["exhaustive"])
        zero_work = solve_ir(source, [{"name": "r", "op": "eq", "value": 0}], max_work=1)
        self.assertEqual(zero_work["status"], "unknown")

    def test_synthesis_proves_cancellation_and_combined_expression(self):
        cancelled = module([{"id": "r", "op": "xor", "args": ["x", "x"]}], "r")
        result = synthesize_expression(cancelled, input_bits=2)
        self.assertEqual(result["status"], "synthesized")
        self.assertTrue(result["exhaustive"])
        self.assertEqual(result["module"]["instructions"], [{"id": "synth0", "op": "const", "value": 0}])
        source = module([{"id": "sum", "op": "add", "args": ["x", "y"]},
                         {"id": "zero", "op": "const", "value": 0},
                         {"id": "r", "op": "xor", "args": ["sum", "zero"]}], "r")
        result = synthesize_expression(source, input_bits=2)
        self.assertEqual(result["status"], "synthesized")
        self.assertEqual(len(result["module"]["instructions"]), 1)
        for x in range(4):
            for y in range(4):
                inputs = {"x": x, "y": y}
                self.assertEqual(interpret(source, inputs), interpret(result["module"], inputs))

    def test_synthesis_never_claims_equivalence_after_partial_enumeration(self):
        source = module([{"id": "r", "op": "add", "args": ["x", "y"]}], "r")
        self.assertEqual(synthesize_expression(source, input_bits=8, max_cases=4)["status"], "unknown")
        limited = synthesize_expression(source, max_candidates=1)
        self.assertEqual(limited["status"], "unknown")
        self.assertEqual(limited["reason"], "candidate_budget_exhausted")
        grammar = synthesize_expression(source, max_nodes=1)
        self.assertEqual(grammar["status"], "unknown")
        self.assertTrue(grammar["grammar_exhaustive"])

    def test_record_replay_reverse_and_recomputed_digest_tampering(self):
        source = module([{"id": "a", "op": "add", "args": ["x", "y"]},
                         {"id": "b", "op": "neg", "args": ["a"]}], "b")
        recording = record_ir(source, {"x": 250, "y": 10})
        self.assertEqual(recording["execution_domain"], "pure_word_ir")
        self.assertEqual(recording["result"], 252)
        self.assertEqual(replay_ir(recording)["state"], {"x": 250, "y": 10, "a": 4, "b": 252})
        self.assertEqual(reverse_ir(recording)["state"], {"x": 250, "y": 10, "a": 4})
        self.assertEqual(reverse_ir(recording, steps=2)["state"], {"x": 250, "y": 10})
        self.assertEqual(reverse_ir(recording, from_step=1)["step"], 0)
        tampered = copy.deepcopy(recording)
        tampered["events"][0]["value"] = 99
        payload = {k: v for k, v in tampered.items() if k != "sha256"}
        tampered["sha256"] = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        with self.assertRaisesRegex(IRAnalysisError, "recording_mismatch"):
            replay_ir(tampered)
        same_number_wrong_type = copy.deepcopy(recording)
        same_number_wrong_type["events"][0]["value"] = 4.0
        with self.assertRaisesRegex(IRAnalysisError, "invalid_recording"):
            replay_ir(same_number_wrong_type)

    def test_all_ir_operations_record_identical_values_at_all_steps(self):
        operations = ["add", "sub", "mul", "and", "or", "xor", "shl", "lshr", "eq", "ult", "slt"]
        instructions = [{"id": "v" + str(index), "op": op, "args": ["x", "y"]}
                        for index, op in enumerate(operations)]
        instructions.extend([{"id": "unot", "op": "not", "args": ["x"]},
                             {"id": "uneg", "op": "neg", "args": ["x"]},
                             {"id": "r", "op": "select", "args": ["x", "unot", "uneg"]}])
        source = module(instructions, "r")
        for x, y in [(0, 0), (128, 255), (255, 8), (7, 9)]:
            inputs = {"x": x, "y": y}
            recording = record_ir(source, inputs)
            for step in range(1, len(instructions) + 1):
                prefix = {**source, "instructions": instructions[:step], "result": instructions[step - 1]["id"]}
                self.assertEqual(replay_ir(recording, step=step)["state"][prefix["result"]], interpret(prefix, inputs))

    def test_budget_and_boundary_validation(self):
        source = module([{"id": "r", "op": "add", "args": ["x", "y"]}], "r")
        for kwargs in [{"input_bits": 0}, {"input_bits": 9}, {"max_cases": True}, {"max_work": 0}]:
            with self.subTest(kwargs=kwargs), self.assertRaises(IRAnalysisError):
                solve_ir(source, [{"name": "r", "op": "eq", "value": 0}], **kwargs)
        with self.assertRaisesRegex(IRAnalysisError, "step_budget"):
            record_ir(source, {"x": 0, "y": 0}, max_steps=0)
        with self.assertRaises(TranslationError):
            record_ir(source, {"x": 0, "y": 0, "z": 0})
        with self.assertRaises(IRAnalysisError):
            solve_ir(source, [{"name": "r", "op": "eval", "value": 0}])
        with self.assertRaises(IRAnalysisError):
            analyze_ir(source, taint_sources=["unknown"])
        recording = record_ir(source, {"x": 0, "y": 0})
        with self.assertRaises(IRAnalysisError):
            reverse_ir(recording, steps=2)
        with self.assertRaises(IRAnalysisError):
            analyze_ir(module([], "x", ["x", "a", "b", "c", "d"]))


if __name__ == "__main__":
    unittest.main()
