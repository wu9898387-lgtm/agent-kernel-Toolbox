import ctypes
import hashlib
import mmap
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_runtime import ProcessSession, NativeRuntimeError
from observation_extension.runtime_host import RuntimeHost


class MemoryCompatibilityTests(unittest.TestCase):
    def test_adjacent_mapping_boundaries_and_unreadable_hole(self):
        page = os.sysconf('SC_PAGE_SIZE')
        mapping = mmap.mmap(-1, page * 3)
        view = (ctypes.c_char * (page * 3)).from_buffer(mapping)
        address = ctypes.addressof(view)
        mapping[page - 2:page + 4] = b'needle'
        libc = ctypes.CDLL(None, use_errno=True)
        libc.mprotect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
        libc.mprotect.restype = ctypes.c_int
        process = ProcessSession.attach(os.getpid(), allow_memory=True)
        try:
            self.assertEqual(libc.mprotect(address + page, page, mmap.PROT_READ), 0)
            result = process.search_memory(address, page * 3, b'needle')
            self.assertEqual(result['matches'], [hex(address + page - 2)])
            self.assertEqual(libc.mprotect(address + page, page, 0), 0)
            before = process.memory_consumed
            with self.assertRaisesRegex(NativeRuntimeError, 'range_not_in_readable_mapping'):
                process.search_memory(address, page * 3, b'needle')
            self.assertEqual(process.memory_consumed, before)
        finally:
            libc.mprotect(address + page, page, mmap.PROT_READ | mmap.PROT_WRITE)
            process.close();del view;mapping.close()

    def test_live_heap_and_file_mapping_values_in_both_byte_orders(self):
        raw = struct.pack('>Q', 2**64 - 1) + '状态😀'.encode('utf-32-be')
        with tempfile.TemporaryFile() as stream:
            stream.write(raw);stream.flush()
            mapping = mmap.mmap(stream.fileno(), len(raw))
            view = (ctypes.c_char * len(raw)).from_buffer(mapping)
            with ProcessSession.attach(os.getpid(), allow_memory=True) as process:
                address = ctypes.addressof(view)
                self.assertEqual(process.read_value(address, 8, 'uint64', 'big')['value'], [str(2**64 - 1)])
                self.assertEqual(process.read_value(address + 8, len(raw) - 8, 'utf32', 'big')['value'], '状态😀')
                self.assertEqual(process.read_memory(address, len(raw))['sha256'], hashlib.sha256(raw).hexdigest())
            del view;mapping.close()

    def test_host_search_encodings_and_target_abi_registry(self):
        with tempfile.TemporaryDirectory() as directory:
            host = RuntimeHost({'schema_version': 1, 'state_directory': directory + '/state',
                                'allowed_tools': ['process.search_memory', 'process.read_value', 'process.abi', 'runtime.capabilities']})
            host.processes['fixture'] = ProcessSession.attach(os.getpid(), allow_memory=True)
            try:
                for encoding, codec in [('utf16le', 'utf-16-le'), ('utf16be', 'utf-16-be'), ('utf32le', 'utf-32-le'), ('utf32be', 'utf-32-be')]:
                    raw = '状态'.encode(codec)
                    buffer = ctypes.create_string_buffer(raw)
                    result = host.call('process.search_memory', {'session_id': 'fixture', 'address': hex(ctypes.addressof(buffer)),
                                      'size': len(raw), 'needle': '状态', 'encoding': encoding})
                    self.assertTrue(result['ok'], result)
                    self.assertEqual(result['data']['matches'], [hex(ctypes.addressof(buffer))])
                result = host.call('process.abi', {'session_id': 'fixture'})
                self.assertEqual(result['data']['pointer_bits'], ctypes.sizeof(ctypes.c_void_p) * 8)
                self.assertTrue(host.call('runtime.capabilities', {})['data']['pidfd_self_probe'])
                result = host.call('process.read_value', {'session_id': 'fixture', 'address': hex(ctypes.addressof(buffer)),
                                   'size': len(raw), 'type': 'utf32', 'byte_order': 'big'})
                self.assertTrue(result['ok'], result)
                self.assertEqual(result['data']['value'], '状态')
            finally:
                host.close()


if __name__ == '__main__': unittest.main()
