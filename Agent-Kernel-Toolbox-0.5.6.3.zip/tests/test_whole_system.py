"""Real whole-machine TCG tests, not QEMU-user or a protocol simulation.

Set RUNTIME_QEMU_ROOT to an installed/extracted QEMU package root containing
usr/bin/qemu-system-i386, usr/share/{qemu,seabios} and optional private libraries.
The fixture is an owned multiboot kernel, not a third-party VM image.
"""
import copy
import hashlib
import importlib.util
import os
from pathlib import Path
import shutil
import sys
import tempfile
import select
import signal
import subprocess
import time
import threading
import json
import re
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.whole_system import WholeSystem,WholeSystemError


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def wait_pidfd(descriptor,deadline):
    while True:
        left=max(0,deadline-time.monotonic())
        if select.select([descriptor],[],[],left)[0]:
            return True
        if time.monotonic()>=deadline:
            return False


def profile(qemu_root,kernel):
    root=Path(qemu_root)
    executable=root/'usr/bin/qemu-system-i386'
    firmware=root/'usr/share/seabios/bios.bin'
    roms={}
    for name in ('multiboot.bin','multiboot_dma.bin','kvmvapic.bin'):
        path=root/'usr/share/qemu'/name
        roms[name]={'path':str(path),'sha256':digest(path)}
    return {'executable':str(executable),'sha256':digest(executable),'kernel':str(kernel),
            'kernel_sha256':digest(kernel),'firmware':str(firmware),'firmware_sha256':digest(firmware),
            'roms':roms,'machine':'pc-i440fx-10.0','cpu':'qemu32','memory_mib':16,
            'timeout_seconds':10,'lifetime_seconds':30,'rr_shift':3,
            'library_directories':[str(root/'usr/lib/x86_64-linux-gnu')],
            'ram_regions':{'state':{'address':0x200000,'size':8}},
            'serial_commands':{'increment':{'data_hex':'69','ack_utf8':'incremented\n'}},
            'ready_utf8':'owned-machine-ready\n'}


class MachineValidationTests(unittest.TestCase):
    def test_device_low_memory_and_arbitrary_machine_options_are_rejected(self):
        base={'executable':'/not-installed/qemu','sha256':'0'*64,'kernel':'/fixed/kernel',
              'kernel_sha256':'0'*64,'firmware':'/fixed/bios','firmware_sha256':'0'*64,
              'roms':{'multiboot.bin':{'path':'/fixed/rom','sha256':'0'*64}},
              'machine':'pc-i440fx-10.0','ram_regions':{'screen':{'address':0xb8000,'size':8}},
              'serial_commands':{},'ready_utf8':'ready'}
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(WholeSystemError,'machine_ram_not_ordinary'):
                WholeSystem({'profiles':{'owned':base}},Path(directory)/'state')
            base['ram_regions']={}
            for mutation in ({'machine':'pc,accel=kvm'},{'memory_mib':1024},{'argv':['-net','user']},
                             {'cpu':'host'},{'serial_commands':{'x':{'data_hex':'$(whoami)','ack_utf8':'x'}}},
                             {'roms':{'..':{'path':'/fixed/rom','sha256':'0'*64}}}):
                with self.subTest(mutation=mutation),self.assertRaises(WholeSystemError):
                    WholeSystem({'profiles':{'owned':{**base,**mutation}}},Path(directory)/'state')


@unittest.skipUnless(os.environ.get('RUNTIME_QEMU_ROOT') and shutil.which('gcc') and shutil.which('ld'),
                     'set RUNTIME_QEMU_ROOT for actual QEMU TCG whole-machine tests')
class WholeMachineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory=tempfile.TemporaryDirectory()
        cls.root=Path(cls.directory.name)
        spec=importlib.util.spec_from_file_location('build_machine_fixture',ROOT/'tools/build_machine_fixture.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        cls.fixture=module.build(cls.root/'kernel.elf')
        cls.base=profile(os.environ['RUNTIME_QEMU_ROOT'],cls.root/'kernel.elf')

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name)
        self.backend=WholeSystem({'profiles':{'owned':self.base}},Path(self.temporary.name)/'state')
        self.addCleanup(self.backend.close)

    def value(self,session):
        memory=self.backend.read_ram(session,'state')
        raw=bytes.fromhex(memory['data_hex'])
        self.assertEqual(int.from_bytes(raw[4:8],'little'),0x05550001)
        self.assertTrue(memory['vcpus_paused'])
        self.assertFalse(memory['host_physical_memory'])
        return int.from_bytes(raw[:4],'little')

    def test_real_boot_registered_UART_and_full_machine_checkpoint_restore(self):
        launched=self.backend.launch('owned')
        session=launched['session_id']
        self.assertFalse(launched['running'])
        ready=self.backend.resume(session,wait_ready=True)
        self.assertIn('owned-machine-ready',ready['serial_observation'])
        with self.assertRaisesRegex(WholeSystemError,'machine_ram_requires_paused_vcpu'):
            self.backend.read_ram(session,'state')
        self.backend.command(session,'increment');self.backend.pause(session)
        self.assertEqual(self.value(session),8)
        cpu_before=self.backend.registers(session)
        self.assertEqual(cpu_before['architecture'],'i386')
        saved=self.backend.checkpoint(session)
        self.assertGreater(saved['bytes'],1000)
        self.backend.resume(session)
        self.backend.command(session,'increment');self.backend.command(session,'increment')
        self.backend.pause(session);self.assertEqual(self.value(session),10)
        before=self.backend.status(session)
        restored=self.backend.restore(session,saved['checkpoint_id'])
        self.assertFalse(restored['running'])
        self.assertEqual(restored['machine_epoch'],2)
        self.assertNotEqual(restored['pid'],before['pid'])
        self.assertTrue(restored['prior_guest_addresses_require_revalidation'])
        self.assertEqual(self.value(session),8)
        self.assertEqual(self.backend.registers(session)['registers'],cpu_before['registers'])
        self.backend.resume(session);self.backend.command(session,'increment');self.backend.pause(session)
        self.assertEqual(self.value(session),9)
        self.assertTrue(self.backend.close_session(session)['owned_emulator_reaped'])

    def test_real_TCG_input_recording_replay_and_reverse_by_instruction_count(self):
        launched=self.backend.launch('owned',mode='record')
        session=launched['session_id']
        with self.assertRaisesRegex(WholeSystemError,'machine_restore_requires_normal_mode'):
            self.backend.restore(session,'unavailable')
        self.backend.resume(session,wait_ready=True)
        self.backend.command(session,'increment');self.backend.pause(session)
        early=self.backend.status(session)['icount']
        self.assertEqual(self.value(session),8)
        self.backend.resume(session);self.backend.command(session,'increment');self.backend.pause(session)
        late=self.backend.status(session)['icount']
        self.assertGreater(late,early)
        self.assertEqual(self.value(session),9)
        ended=self.backend.close_session(session)
        recording=ended['recording']['recording_id']
        self.assertGreater(ended['recording']['bytes'],0)
        with patch.object(self.backend,'status',side_effect=WholeSystemError('machine_qmp_timeout',effect_dispatched=True)):
            with self.assertRaisesRegex(WholeSystemError,'machine_launch_outcome_unknown'):
                self.backend.launch('owned',mode='replay',recording_id=recording)
        self.assertTrue(self.backend.recordings[recording]['finalized'])
        self.assertTrue(self.backend.recordings[recording]['path'].is_file())
        replay=self.backend.replay_to('owned',recording,early)
        key=replay['session_id']
        self.assertEqual(replay['icount'],early)
        self.assertEqual(self.value(key),8)
        with self.assertRaisesRegex(WholeSystemError,'machine_replay_external_input_denied'):
            self.backend.command(key,'increment')
        forward=self.backend.seek(key,late)
        self.assertEqual(forward['icount'],late)
        self.assertEqual(self.value(key),9)
        reversed_state=self.backend.seek(key,early)
        self.assertTrue(reversed_state['reversed'])
        self.assertEqual(reversed_state['machine_epoch'],2)
        self.assertEqual(reversed_state['icount'],early)
        self.assertEqual(self.value(key),8)
        unchanged=self.backend.seek(key,early)
        self.assertEqual(unchanged['icount'],early)
        self.assertEqual(unchanged['machine_epoch'],2)
        with self.assertRaisesRegex(WholeSystemError,'machine_recording_in_use'):
            self.backend.release_artifact('recording',recording)
        self.backend.close_session(key)
        self.assertTrue(self.backend.release_artifact('recording',recording)['released'])
        print('WHOLE_SYSTEM_REPLAY',{'engine':replay['qemu'],'early_icount':early,'late_icount':late,
              'values':[8,9,8],'recording_sha256':ended['recording']['sha256']})

    def test_digest_mismatch_capacity_and_checkpoint_tampering_fail_closed(self):
        bad=copy.deepcopy(self.base);bad['kernel_sha256']='0'*64
        other=WholeSystem({'profiles':{'bad':bad}},Path(self.temporary.name)/'bad')
        self.addCleanup(other.close)
        with self.assertRaisesRegex(RuntimeError,'digest_mismatch'):
            other.launch('bad')
        self.assertFalse(other.sessions)
        launched=self.backend.launch('owned');key=launched['session_id']
        self.backend.resume(key,wait_ready=True);self.backend.pause(key)
        saved=self.backend.checkpoint(key)
        path=self.backend.checkpoints[saved['checkpoint_id']]['path']
        path.chmod(0o600)
        with path.open('r+b') as stream:stream.write(b'altered')
        with self.assertRaisesRegex(WholeSystemError,'machine_checkpoint_digest_mismatch'):
            self.backend.restore(key,saved['checkpoint_id'])
        with self.assertRaisesRegex(WholeSystemError,'machine_unregistered_ram_region'):
            self.backend.read_ram(key,'MMIO')
        with self.assertRaisesRegex(WholeSystemError,'machine_unregistered_serial_command'):
            self.backend.command(key,'arbitrary')

    def test_owned_watchdog_expiry_fences_the_session(self):
        key=self.backend.launch('owned')['session_id']
        machine=self.backend.sessions[key]
        machine._expire()
        self.assertIsNotNone(machine.process.poll())
        with self.assertRaisesRegex(WholeSystemError,'machine_outcome_unresolved'):
            self.backend.status(key)
        self.assertTrue(self.backend.close_session(key)['owned_emulator_reaped'])

    def test_QMP_failure_after_launch_reaps_unreported_session_and_new_recording(self):
        original=self.backend._spawn
        created=[]
        def spawn(*args,**kwargs):
            machine=original(*args,**kwargs);created.append(machine);return machine
        for mode in ('normal','record'):
            with self.subTest(mode=mode),patch.object(self.backend,'_spawn',side_effect=spawn),patch.object(
                    self.backend,'status',side_effect=WholeSystemError('machine_qmp_timeout',effect_dispatched=True)):
                with self.assertRaisesRegex(WholeSystemError,'machine_launch_outcome_unknown') as error:
                    self.backend.launch('owned',mode=mode)
                self.assertTrue(error.exception.effect_dispatched)
            self.assertIsNotNone(created[-1].process.poll())
            self.assertTrue(created[-1].emulator_reaped)
            self.assertFalse(self.backend.sessions)
            self.assertFalse(self.backend.recordings)
            self.assertFalse(list(self.backend.directory.glob('vm-*')))
            self.assertFalse(list(self.backend.directory.glob('record-*')))

    def test_real_host_SIGKILL_kills_owned_VM_and_CPU_ceiling_is_effective(self):
        config=copy.deepcopy(self.base);config['lifetime_seconds']=5
        configuration=self.directory/'host-config.json'
        configuration.write_text(json.dumps({'profiles':{'owned':config}}))
        state=self.directory/'host-state'
        source=r'''
import json,sys,time
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from observation_extension.whole_system import WholeSystem
backend=WholeSystem(json.loads(Path(sys.argv[2]).read_text()),Path(sys.argv[3]))
print(json.dumps(backend.launch('owned')),flush=True)
time.sleep(60)
'''
        errors=tempfile.TemporaryFile(dir=self.directory)
        host=subprocess.Popen([sys.executable,'-c',source,str(RUNTIME),str(configuration),str(state)],
                              stdout=subprocess.PIPE,stderr=errors)
        descriptors=[]
        try:
            self.assertTrue(select.select([host.stdout],[],[],16)[0],'VM owner startup deadline')
            line=host.stdout.readline()
            if not line:
                errors.seek(0);self.fail(errors.read(4096).decode('utf-8','replace'))
            ready=json.loads(line);pid=ready['pid']
            descriptors=[os.pidfd_open(pid),os.pidfd_open(ready['controller_pid'])]
            status=Path(f'/proc/{pid}/status').read_text()
            self.assertRegex(status,r'(?m)^PPid:\s+'+str(ready['controller_pid'])+r'\s*$')
            controller_status=Path(f'/proc/{ready["controller_pid"]}/status').read_text()
            self.assertRegex(controller_status,r'(?m)^PPid:\s+'+str(host.pid)+r'\s*$')
            limits=Path(f'/proc/{pid}/limits').read_text()
            cpu=re.search(r'^Max cpu time\s+(\d+)\s+(\d+)',limits,re.MULTILINE)
            self.assertIsNotNone(cpu)
            self.assertTrue(0<int(cpu[1])<=6 and 0<int(cpu[2])<=6)
            self.assertTrue(ready['parent_death_guard'])
            host.kill();host.wait(timeout=2)
            deadline=time.monotonic()+3
            for descriptor in descriptors:
                self.assertTrue(select.select([descriptor],[],[],max(0,deadline-time.monotonic()))[0],
                                'QEMU or guardian survived owner SIGKILL')
            state_name='absent'
            try:
                state_name=re.search(r'^State:\s+(\w)',Path(f'/proc/{pid}/status').read_text(),re.MULTILINE)[1]
            except FileNotFoundError:
                pass
            self.assertEqual(state_name,'absent','guardian failed to reap its QEMU child')
            guardian_state='absent'
            try:
                guardian_state=re.search(r'^State:\s+(\w)',Path(f'/proc/{ready["controller_pid"]}/status').read_text(),re.MULTILINE)[1]
            except FileNotFoundError:
                pass
            self.assertIn(guardian_state,('Z','absent'))
            print('WHOLE_SYSTEM_HOST_DEATH',{'target_exit_confirmed':True,
                'pid_reaped':True,'state':state_name,'guardian_state':guardian_state,
                'CPU_ceiling_seconds':int(cpu[2])})
        finally:
            if host.poll() is None:host.kill();host.wait(timeout=2)
            for descriptor in descriptors:
                if not select.select([descriptor],[],[],1)[0]:
                    try:signal.pidfd_send_signal(descriptor,signal.SIGKILL)
                    except ProcessLookupError:pass
                os.close(descriptor)
            host.stdout.close();errors.close()

    def test_short_lived_launch_worker_does_not_terminate_the_live_VM(self):
        launched=[];errors=[]
        def launch():
            try:launched.append(self.backend.launch('owned'))
            except BaseException as error:errors.append(error)
        worker=threading.Thread(target=launch)
        worker.start();worker.join(10)
        self.assertFalse(worker.is_alive(),'launch worker did not finish')
        self.assertFalse(errors,errors)
        ready=launched[0];key=ready['session_id']
        self.assertNotEqual(ready['pid'],ready['controller_pid'])
        self.assertEqual(ready['watchdog_scope'],'independent_host_TGID_guardian')
        guardian_limits=Path(f'/proc/{ready["controller_pid"]}/limits').read_text()
        cpu=re.search(r'^Max cpu time\s+(\d+)\s+(\d+)',guardian_limits,re.MULTILINE)
        self.assertIsNotNone(cpu);self.assertLessEqual(int(cpu[2]),1)
        self.backend.resume(key,wait_ready=True)
        self.backend.command(key,'increment');self.backend.pause(key)
        self.assertEqual(self.value(key),8)
        self.assertTrue(self.backend.close_session(key)['owned_emulator_reaped'])

    def test_independent_guardian_enforces_deadline_while_host_is_alive(self):
        profile=copy.deepcopy(self.base);profile['lifetime_seconds']=5
        backend=WholeSystem({'profiles':{'owned':profile}},self.directory/'deadline-state')
        self.addCleanup(backend.close)
        ready=backend.launch('owned');key=ready['session_id']
        machine=backend.sessions[key]
        descriptor=os.dup(machine.pidfd)
        guardian=os.pidfd_open(ready['controller_pid'])
        try:
            exited=wait_pidfd(descriptor,machine.deadline+1)
            if not exited:
                details={'deadline':machine.deadline,'now':time.monotonic(),
                    'guardian':Path(f'/proc/{ready["controller_pid"]}/status').read_text(),
                    'emulator':Path(f'/proc/{ready["pid"]}/status').read_text()}
                self.fail('independent VM deadline did not fire: '+json.dumps(details))
            self.assertTrue(select.select([guardian],[],[],2)[0],'guardian failed to finish deadline cleanup')
            with self.assertRaisesRegex(WholeSystemError,'machine_outcome_unresolved'):
                backend.status(key)
            closed=backend.close_session(key)
            self.assertTrue(closed['emulator_exit_confirmed'])
            self.assertTrue(closed['owned_emulator_reaped'])
            self.assertTrue(closed['owned_controller_reaped'])
        finally:
            os.close(descriptor);os.close(guardian)

    def test_guardian_SIGKILL_still_kills_emulator_and_reports_unreaped_state(self):
        ready=self.backend.launch('owned');key=ready['session_id']
        machine=self.backend.sessions[key]
        descriptor=os.dup(machine.pidfd)
        try:
            machine.process.kill();machine.process.wait(timeout=2)
            self.assertTrue(select.select([descriptor],[],[],3)[0],
                            'QEMU survived the independent guardian being SIGKILLed')
            closed=self.backend.close_session(key)
            self.assertTrue(closed['emulator_exit_confirmed'])
            self.assertTrue(closed['owned_controller_reaped'])
            self.assertFalse(closed['owned_emulator_reaped'])
        finally:
            os.close(descriptor)


if __name__=='__main__':
    unittest.main()
