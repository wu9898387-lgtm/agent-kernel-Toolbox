"""Real JDI object control and checked HotSwap, using an owned Java fixture.

JVM runtime field metadata is deliberately not treated as a physical address.
No existing process is attached. Missing JDK compiler/JDI modules are explicit
skips; protocol mocks are used only for a post-dispatch transport fault.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import select
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.managed_jvm import ManagedJvm,ManagedJvmError,classpath_sha256

JAVA=Path(os.environ.get('RUNTIME_JAVA','/usr/lib/jvm/java-21-openjdk-amd64/bin/java'))
try:
    modules=subprocess.check_output([str(JAVA),'--list-modules'],text=True,timeout=3)
    HAS_JDI='jdk.jdi@' in modules and 'jdk.compiler@' in modules
except (OSError,subprocess.SubprocessError):
    HAS_JDI=False


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(sys.platform.startswith('linux') and HAS_JDI and hasattr(os,'pidfd_open'),
                     'a Linux JDK with jdk.compiler/jdk.jdi and pidfd is required')
class ManagedJvmTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory()
        cls.root=Path(cls.temporary.name)
        try:
            spec=importlib.util.spec_from_file_location('build_managed_agent',ROOT/'native/managed-jvm/build.py')
            builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
            cls.helper=builder.build(JAVA,cls.root/'helper')
            original=(ROOT/'tests/fixtures/recovery/ManagedFixture.java').read_text()
            cls.target=cls.compile(original,'original')
            doubled=original.replace('value += delta;','value += delta * 2;',1)
            if doubled==original:
                raise AssertionError('fixture method source changed')
            cls.doubled=cls.compile(doubled,'double')/'runtimeaccess/managed/ManagedFixture$Node.class'
            schema=original.replace('public int value = 7;','public int value = 7; public long addedField = 0;',1)
            if schema==original:
                raise AssertionError('fixture schema source changed')
            cls.schema=cls.compile(schema,'schema')/'runtimeaccess/managed/ManagedFixture$Node.class'
            cls.changed_root=cls.compile('''package review;
public class FailAfterAdvance {
    public static class State { public int value = 7; }
    public static Object ROOT = new State();
    public static void ready() {}
    public static void main(String[] args) throws Exception {
        ready(); ROOT = new Object(); ready(); Thread.sleep(10000);
    }
}''','changed-root',filename='FailAfterAdvance.java')
            cls.config={'java':str(JAVA.resolve()),'java_sha256':digest(JAVA.resolve()),
                **cls.helper,'class_path':str(cls.target),'class_path_sha256':classpath_sha256(cls.target),
                'main_class':'runtimeaccess.managed.ManagedFixture',
                'root_class':'runtimeaccess.managed.ManagedFixture','safe_point_method':'ready','root_field':'ROOT',
                'fields':['value','state','enabled','label'],'methods':['bump'],
                'patches':{'double':{'path':str(cls.doubled),'sha256':digest(cls.doubled)},
                           'schema':{'path':str(cls.schema),'sha256':digest(cls.schema)}}}
        except BaseException:
            cls.temporary.cleanup()
            raise

    @classmethod
    def compile(cls,source,name,*,filename='ManagedFixture.java'):
        directory=cls.root/name
        directory.mkdir()
        java=directory/filename;java.write_text(source)
        output=directory/'classes';output.mkdir()
        subprocess.run([str(JAVA),'com.sun.tools.javac.Main','-g','-encoding','UTF-8',
                        '-d',str(output),str(java)],check=True,timeout=20)
        return output

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name)

    def client(self,config=None):
        client=ManagedJvm(config or self.config,self.directory,bundle_root=ROOT)
        self.addCleanup(client.close)
        self.assertTrue(client.initial['ok'],client.initial)
        self.assertFalse(client.initial['physical_address_known'])
        return client

    def test_live_runtime_fields_method_invocation_and_GC_stable_identity(self):
        client=self.client()
        initial=client.snapshot();object_id=initial['object_id']
        self.assertEqual(initial['values'],{'value':7,'state':0,'enabled':True,'label':'owned-jvm-object'})
        self.assertEqual(initial['runtime'],'JVM_JDI')
        self.assertEqual(initial['class_signature'],'Lruntimeaccess/managed/ManagedFixture$Node;')
        self.assertTrue(all(item['location_source']=='JVM_runtime_field_metadata' for item in initial['layout']))
        self.assertFalse(any('address' in item or 'offset' in item for item in initial['layout']))
        changed=client.set_field(object_id,'value',7,9)
        self.assertTrue(changed['ok'],changed);self.assertEqual(changed['status'],'verified')
        called=client.invoke(object_id,'bump',9,3)
        self.assertTrue(called['ok'],called)
        self.assertEqual(called['value'],12)
        self.assertEqual(called['snapshot']['values']['state'],1)
        # bump calls System.gc(); strong root identity must survive it.
        self.assertEqual(called['snapshot']['object_id'],object_id)
        observed=client.advance()
        self.assertTrue(observed['ok'],observed)
        self.assertEqual(observed['values']['value'],12)
        self.assertEqual(observed['object_id'],object_id)
        self.assertIn('managed-state=12',observed['stdout']['prefix'])
        self.assertFalse(observed['physical_address_known'])

    def test_checked_redefinition_changes_future_method_body_and_rejects_schema_change(self):
        client=self.client();initial=client.snapshot();object_id=initial['object_id']
        self.assertTrue(initial['class_redefinition_supported'])
        self.assertTrue(client.set_field(object_id,'value',7,9)['ok'])
        self.assertEqual(client.invoke(object_id,'bump',9,3)['value'],12)
        patched=client.redefine(object_id,0,'double',12)
        self.assertTrue(patched['ok'],patched)
        self.assertEqual(patched['status'],'redefined')
        self.assertEqual(patched['class_epoch'],1)
        self.assertTrue(patched['existing_frames_may_use_old_bytecode'])
        self.assertEqual(patched['snapshot']['object_id'],object_id)
        changed=client.invoke(object_id,'bump',12,3)
        self.assertTrue(changed['ok'],changed);self.assertEqual(changed['value'],18)
        denied=client.redefine(object_id,1,'schema',18)
        self.assertFalse(denied['ok'],denied)
        self.assertEqual(denied['error'],'managed_class_schema_change_denied')
        self.assertFalse(denied['dispatched'])
        after=client.snapshot()
        self.assertEqual(after['class_epoch'],1)
        self.assertEqual(after['values']['value'],18)
        self.assertFalse(client.unresolved)

    def test_expected_state_stale_handles_and_class_epochs_refuse_without_writes(self):
        client=self.client();object_id=client.snapshot()['object_id']
        for result,error in [
            (client.set_field(object_id,'value',8,99),'managed_precondition_mismatch'),
            (client.invoke(object_id,'bump',8,99),'managed_precondition_mismatch'),
            (client.redefine(object_id,0,'double',8),'managed_precondition_mismatch'),
            (client.set_field(str(int(object_id)+1),'value',7,99),'managed_stale_object_handle'),
            (client.redefine(object_id,1,'double',7),'managed_stale_class_epoch')]:
            with self.subTest(error=error):
                self.assertFalse(result['ok'],result)
                self.assertEqual(result['error'],error)
                self.assertFalse(result['dispatched'])
        self.assertEqual(client.snapshot()['values']['value'],7)
        self.assertFalse(client.unresolved)
        self.assertTrue(client.set_field(object_id,'value',7,9)['ok'])

    def test_grants_field_types_final_fields_and_value_boundaries(self):
        client=self.client();object_id=client.snapshot()['object_id']
        for operation,error in [
            (lambda:client.set_field(object_id,'missing',7,9),'managed_field_not_allowed'),
            (lambda:client.invoke(object_id,'unknown',7,1),'managed_method_not_allowed'),
            (lambda:client.redefine(object_id,0,'unknown',7),'managed_patch_not_allowed'),
            (lambda:client.set_field('0','value',7,9),'managed_invalid_object_id'),
            (lambda:client.set_field(object_id,'value',True,9),'managed_invalid_value'),
            (lambda:client.invoke(object_id,'bump',7,2**31),'managed_invalid_method_argument')]:
            with self.subTest(error=error),self.assertRaisesRegex(ManagedJvmError,error):
                operation()
        final=client.set_field(object_id,'label',0,0)
        self.assertFalse(final['ok']);self.assertEqual(final['error'],'managed_final_field_write_denied')
        too_large=client.set_field(object_id,'value',7,2**31)
        self.assertFalse(too_large['ok']);self.assertEqual(too_large['error'],'managed_value_out_of_range')
        self.assertTrue(client.set_field(object_id,'enabled',1,0)['ok'])
        self.assertFalse(client.snapshot()['values']['enabled'])
        self.assertTrue(client.set_field(object_id,'state',0,-(2**63))['ok'])
        self.assertEqual(client.snapshot()['values']['state'],-(2**63))
        self.assertEqual(client.snapshot()['values']['value'],7)

    def test_all_pinned_profile_digests_are_checked_before_launch(self):
        for key in ('java_sha256','helper_sha256','class_path_sha256','patch'):
            config=copy.deepcopy(self.config)
            if key=='patch':config['patches']['double']['sha256']='0'*64
            else:config[key]='0'*64
            before=len(os.listdir('/proc/self/fd'))
            with self.subTest(key=key),patch('observation_extension.managed_jvm.subprocess.Popen') as launch:
                with self.assertRaisesRegex(ManagedJvmError,'digest_mismatch'):
                    ManagedJvm(config,self.directory,bundle_root=ROOT)
                launch.assert_not_called()
            self.assertEqual(len(os.listdir('/proc/self/fd')),before)
        self.assertFalse(list(self.directory.glob('managed-*')))

    def test_empty_method_allowlist_still_allows_authorized_field_operations(self):
        config=copy.deepcopy(self.config);config['methods']=[];config['patches']={}
        client=self.client(config);initial=client.snapshot()
        self.assertEqual(initial['values']['value'],7)
        self.assertTrue(client.set_field(initial['object_id'],'value',7,11)['ok'])
        self.assertEqual(client.snapshot()['values']['value'],11)
        with self.assertRaisesRegex(ManagedJvmError,'managed_method_not_allowed'):
            client.invoke(initial['object_id'],'bump',11,1)

    def test_advance_followed_by_missing_root_field_is_unknown_and_fences(self):
        config=copy.deepcopy(self.config)
        config.update(class_path=str(self.changed_root),class_path_sha256=classpath_sha256(self.changed_root),
            main_class='review.FailAfterAdvance',root_class='review.FailAfterAdvance',
            fields=['value'],methods=[],patches={})
        client=self.client(config)
        self.assertEqual(client.initial['values']['value'],7)
        result=client.advance()
        self.assertFalse(result['ok'],result)
        self.assertEqual(result['status'],'unknown')
        self.assertTrue(result['dispatched'])
        self.assertTrue(client.unresolved)
        with self.assertRaisesRegex(ManagedJvmError,'managed_outcome_unresolved'):
            client.advance()
        self.assertTrue(client.close()['target_exit_confirmed'])

    def test_transport_loss_after_method_dispatch_is_unknown_and_target_exits(self):
        client=self.client();object_id=client.snapshot()['object_id']
        target_fd=os.dup(client.target_fd)
        self.addCleanup(os.close,target_fd)
        with patch.object(client,'_read',side_effect=ManagedJvmError('managed_response_timeout',effect_dispatched=True)):
            result=client.invoke(object_id,'bump',7,3)
        self.assertFalse(result['ok']);self.assertEqual(result['status'],'unknown')
        self.assertTrue(result['dispatched']);self.assertTrue(client.unresolved)
        self.assertTrue(select.select([target_fd],[],[],4)[0],'owned JVM still active after transport loss')
        with self.assertRaisesRegex(ManagedJvmError,'managed_closed|managed_outcome_unresolved'):
            client.invoke(object_id,'bump',7,3)
        self.assertTrue(client.close()['target_exit_confirmed'])

    def test_normal_close_reaps_processes_is_idempotent_and_releases_descriptors(self):
        before=len(os.listdir('/proc/self/fd'))
        client=ManagedJvm(self.config,self.directory,bundle_root=ROOT)
        self.addCleanup(client.close)
        target=client.initial['pid']
        closed=client.close()
        self.assertTrue(closed['target_exit_confirmed'])
        self.assertIsNotNone(client.child.poll())
        self.assertEqual(client.close(),closed)
        self.assertEqual(len(os.listdir('/proc/self/fd')),before)
        self.assertFalse(Path(f'/proc/{target}').exists(),'normal close left an unreaped target')

    def test_guardian_exits_target_when_owned_controller_host_is_SIGKILLed(self):
        state=self.directory/'host-state';state.mkdir()
        config=self.directory/'profile.json';config.write_text(json.dumps(self.config))
        source=r'''
import json,os,re,sys,time
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from observation_extension.managed_jvm import ManagedJvm
c=ManagedJvm(json.loads(Path(sys.argv[2]).read_text()),Path(sys.argv[3]),bundle_root=Path(sys.argv[4]))
s=c.snapshot()
status=Path('/proc/'+str(s['pid'])+'/status').read_text()
controller=int(re.search(r'^PPid:\s+(\d+)',status,re.MULTILINE).group(1))
print(json.dumps({'target':s['pid'],'guardian':c.child.pid,'controller':controller}),flush=True)
time.sleep(60)
'''
        errors=tempfile.TemporaryFile(dir=self.directory)
        host=subprocess.Popen([sys.executable,'-c',source,str(RUNTIME),str(config),str(state),str(ROOT)],
                              stdout=subprocess.PIPE,stderr=errors)
        descriptors=[]
        try:
            self.assertTrue(select.select([host.stdout],[],[],16)[0],'managed host startup deadline')
            line=host.stdout.readline()
            if not line:
                errors.seek(0);self.fail('managed host failed: '+errors.read(4096).decode('utf-8','replace'))
            processes=json.loads(line)
            descriptors=[os.pidfd_open(processes[name]) for name in ('target','controller','guardian')]
            host.kill();host.wait(timeout=3)
            deadline=time.monotonic()+6
            for descriptor in descriptors:
                self.assertTrue(select.select([descriptor],[],[],max(0,deadline-time.monotonic()))[0],
                                'owned JVM/controller/guardian survived host SIGKILL')
        finally:
            if host.poll() is None:host.kill();host.wait(timeout=3)
            for descriptor in descriptors:
                if not select.select([descriptor],[],[],0)[0]:
                    try:signal.pidfd_send_signal(descriptor,signal.SIGKILL)
                    except ProcessLookupError:pass
                os.close(descriptor)
            host.stdout.close();errors.close()


if __name__=='__main__':
    unittest.main()
