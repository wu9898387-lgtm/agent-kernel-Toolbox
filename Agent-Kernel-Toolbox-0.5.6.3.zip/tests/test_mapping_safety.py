"""Linux mapping semantics and failure-closed memory access regression checks."""
import ctypes
import hashlib
import mmap
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_runtime import ProcessSession, NativeRuntimeError
from observation_extension.native_control import _region, cpu_environment


def mapping(**changes):
    row = {'start': '0x1000', 'end': '0x2000', 'permissions': 'rw-p',
           'offset': '0x0', 'device': '00:00', 'inode': '0', 'path': '',
           'vm_flags': ['rd', 'wr', 'mr', 'mw', 'ac'],
           'memory_kind': 'private_anonymous', 'ordinary_memory': True,
           'mapping_fingerprint': 'a' * 64}
    row.update(changes)
    return row


def fake_session(rows):
    session = ProcessSession.__new__(ProcessSession)
    session._memory_binding_invalid = False
    session.memory_consumed = 0
    session.allow_memory = True
    session.memfd = 22
    session.identity = {'pid': 1}
    session._check = lambda: None
    session.maps = lambda: rows
    return session


class MappingGuardTests(unittest.TestCase):
    def test_device_mapping_is_denied_before_any_read(self):
        session = fake_session([mapping(vm_flags=['rd', 'io', 'pf'],
                                        memory_kind='device_or_pfn', ordinary_memory=False)])
        with patch('observation_extension.native_runtime.os.pread', return_value=b'x') as read:
            with self.assertRaisesRegex(NativeRuntimeError, 'nonordinary_memory_mapping'):
                session._read_memory_bytes(0x1000, 1)
            read.assert_not_called()
        self.assertEqual(session.memory_consumed, 0)

    def test_unknown_mapping_is_denied_before_search(self):
        session = fake_session([mapping(vm_flags=None, memory_kind='unknown', ordinary_memory=False)])
        with patch('observation_extension.native_runtime.os.pread', return_value=b'x') as read:
            with self.assertRaisesRegex(NativeRuntimeError, 'nonordinary_memory_mapping'):
                session.search_memory(0x1000, 1, b'x')
            read.assert_not_called()

    def test_loader_relro_split_between_maps_and_smaps_is_unknown_and_denied(self):
        session = fake_session([])
        del session.maps
        session.procfd = 11
        before = b'00403000-00405000 rw-p 00002000 00:22 77 /tmp/owned-app\n'
        after = (b'00403000-00404000 r--p 00002000 00:22 77 /tmp/owned-app\n'
                 b'VmFlags: rd mr mw me ac\n'
                 b'00404000-00405000 rw-p 00003000 00:22 77 /tmp/owned-app\n'
                 b'VmFlags: rd wr mr mw me ac\n')
        def procfs(_directory, name, _limit):
            return before if name == 'maps' else after
        with patch('observation_extension.native_runtime._read_at', side_effect=procfs), \
                patch('observation_extension.native_runtime.os.pread') as read:
            observed = session.maps()
            self.assertEqual(observed[0]['memory_kind'], 'unknown')
            self.assertIsNone(observed[0]['vm_flags'])
            with self.assertRaisesRegex(NativeRuntimeError, 'nonordinary_memory_mapping'):
                session._read_memory_bytes(0x404060, 8)
            read.assert_not_called()

    def test_mapping_change_during_read_invalidates_binding(self):
        session = fake_session([])
        rows = [mapping()]
        session.maps = lambda: rows
        def changed(_fd, _size, _address):
            rows[0] = mapping(permissions='r--p', mapping_fingerprint='b' * 64)
            return b'x'
        with patch('observation_extension.native_runtime.os.pread', side_effect=changed):
            with self.assertRaisesRegex(NativeRuntimeError, 'memory_mapping_changed'):
                session._read_memory_bytes(0x1000, 1)
        self.assertTrue(session._memory_binding_invalid)

    def test_shared_write_region_is_denied(self):
        session = fake_session([mapping(permissions='rw-s', memory_kind='shared_anonymous')])
        session.write_regions = {'value': {'address': '0x1000', 'size': 8}}
        with self.assertRaisesRegex(NativeRuntimeError, 'write_requires_unique_writable_nonexecutable_mapping'):
            _region(session, 'value', 0, 8)

    def test_changed_write_region_does_not_rebind_silently(self):
        rows = [mapping()]
        session = fake_session(rows)
        session.write_regions = {'value': {'address': '0x1000', 'size': 8}}
        self.assertEqual(_region(session, 'value', 0, 8), 0x1000)
        rows[0] = mapping(offset='0x1000', mapping_fingerprint='b' * 64)
        with self.assertRaisesRegex(NativeRuntimeError, 'memory_write_mapping_changed'):
            _region(session, 'value', 0, 8)

    def test_inaccessible_cpu_configuration_is_unknown_not_claimed_available(self):
        with patch('builtins.open', side_effect=PermissionError), patch('os.scandir', side_effect=PermissionError):
            result = cpu_environment()
        self.assertFalse(result['preempt_rt']['configuration_known'])
        self.assertIsNone(result['pmu']['perf_event_paranoid'])
        self.assertEqual(result['pmu']['event_sources'], [])
        self.assertFalse(result['instrumentation_access_proven'])
        self.assertFalse(result['configuration_changed'])


@unittest.skipUnless(sys.platform == 'linux', 'Linux procfs required')
class LiveMappingTests(unittest.TestCase):
    def test_cow_shared_and_device_are_distinct_and_no_pfn_claim(self):
        page = os.sysconf('SC_PAGE_SIZE')
        with tempfile.TemporaryFile() as stream:
            stream.truncate(page)
            private = mmap.mmap(stream.fileno(), page, flags=mmap.MAP_PRIVATE)
            shared = mmap.mmap(stream.fileno(), page, flags=mmap.MAP_SHARED)
            private_view = (ctypes.c_char * page).from_buffer(private)
            shared_view = (ctypes.c_char * page).from_buffer(shared)
            try:
                with ProcessSession.attach(os.getpid(), allow_memory=True) as session:
                    a = ctypes.addressof(private_view)
                    b = ctypes.addressof(shared_view)
                    cow = session.memory_mapping(a, 8)
                    shmem = session.memory_mapping(b, 8)
                    self.assertEqual(cow['memory_kind'], 'private_file_cow')
                    self.assertEqual(shmem['memory_kind'], 'shared_file')
                    self.assertTrue(shmem['other_writers_possible'])
                    self.assertFalse(cow['physical_page_identity_proven'])
                    self.assertEqual(len(cow['mapping_fingerprint']), 64)
                    special = [row for row in session.maps() if row['path'].startswith('[vvar')]
                    if special:
                        self.assertFalse(special[0]['ordinary_memory'])
                        with self.assertRaisesRegex(NativeRuntimeError, 'nonordinary_memory_mapping'):
                            session._read_memory_bytes(int(special[0]['start'], 16), 1)
                    before = session.memory_consumed
                    old = session.memory_mapping(a, 8)['mapping_fingerprint']
                    libc = ctypes.CDLL(None, use_errno=True)
                    libc.mprotect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
                    libc.mprotect.restype = ctypes.c_int
                    self.assertEqual(libc.mprotect(a, page, mmap.PROT_READ), 0)
                    self.assertNotEqual(session.memory_mapping(a, 8)['mapping_fingerprint'], old)
                    self.assertEqual(session.memory_consumed, before)
                    self.assertEqual(libc.mprotect(a, page, mmap.PROT_READ | mmap.PROT_WRITE), 0)
            finally:
                del private_view, shared_view
                private.close();shared.close()


if __name__ == '__main__':
    unittest.main()
