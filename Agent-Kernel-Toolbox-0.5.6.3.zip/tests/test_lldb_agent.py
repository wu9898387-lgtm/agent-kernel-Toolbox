"""Real optional native LLDB SDK/stdio/MCP integration, not a mocked debugger."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0,str(RUNTIME))
from observation_extension.runtime_host import RuntimeHost,SPECS
from observation_extension.runtime_state import canonical
from observation_extension.native_runtime import ProcessSession


@unittest.skipUnless(os.environ.get('RUNTIME_LLDB_PYTHON') and os.environ.get('RUNTIME_LLDB_BINDINGS') and shutil.which('gcc'),
                     'set a native LLDB interpreter and binding directory to run real SDK checks')
class LLDBAgentTests(unittest.TestCase):
    def test_host_cleanup_detaches_running_app_instead_of_terminating_it(self):
        with tempfile.TemporaryDirectory() as directory:
            directory=Path(directory);binary=directory/'native-app'
            subprocess.run(['gcc','-g','-O0','-no-pie',str(ROOT/'tests/fixtures/native_control_app.c'),'-o',str(binary)],check=True,timeout=10)
            profile={'argv':[str(binary)],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'allow_debug':True}
            path=directory/'profile.json';path.write_text(json.dumps(profile))
            environment={'PYTHONPATH':os.environ['RUNTIME_LLDB_BINDINGS']}
            for key in ('LD_LIBRARY_PATH','LLDB_DEBUGSERVER_PATH'):
                if os.environ.get(key):environment[key]=os.environ[key]
            host=RuntimeHost({'schema_version':1,'state_directory':str(directory/'state'),'allowed_tools':list(SPECS),
                'debuggers':{'app':{'argv':[os.environ['RUNTIME_LLDB_PYTHON'],str(ROOT/'tools/lldb_agent.py'),'--config',str(path)],
                'profile_sha256':hashlib.sha256(canonical(profile)).hexdigest(),'env':environment}}},bundle_root=ROOT)
            target=None
            try:
                result=host.call('debugger.open',{'target':'app','request_id':'launch-detach-check'})
                self.assertTrue(result['ok'],result)
                target=ProcessSession.attach(result['data']['pid'])
                identity=target.identity
                target.close();target=ProcessSession.attach(identity['pid'],expected_identity=identity,allow_terminate=True)
                self.assertFalse(host.close()['cleanup_errors']);host=None
                self.assertFalse(any(t['state'].startswith('T') for t in target.threads()))
                self.assertIn('TracerPid:\t0\n',Path(f'/proc/{target.pid}/status').read_text())
            finally:
                if host:host.close()
                if target:target.terminate_selected();target.close()

    def test_real_native_debugger_memory_registers_single_step_and_postcondition(self):
        with tempfile.TemporaryDirectory() as directory:
            directory=Path(directory);binary=directory/'native-app';business=directory/'business-state'
            subprocess.run(['gcc','-g','-O0','-no-pie',str(ROOT/'tests/fixtures/native_control_app.c'),'-o',str(binary)],check=True,timeout=10)
            symbols={line.split()[2]:int(line.split()[0],16) for line in subprocess.check_output(['nm',str(binary)],text=True).splitlines() if len(line.split())==3}
            profile={'argv':[str(binary),str(business)],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
                     'allow_debug':True,'allow_memory':True,'allow_memory_write':True,'allow_step':True,
                     'write_regions':{'value':{'symbol':'native_value','size':8}}}
            path=directory/'debugger-profile.json';path.write_text(json.dumps(profile))
            environment={'PYTHONPATH':os.environ['RUNTIME_LLDB_BINDINGS']}
            if os.environ.get('LD_LIBRARY_PATH'):environment['LD_LIBRARY_PATH']=os.environ['LD_LIBRARY_PATH']
            if os.environ.get('LLDB_DEBUGSERVER_PATH'):environment['LLDB_DEBUGSERVER_PATH']=os.environ['LLDB_DEBUGSERVER_PATH']
            config={'schema_version':1,'state_directory':str(directory/'state'),'allowed_tools':list(SPECS),
                    'debuggers':{'native':{'argv':[os.environ['RUNTIME_LLDB_PYTHON'],str(ROOT/'tools/lldb_agent.py'),'--config',str(path)],
                        'profile_sha256':hashlib.sha256(canonical(profile)).hexdigest(),'env':environment}}}
            host=RuntimeHost(config,bundle_root=ROOT);session=None
            def call(name,args):
                result=host.call(name,args);self.assertTrue(result['ok'],result);return result['data']
            try:
                opened=call('debugger.open',{'target':'native','request_id':'debugger-launch'})
                session=opened['debugger_session'];self.assertEqual(opened['pointer_bits'],64)
                inspected=call('debugger.inspect',{'debugger_session':session,'request_id':'debugger-registers'})
                self.assertTrue(inspected['threads'][0]['registers'])
                value=call('debugger.read_value',{'debugger_session':session,'address':hex(symbols['native_value']),
                    'size':8,'type':'uint64','request_id':'debugger-read'})
                self.assertEqual(value['value'],['7'])
                patched=call('debugger.write_memory',{'debugger_session':session,'region':'value','offset':0,
                    'data_hex':(13).to_bytes(8,opened['byte_order']).hex(),'expected_sha256':value['sha256'],'request_id':'debugger-write'})
                self.assertEqual(patched['status'],'verified')
                deadline=time.monotonic()+3
                while not business.exists() or business.read_text()!='13 home':
                    if time.monotonic()>deadline:self.fail('LLDB memory write was not observed by the native APP')
                    time.sleep(.01)
                stepped=call('debugger.step',{'debugger_session':session,'thread_index':inspected['threads'][0]['index_id'],
                    'instructions':1,'request_id':'debugger-step'})
                self.assertEqual(stepped['instructions_requested'],1)
                self.assertIsNotNone(call('debugger.status',{'debugger_session':session})['pid'])
                self.assertTrue(call('debugger.terminate',{'debugger_session':session,'request_id':'debugger-terminate'})['exited'])
                call('debugger.detach',{'debugger_session':session,'request_id':'debugger-detach'});session=None
            finally:
                if session:
                    host.call('debugger.terminate',{'debugger_session':session,'request_id':'debugger-failure-cleanup'})
                self.assertFalse(host.close()['cleanup_errors'])


if __name__=='__main__':unittest.main()
