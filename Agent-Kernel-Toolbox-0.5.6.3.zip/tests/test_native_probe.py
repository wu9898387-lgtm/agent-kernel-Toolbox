"""Real Frida observations of owned, compiler-built x86_64 fixtures only."""
import copy
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.native_probe import NativeProbe,NativeProbeError

PYTHON=Path(os.environ.get('RUNTIME_FRIDA_PYTHON','/workspace/work/toolchains/frida-venv/bin/python'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(sys.platform=='linux' and PYTHON.is_file() and shutil.which('gcc'),
                     'Linux pidfd, gcc and installed Frida Python required')
class NativeProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory()
        cls.directory=Path(cls.temporary.name)
        cls.target=cls.directory/'owned-probe'
        subprocess.run([shutil.which('gcc'),'-g','-O0','-fno-inline','-fno-builtin','-rdynamic',
            str(ROOT/'tests/fixtures/recovery/native_probe_target.c'),
            str(ROOT/'tests/fixtures/recovery/native_probe_access.S'),'-o',str(cls.target)],check=True,timeout=20)
        rows=subprocess.check_output(['nm','-S','--defined-only',str(cls.target)],text=True).splitlines()
        cls.symbols={row.split()[3]:(int(row.split()[0],16),int(row.split()[1],16))
                     for row in rows if len(row.split())==4}

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.state=Path(self.temp.name)/'state'
        self.oracle=Path(self.temp.name)/'oracle.json'
        self.settings={'python':str(PYTHON),'python_sha256':sha(PYTHON),'profiles':{'owned':{
            'executable':str(self.target),'sha256':sha(self.target),
            'functions':{name:self.symbols[name][1] for name in ('probe_work','probe_access')},
            'entry_function':'probe_work','argv':[str(self.oracle),'1'],
            'registration_hooks':{'define':'ra_probe_object','retire':'ra_probe_retire','move':'ra_probe_move'},
            'environment_functions':['clock_gettime'],
            'lifetime_ms':5000}}}

    def backend(self):
        value=NativeProbe(self.settings,self.state,bundle_root=ROOT)
        self.addCleanup(value.close)
        return value

    def collect(self, backend, session, seconds=6):
        events=[];cursor=0;deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            result=backend.poll(session,cursor,max_events=128)
            events.extend(result['events']);cursor=result['next_cursor']
            if result['state']=='closed' and not result['events']:
                return events,result
            time.sleep(.01)
        self.fail('owned probe did not reach a bounded terminal state')

    def test_real_effective_addresses_access_size_and_no_value_reads(self):
        backend=self.backend();opened=backend.open('owned')
        events,result=self.collect(backend,opened['probe_session'])
        oracle=json.loads(self.oracle.read_text())
        self.assertEqual(oracle['returned'],34)
        self.assertFalse(result['memory_values_read'])
        self.assertFalse(result['complete_execution_trace_proven'])
        self.assertTrue(result['cleanup']['target_exit_confirmed'])
        module=result['module'];base=int(module['base'],16)
        start=base+self.symbols['probe_access'][0]
        expected=[(0,int(oracle['first'],16),'read'),(3,int(oracle['first'],16)+8,'write'),
                  (7,int(oracle['first'],16)+8,'read'),(11,int(oracle['global'],16),'read')]
        memory=[event for event in events if event['kind']=='memory']
        for offset,address,access in expected:
            matches=[event for event in memory if int(event['pc'],16)==start+offset and int(event['address'],16)==address]
            self.assertTrue(matches,(offset,hex(address),memory))
            event=matches[0]
            self.assertEqual((event['size'],event['access'],event['phase'],event['committed']),(8,access,'before',False))
            self.assertIn(event['operand']['access'],('r','w','rw'))
            self.assertNotIn('value',event)
        self.assertFalse(any(int(event['pc'],16)==start+18 for event in memory),'LEA must not be a memory access')
        self.assertTrue(any(event['kind']=='unsupported' and event['reason']=='vector_operand' for event in events))
        self.assertTrue(any(event['kind']=='unsupported' and event['reason']=='implicit_memory_not_reconstructed' for event in events))
        self.assertTrue(all(event['source']=='native_probe' and event['session_id']==opened['probe_session'] for event in events))
        self.assertEqual([event['seq'] for event in events],sorted(set(event['seq'] for event in events)))
        self.assertTrue(all(type(event['tid']) is int for event in events))
        self.assertEqual(module['build_sha'],sha(self.target))
        self.assertEqual(module['page_size'],os.sysconf('SC_PAGE_SIZE'))
        environment=[event for event in events if event['kind']=='environment']
        self.assertTrue(any(event['operation']=='clock_gettime' and event['return_value']==0 for event in environment))
        self.assertTrue(all(not event['buffers_read'] and not event['strings_read'] for event in environment))
        indexed=next(event for event in memory if int(event['pc'],16)==start+7 and int(event['address'],16)==int(oracle['first'],16)+8)
        evidence=indexed['address_evidence']
        self.assertEqual(evidence['scale'],8)
        self.assertEqual(int(evidence['base_value'],16)+int(evidence['index_value'],16)*8+evidence['disp'],
                         int(indexed['address'],16))

    def test_allocation_reuse_failures_zero_size_and_explicit_object_identity(self):
        backend=self.backend();session=backend.open('owned')['probe_session']
        events,_result=self.collect(backend,session)
        allocations=[event for event in events if event['kind']=='allocation']
        oracle=json.loads(self.oracle.read_text())
        self.assertEqual(oracle['first'],oracle['reused'],'owned glibc tcache fixture must exercise address reuse')
        mallocs=[event for event in allocations if event['operation']=='malloc' and event['size']==64]
        self.assertGreaterEqual(len(mallocs),2)
        self.assertEqual(mallocs[0]['address'],mallocs[1]['address'])
        self.assertTrue(all(event['object_identity_known'] is False for event in allocations))
        self.assertTrue(any(event['operation']=='calloc' and event['size']==64 and event['count']==4 for event in allocations))
        self.assertTrue(any(event['operation']=='realloc' and event['success'] is False and event['old_address']!='0x0'
                            for event in allocations))
        self.assertTrue(any(event['operation']=='realloc' and event['size']==0 and
                            event['zero_size_behavior']=='implementation_defined_old_allocation_may_be_freed' for event in allocations))
        self.assertTrue(any(event['operation']=='free' and event['address']=='0x0' and
                            event['zero_size_behavior']=='free_null_noop' for event in allocations))
        self.assertTrue(any(event['operation']=='mmap' and event['success'] for event in allocations))
        self.assertTrue(any(event['operation']=='munmap' and event['success'] for event in allocations))
        objects=[event for event in events if event['kind']=='object']
        definitions=[event for event in objects if event['operation']=='define']
        self.assertEqual([(event['object_id'],event['generation'],event['type_slot']) for event in definitions],
                         [('71','1',3),('72','2',3)])
        self.assertTrue(any(event['operation']=='retire' and event['object_id']=='71' for event in objects))
        self.assertTrue(any(event['operation']=='move' and event['object_id']=='72' for event in objects))

    def test_poll_is_repeatable_cursor_bounded_and_alias_identity_is_binary_digest(self):
        self.settings['profiles']['alias']=copy.deepcopy(self.settings['profiles']['owned'])
        backend=self.backend();session=backend.open('owned')['probe_session']
        self.collect(backend,session)
        first=backend.poll(session,0,64);again=backend.poll(session,0,64)
        self.assertEqual(first['events'],again['events'])
        self.assertEqual(len(first['events']),64)
        following=backend.poll(session,first['next_cursor'],64)
        self.assertTrue(all(event['seq']>first['next_cursor'] for event in following['events']))
        self.assertEqual(backend.binary_scope('owned'),backend.binary_scope('alias'))
        self.assertEqual(backend.profile_identity('owned')['binary_sha256'],sha(self.target))
        with self.assertRaises(NativeProbeError):backend.poll(session,0,129)
        with self.assertRaises(NativeProbeError):backend.poll(session,-1,1)

    def test_real_non_exported_function_and_registration_symbols_need_no_rdynamic(self):
        target=Path(self.temp.name)/'owned-no-export'
        subprocess.run([shutil.which('gcc'),'-g','-O0','-fno-inline','-fno-builtin',
            str(ROOT/'tests/fixtures/recovery/native_probe_target.c'),
            str(ROOT/'tests/fixtures/recovery/native_probe_access.S'),'-o',str(target)],check=True,timeout=20)
        dynamic=subprocess.check_output(['nm','-D','--defined-only',str(target)],text=True)
        self.assertNotIn('probe_work',dynamic)
        self.assertNotIn('ra_probe_object',dynamic)
        rows=subprocess.check_output(['nm','-S','--defined-only',str(target)],text=True).splitlines()
        symbols={row.split()[3]:(int(row.split()[0],16),int(row.split()[1],16))
                 for row in rows if len(row.split())==4}
        self.settings['profiles']['owned'].update(executable=str(target),sha256=sha(target),
            functions={name:symbols[name][1] for name in ('probe_work','probe_access')})
        backend=self.backend();opened=backend.open('owned')
        resolution=opened['coverage']['function_resolution']
        self.assertEqual({row['source'] for row in resolution},{'unique_function_symbol'})
        self.assertEqual({row['name'] for row in resolution},
                         {'probe_work','probe_access','ra_probe_object','ra_probe_retire','ra_probe_move'})
        events,result=self.collect(backend,opened['probe_session'])
        oracle=json.loads(self.oracle.read_text());pc=int(result['module']['base'],16)+symbols['probe_access'][0]
        self.assertTrue(any(event['kind']=='memory' and int(event['pc'],16)==pc+3 and
            int(event['address'],16)==int(oracle['first'],16)+8 and event['access']=='write' for event in events))
        self.assertTrue(any(event['kind']=='object' and event['operation']=='define' and event['object_id']=='71'
                            for event in events))
        self.assertTrue(any(event['kind']=='allocation' and event['operation']=='malloc' for event in events))

    def test_real_duplicate_static_function_names_are_rejected_before_resume(self):
        directory=Path(self.temp.name)
        sources=[('first.c','static __attribute__((noinline,used)) int duplicate(void){return 1;} int first(void){return duplicate();}'),
                 ('second.c','static __attribute__((noinline,used)) int duplicate(void){return 2;} int second(void){return duplicate();}'),
                 ('main.c','extern int first(void),second(void);int main(void){return first()+second()==3?0:1;}')]
        for name,source in sources:(directory/name).write_text(source)
        target=directory/'owned-ambiguous'
        subprocess.run([shutil.which('gcc'),'-g','-O0',*(str(directory/name) for name,_source in sources),
                        '-o',str(target)],check=True,timeout=20)
        symbols=subprocess.check_output(['nm','--defined-only',str(target)],text=True).splitlines()
        self.assertEqual(sum(line.endswith(' t duplicate') for line in symbols),2)
        self.settings['profiles']['owned'].update(executable=str(target),sha256=sha(target),
            functions={'duplicate':1},entry_function='duplicate',registration_hooks={},environment_functions=[],argv=[])
        backend=self.backend()
        with self.assertRaises(NativeProbeError):backend.open('owned')
        self.assertEqual(backend.close()['cleanup_errors'],[])
        self.assertFalse(self.oracle.exists())

    def test_event_and_instruction_budgets_report_loss_or_coverage_stop(self):
        self.settings['profiles']['owned'].update(max_events=32,max_instructions=100000,argv=[str(self.oracle),'1000'])
        backend=self.backend();session=backend.open('owned')['probe_session']
        events,result=self.collect(backend,session)
        self.assertLessEqual(len(events),32)
        self.assertGreater(result['dropped'],0)
        self.assertTrue(result['loss']['identity_uncertain'])
        self.assertTrue(result['coverage']['stopped'])
        self.assertEqual(result['coverage']['stop_reason'],'event_or_byte_budget')
        self.assertLessEqual(result['coverage']['collector_bytes'],1048576)

    def test_instruction_budget_is_distinct_from_hardware_retirement(self):
        self.settings['profiles']['owned'].update(max_instructions=10)
        backend=self.backend();session=backend.open('owned')['probe_session']
        _events,result=self.collect(backend,session)
        self.assertEqual(result['coverage']['instructions'],10)
        self.assertEqual(result['coverage']['stop_reason'],'instruction_budget')
        self.assertFalse(result['coverage']['hardware_retired'])

    def test_callback_wall_budget_stops_and_detaches_the_owned_hooks(self):
        self.settings['profiles']['owned'].update(max_callback_us=1000,max_events=16384,
            argv=[str(self.oracle),'10000'])
        backend=self.backend();session=backend.open('owned')['probe_session']
        _events,result=self.collect(backend,session)
        self.assertTrue(result['coverage']['stopped'])
        self.assertEqual(result['coverage']['stop_reason'],'callback_wall_budget')
        self.assertGreaterEqual(result['coverage']['callback_ms']*1000+result['coverage']['native_callback_us'],1000)

    def test_real_two_threads_keep_native_ring_tid_address_and_allocator_order(self):
        target=Path(self.temp.name)/'owned-thread-probe'
        subprocess.run([shutil.which('gcc'),'-g','-O0','-fno-inline','-fno-builtin','-rdynamic','-pthread',
            str(ROOT/'tests/fixtures/recovery/native_probe_threads.c'),
            str(ROOT/'tests/fixtures/recovery/native_probe_access.S'),'-o',str(target)],check=True,timeout=20)
        rows=subprocess.check_output(['nm','-S','--defined-only',str(target)],text=True).splitlines()
        symbols={row.split()[3]:(int(row.split()[0],16),int(row.split()[1],16))
                 for row in rows if len(row.split())==4}
        profile=self.settings['profiles']['owned']
        profile.update(executable=str(target),sha256=sha(target),entry_function='probe_thread_work',
            functions={name:symbols[name][1] for name in ('probe_thread_work','probe_access')},
            registration_hooks={},environment_functions=[],argv=[str(self.oracle)])
        backend=self.backend();session=backend.open('owned')['probe_session']
        events,result=self.collect(backend,session)
        oracle=json.loads(self.oracle.read_text())
        self.assertEqual(result['dropped'],0)
        self.assertEqual(len({item['tid'] for item in oracle}),2)
        access=int(result['module']['base'],16)+symbols['probe_access'][0]
        for item in oracle:
            tid,address=item['tid'],int(item['address'],16)
            allocations=[event for event in events if event['kind']=='allocation' and event['tid']==tid]
            allocated=next(event for event in allocations if event['operation']=='malloc' and int(event['address'],16)==address)
            freed=next(event for event in allocations if event['operation']=='free' and int(event['address'],16)==address)
            memory=[event for event in events if event['kind']=='memory' and event['tid']==tid
                    and int(event['pc'],16)==access+7 and int(event['address'],16)==address+8]
            self.assertEqual(len(memory),1)
            self.assertLess(allocated['seq'],memory[0]['seq'])
            self.assertLess(memory[0]['seq'],freed['seq'])
            self.assertIn(item['returned'],(202,204))

    def test_worker_thread_open_does_not_bind_lifetime_to_host_thread(self):
        self.settings['profiles']['owned']['argv']=[str(self.oracle),'1','hold']
        backend=self.backend();results=[]
        thread=threading.Thread(target=lambda:results.append(backend.open('owned')))
        thread.start();thread.join(8);self.assertFalse(thread.is_alive())
        session=results[0]['probe_session'];pid=results[0]['target_pid'];descriptor=os.pidfd_open(pid)
        try:
            self.assertFalse(select.select([descriptor],[],[],.15)[0])
            self.assertEqual(backend.close(session)['cleanup_errors'],[])
            self.assertTrue(select.select([descriptor],[],[],2)[0])
        finally:os.close(descriptor)

    def test_independent_guardian_enforces_lifetime_and_survives_host_sigkill(self):
        self.settings['profiles']['owned'].update(lifetime_ms=4000,argv=[str(self.oracle),'1','hold'])
        backend=self.backend();opened=backend.open('owned');descriptor=os.pidfd_open(opened['target_pid'])
        try:self.assertTrue(select.select([descriptor],[],[],6)[0])
        finally:os.close(descriptor)
        self.assertEqual(backend.close()['cleanup_errors'],[])
        # A second, owned Python host is deliberately killed. Its guardian is
        # independent and retains the target's exact pidfd.
        self.settings['profiles']['owned']['lifetime_ms']=10000
        config_file=Path(self.temp.name)/'host-config.json';config_file.write_text(json.dumps(self.settings))
        ready=Path(self.temp.name)/'host-ready.json'
        source="""import json,pathlib,sys,time
entry=pathlib.Path(sys.argv[1])/'runtime-access.pyz'
sys.path.insert(0,str(entry if entry.is_file() else pathlib.Path(sys.argv[1])/'src'))
from observation_extension.native_probe import NativeProbe
n=NativeProbe(json.loads(pathlib.Path(sys.argv[2]).read_text()),sys.argv[3],bundle_root=sys.argv[1])
r=n.open('owned');pathlib.Path(sys.argv[4]).write_text(json.dumps(r));time.sleep(30)
"""
        host=subprocess.Popen([sys.executable,'-c',source,str(ROOT),str(config_file),
            str(Path(self.temp.name)/'other-state'),str(ready)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.addCleanup(lambda:host.kill() if host.poll() is None else None)
        deadline=time.monotonic()+8
        while not ready.exists() and time.monotonic()<deadline:time.sleep(.02)
        self.assertTrue(ready.exists(),'owned host failed to arm target')
        pid=json.loads(ready.read_text())['target_pid'];descriptor=os.pidfd_open(pid)
        try:
            host.kill();host.wait(timeout=2)
            self.assertTrue(select.select([descriptor],[],[],3)[0])
        finally:os.close(descriptor)

    def test_guardian_sigkill_fails_closed_via_stable_worker_parent_guard(self):
        self.settings['profiles']['owned']['argv']=[str(self.oracle),'1','hold']
        backend=self.backend();opened=backend.open('owned');session=backend.sessions[opened['probe_session']]
        descriptor=os.pidfd_open(opened['target_pid'])
        try:
            session['process'].kill();session['process'].wait(timeout=2)
            self.assertTrue(select.select([descriptor],[],[],3)[0])
            self.assertEqual(backend.close(opened['probe_session'])['cleanup_errors'],[])
        finally:os.close(descriptor)

    def test_failed_script_start_keeps_cleanup_handle_and_confirms_target_exit(self):
        self.settings['profiles']['owned']['functions']={'symbol_does_not_exist':16}
        self.settings['profiles']['owned']['entry_function']='symbol_does_not_exist'
        backend=self.backend()
        with self.assertRaises(NativeProbeError) as error:backend.open('owned')
        self.assertTrue(error.exception.effect_dispatched)
        self.assertEqual(len(backend.inspect()['sessions']),1)
        self.assertEqual(backend.close()['cleanup_errors'],[])

    def test_fixed_profile_validation_and_preflight_does_not_execute(self):
        backend=self.backend()
        self.assertEqual(backend.inspect()['sessions'],[])
        self.assertEqual(backend.profile_identity('owned')['arch'],'x86_64')
        self.assertFalse(self.oracle.exists())
        with self.assertRaises(NativeProbeError):backend.open('model-supplied-pid-1')
        bad=copy.deepcopy(self.settings);bad['profiles']['owned']['script']='arbitrary'
        with self.assertRaises(NativeProbeError):NativeProbe(bad,Path(self.temp.name)/'bad',bundle_root=ROOT)
        bad=copy.deepcopy(self.settings);bad['profiles']['owned']['sha256']='0'*64
        with self.assertRaisesRegex(NativeProbeError,'native_probe_digest_mismatch'):
            NativeProbe(bad,Path(self.temp.name)/'bad2',bundle_root=ROOT)
        bad=copy.deepcopy(self.settings);del bad['profiles']['owned']['sha256']
        with self.assertRaises(NativeProbeError):NativeProbe(bad,Path(self.temp.name)/'bad3',bundle_root=ROOT)
        empty=NativeProbe({'profiles':{}},Path(self.temp.name)/'empty',bundle_root=ROOT)
        self.assertFalse(empty.inspect()['configured'])
        self.assertEqual(empty.close()['cleanup_errors'],[])


if __name__=='__main__':unittest.main()
