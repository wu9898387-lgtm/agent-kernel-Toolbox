"""Real Frida integration, never attaches to an existing or third-party process."""
import hashlib
import json
import os
import re
import time
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.analysis_tools import AnalysisTools


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(sys.platform == 'linux' and os.environ.get('RUNTIME_FRIDA') and shutil.which('gcc'),
                     'Linux procfs, gcc and RUNTIME_FRIDA required for owned-only real instrumentation')
class FridaIntegrationTests(unittest.TestCase):
    def test_real_fixed_script_function_probe_compiler_field_read_and_guarded_write(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / 'owned-frida-target'
            script = ROOT / 'tests/fixtures/recovery/frida_agent.js'
            subprocess.run([shutil.which('gcc'), '-g', '-O0', '-fno-inline', '-rdynamic',
                            str(ROOT / 'tests/fixtures/recovery/frida_target.c'), '-o', str(target)],
                           check=True, timeout=20)
            state = root / 'state'
            state.mkdir(mode=0o700)
            executable = Path(os.environ['RUNTIME_FRIDA']).resolve()
            tools = AnalysisTools({'profiles': {'owned': {'kind': 'frida',
                'executable': str(executable), 'sha256': digest(executable),
                'allow_execute': True, 'script': str(script), 'script_sha256': digest(script),
                # Keep the actual observation window at two seconds while
                # separately budgeting native startup and detach/kill work.
                'timeout_seconds': 45, 'frida_duration_seconds': 2}}, 'digests': {'owned': digest(target)}},
                state, {'owned': str(target)}, bundle_root=ROOT)
            result = tools.run('owned', 'owned', 'instrument')
            self.assertTrue(result['success'], result['stdout'] + result['stderr'])
            self.assertTrue(result['target_execution_requested'])
            events = []
            for line in result['stdout'].splitlines():
                try:
                    value = json.loads(line)
                except ValueError:
                    continue
                if type(value) is dict and 'event' in value:
                    events.append(value)
            self.assertTrue(events, result['stdout'] + result['stderr'])
            ready = next(x for x in events if x['event'] == 'agent-ready')
            self.assertEqual(ready['layout_source'], 'compiler offsetof/sizeof export')
            self.assertEqual(ready['object_identity'], str(0x05550001))
            self.assertEqual(ready['compiler_field_offset'], 8)
            patch = next(x for x in events if x['event'] == 'guarded-write')
            self.assertEqual((patch['expected'], patch['replacement'], patch['value']), (7, 9, 9))
            leaves = [x for x in events if x['event'] == 'function-leave']
            self.assertEqual(len(leaves), 16)
            self.assertEqual((leaves[-1]['value'], leaves[-1]['returned'], leaves[-1]['state']), (25, 25, 16))
            final = re.search(r'owned-final pid=(\d+) value=25 state=16', result['stdout'])
            self.assertIsNotNone(final, result['stdout'])
            target_pid = int(final.group(1))
            deadline = time.monotonic() + 2
            while True:
                try:
                    fields = Path(f'/proc/{target_pid}/stat').read_text().rpartition(') ')[2].split()
                except FileNotFoundError:
                    cleanup = {'target_pid': target_pid, 'target_exit_confirmed': True,
                               'pid_reaped': True, 'state': 'absent'}
                    break
                if fields[0] in ('Z', 'X'):
                    # Frida starts the target in a new session. Some container
                    # PID 1 implementations do not reap the adopted exit record.
                    # A zombie has exited, but must not be reported as reaped.
                    cleanup = {'target_pid': target_pid, 'target_exit_confirmed': True,
                               'pid_reaped': False, 'state': fields[0], 'parent_pid': int(fields[1])}
                    break
                self.assertLess(time.monotonic(), deadline,
                                f'owned target still running after --kill-on-exit: state={fields[0]}')
                time.sleep(.02)
            print('FRIDA_CLEANUP ' + json.dumps(cleanup, sort_keys=True), flush=True)
            journal = [json.loads(x) for x in (state / 'analysis-tools.jsonl').read_text().splitlines()]
            self.assertEqual([x['state'] for x in journal], ['started', 'finished'])
            self.assertEqual(journal[-1]['exit_code'], 0)
            self.assertFalse(any(state.glob('analysis-*/')))


if __name__ == '__main__':
    unittest.main()
