"""Human reconciliation joins exact coordinated intents without clearing other work."""
import fcntl
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.coordinated_state import CoordinatedState
from observation_extension.runtime_host import RuntimeHost
from observation_extension.runtime_state import RuntimeState,StateError
import test_coordinated_state as fixtures


class ReconciliationJournalTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name)/'state'
        self.state=RuntimeState(self.directory);self.addCleanup(self.state.close)
        coordinator=CoordinatedState({'profiles':{}},self.directory/'coordinated_state',bundle_root=ROOT)
        coordinator.close()
        self.path=self.directory/'coordinated_state'/'coordinated.sqlite3'
        self.inner=sqlite3.connect(self.path,isolation_level=None);self.addCleanup(self.inner.close)

    def pending(self,request,operation,scope,*,linked=True):
        self.state.begin(request,'coordinated.capture',scope,{})
        self.state.finish(request,known=False)
        self.inner.executemany('INSERT INTO effects VALUES (?,?,?)',[
            (operation,operation+':writer-one','unknown'),
            (operation,operation+':writer-two','unknown'),
            (operation,operation+':backing','unknown')])
        if linked:self.inner.execute('INSERT INTO request_links VALUES (?,?,?)',(request,operation,scope))

    def status(self,request,operation):
        outer=self.state.db.execute('SELECT status FROM effects WHERE id=?',(request,)).fetchone()[0]
        inner=self.inner.execute('SELECT status FROM effects WHERE id=? ORDER BY scope',(operation,)).fetchall()
        return outer,[row[0]for row in inner]

    def test_reconcile_updates_every_owned_scope_and_preserves_unrelated_unknown(self):
        self.pending('first','operation-one','coordinated:one')
        self.pending('second','operation-two','coordinated:two')
        self.state.reconcile('first','effect_observed')
        self.assertEqual(self.status('first','operation-one'),('done',['done']*3))
        self.assertEqual(self.status('second','operation-two'),('unknown',['unknown']*3))
        with self.assertRaisesRegex(StateError,'request_replay'):
            self.state.begin('first','coordinated.capture','coordinated:one',{})

    def test_outer_commit_failure_rolls_back_the_inner_reconciliation(self):
        self.pending('first','operation-one','coordinated:one')
        self.state.db.execute("CREATE TRIGGER fail_receipt BEFORE INSERT ON reconciliations "
                              "BEGIN SELECT RAISE(ABORT,'injected receipt failure'); END")
        with self.assertRaisesRegex(sqlite3.IntegrityError,'injected receipt failure'):
            self.state.reconcile('first','no_effect_observed')
        self.assertEqual(self.status('first','operation-one'),('unknown',['unknown']*3))
        self.assertEqual(self.state.db.execute('SELECT count(*) FROM reconciliations').fetchone()[0],0)
        self.state.db.execute('DROP TRIGGER fail_receipt')
        self.state.reconcile('first','no_effect_observed')
        self.assertEqual(self.status('first','operation-one'),('done',['done']*3))

    def test_mismatched_scope_is_refused_without_clearing_any_intent(self):
        self.pending('first','operation-one','coordinated:one')
        self.inner.execute("UPDATE request_links SET host_scope='coordinated:other'")
        with self.assertRaisesRegex(StateError,'coordinated_reconciliation_scope_mismatch'):
            self.state.reconcile('first','abandoned')
        self.assertEqual(self.status('first','operation-one'),('unknown',['unknown']*3))

    def test_legacy_unlinked_unknown_requires_explicit_operator_recovery(self):
        self.pending('legacy-request','legacy-operation','coordinated:legacy',linked=False)
        self.inner.execute('DROP TABLE request_links')
        with self.assertRaisesRegex(StateError,'coordinated_reconciliation_link_unavailable'):
            self.state.reconcile('legacy-request','no_effect_observed')
        self.assertEqual(self.status('legacy-request','legacy-operation'),('unknown',['unknown']*3))

    def test_missing_link_does_not_clear_unrelated_standalone_unknown(self):
        self.pending('first','standalone-operation','coordinated:one',linked=False)
        with self.assertRaisesRegex(StateError,'coordinated_reconciliation_link_unavailable'):
            self.state.reconcile('first','no_effect_observed')
        self.assertEqual(self.status('first','standalone-operation'),('unknown',['unknown']*3))

    def test_outer_pending_before_inner_intent_can_be_reconciled(self):
        self.state.begin('pre-dispatch','coordinated.capture','coordinated:one',{})
        self.state.reconcile('pre-dispatch','no_effect_observed')
        self.assertEqual(self.state.db.execute("SELECT status FROM effects WHERE id='pre-dispatch'").fetchone(),('done',))
        self.assertEqual(self.inner.execute('SELECT count(*) FROM effects').fetchone()[0],0)

    def test_nonprivate_database_and_symlink_are_refused(self):
        self.pending('first','operation-one','coordinated:one')
        self.path.chmod(0o644)
        try:
            with self.assertRaisesRegex(StateError,'coordinated_reconciliation_state_invalid'):
                self.state.reconcile('first','no_effect_observed')
        finally:self.path.chmod(0o600)
        self.assertEqual(self.status('first','operation-one'),('unknown',['unknown']*3))
        original=self.path.with_name('original.sqlite3');self.path.rename(original)
        self.path.symlink_to(original)
        try:
            with self.assertRaisesRegex(StateError,'coordinated_reconciliation_state_invalid'):
                self.state.reconcile('first','no_effect_observed')
        finally:self.path.unlink();original.rename(self.path)
        self.assertEqual(self.status('first','operation-one'),('unknown',['unknown']*3))

    def test_active_coordinator_lock_prevents_reconciliation(self):
        self.pending('first','operation-one','coordinated:one')
        descriptor=os.open(self.directory/'coordinated_state'/'coordinated.lock',os.O_RDWR)
        try:
            fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
            with self.assertRaisesRegex(StateError,'stop_live_coordinator_before_reconciliation'):
                self.state.reconcile('first','no_effect_observed')
        finally:os.close(descriptor)
        self.assertEqual(self.status('first','operation-one'),('unknown',['unknown']*3))


@unittest.skipUnless(sys.platform=='linux'and hasattr(os,'pidfd_open')and shutil.which('gcc'),
                     'actual Linux pidfd and C compiler required')
class CoordinatedReconciliationIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixtures.CoordinatedStateTests.setUpClass()

    @classmethod
    def tearDownClass(cls):fixtures.CoordinatedStateTests.tearDownClass()

    def test_actual_lease_expiry_human_cli_restart_and_request_replay(self):
        fixture=fixtures.CoordinatedStateTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
        profile,sessions,_path,_address=fixture.fixture();profile['max_pause_ms']=100
        config={'schema_version':1,'state_directory':str(fixture.directory/'host-state'),
                'allowed_tools':['coordinated.capture','coordinated.inspect'],
                'coordinated_state':{'profiles':{'owned':profile}}}
        host=RuntimeHost(config,bundle_root=ROOT);active_hosts=[host]
        def close_host():
            if active_hosts:active_hosts.pop().close()
        self.addCleanup(close_host)
        original=fixtures.module._read_regions
        def wait_for_watchdog(*args):
            values=original(*args);deadline=time.monotonic()+2
            while all(fixtures.module._all_stopped(session)for session in sessions.values()):
                if time.monotonic()>=deadline:raise AssertionError('watchdog did not resume owned writers')
                time.sleep(.005)
            return values
        with patch.object(fixtures.module,'_read_regions',side_effect=wait_for_watchdog):
            unknown=host.call('coordinated.capture',{'profile':'owned','request_id':'expired-capture'})
        self.assertEqual(unknown['data']['status'],'unknown',unknown)
        self.assertEqual(unknown['data']['reason'],'coordinated_barrier_expired')
        self.assertFalse(unknown['data']['memory_written']);self.assertTrue(unknown['data']['cleanup']['complete'])
        command=[sys.executable,str(RUNTIME),'reconcile','--state-directory',config['state_directory'],
                 '--request-id','expired-capture','--disposition','no_effect_observed']
        active=subprocess.run(command,capture_output=True,text=True,timeout=10)
        self.assertEqual(active.returncode,2);self.assertIn('stop_live_host_before_reconciliation',active.stderr)
        close_host()
        reconciled=subprocess.run(command,capture_output=True,text=True,timeout=10)
        self.assertEqual(reconciled.returncode,0,(reconciled.stdout,reconciled.stderr))
        effects=json.loads(reconciled.stdout)['effects']
        self.assertEqual(next(row['status']for row in effects if row['request_id']=='expired-capture'),'done')
        reopened=RuntimeHost(config,bundle_root=ROOT);active_hosts.append(reopened)
        replay=reopened.call('coordinated.capture',{'profile':'owned','request_id':'expired-capture'})
        self.assertEqual(replay['error'],'request_replay')
        retry=reopened.call('coordinated.capture',{'profile':'owned','request_id':'after-human-reconciliation'})
        self.assertTrue(retry['ok'],retry);self.assertEqual(retry['data']['status'],'captured',retry)
        inspect=reopened.call('coordinated.inspect',{})
        self.assertEqual(inspect['data']['unresolved_scope_count'],0)


if __name__=='__main__':unittest.main()
