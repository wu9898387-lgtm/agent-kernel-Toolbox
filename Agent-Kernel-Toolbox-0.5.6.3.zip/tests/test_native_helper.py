import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0,str(RUNTIME))
from observation_extension.native_runtime import ProcessSession,NativeRuntimeError
from observation_extension.native_helper import NativeHelper
from observation_extension.native_control import suspend_for
from observation_extension.runtime_host import RuntimeHost,SPECS


@unittest.skipUnless(os.environ.get('RUNTIME_NATIVE_HELPER') and shutil.which('gcc'), 'set RUNTIME_NATIVE_HELPER to the compiled native worker')
class NativeHelperTests(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory();self.addCleanup(self.directory.cleanup)
        self.root=Path(self.directory.name)
        self.config={'path':os.environ['RUNTIME_NATIVE_HELPER'],
            'sha256':hashlib.sha256(Path(os.environ['RUNTIME_NATIVE_HELPER']).read_bytes()).hexdigest()}
        self.binary=self.root/'app'
        subprocess.run(['gcc',str(ROOT/'tests/fixtures/native_connections.c'),'-o',str(self.binary)],check=True,timeout=10)

    def test_actual_connections_over_mcp_and_native_resume(self):
        host=RuntimeHost({'schema_version':1,'state_directory':str(self.root/'state'),'allowed_tools':list(SPECS),
            'native_helper':self.config,'profiles':{'app':{'argv':[str(self.binary)],'allow_control':True,'allow_connections':True}}})
        self.addCleanup(host.close)
        launch=host.call('process.launch',{'profile':'app','request_id':'launch'});self.assertTrue(launch['ok'],launch)
        session=launch['data']['session_id'];process=host.processes[session]
        self.addCleanup(process.terminate_owned)
        # Wait for actual sockets; the APP's stdout is intentionally not captured by MCP.
        deadline=time.monotonic()+2
        while True:
            result=host.call('process.connections',{'session_id':session});self.assertTrue(result['ok'],result)
            rows=result['data']['connections']
            if len(rows)>=6:break
            if time.monotonic()>deadline:self.fail('APP socket readiness deadline')
        self.assertEqual({r['protocol'] for r in rows},{'tcp','udp','unix'})
        self.assertTrue(any(r['state']=='ESTABLISHED' for r in rows))
        self.assertTrue(any(r['state']=='LISTEN' for r in rows))
        for row in rows:
            for fd in row['fds']:self.assertEqual(os.readlink(f'/proc/{process.pid}/fd/{fd}'),'socket:['+row['socket_inode']+']')
        with socket.socket() as other:
            other.bind(('127.0.0.1',0));other.listen()
            outside=os.fstat(other.fileno()).st_ino
            result=host.call('process.connections',{'session_id':session})
            self.assertNotIn(str(outside),{r['socket_inode'] for r in result['data']['connections']})
        paused=host.call('process.suspend_for',{'session_id':session,'milliseconds':10,'request_id':'native-pause'})
        self.assertTrue(paused['ok'],paused);self.assertTrue(paused['data']['resumed'])
        host.process_options[session]['allow_connections']=False
        denied=host.call('process.connections',{'session_id':session})
        self.assertFalse(denied['ok']);self.assertIn('not_authorized',denied['error'])

    def test_digest_pin_and_private_executable_snapshot(self):
        with self.assertRaisesRegex(NativeRuntimeError,'native_helper_digest_mismatch'):
            NativeHelper({**self.config,'sha256':'0'*64},self.root)
        copied=self.root/'worker';shutil.copyfile(self.config['path'],copied)
        helper=NativeHelper({**self.config,'path':str(copied)},self.root);self.addCleanup(helper.close)
        copied.write_bytes(b'changed source')
        process=ProcessSession.attach(os.getpid());self.addCleanup(process.close)
        self.assertEqual(helper.connections(process,permitted=True)['backend'],'compiled_go_procfs')

    def test_compiled_watchdog_resumes_after_controller_sigkill(self):
        script='''
import json,sys,time,subprocess
sys.path.insert(0,sys.argv[1])
from observation_extension.native_runtime import ProcessSession
from observation_extension.native_control import stopped_owned
from observation_extension.native_helper import NativeHelper
p=ProcessSession.launch([sys.argv[2]],allow_control=True,stdout=subprocess.DEVNULL)
p.native_helper=NativeHelper(json.loads(sys.argv[3]),sys.argv[4])
with stopped_owned(p):
 print(json.dumps({'pid':p.pid,'identity':p.identity}),flush=True)
 time.sleep(60)
'''
        controller=subprocess.Popen([sys.executable,'-c',script,str(RUNTIME),str(self.binary),json.dumps(self.config),str(self.root)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        target=None
        try:
            self.assertTrue(select.select([controller.stdout],[],[],5)[0])
            record=json.loads(controller.stdout.readline())
            target=ProcessSession.attach(record['pid'],expected_identity=record['identity'],allow_terminate=True)
            self.assertTrue(target.threads()[0]['state'].startswith('T'))
            controller.kill();controller.wait(timeout=2)
            deadline=time.monotonic()+4
            while any(t['state'].startswith('T') for t in target.threads()):
                if time.monotonic()>deadline:self.fail('compiled watchdog did not resume target')
                time.sleep(0.01)
        finally:
            if controller.poll() is None:controller.kill();controller.wait(timeout=2)
            if target:target.terminate_selected();target.close()
            controller.stdout.close()

    def test_delayed_arm_never_stops_target_after_guard_exit(self):
        helper=NativeHelper(self.config,self.root);self.addCleanup(helper.close)
        process=ProcessSession.launch([str(self.binary)],allow_control=True,stdout=subprocess.DEVNULL);self.addCleanup(process.close);self.addCleanup(process.terminate_owned)
        read,write=os.pipe2(os.O_CLOEXEC);guard=helper.spawn('watchdog',process.pidfd,read);os.close(read)
        try:
            self.assertEqual(guard.stdout.read(1),b'A')
            guard.wait(timeout=2)
            with self.assertRaises(BrokenPipeError):os.write(write,b'S')
            self.assertFalse(any(t['state'].startswith('T') for t in process.threads()))
        finally:os.close(write);guard.stdout.close()


if __name__=='__main__':unittest.main()
