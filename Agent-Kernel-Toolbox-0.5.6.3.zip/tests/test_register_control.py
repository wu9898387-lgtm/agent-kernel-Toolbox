"""Real ptrace register writes and bounded failure-path tests for owned fixtures."""
import os
from pathlib import Path
import platform
import select
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_runtime import ProcessSession, NativeRuntimeError
from observation_extension.native_control import _all_stopped
from observation_extension import register_control
from observation_extension.register_control import write_register

SOURCE = r'''
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
static volatile uint64_t counter;
static void *worker(void *unused) {
    (void)unused;
    for (;;) ++counter;
    return NULL;
}
int main(void) {
    pthread_t thread;
    if (pthread_create(&thread, NULL, worker, NULL)) return 2;
    puts("register-ready");
    fflush(stdout);
    __asm__ volatile("mov $4660, %%r12\n1: pause\njmp 1b" : : : "r12", "memory");
    return 0;
}
'''


class RegisterPolicyTests(unittest.TestCase):
    def test_control_registers_and_invalid_policy_are_refused_before_target_access(self):
        for register in ('rip', 'rsp', 'eflags', 'fs_base'):
            with self.assertRaisesRegex(NativeRuntimeError, 'register_write_outside_operator_scope'):
                write_register(None, register, 0, 1, allowed_registers=['r12'])
        with self.assertRaisesRegex(NativeRuntimeError, 'invalid_register_write_allowlist'):
            write_register(None, 'r12', 0, 1, allowed_registers=['rip'])
        with self.assertRaisesRegex(NativeRuntimeError, 'invalid_register_expected_value'):
            write_register(None, 'r12', True, 1, allowed_registers=['r12'])


@unittest.skipUnless(sys.platform == 'linux' and platform.machine().lower() in ('x86_64', 'amd64')
                     and shutil.which('gcc'), 'Linux x86-64 compiler/ptrace required')
class RegisterIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory()
        source = Path(cls.directory.name) / 'register_fixture.c'
        source.write_text(SOURCE)
        cls.binary = Path(cls.directory.name) / 'register_fixture'
        subprocess.run(['gcc', '-O0', '-pthread', str(source), '-o', str(cls.binary)],
                       check=True, timeout=10, capture_output=True)

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def launch(self, *, control=True, debug=True):
        process = ProcessSession.launch([str(self.binary)], stdout=subprocess.PIPE,
                                        allow_control=control, allow_debug=debug)
        self.assertTrue(select.select([process.child.stdout], [], [], 3)[0])
        self.assertEqual(process.child.stdout.readline(), b'register-ready\n')
        def cleanup():
            if process.child.poll() is None:
                process.terminate_owned()
            process.close()
            process.child.stdout.close()
        self.addCleanup(cleanup)
        return process

    def initial(self, process):
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            value = int(process.cpu_snapshot(max_frames=0)['registers']['r12'], 16)
            if value == 4660:
                return value
        self.fail('fixture never entered register holding loop')

    def assert_running_detached(self, process):
        self.assertIn('TracerPid:\t0\n', Path(f'/proc/{process.pid}/status').read_text())
        self.assertFalse(any(row['state'].startswith(('T', 't')) for row in process.threads()))
        self.assertIsNone(process.child.poll())

    def test_expected_value_write_and_restore_pause_all_threads(self):
        process = self.launch()
        expected = self.initial(process)
        original = register_control._set_registers
        stopped_threads = []
        def checked(session, raw):
            rows = session.threads()
            stopped_threads.append(len(rows))
            self.assertGreaterEqual(len(rows), 2)
            self.assertTrue(_all_stopped(session))
            return original(session, raw)
        with patch.object(register_control, '_set_registers', side_effect=checked):
            result = write_register(process, 'r12', expected, 0x9876, allowed_registers=['r12'])
        self.assertEqual(result['status'], 'verified', result)
        self.assertTrue(result['resumed'])
        self.assertTrue(result['debugger_detached'])
        self.assertEqual(int(process.cpu_snapshot(max_frames=0)['registers']['r12'], 16), 0x9876)
        result = write_register(process, 'r12', 0x9876, expected, allowed_registers=['r12'])
        self.assertEqual(result['status'], 'verified', result)
        self.assert_running_detached(process)
        self.assertTrue(stopped_threads)

    def test_compare_mismatch_never_writes(self):
        process = self.launch()
        expected = self.initial(process)
        with patch.object(register_control, '_set_registers') as setter:
            result = write_register(process, 'r12', expected + 1, 3, allowed_registers=['r12'])
        setter.assert_not_called()
        self.assertEqual(result['status'], 'rejected')
        self.assertFalse(result['register_written'])
        self.assert_running_detached(process)

    def test_readback_failure_rolls_back_before_resuming(self):
        process = self.launch()
        expected = self.initial(process)
        original = register_control._get_registers
        calls = 0
        def corrupted(session, abi):
            nonlocal calls
            calls += 1
            raw = original(session, abi)
            return bytes([raw[0] ^ 1]) + raw[1:] if calls == 2 else raw
        with patch.object(register_control, '_get_registers', side_effect=corrupted):
            result = write_register(process, 'r12', expected, 7, allowed_registers=['r12'])
        self.assertEqual(result['status'], 'rolled_back', result)
        self.assertTrue(result['rollback_verified'])
        self.assertEqual(int(process.cpu_snapshot(max_frames=0)['registers']['r12'], 16), expected)
        self.assert_running_detached(process)

    def test_rollback_failure_is_unknown_and_fences_control(self):
        process = self.launch()
        expected = self.initial(process)
        original_get = register_control._get_registers
        original_set = register_control._set_registers
        reads = writes = 0
        def corrupted(session, abi):
            nonlocal reads
            reads += 1
            raw = original_get(session, abi)
            return bytes([raw[0] ^ 1]) + raw[1:] if reads == 2 else raw
        def failed_restore(session, raw):
            nonlocal writes
            writes += 1
            if writes > 1:
                raise NativeRuntimeError('register_test_restore_failure')
            return original_set(session, raw)
        with patch.object(register_control, '_get_registers', side_effect=corrupted), \
                patch.object(register_control, '_set_registers', side_effect=failed_restore):
            result = write_register(process, 'r12', expected, 7, allowed_registers=['r12'])
        self.assertEqual(result['status'], 'unknown', result)
        self.assertTrue(result['cleanup_unresolved'])
        self.assertTrue(result['debugger_detached'])
        self.assertTrue(process._control_unresolved)
        with self.assertRaisesRegex(NativeRuntimeError, 'process_control_cleanup_unresolved'):
            write_register(process, 'r12', 7, expected, allowed_registers=['r12'])
        self.assert_running_detached(process)

    def test_missing_control_or_debug_grant_cannot_write(self):
        process = self.launch(control=False)
        with self.assertRaisesRegex(NativeRuntimeError, 'owned_process_control_not_authorized'):
            write_register(process, 'r12', 0, 0, allowed_registers=['r12'])
        process = self.launch(debug=False)
        with self.assertRaisesRegex(NativeRuntimeError, 'debug_not_authorized_for_owned_child'):
            write_register(process, 'r12', 0, 0, allowed_registers=['r12'])

    def test_interrupted_readback_rolls_back_and_detaches(self):
        process = self.launch()
        expected = self.initial(process)
        original = register_control._get_registers
        calls = 0
        def interrupted(session, abi):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise KeyboardInterrupt
            return original(session, abi)
        with patch.object(register_control, '_get_registers', side_effect=interrupted):
            with self.assertRaises(KeyboardInterrupt):
                write_register(process, 'r12', expected, 7, allowed_registers=['r12'])
        self.assertEqual(int(process.cpu_snapshot(max_frames=0)['registers']['r12'], 16), expected)
        self.assert_running_detached(process)


if __name__ == '__main__':
    unittest.main()
