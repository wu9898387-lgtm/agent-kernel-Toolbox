"""Real optional native reverse execution and instruction-level DBI checks."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_debug import NativeDebug, NativeDebugError, _target_cleanup


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class DebugProfileTests(unittest.TestCase):
    def test_invalid_symbols_registers_unregistered_targets_and_budgets(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            binary = directory / 'fixture'
            binary.write_bytes(b'not executed')
            profile = {'kind': 'gdb', 'executable': '/usr/bin/false', 'sha256': '0'*64,
                       'binary': 'fixture', 'binary_sha256': digest(binary), 'entry': 'entry'}
            cases = [{'entry': 'entry\nshell arbitrary'}, {'register': 'pc'}, {'register': []},
                     {'steps': 129}, {'steps': True}, {'binary': []}, {'timeout_seconds': 0}]
            for invalid in cases:
                with self.subTest(invalid=invalid), self.assertRaises(NativeDebugError):
                    NativeDebug({'profiles': {'p': {**profile, **invalid}}}, directory,
                                {'fixture': str(binary)})

    def test_tool_and_binary_pins_and_permission_precede_execution(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            binary = directory / 'fixture'
            binary.write_bytes(b'not executed')
            tool = str(Path(shutil.which('false')).resolve())
            profile = {'kind': 'gdb', 'executable': tool, 'sha256': digest(tool),
                       'binary': 'fixture', 'binary_sha256': digest(binary), 'entry': 'entry'}
            with patch('observation_extension.native_debug._execute') as execute:
                denied = NativeDebug({'profiles': {'p': profile}}, directory, {'fixture': str(binary)})
                with self.assertRaisesRegex(NativeDebugError, 'not_authorized'):
                    denied.record_reverse('p')
                execute.assert_not_called()
                engine = NativeDebug({'profiles': {'p': {**profile, 'allow_execute': True}}}, directory,
                                     {'fixture': str(binary)})
                binary.write_bytes(b'changed fixture')
                with self.assertRaisesRegex(RuntimeError, 'digest_mismatch'):
                    engine.record_reverse('p')
                execute.assert_not_called()


GDB = os.environ.get('RUNTIME_GDB')


@unittest.skipUnless(sys.platform == 'linux' and GDB and shutil.which('gcc'),
                     'set RUNTIME_GDB to installed GDB for actual native recording')
class RealNativeReverseTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.binary = self.directory / 'owned-recording-app'
        subprocess.run(['gcc', '-g', '-nostdlib', '-no-pie',
                        str(ROOT / 'tests/fixtures/recovery/record_reverse.S'), '-o', str(self.binary)],
                       check=True, timeout=15)
        tool = str(Path(GDB).resolve())
        self.profile = {'kind': 'gdb', 'executable': tool, 'sha256': digest(tool),
                        'binary': 'fixture', 'binary_sha256': digest(self.binary),
                        'entry': 'record_entry', 'register': 'rax', 'steps': 2,
                        'allow_execute': True, 'timeout_seconds': 10}
        for environment, key in [('RUNTIME_GDB_LIBRARIES', 'library_directory'),
                                 ('RUNTIME_GDB_DATA', 'data_directory')]:
            if os.environ.get(environment):
                self.profile[key] = os.environ[environment]

    def engine(self, profile=None):
        return NativeDebug({'profiles': {'record': profile or self.profile}},
                           self.directory / 'state', {'fixture': str(self.binary)})

    def test_record_full_reverse_and_forward_replay_restore_real_native_state(self):
        engine = self.engine()
        self.assertTrue(engine.inspect()['profiles'][0]['available'])
        result = engine.record_reverse('record')
        self.assertEqual(result['status'], 'verified')
        self.assertEqual(result['states']['before']['register_value'], 7)
        self.assertEqual(result['states']['forward']['register_value'], 36)
        self.assertEqual(result['states']['before'], result['states']['reverse'])
        self.assertEqual(result['states']['forward'], result['states']['replay'])
        self.assertGreater(result['recording']['bytes'], 1024)
        self.assertEqual(result['recorded_instructions'], 2)
        self.assertFalse(result['recording']['persistent'])
        self.assertTrue(result['cleanup']['target_exit_confirmed'])
        self.assertFalse(result['all_process_state_equivalence_proven'])
        self.assertEqual(list((self.directory / 'state').iterdir()), [])

    def test_timeout_terminates_only_verified_direct_parent_child(self):
        source = self.directory / 'infinite.S'
        source.write_text('.global _start\n.global record_entry\n.text\n_start: jmp _start\n'
                          'record_entry: nop\n.section .note.GNU-stack,"",@progbits\n')
        subprocess.run(['gcc', '-nostdlib', '-no-pie', str(source), '-o', str(self.binary)],
                       check=True, timeout=15)
        profile = {**self.profile, 'timeout_seconds': 2, 'binary_sha256': digest(self.binary)}
        observed = []
        def cleanup(path):
            result = _target_cleanup(path)
            observed.append(result)
            return result
        with patch('observation_extension.native_debug._target_cleanup', cleanup):
            with self.assertRaisesRegex(RuntimeError, 'tool_timeout') as error:
                self.engine(profile).record_reverse('record')
        self.assertTrue(error.exception.effect_dispatched)
        self.assertTrue(observed[0]['target_started'])
        self.assertTrue(observed[0]['target_exit_confirmed'])

    @unittest.skipUnless(os.environ.get('RUNTIME_GEF'), 'set RUNTIME_GEF to installed GEF entry script')
    def test_real_gef_extension_reads_owned_native_register(self):
        engine = self.engine()
        command = engine._gdb(self.profile)
        script = Path(os.environ['RUNTIME_GEF']).resolve()
        # Fixed operator-selected script; no command input is accepted by MCP.
        result = subprocess.run([*command, '--nx', '--nh', '--batch', '-iex', 'set auto-load off',
            '-ex', 'source ' + str(script), '-ex', 'gef config context.enable false',
            '-ex', 'set disable-randomization off', '-ex', 'set confirm off',
            '-ex', 'break record_entry', '-ex', 'run', '-ex', 'registers', '-ex', 'kill',
            '--args', str(self.binary)], capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        cleaned = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', result.stdout).replace('\x01', '').replace('\x02', '')
        self.assertIn('commands loaded', cleaned)
        self.assertIn('$rax', cleaned)
        self.assertRegex(cleaned, r'\$rax\s*: 0x7\b')

    @unittest.skipUnless(os.environ.get('RUNTIME_PWNDBG'), 'set RUNTIME_PWNDBG to installed Pwndbg launcher')
    def test_real_pwndbg_extension_and_record_reverse_engine(self):
        executable = str(Path(os.environ['RUNTIME_PWNDBG']).resolve())
        probe = subprocess.run([executable, '--nx', '--nh', '--batch',
            '-iex', 'set debuginfod enabled off',
            '-ex', 'python import pwndbg; print("RK_PWNDBG_VERSION", pwndbg.__version__)'],
            capture_output=True, text=True, timeout=15)
        self.assertEqual(probe.returncode, 0, probe.stderr)
        self.assertIn('RK_PWNDBG_VERSION', probe.stdout)
        self.assertIn('pwndbg commands', probe.stdout)
        profile = {key: value for key, value in self.profile.items()
                   if key not in ('library_directory', 'data_directory')}
        profile.update(executable=executable, sha256=digest(executable), timeout_seconds=15)
        result = self.engine(profile).record_reverse('record')
        self.assertEqual(result['states']['before']['register_value'], 7)
        self.assertEqual(result['states']['forward']['register_value'], 36)
        self.assertTrue(result['forward_replay_matched'])


@unittest.skipUnless(os.environ.get('RUNTIME_FRIDA') and shutil.which('gcc'),
                     'set RUNTIME_FRIDA for actual Frida Stalker instrumentation')
class RealInstructionDBITests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.binary = self.directory / 'owned-dbi-app'
        subprocess.run(['gcc', '-g', '-O0', '-fno-inline', '-rdynamic',
                        str(ROOT / 'tests/fixtures/recovery/stalker_target.c'), '-o', str(self.binary)],
                       check=True, timeout=15)
        symbol = next(line for line in subprocess.check_output(['nm', '-S', str(self.binary)], text=True).splitlines()
                      if line.endswith(' trace_region'))
        self.size = int(symbol.split()[1], 16)

    def run_trace(self, **changes):
        executable = str(Path(os.environ['RUNTIME_FRIDA']).resolve())
        profile = {'kind': 'frida', 'executable': executable, 'sha256': digest(executable),
                   'binary': 'fixture', 'binary_sha256': digest(self.binary), 'function': 'trace_region',
                   'function_size': self.size, 'max_events': 32, 'max_instructions': 100000,
                   'timeout_seconds': 6, 'allow_execute': True, **changes}
        engine = NativeDebug({'profiles': {'trace': profile}}, self.directory / 'state', {'fixture': str(self.binary)})
        return engine.stalker('trace')

    def test_real_instruction_block_call_events_with_explicit_loss_budget(self):
        result = self.run_trace()
        trace = result['trace']
        self.assertEqual(trace['returned'], sum((index ^ 0x5a) if index & 1 else index for index in range(12)))
        self.assertGreater(trace['counts']['exec'], 100)
        self.assertGreater(trace['counts']['block'], 10)
        self.assertEqual(trace['counts']['call'], 6)
        self.assertEqual(len(trace['events']), 32)
        self.assertEqual(sum(trace['counts'].values()), len(trace['events']) + trace['dropped'])
        self.assertFalse(result['hardware_retired_instructions'])
        self.assertFalse(result['complete_original_function_coverage_proven'])
        self.assertTrue(all(0 <= row['offset'] < self.size for row in trace['events']))

    def test_instruction_budget_requests_stop_but_application_completes(self):
        trace = self.run_trace(max_events=8, max_instructions=10)['trace']
        self.assertTrue(trace['budget_stop_requested'])
        self.assertGreaterEqual(trace['counts']['exec'], 10)
        self.assertLess(trace['counts']['exec'], 100)
        self.assertEqual(len(trace['events']), 8)
        self.assertEqual(trace['returned'], 562)


if __name__ == '__main__':
    unittest.main()
