"""Exercise the original Frida JS budget functions without a live target."""
from pathlib import Path
import shutil
import subprocess
import unittest


class ProbeBudgetTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which('node'), 'Node required for original probe JS budget functions')
    def test_production_js_budget_stop_and_reentry(self):
        script=Path(__file__).with_name('native_probe_budget.test.mjs')
        result=subprocess.run([shutil.which('node'),'--test',str(script)],
                              capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)


if __name__=='__main__':unittest.main()
