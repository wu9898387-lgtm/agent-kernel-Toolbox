"""Revised adapters must share policy, durable effects and the packaged MCP path."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
import zipfile
import io

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))

from observation_extension.runtime_host import RuntimeHost, SPECS
from observation_extension.policy import Endpoint, EndpointGate, MAX_ENDPOINTS


NEW_TOOLS = ['tree.inspect', 'tree.run', 'files.inspect', 'files.capture',
             'malware.inspect', 'malware.scan', 'network.inspect', 'network.request']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class PreflightError(RuntimeError):
    def __init__(self, code, dispatched=False):
        super().__init__(code)
        self.effect_dispatched = dispatched


class RevisionHostTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.config = {'schema_version': 1, 'state_directory': str(self.root / 'state'),
                       'allowed_tools': NEW_TOOLS + ['runtime.audit', 'runtime.status']}

    def host(self, config=None):
        host = RuntimeHost(self.config if config is None else config, bundle_root=ROOT)
        self.addCleanup(host.close)
        return host

    def test_modules_are_lazy_and_tools_require_independent_allowlist(self):
        self.config.update({name: {} for name in ('process_tree', 'file_activity', 'malware_triage', 'network_policy')})
        self.config['allowed_tools'] = ['runtime.status']
        host = self.host()
        self.assertEqual(host.extended_backends, {})
        for name in NEW_TOOLS:
            args = {'profile': 'fixed'} if name.split('.')[1] not in ('inspect',) else {}
            if SPECS[name][3]:
                args['request_id'] = 'denied-' + name
            self.assertFalse(host.call(name, args)['ok'])
        self.assertEqual(host.extended_backends, {})
        configured = host.call('runtime.status', {})['data']['extended_backends_configured']
        self.assertTrue({'process_tree', 'file_activity', 'malware_triage', 'network_policy'} <= set(configured))

    def test_full_registry_fits_and_registration_remains_bounded(self):
        host = self.host({**self.config, 'allowed_tools': list(SPECS)})
        self.assertTrue(host.call('runtime.status', {})['ok'])
        self.assertLessEqual(len(SPECS), MAX_ENDPOINTS)
        endpoints = [Endpoint('endpoint' + str(index), lambda value: value)
                     for index in range(MAX_ENDPOINTS + 1)]
        with self.assertRaisesRegex(ValueError, 'endpoint_limit'):
            EndpointGate(endpoints, set())

    def test_missing_backends_are_known_preflight_and_fixed_arguments_only(self):
        host = self.host()
        for tool, kind in [('tree.run', 'process_tree'), ('files.capture', 'file_activity'),
                           ('network.request', 'network_policy')]:
            required = host.call(tool, {'profile': 'fixed'})
            self.assertEqual(required['error'], 'request_id_required')
            for index in range(2):
                result = host.call(tool, {'profile': 'fixed', 'request_id': tool + str(index)})
                self.assertEqual(result['error'], kind + '_not_configured')
                self.assertFalse(result['effect_unknown'])
            invalid = host.call(tool, {'profile': 'fixed', 'request_id': tool + '-argv',
                                      'argv': ['/not/operator/registered']})
            self.assertEqual(invalid['error'], 'invalid_tool_arguments')
        for tool in ('malware.scan', 'network.request'):
            args = {'profile': 'fixed', 'url': 'http://model-selected.invalid/'}
            if SPECS[tool][3]:
                args['request_id'] = 'arbitrary-url'
            self.assertEqual(host.call(tool, args)['error'], 'invalid_tool_arguments')
        self.assertTrue(all(row['status'] == 'done' for row in host.state.audit()['effects']))

    def test_config_types_and_no_deps_constructor_failure_precede_dispatch(self):
        for key in ('process_tree', 'file_activity', 'malware_triage', 'network_policy'):
            with self.subTest(key=key), self.assertRaisesRegex(RuntimeError, 'invalid_host_backend_config'):
                self.host({**self.config, key: []})
        self.config['process_tree'] = {}
        host = self.host()
        with patch('observation_extension.runtime_host.importlib.import_module',
                   side_effect=ModuleNotFoundError('missing dependency')):
            result = host.call('tree.run', {'profile': 'fixed', 'request_id': 'no-dependency'})
        self.assertFalse(result['ok'])
        self.assertFalse(result['effect_unknown'])
        self.assertEqual(host.state.audit()['effects'][0]['status'], 'done')

    def test_unknown_offline_analysis_is_logged_without_an_effect(self):
        self.config['malware_triage'] = {}
        host = RuntimeHost(self.config, bundle_root=ROOT)
        class Offline:
            closed = False
            def scan(self, profile):
                return {'status': 'unknown', 'classification': 'unknown', 'target_executed': False}
            def close(self):
                self.closed = True
                return {'cleanup_errors': []}
        backend = Offline()
        try:
            host.extended_backends['malware_triage'] = backend
            value = host.call('malware.scan', {'profile': 'registered'})
            self.assertTrue(value['ok'])
            self.assertFalse(value['unknown_effect'])
            audit = host.state.audit()
            self.assertEqual(audit['effects'], [])
            self.assertEqual([row['phase'] for row in reversed(audit['calls'])], ['started', 'returned'])
            self.assertEqual(audit['calls'][0]['tool'], 'malware.scan')
        finally:
            cleanup = host.close()
        self.assertEqual(cleanup['cleanup_errors'], [])
        self.assertTrue(backend.closed)

    def test_network_unknown_fences_origin_aliases_and_request_ids_across_restart(self):
        self.config['network_policy'] = {}
        class Network:
            def __init__(self): self.calls = []
            def origin_scope(self, profile): return 'http://127.0.0.1:34567'
            def request(self, profile, request_id):
                self.calls.append((profile, request_id))
                return {'status': 'unknown', 'effect_dispatched': True, 'dispatched': True}
            def inspect(self): return {'observation_only': True}
            def close(self): return {'cleanup_errors': []}
        host = RuntimeHost(self.config, bundle_root=ROOT)
        backend = Network()
        host.extended_backends['network_policy'] = backend
        try:
            first = host.call('network.request', {'profile': 'write', 'request_id': 'uncertain-write'})
            self.assertTrue(first['unknown_effect'])
            for profile, request_id in [('write-alias', 'alias-write'), ('write', 'uncertain-write')]:
                result = host.call('network.request', {'profile': profile, 'request_id': request_id})
                self.assertIn(result['error'], ('scope_outcome_unresolved', 'request_replay'))
            self.assertEqual(backend.calls, [('write', 'uncertain-write')])
            self.assertTrue(host.call('network.inspect', {})['ok'])
        finally:
            host.close()
        reopened = self.host()
        backend = Network()
        reopened.extended_backends['network_policy'] = backend
        rejected = reopened.call('network.request', {'profile': 'another-alias', 'request_id': 'restart-write'})
        self.assertEqual(rejected['error'], 'scope_outcome_unresolved')
        self.assertEqual(backend.calls, [])

    def test_tree_and_file_errors_preserve_dispatch_fence(self):
        self.config.update({'process_tree': {}, 'file_activity': {}})
        host = self.host()
        class Backend:
            def run(self, profile):
                raise PreflightError('owned_target_outcome_unknown' if profile == 'sent' else 'owned_target_unavailable',
                                     dispatched=profile == 'sent')
            capture = run
            def close(self): return {'cleanup_errors': []}
        host.extended_backends.update({'process_tree': Backend(), 'file_activity': Backend()})
        for tool in ('tree.run', 'files.capture'):
            refused = host.call(tool, {'profile': 'missing', 'request_id': tool + '-missing'})
            self.assertFalse(refused['effect_unknown'])
            uncertain = host.call(tool, {'profile': 'sent', 'request_id': tool + '-sent'})
            self.assertTrue(uncertain['effect_unknown'])
            fenced = host.call(tool, {'profile': 'sent', 'request_id': tool + '-again'})
            self.assertEqual(fenced['error'], 'scope_outcome_unresolved')

    def test_owned_execution_fence_covers_profile_and_capture_aliases(self):
        fixed = 'a' * 64
        self.config.update({
            'process_tree': {'profiles': {'first': {'binary_sha256': fixed}, 'alias': {'binary_sha256': fixed}}},
            'file_activity': {'profiles': {'capture': {'sha256': fixed}}},
        })
        host = self.host()
        class Backend:
            calls = 0
            def run(self, profile):
                self.calls += 1
                return {'status': 'unknown', 'effect_dispatched': True}
            capture = run
            def inspect(self): return {'observation_only': True}
            def close(self): return {'cleanup_errors': []}
        backend = Backend()
        host.extended_backends.update({'process_tree': backend, 'file_activity': backend})
        result = host.call('tree.run', {'profile': 'first', 'request_id': 'first-owned-run'})
        self.assertTrue(result['unknown_effect'])
        for tool, profile in [('tree.run', 'alias'), ('files.capture', 'capture')]:
            blocked = host.call(tool, {'profile': profile, 'request_id': 'alias-' + tool})
            self.assertEqual(blocked['error'], 'scope_outcome_unresolved')
        self.assertEqual(backend.calls, 1)
        self.assertTrue(host.call('files.inspect', {})['ok'])

    def loopback(self):
        observations = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args): pass
            def do_GET(self):
                observations.append(('GET', self.path, b''))
                if self.path == '/drop':
                    self.close_connection = True
                    self.connection.shutdown(socket.SHUT_RDWR)
                    self.connection.close()
                    return
                body = b'{"owned_service":"ready"}'
                self.send_response(200)
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            def do_POST(self):
                body = self.rfile.read(int(self.headers.get('Content-Length', '0')))
                observations.append(('POST', self.path, body))
                # The server performed its side effect but loses the reply.
                # Retrying this write would duplicate a real business action.
                self.close_connection = True
                self.connection.shutdown(socket.SHUT_RDWR)
                self.connection.close()
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        def cleanup():
            server.shutdown()
            server.server_close()
            worker.join(timeout=2)
        self.addCleanup(cleanup)
        return 'http://127.0.0.1:' + str(server.server_address[1]), observations

    def network_config(self, origin):
        limits = {'origin': origin, 'min_interval_ms': 1, 'max_concurrent': 2,
                  'max_requests': 16, 'failure_threshold': 3, 'circuit_ms': 10}
        request = {'origin': 'service', 'method': 'GET', 'path': '/health',
                   'headers': {'Accept': 'application/json'}, 'body_utf8': '', 'allow_write': False,
                   'max_attempts': 1, 'timeout_ms': 1000, 'max_response_bytes': 4096,
                   'retry_base_ms': 1, 'retry_max_ms': 10}
        return {'origins': {'service': limits, 'same-service': dict(limits)},
                'profiles': {'read': request,
                             'drop-read': {**request, 'path': '/drop'},
                             'write': {**request, 'method': 'POST', 'path': '/change',
                                       'body_utf8': 'owned-fixed-write', 'allow_write': True},
                             'alias-read': {**request, 'origin': 'same-service'}}}

    def malware_config(self):
        fixture = self.root / 'fixed-file.bin'
        fixture.write_bytes(b'OWNED_FILE_CONTENT_NEVER_RETURNED')
        return {'profiles': {'owned': {'path': str(fixture), 'sha256': digest(fixture),
            'ioc_rules': [{'sha256': digest(fixture), 'label': 'test_indicator',
                           'source': 'owned-test-fixture', 'version': '1', 'confidence': 'high'}],
            'max_file_bytes': 4096, 'timeout_seconds': 2, 'max_matches': 16}}}

    def scanner_fixture(self):
        """An owned demo, never a vendor anticheat or malware executable."""
        compiler = shutil.which('gcc')
        if not compiler:
            self.skipTest('GCC required for the owned scanner fixture')
        directory = self.root / 'scan-input'
        directory.mkdir(exist_ok=True)
        for index in range(12):
            (directory / ('file' + str(index))).write_bytes(b'PRIVATE_SCANNER_INPUT_' + bytes([65 + index]))
        source = self.root / 'scanner.c'
        source.write_text(r'''
#define _POSIX_C_SOURCE 200809L
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
static int scan(const char *root) {
    DIR *directory=opendir(root); if(!directory)return 2;
    struct dirent *entry; char path[4096], buffer[16];
    while((entry=readdir(directory))) {
        if(entry->d_name[0]=='.')continue;
        int n=snprintf(path,sizeof(path),"%s/%s",root,entry->d_name);
        if(n<0 || (size_t)n>=sizeof(path))return 3;
        int fd=open(path,O_RDONLY); if(fd<0)return 4;
        while(read(fd,buffer,sizeof(buffer))>0){}
        close(fd);
    }
    closedir(directory);
    struct timespec pause={0,200000000};nanosleep(&pause,NULL);return 0;
}
int main(int argc,char **argv) {
    if(argc!=3)return 2;
    pid_t first=fork(); if(first==0)_exit(scan(argv[1])); if(first<0)return 3;
    pid_t second=fork(); if(second==0)_exit(scan(argv[1])); if(second<0)return 4;
    int a=0,b=0;
    if(waitpid(first,&a,0)<0 || waitpid(second,&b,0)<0 || !WIFEXITED(a) || !WIFEXITED(b) || WEXITSTATUS(a) || WEXITSTATUS(b))return 5;
    FILE *marker=fopen(argv[2],"w");if(!marker)return 6;
    fputs("owned-scanner-complete",marker);fclose(marker);return 0;
}
''')
        binary = self.root / 'owned-scanner'
        subprocess.run([compiler, '-std=c11', '-Wall', '-Wextra', '-Werror', '-O0',
                        str(source), '-o', str(binary)], check=True, capture_output=True, timeout=15)
        marker = self.root / 'scanner-complete'
        return binary, directory, marker

    def scanner_configs(self):
        binary, directory, marker = self.scanner_fixture()
        argv = [str(binary), str(directory), str(marker)]
        strace = os.environ.get('RUNTIME_STRACE') or shutil.which('strace')
        if not strace:
            self.skipTest('strace required for real file-activity capture')
        configs = {
            'file_activity': {'strace': {'path': str(Path(strace).resolve()), 'sha256': digest(strace)},
                'profiles': {'scanner': {'argv': argv, 'sha256': digest(binary), 'roots': [str(directory)],
                    'allow_capture': True, 'show_paths': False, 'duration_ms': 3000,
                    'max_events': 1024, 'max_log_bytes': 1048576,
                    'scan_min_paths': 8, 'scan_min_enumerations': 2}}},
            'malware_triage': {'profiles': {'scanner': {'path': str(binary), 'sha256': digest(binary),
                'ioc_rules': [{'sha256': digest(binary), 'label': 'known_anticheat',
                    'source': 'owned-fixture-rule-not-vendor-authenticated',
                    'version': '1', 'confidence': 'unverified'}],
                'max_file_bytes': 1048576, 'timeout_seconds': 2, 'max_matches': 16}}},
            'process_tree': {'profiles': {'scanner': {'argv': argv, 'binary_sha256': digest(binary),
                'allow_run': True, 'cpu_milliseconds': 5000, 'rss_bytes': 128 * 1024 * 1024,
                'wall_ms': 5000, 'sample_ms': 100, 'max_processes': 8,
                'address_space_bytes': 256 * 1024 * 1024, 'open_files': 64,
                'max_pause_ms': 500, 'capture_output': False}}},
        }
        return configs, binary, marker

    def test_real_loopback_request_fixed_profile_and_lost_write_reply_fence(self):
        origin, observations = self.loopback()
        self.config['network_policy'] = self.network_config(origin)
        host = self.host()
        self.assertTrue(host.call('network.inspect', {})['ok'])
        self.assertEqual(observations, [], 'inspect must not send any request')
        read = host.call('network.request', {'profile': 'read', 'request_id': 'owned-health'})
        self.assertTrue(read['ok'], read)
        self.assertFalse(read['unknown_effect'], read)
        self.assertEqual(observations, [('GET', '/health', b'')])
        lost = host.call('network.request', {'profile': 'write', 'request_id': 'owned-write'})
        self.assertTrue(lost.get('unknown_effect') or lost.get('effect_unknown'), lost)
        self.assertEqual(observations[-1], ('POST', '/change', b'owned-fixed-write'))
        for profile, request_id in [('alias-read', 'same-origin-after-unknown'), ('write', 'owned-write')]:
            denied = host.call('network.request', {'profile': profile, 'request_id': request_id})
            self.assertFalse(denied['ok'], denied)
        self.assertEqual(len(observations), 2, 'uncertain write and origin aliases must never replay')
        self.assertTrue(host.call('network.inspect', {})['ok'])
        self.assertNotIn('owned_service', json.dumps(host.state.audit()))

    def test_real_dispatched_get_failure_also_fences_origin_without_replay(self):
        origin, observations = self.loopback()
        self.config['network_policy'] = self.network_config(origin)
        host = self.host()
        dropped = host.call('network.request', {'profile': 'drop-read', 'request_id': 'sent-get-lost-reply'})
        self.assertTrue(dropped.get('unknown_effect') or dropped.get('effect_unknown'), dropped)
        denied = host.call('network.request', {'profile': 'alias-read', 'request_id': 'sent-get-alias'})
        self.assertFalse(denied['ok'], denied)
        self.assertEqual(observations, [('GET', '/drop', b'')])
        self.assertTrue(host.call('network.inspect', {})['ok'])

    def test_real_fixed_file_indicator_scan_is_offline_and_payload_free(self):
        self.config['malware_triage'] = self.malware_config()
        host = self.host()
        inspected = host.call('malware.inspect', {})
        self.assertTrue(inspected['ok'], inspected)
        scanned = host.call('malware.scan', {'profile': 'owned'})
        self.assertTrue(scanned['ok'], scanned)
        self.assertEqual(scanned['data']['classification'], 'indicator_match')
        self.assertFalse(scanned['unknown_effect'])
        self.assertNotIn('OWNED_FILE_CONTENT_NEVER_RETURNED', json.dumps(scanned))
        self.assertEqual(host.state.audit()['effects'], [])
        self.assertEqual((self.root / 'fixed-file.bin').read_bytes(), b'OWNED_FILE_CONTENT_NEVER_RETURNED')

    def test_real_scanner_file_activity_and_declared_indicator_share_binary_identity(self):
        configs, binary, marker = self.scanner_configs()
        self.config.update(configs)
        host = self.host()
        self.assertTrue(host.call('files.inspect', {})['ok'])
        self.assertFalse(marker.exists(), 'inspect must not launch the scanner')
        captured = host.call('files.capture', {'profile': 'scanner', 'request_id': 'owned-scanner-capture'})
        self.assertTrue(captured['ok'], captured)
        self.assertEqual(marker.read_text(), 'owned-scanner-complete')
        scanned = host.call('malware.scan', {'profile': 'scanner'})
        self.assertTrue(scanned['ok'], scanned)
        self.assertEqual(captured['data']['binary_sha256'], digest(binary))
        self.assertEqual(scanned['data']['artifact']['sha256'], captured['data']['binary_sha256'])
        self.assertGreaterEqual(captured['data']['summary']['distinct_paths'], 12)
        self.assertGreaterEqual(captured['data']['summary']['enumeration_calls'], 2)
        self.assertFalse(captured['data']['observed_scan_pattern']['maliciousness_proven'])
        self.assertNotIn('known_anticheat', json.dumps(captured['data']))
        evidence = json.dumps(scanned['data'])
        self.assertIn('known_anticheat', evidence)
        self.assertIn('owned-fixture-rule-not-vendor-authenticated', evidence)
        self.assertFalse(scanned['data']['source_authenticated'])
        declared = next(item for item in scanned['data']['findings']
                        if item.get('declared_label') == 'known_anticheat')
        self.assertEqual(declared['declared_confidence'], 'unverified')
        self.assertFalse(declared['source_authenticated'])
        self.assertFalse(declared['label_truth_proven'])
        self.assertNotIn('PRIVATE_SCANNER_INPUT_', json.dumps(captured['data']))

    def test_real_process_tree_through_host_checks_business_postcondition(self):
        configs, _binary, marker = self.scanner_configs()
        self.config.update(configs)
        host = self.host()
        self.assertTrue(host.call('tree.inspect', {})['ok'])
        self.assertFalse(marker.exists())
        result = host.call('tree.run', {'profile': 'scanner', 'request_id': 'owned-tree-run'})
        self.assertTrue(result['ok'], result)
        self.assertFalse(result['unknown_effect'], result)
        self.assertEqual(marker.read_text(), 'owned-scanner-complete')
        self.assertEqual(host.state.audit()['effects'][0]['status'], 'done')

    def test_packaged_mcp_real_network_scan_capture_and_tree(self):
        configs, binary, marker = self.scanner_configs()
        origin, observations = self.loopback()
        self.config.update(configs)
        self.config['network_policy'] = self.network_config(origin)
        specification = importlib.util.spec_from_file_location('revision_builder', ROOT / 'build-source.py')
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        archive = zipfile.ZipFile(io.BytesIO(builder.build()))
        package = self.root / 'package'
        archive.extractall(package)
        config_file = self.root / 'mcp-config.json'
        config_file.write_text(json.dumps(self.config))
        tools = [('network.inspect', {}), ('network.request', {'profile': 'read', 'request_id': 'mcp-read'}),
                 ('malware.scan', {'profile': 'scanner'}),
                 ('files.capture', {'profile': 'scanner', 'request_id': 'mcp-capture'}),
                 ('tree.run', {'profile': 'scanner', 'request_id': 'mcp-tree'}), ('runtime.audit', {})]
        requests = [{'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
            'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'revision-real-check'}}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'}]
        requests.extend({'jsonrpc': '2.0', 'id': index + 2, 'method': 'tools/call',
                         'params': {'name': name, 'arguments': args}}
                        for index, (name, args) in enumerate(tools))
        process = subprocess.run([sys.executable, str(package / 'runtime-access.pyz'), 'serve',
                                  '--config', str(config_file)],
            input=('\n'.join(json.dumps(row) for row in requests) + '\n').encode(),
            capture_output=True, timeout=30, check=True)
        responses = [json.loads(line) for line in process.stdout.splitlines()]
        values = [row['result']['structuredContent'] for row in responses[1:]]
        self.assertEqual(len(values), len(tools))
        for (name, _), value in zip(tools, values):
            self.assertTrue(value['ok'], (name, value, process.stderr.decode()))
        self.assertEqual(observations, [('GET', '/health', b'')])
        self.assertEqual(values[2]['data']['artifact']['sha256'], digest(binary))
        self.assertEqual(values[3]['data']['binary_sha256'], digest(binary))
        self.assertEqual(marker.read_text(), 'owned-scanner-complete')
        self.assertEqual({row['tool'] for row in values[-1]['data']['effects']},
                         {'network.request', 'files.capture', 'tree.run'})


if __name__ == '__main__':
    unittest.main()
