"""Regression contracts for real-world menu pressure and scoped query handles."""
import copy
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0,str(RUNTIME))
from observation_extension.native_accessibility import _Session,_Atspi,AccessibilityError
from observation_extension.native_runtime import ProcessSession,NativeRuntimeError


def node(role, text='', *, name='', showing=True, editable=False, private=False):
    return {'role':role,'role_id':40 if private else 1,
        'states':{'defunct':False,'editable':editable,'enabled':True,'sensitive':True,'showing':showing,'stale':False,'visible':True},
        'redacted':private,'name':name,'text':text,'text_truncated':False,
        'actions':[{'index':0,'name':'activate'}], 'links':[]}


class Backend:
    def __init__(self):
        self.rows={1:node('application',showing=False),2:node('frame'),3:node('menu',name='File'),
            4:node('menu',name='Hidden submenu',showing=False),5:node('text','Actual editor',editable=True)}
        self.tree={0:[1],1:[2],2:[3,5],3:[4],4:list(range(10,310))}
        self.rows.update({n:node('menu item',name='Hidden item '+str(n),showing=False) for n in range(10,310)})
        self.dispatched=[]
    def desktop(self):return 0
    def pid(self,obj):return 42
    def child_count(self,obj):return len(self.tree.get(obj,[]))
    def child(self,obj,index):return self.tree[obj][index]
    def describe(self,obj,redacted):
        row=copy.deepcopy(self.rows[obj])
        if redacted or row['redacted']:
            row.update(redacted=True,name='',text='',actions=[],links=[])
        return row
    def release(self,obj):pass
    def close(self):pass
    def action(self,obj,index):self.dispatched.append(obj);return True


class NativeQueryTests(unittest.TestCase):
    def test_setter_ack_without_text_readback_remains_unknown_and_fenced(self):
        backend=Backend();backend.rows[5]['can_set_text']=True;backend.set_text=lambda _obj,_text:True
        session=self.session(backend);snapshot=session.snapshot({'query':'Actual','roles':['text'],'limit':1})
        result=session.invoke(snapshot['snapshot_id'],snapshot['nodes'][0]['node_id'],0,text='not observed')
        self.assertEqual(result['status'],'unknown');self.assertIs(result['text_verified'],False)
        self.assertEqual(result['reason'],'text_readback_unverified');self.assertTrue(session.fenced)

    def test_optional_hyperlink_metadata_is_bounded_and_does_not_abort_query(self):
        from types import SimpleNamespace
        backend=object.__new__(_Atspi);released=[];backend.release=released.append
        backend.a=SimpleNamespace(atspi_accessible_get_hyperlink=lambda _obj:42)
        backend._call=lambda *_args:100
        backend._string=lambda _method,_obj,index:'https://example.com/'+str(index)
        result=backend.hyperlinks(1)
        self.assertEqual(len(result['links']),16);self.assertTrue(result['links_truncated']);self.assertEqual(released,[42])
        backend._call=lambda *_args:-1
        result=backend.hyperlinks(1);self.assertEqual(result['links'],[]);self.assertTrue(result['links_unavailable'])

    def test_related_label_matches_unnamed_input_and_label_change_blocks_action(self):
        backend=Backend();backend.rows[5]['labels']=['Search for:'];backend.rows[5]['label_source']='parent-labelled-by'
        session=self.session(backend);snapshot=session.snapshot({'query':'search for:','roles':['text'],'limit':1})
        self.assertEqual(snapshot['nodes'][0]['text'],'Actual editor')
        self.assertEqual(snapshot['nodes'][0]['labels'],['Search for:'])
        backend.rows[5]['labels']=['Replace with:']
        with self.assertRaisesRegex(AccessibilityError,'accessibility_snapshot_stale'):
            session.invoke(snapshot['snapshot_id'],snapshot['nodes'][0]['node_id'],0)
        self.assertEqual(backend.dispatched,[])

    def test_missing_text_interface_is_known_refusal_and_does_not_fence(self):
        backend=Backend();backend.rows[5]['can_set_text']=False;session=self.session(backend)
        snapshot=session.snapshot({'query':'Actual','roles':['text'],'limit':1});chosen=snapshot['nodes'][0]
        with self.assertRaises(AccessibilityError) as refused:
            session.invoke(snapshot['snapshot_id'],chosen['node_id'],0,text='must not dispatch')
        self.assertEqual(str(refused.exception),'native_text_interface_unsupported')
        self.assertIs(refused.exception.effect_dispatched,False);self.assertFalse(session.fenced)
        session.invoke(snapshot['snapshot_id'],chosen['node_id'],0)
        self.assertEqual(backend.dispatched,[5])

    def test_atspi_state_numbers_follow_external_abi(self):
        from types import SimpleNamespace
        backend=object.__new__(_Atspi);backend.release=lambda _obj:None
        backend.a=SimpleNamespace(atspi_accessible_get_state_set=lambda _obj:42,
            atspi_state_set_contains=lambda _set,state:state in {4,10,12,23})
        states=backend.states(123)
        self.assertTrue(states['checked']);self.assertTrue(states['expanded'])
        self.assertTrue(states['focused']);self.assertTrue(states['selected']);self.assertFalse(states['editable'])

    def test_related_label_cannot_escape_private_or_foreign_ancestry(self):
        from types import SimpleNamespace
        backend=object.__new__(_Atspi);backend.include_editable_text=False;released=[]
        parents={1:2,2:3};roles={1:29,2:40,3:75}
        backend.a=SimpleNamespace(atspi_accessible_clear_cache_single=lambda _obj:None)
        backend.release=released.append;backend.pid=lambda _obj:42
        backend.states=lambda _obj:{'editable':False,'defunct':False,'stale':False,'showing':True}
        backend._call=lambda method,obj:roles[obj] if method=='atspi_accessible_get_role' else parents.get(obj)
        backend._string=lambda method,obj,**_kwargs:('Search for:' if method=='atspi_accessible_get_name'
            else 'application' if obj==3 else 'label' if obj==1 else 'panel')
        self.assertIsNone(backend._safe_label(1,42));self.assertEqual(released,[2])
        roles[2]=20;released.clear()
        self.assertEqual(backend._safe_label(1,42),'Search for:');self.assertEqual(released,[2,3])
        backend.pid=lambda obj:99 if obj==2 else 42
        self.assertIsNone(backend._safe_label(1,42))

    def session(self,backend):
        session=_Session(backend,42,lambda:None,{'operation_timeout_ms':1000,'max_nodes':128,
            'max_text_bytes':16384,'max_depth':32,'allow_text_input':True},True)
        self.addCleanup(session.close);return session

    def test_hidden_menus_do_not_exhaust_snapshot_before_document(self):
        session=self.session(Backend());snapshot=session.snapshot()
        self.assertTrue(any(n['text']=='Actual editor' for n in snapshot['nodes']))
        self.assertFalse(any('Hidden' in n['name'] for n in snapshot['nodes']))
        self.assertFalse(snapshot['truncated'])

    def test_query_handle_can_act_once_and_remains_bound_to_private_ancestry(self):
        backend=Backend();session=self.session(backend)
        snapshot=session.snapshot({'query':'actual','roles':['text'],'limit':1})
        self.assertEqual(len(snapshot['nodes']),1);chosen=snapshot['nodes'][0]
        session.invoke(snapshot['snapshot_id'],chosen['node_id'],0)
        with self.assertRaisesRegex(AccessibilityError,'accessibility_snapshot_stale'):
            session.invoke(snapshot['snapshot_id'],chosen['node_id'],0)
        self.assertEqual(backend.dispatched,[5])
        snapshot=session.snapshot({'query':'Actual','roles':['text'],'limit':1})
        backend.rows[2]['redacted']=True
        with self.assertRaisesRegex(AccessibilityError,'accessibility_snapshot_stale'):
            session.invoke(snapshot['snapshot_id'],snapshot['nodes'][0]['node_id'],0)
        self.assertEqual(backend.dispatched,[5])

    def test_redacted_subtrees_never_match_query(self):
        backend=Backend();backend.rows[2]['redacted']=True
        snapshot=self.session(backend).snapshot({'query':'Actual','roles':[],'limit':16})
        self.assertEqual(snapshot['nodes'],[])

    def test_scan_and_result_limits_are_explicit(self):
        backend=Backend();backend.tree={0:[1],1:list(range(10,5010))}
        backend.rows.update({n:node('text','other') for n in range(10,5010)})
        snapshot=self.session(backend).snapshot({'query':'no match','roles':[],'limit':1})
        self.assertEqual(snapshot['nodes'],[]);self.assertEqual(snapshot['nodes_examined'],4096)
        self.assertTrue(snapshot['truncated'])

    def test_accessibility_bridge_is_an_explicit_child_only_launch_option(self):
        before={key:os.environ.get(key) for key in ('ACCESSIBILITY_ENABLED','GNOME_ACCESSIBILITY','NO_AT_BRIDGE')}
        process=ProcessSession.launch([sys.executable,'-c','import os;print(os.environ["ACCESSIBILITY_ENABLED"],os.environ["GNOME_ACCESSIBILITY"],os.environ["NO_AT_BRIDGE"])'],
                                      enable_accessibility=True,stdout=subprocess.PIPE)
        try:
            self.assertEqual(process.child.communicate(timeout=3)[0],b'1 1 0\n')
        finally:process.close();process.child.stdout.close()
        self.assertEqual({key:os.environ.get(key) for key in before},before)
        with self.assertRaisesRegex(NativeRuntimeError,'invalid_accessibility_launch_option'):
            ProcessSession.launch(['/usr/bin/true'],enable_accessibility='true')


if __name__=='__main__':unittest.main()
