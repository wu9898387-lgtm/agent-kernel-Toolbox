from concurrent.futures import ThreadPoolExecutor
import copy
import operator
from pathlib import Path
import random
import shutil
import sys
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.translation import (TranslationEngine, TranslationError,
                                              emit_c, interpret, validate_module)


def program(width=64):
    return {'schema_version': 1, 'width': width, 'inputs': ['x', 'y'], 'instructions': [
        {'id': 'sum', 'op': 'add', 'args': ['x', 'y']},
        {'id': 'delta', 'op': 'sub', 'args': ['sum', 'y']},
        {'id': 'result', 'op': 'xor', 'args': ['delta', 'y']},
    ], 'result': 'result'}


OPERATIONS = ['const', 'add', 'sub', 'mul', 'and', 'or', 'xor', 'shl', 'lshr', 'eq', 'ult', 'slt', 'not', 'neg', 'select']


def all_operations_program(width):
    # One native artifact per width. The input `which` selects each operation's
    # independent output, preventing a checksum from hiding cancelling defects.
    instructions = [{'id': 'seven', 'op': 'const', 'value': 7}]
    previous = 'seven'
    for index, operation in enumerate(OPERATIONS):
        if operation == 'const':
            value = 'seven'
        else:
            value = f'value{index}'
            args = ['x'] if operation in ('not', 'neg') else ['x', 'y']
            if operation == 'select': args = ['x', 'y', 'seven']
            instructions.append({'id': value, 'op': operation, 'args': args})
        instructions.extend([
            {'id': f'index{index}', 'op': 'const', 'value': index},
            {'id': f'pick{index}', 'op': 'eq', 'args': ['which', f'index{index}']},
            {'id': f'result{index}', 'op': 'select', 'args': [f'pick{index}', value, previous]},
        ])
        previous = f'result{index}'
    return {'schema_version': 1, 'width': width, 'inputs': ['x', 'y', 'which'],
            'instructions': instructions, 'result': previous}


def mathematical_oracle(operation, x, y, width):
    mask = (1 << width) - 1
    binary = {'add': operator.add, 'sub': operator.sub, 'mul': operator.mul,
              'and': operator.and_, 'or': operator.or_, 'xor': operator.xor,
              'eq': operator.eq, 'ult': operator.lt}
    if operation in binary:
        return int(binary[operation](x, y)) & mask
    if operation == 'const': return 7
    if operation == 'shl': return (x << (y % width)) & mask
    if operation == 'lshr': return x >> (y % width)
    if operation == 'not': return operator.invert(x) & mask
    if operation == 'neg': return operator.neg(x) & mask
    if operation == 'select': return y if x else 7
    # Independent two's complement interpretation, rather than the code
    # generator/interpreter's sign-bit XOR comparison implementation.
    sign = 1 << (width - 1)
    signed_x = x - (1 << width) if x >= sign else x
    signed_y = y - (1 << width) if y >= sign else y
    return int(signed_x < signed_y)


class WordIRTests(unittest.TestCase):
    def test_arithmetic_boundaries_and_no_input_mutation(self):
        for width in (8, 16, 32, 64):
            module = program(width)
            before = copy.deepcopy(module)
            mask = (1 << width) - 1
            self.assertEqual(interpret(module, {'x': mask, 'y': 1}), mask ^ 1)
            self.assertEqual(module, before)
            for x in (0, 1, 1 << (width - 1), mask):
                self.assertEqual(interpret(module, {'x': x, 'y': mask}), x ^ mask)

    def test_invalid_schema_names_forward_refs_and_operations(self):
        cases = []
        broken = program(); broken['width'] = True; cases.append(broken)
        broken = program(); broken['inputs'] = ['x', 'x']; cases.append(broken)
        broken = program(); broken['instructions'][0]['args'] = ['x', 'later']; cases.append(broken)
        broken = program(); broken['instructions'][0]['op'] = 'system'; cases.append(broken)
        broken = program(); broken['instructions'][0]['id'] = 'x'; cases.append(broken)
        broken = program(); broken['inputs'][0] = 'x); system("id");'; cases.append(broken)
        broken = program(); broken['instructions'] = [{'id': 'c', 'op': 'const', 'value': -1}]; cases.append(broken)
        broken = program(); broken['extra'] = 'C fragment'; cases.append(broken)
        broken = program(); broken['instructions'] *= 100; cases.append(broken)
        broken = program(); broken['result'] = 'absent'; cases.append(broken)
        for module in cases:
            with self.subTest(module=repr(module)[:100]):
                with self.assertRaises(TranslationError): validate_module(module)
        with self.assertRaises(TranslationError): interpret(program(8), {'x': 256, 'y': 0})
        with self.assertRaises(TranslationError): interpret(program(8), {'x': True, 'y': 0})
        with self.assertRaises(TranslationError): interpret(program(8), {'x': 1})

    def test_explicit_shift_signed_compare_select_semantics(self):
        module = {'schema_version': 1, 'width': 8, 'inputs': ['x', 'y'], 'instructions': [
            {'id': 'left', 'op': 'shl', 'args': ['x', 'y']},
            {'id': 'negative', 'op': 'slt', 'args': ['x', 'y']},
            {'id': 'r', 'op': 'select', 'args': ['negative', 'left', 'y']},
        ], 'result': 'r'}
        self.assertEqual(interpret(module, {'x': 255, 'y': 8}), 255)  # shift 8 % 8
        self.assertEqual(interpret(module, {'x': 127, 'y': 8}), 8)
        source = emit_c(module)
        self.assertIn('% 8ULL', source)
        self.assertNotIn('negative =', source)  # user identifiers never enter C


@unittest.skipUnless(sys.platform == 'linux' and shutil.which('cc'), 'Linux C compiler required')
class NativeTranslationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.engine = TranslationEngine(shutil.which('cc'), self.directory / 'cache')

    def tearDown(self):
        self.temporary.cleanup()

    def test_aot_cache_jit_and_build_identity(self):
        module = program()
        first = self.engine.compile(module, build_id='fixture-1')
        self.assertFalse(first['cache_hit'])
        self.assertEqual(first['artifact_abi']['architecture'], self.engine.native['architecture'])
        second = self.engine.compile(module, build_id='fixture-1')
        self.assertTrue(second['cache_hit'])
        self.assertEqual(first['cache_key'], second['cache_key'])
        self.assertNotEqual(first['cache_key'], self.engine.compile(module, build_id='fixture-2')['cache_key'])
        result = self.engine.run(module, {'x': (1 << 64) - 1, 'y': 7}, build_id='fixture-1')
        self.assertTrue(result['cache_hit'])
        self.assertTrue(result['oracle_checked'])
        self.assertEqual(result['value'], ((1 << 64) - 1) ^ 7)
        self.assertEqual(result['execution'], 'native_subprocess')

    def test_generated_native_vs_interpreter_seed_20261113(self):
        rng = random.Random(20261113)
        for width in (8, 16, 32, 64):
            module = all_operations_program(width)
            maximum, sign = (1 << width) - 1, 1 << (width - 1)
            pairs = [(0, 0), (maximum, maximum), (maximum, width), (maximum, width - 1),
                     (sign - 1, sign), (sign, maximum), (0, maximum)]
            pairs.extend((rng.randrange(1 << width), rng.randrange(1 << width)) for _ in range(4))
            for index, operation in enumerate(OPERATIONS):
                for x, y in pairs:
                    with self.subTest(width=width, operation=operation, x=x, y=y):
                        inputs = {'x': x, 'y': y, 'which': index}
                        expected = mathematical_oracle(operation, x, y, width)
                        self.assertEqual(interpret(module, inputs), expected)
                        self.assertEqual(self.engine.run(module, inputs)['value'], expected)

    def test_generated_c_with_undefined_behavior_sanitizer(self):
        # The emitter uses ULL for every temporary (including width 8/16), so
        # C's signed integer promotions cannot turn multiplication into UB.
        probe = subprocess.run([self.engine.compiler, '-x', 'c', '-', '-fsanitize=undefined',
                                '-o', str(self.directory / 'sanitizer-probe')],
                               input=b'int main(void) { return 0; }', capture_output=True, timeout=10)
        if probe.returncode:
            self.skipTest('Host compiler does not provide the undefined-behavior sanitizer')
        for width in (8, 16, 32, 64):
            module = all_operations_program(width)
            source, executable = self.directory / f'sanitizer{width}.c', self.directory / f'sanitizer{width}'
            source.write_text(emit_c(module, executable=True))
            built = subprocess.run([self.engine.compiler, '-std=c11', '-O1', '-fsanitize=undefined',
                                    '-fno-sanitize-recover=all', str(source), '-o', str(executable)],
                                   capture_output=True, timeout=10)
            self.assertEqual(built.returncode, 0, built.stderr.decode('utf-8', 'replace'))
            maximum = (1 << width) - 1
            for index, operation in enumerate(OPERATIONS):
                for x, y in [(maximum, maximum), (maximum, width - 1), (maximum, width), (0, maximum)]:
                    result = subprocess.run([str(executable), str(x), str(y), str(index)],
                                            capture_output=True, timeout=2)
                    with self.subTest(width=width, operation=operation, x=x, y=y):
                        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
                        self.assertEqual(result.stderr, b'')
                        self.assertEqual(int(result.stdout), mathematical_oracle(operation, x, y, width))

    def test_cache_tampering_and_compiler_digest_fail_closed(self):
        first = self.engine.compile(program())
        path = Path(first['path'])
        path.chmod(0o600)
        path.write_bytes(b'not an executable')
        with self.assertRaisesRegex(TranslationError, 'cache_integrity'):
            self.engine.run(program(), {'x': 1, 'y': 2})
        with self.assertRaisesRegex(TranslationError, 'compiler_digest_mismatch'):
            TranslationEngine(shutil.which('cc'), self.directory / 'bad', compiler_sha256='0' * 64)

    def test_private_cache_and_rejected_target(self):
        public = self.directory / 'public'
        public.mkdir(mode=0o755)
        public.chmod(0o755)
        with self.assertRaisesRegex(TranslationError, 'cache_must_be_private'):
            TranslationEngine(shutil.which('cc'), public)
        with self.assertRaisesRegex(TranslationError, 'unsupported_target'):
            self.engine.compile(program(), target='aarch64;rm -rf /', kind='object')
        with self.assertRaisesRegex(TranslationError, 'foreign_execution_denied'):
            self.engine.compile(program(), target='i686-linux-gnu')

    def test_compiler_defect_is_caught_by_independent_oracle(self):
        original = emit_c
        def defective(module, *, executable=False):
            return original(module, executable=executable).replace('(v0 + v1)', '(v0 - v1)', 1)
        with patch('observation_extension.translation.emit_c', defective):
            with self.assertRaisesRegex(TranslationError, 'native_semantics_mismatch'):
                self.engine.run(program(), {'x': 11, 'y': 3})

    def test_shared_cache_publication_and_capacity_limit(self):
        other = TranslationEngine(shutil.which('cc'), self.directory / 'cache')
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(engine.compile, program()) for engine in (self.engine, other)]
            first, second = [future.result(timeout=15) for future in futures]
        self.assertEqual(first['sha256'], second['sha256'])
        self.assertEqual(sorted([first['cache_hit'], second['cache_hit']]), [False, True])
        with patch('observation_extension.translation.MAX_CACHE_ENTRIES', 1):
            self.assertTrue(self.engine.compile(program())['cache_hit'])
            with self.assertRaisesRegex(TranslationError, 'cache_budget'):
                self.engine.compile(program(8))

    def test_foreign_x86_object_is_real_elf32_and_not_executed(self):
        if self.engine.native['architecture'] != 'x86_64': self.skipTest('GCC multilib object test requires x86_64')
        result = self.engine.compile(program(), kind='object', target='i686-linux-gnu')
        self.assertEqual(result['artifact_abi']['architecture'], 'x86')
        self.assertEqual(result['artifact_abi']['pointer_bits'], 32)
        raw = Path(result['path']).read_bytes()
        self.assertEqual(raw[:5], b'\x7fELF\x01')
        self.assertEqual(int.from_bytes(raw[16:18], 'little'), 1)  # ET_REL
        self.assertNotEqual(result['cache_key'], self.engine.compile(program(), kind='object')['cache_key'])


if __name__ == '__main__': unittest.main()
