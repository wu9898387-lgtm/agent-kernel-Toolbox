"""Real stdio MCP integration for fixed portable compilation profiles.

These tests invoke actual compiler processes and inspect their object bytes.
Cross-platform checks validate objects only; they do not execute foreign code.
The packaged zipapp is the default. RUNTIME_MCP_ENTRY selects another explicit
entrypoint for a development check.
"""
from contextlib import contextmanager
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(ROOT / 'tools'))
from check_browser_mcp import Client

BUILD_TOOLS = ['build.inspect', 'build.plan', 'build.compile', 'runtime.audit']
MODULE = {'schema_version': 1, 'width': 64, 'inputs': ['x', 'y'],
          'instructions': [{'id': 'sum', 'op': 'add', 'args': ['x', 'y']},
                           {'id': 'result', 'op': 'xor', 'args': ['sum', 'y']}], 'result': 'result'}
ZIG = os.environ.get('RUNTIME_ZIG') or shutil.which('zig')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(sys.platform == 'linux' and shutil.which('gcc'), 'Linux and a real GCC compiler required')
class BuildHostTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.source = self.directory / 'owned-word-ir.json'
        self.source.write_text(json.dumps(MODULE))
        self.original = self.source.read_bytes()
        self.compiler = str(Path(shutil.which('gcc')).resolve())
        self.state = self.directory / 'state'
        profile = {'module_path': str(self.source), 'module_sha256': digest(self.source),
                   'target': 'host', 'allow_compile': True}
        self.config = {'schema_version': 1, 'state_directory': str(self.state), 'allowed_tools': BUILD_TOOLS,
                       'portable_build': {'compiler': self.compiler, 'compiler_sha256': digest(self.compiler),
                           'profiles': {'owned': profile, 'read-only': {**profile, 'allow_compile': False}}}}
        self.entry = Path(os.environ.get('RUNTIME_MCP_ENTRY', str(RUNTIME))).resolve()
        self.version = json.loads((ROOT / 'runtime-manifest.json').read_text())['version']

    @contextmanager
    def server(self, config=None):
        config = self.config if config is None else config
        path = self.directory / 'host.json'
        path.write_text(json.dumps(config))
        path.chmod(0o600)
        with tempfile.TemporaryFile() as stderr:
            client = Client(self.entry, ROOT, path, stderr)
            try:
                initialized = client.exchange('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                    'clientInfo': {'name': 'owned-build-integration', 'version': '1'}})
                self.assertEqual(initialized['serverInfo']['version'], self.version)
                client.exchange('notifications/initialized', {}, notify=True)
                tools = client.exchange('tools/list', {})['tools']
                self.assertEqual({tool['name'] for tool in tools}, set(config['allowed_tools']))
                yield client, {tool['name']: tool for tool in tools}
            finally:
                client.close()
                stderr.seek(0)
                self.assertEqual(client.child.returncode, 0, stderr.read().decode('utf-8', errors='replace'))

    def call(self, client, tool, arguments=None):
        envelope = client.exchange('tools/call', {'name': tool, 'arguments': arguments or {}})
        result = envelope['structuredContent']
        self.assertEqual(envelope['isError'], not result['ok'])
        return result

    def success(self, client, tool, arguments=None):
        result = self.call(client, tool, arguments)
        self.assertTrue(result['ok'], result)
        self.assertFalse(result.get('unknown_effect'), result)
        return result['data']

    def refused(self, client, tool, arguments, code):
        result = self.call(client, tool, arguments)
        self.assertFalse(result['ok'], result)
        self.assertEqual(result['error'], code)
        self.assertFalse(result.get('effect_unknown', False), result)
        self.assertFalse(result.get('effect_dispatched', False), result)
        return result

    def object_bytes(self, result, expected_format):
        artifact = Path(result['artifact_path'])
        self.assertTrue(artifact.is_relative_to(self.state))
        raw = artifact.read_bytes()
        self.assertEqual(result['artifact_sha256'], hashlib.sha256(raw).hexdigest())
        self.assertEqual(result['artifact_bytes'], len(raw))
        self.assertEqual(result['artifact_abi']['format'], expected_format)
        self.assertFalse(result['input_executed'])
        self.assertFalse(result['target_execution_verified'])
        self.assertTrue(result['linking_required'])
        return raw

    def test_actual_gcc_object_cache_and_request_replay_across_mcp_restart(self):
        with self.server() as (client, tools):
            inspected = self.success(client, 'build.inspect')
            self.assertFalse(inspected['compiler_invoked'])
            planned = self.success(client, 'build.plan', {'profile': 'owned'})
            self.assertTrue(planned['source_digest_verified'])
            self.assertFalse(planned['compiler_invoked'])
            self.assertEqual(set(tools['build.compile']['inputSchema']['required']), {'profile', 'request_id'})
            self.assertEqual(set(tools['build.compile']['inputSchema']['properties']), {'profile', 'request_id'})
            self.assertFalse(tools['build.compile']['inputSchema']['additionalProperties'])
            self.assertTrue(tools['build.inspect']['annotations']['readOnlyHint'])
            self.assertFalse(tools['build.compile']['annotations']['readOnlyHint'])
            first = self.success(client, 'build.compile', {'profile': 'owned', 'request_id': 'compile-first'})
            raw = self.object_bytes(first, 'ELF')
            self.assertEqual(raw[:4], b'\x7fELF')
            order = 'little' if raw[5] == 1 else 'big'
            self.assertEqual(int.from_bytes(raw[16:18], order), 1, 'compiler output must be ET_REL')
            self.assertFalse(first['cache_hit'])
            second = self.success(client, 'build.compile', {'profile': 'owned', 'request_id': 'compile-cached'})
            self.assertTrue(second['cache_hit'])
            self.assertEqual(first['artifact_sha256'], second['artifact_sha256'])
            self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': 'compile-first'}, 'request_replay')
        with self.server() as (client, _tools):
            self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': 'compile-first'}, 'request_replay')
            restarted = self.success(client, 'build.compile', {'profile': 'owned', 'request_id': 'compile-restarted'})
            self.assertTrue(restarted['cache_hit'])
            self.assertEqual(first['cache_key'], restarted['cache_key'])
        print('REAL_BUILD_MCP_GCC ' + json.dumps({'format': 'ELF', 'bytes': len(raw),
            'sha256': first['artifact_sha256'], 'cache_verified': True, 'replay_across_restart_refused': True}))

    def test_tool_allowlist_prevents_backend_dispatch(self):
        config = copy.deepcopy(self.config)
        config['allowed_tools'].remove('build.compile')
        with self.server(config) as (client, tools):
            self.assertNotIn('build.compile', tools)
            self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': 'not-allowlisted'},
                         'endpoint_not_allowlisted')
            self.assertEqual(self.success(client, 'runtime.audit')['effects'], [])
            self.assertFalse((self.state / 'portable_build').exists())

    def test_schema_rejection_cannot_override_fixed_compiler_or_consume_request_id(self):
        with self.server() as (client, _tools):
            for extra in ({'compiler': '/bin/sh'}, {'target': 'aarch64-apple-darwin'}, {'flags': ['-O3']},
                          {'url': 'https://example.invalid/never-fetched'}):
                with self.subTest(extra=extra):
                    self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': 'schema-reuse', **extra},
                                 'invalid_tool_arguments')
            self.refused(client, 'build.plan', {'profile': 7}, 'invalid_tool_arguments')
            self.refused(client, 'build.compile', {'profile': 'owned'}, 'request_id_required')
            self.assertEqual(self.success(client, 'runtime.audit')['effects'], [])
            compiled = self.success(client, 'build.compile', {'profile': 'owned', 'request_id': 'schema-reuse'})
            self.object_bytes(compiled, 'ELF')

    def test_ungranted_profile_refuses_without_unknown_fence_or_compiler(self):
        with self.server() as (client, _tools):
            for identifier in ('ungranted-one', 'ungranted-two'):
                self.refused(client, 'build.compile', {'profile': 'read-only', 'request_id': identifier},
                             'build_compile_not_authorized')
            audit = self.success(client, 'runtime.audit')
            self.assertEqual({item['status'] for item in audit['effects']}, {'done'})
            self.assertEqual({item['request_id'] for item in audit['effects']}, {'ungranted-one', 'ungranted-two'})
            self.assertFalse(list((self.state / 'portable_build').glob('*.o')))

    def test_changed_source_digest_refuses_even_with_existing_cache_and_does_not_fence(self):
        with self.server() as (client, _tools):
            first = self.success(client, 'build.compile', {'profile': 'owned', 'request_id': 'pinned-first'})
            self.source.write_bytes(self.original + b'\n')
            self.refused(client, 'build.plan', {'profile': 'owned'}, 'build_source_digest_mismatch')
            for identifier in ('changed-one', 'changed-two'):
                self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': identifier},
                             'build_source_digest_mismatch')
            self.source.write_bytes(self.original)
            again = self.success(client, 'build.compile', {'profile': 'owned', 'request_id': 'pin-restored'})
            self.assertTrue(again['cache_hit'])
            self.assertEqual(first['artifact_sha256'], again['artifact_sha256'])
            self.assertTrue(all(item['status'] == 'done' for item in self.success(client, 'runtime.audit')['effects']))

    def test_actual_compiler_failure_retains_unknown_and_fences_fresh_request(self):
        # A fixed owned shim forwards to real GCC, adding one deliberately
        # unsupported compiler flag only for the compilation invocation.
        compiler = self.directory / 'owned-failing-gcc'
        compiler.write_text('#!' + sys.executable + '\nimport os,sys\n'
                           'args=sys.argv[1:]\n'
                           'if "--version" not in args: args.append("-fowned-invalid-option")\n'
                           f'os.execv({self.compiler!r}, [{self.compiler!r}] + args)\n')
        compiler.chmod(0o500)
        config = copy.deepcopy(self.config)
        config['portable_build'].update(compiler=str(compiler), compiler_sha256=digest(compiler))
        with self.server(config) as (client, _tools):
            failed = self.call(client, 'build.compile', {'profile': 'owned', 'request_id': 'compiler-failed'})
            self.assertFalse(failed['ok'], failed)
            self.assertEqual(failed['error'], 'translation_tool_failed')
            self.assertTrue(failed['effect_unknown'], failed)
            self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': 'new-after-failure'},
                         'scope_outcome_unresolved')
            audit = self.success(client, 'runtime.audit')
            self.assertEqual(next(item for item in audit['effects'] if item['request_id'] == 'compiler-failed')['status'], 'unknown')
            self.assertFalse(list((self.state / 'portable_build').glob('*.o')))

    def test_version_probe_process_failure_fences_retry_before_wrapper_reexecution(self):
        marker = self.directory / 'version-probe.log'
        compiler = self.directory / 'owned-failing-version-probe'
        compiler.write_text('#!' + sys.executable + '\nimport sys\n'
                           f'with open({str(marker)!r}, "a") as out: out.write(" ".join(sys.argv[1:]) + "\\n")\n'
                           'sys.exit(3)\n')
        compiler.chmod(0o500)
        config = copy.deepcopy(self.config)
        config['portable_build'].update(compiler=str(compiler), compiler_sha256=digest(compiler))
        with self.server(config) as (client, _tools):
            first = self.call(client, 'build.compile', {'profile': 'owned', 'request_id': 'version-failed'})
            self.assertFalse(first['ok'], first)
            self.assertEqual(first['error'], 'translation_tool_failed')
            self.assertTrue(first['effect_unknown'], first)
            self.assertEqual(marker.read_text().splitlines(), ['--version'])
            self.refused(client, 'build.compile', {'profile': 'owned', 'request_id': 'version-retry'},
                         'scope_outcome_unresolved')
            self.assertEqual(marker.read_text().splitlines(), ['--version'], 'fenced retry ran the compiler again')
            audit = self.success(client, 'runtime.audit')
            self.assertEqual(next(item for item in audit['effects'] if item['request_id'] == 'version-failed')['status'], 'unknown')

    def test_equivalent_profile_aliases_share_fence_for_host_and_explicit_target(self):
        marker = self.directory / 'compilation-count.log'
        compiler = self.directory / 'owned-counted-failing-gcc'
        compiler.write_text('#!' + sys.executable + '\nimport os,sys\n'
                           'args=sys.argv[1:]\n'
                           'if "--version" not in args:\n'
                           f' with open({str(marker)!r}, "a") as out: out.write("compile\\n")\n'
                           ' args.append("-fowned-invalid-option")\n'
                           f'os.execv({self.compiler!r}, [{self.compiler!r}] + args)\n')
        compiler.chmod(0o500)
        copied_source = self.directory / 'same-owned-word-ir.json'
        copied_source.write_bytes(self.original)
        explicit_target = subprocess.check_output([self.compiler, '-dumpmachine'], text=True, timeout=5).strip()
        config = copy.deepcopy(self.config)
        config['portable_build'].update(compiler=str(compiler), compiler_sha256=digest(compiler))
        base = config['portable_build']['profiles']['owned']
        config['portable_build']['profiles'] = {'owned': base, 'alias': copy.deepcopy(base),
            'explicit': {**base, 'module_path': str(copied_source), 'target': explicit_target}}
        with self.server(config) as (client, _tools):
            plans = [self.success(client, 'build.plan', {'profile': name})
                     for name in ('owned', 'alias', 'explicit')]
            self.assertEqual({plan['target']['triple'] for plan in plans}, {explicit_target})
            self.assertEqual({plan['source_sha256'] for plan in plans}, {digest(self.source)})
            self.assertTrue(all(plan['compiler_invoked'] is False for plan in plans))
            first = self.call(client, 'build.compile', {'profile': 'owned', 'request_id': 'alias-first-failed'})
            self.assertFalse(first['ok'], first)
            self.assertEqual(first['error'], 'translation_tool_failed')
            self.assertTrue(first['effect_unknown'], first)
            for name in ('alias', 'explicit'):
                self.refused(client, 'build.compile', {'profile': name, 'request_id': 'new-' + name},
                             'scope_outcome_unresolved')
            self.assertEqual(marker.read_text().splitlines(), ['compile'], 'an equivalent profile re-ran the compiler')
            audit = self.success(client, 'runtime.audit')
            self.assertEqual([item['status'] for item in audit['effects']], ['unknown'])

    @unittest.skipUnless(ZIG, 'set RUNTIME_ZIG for real Mach-O and COFF compilation through MCP')
    def test_real_zig_macos_and_windows_objects_through_stdio_mcp(self):
        config = copy.deepcopy(self.config)
        compiler = str(Path(ZIG).resolve())
        config['portable_build'].update(compiler=compiler, compiler_sha256=digest(compiler),
                                        compiler_driver='zig-cc', timeout_seconds=30)
        base = config['portable_build']['profiles']['owned']
        config['portable_build']['profiles'] = {
            'mac': {**base, 'target': 'aarch64-apple-darwin'},
            'windows': {**base, 'target': 'x86_64-pc-windows-msvc'}}
        receipts = []
        with self.server(config) as (client, _tools):
            for profile, format_name, machine in [('mac', 'Mach-O', 0x100000c), ('windows', 'COFF', 0x8664)]:
                with self.subTest(profile=profile):
                    compiled = self.success(client, 'build.compile', {'profile': profile, 'request_id': 'cross-' + profile})
                    raw = self.object_bytes(compiled, format_name)
                    if format_name == 'Mach-O':
                        self.assertEqual(raw[:4], b'\xcf\xfa\xed\xfe')
                        self.assertEqual(int.from_bytes(raw[4:8], 'little'), machine)
                        self.assertEqual(int.from_bytes(raw[12:16], 'little'), 1, 'MH_OBJECT required')
                    else:
                        self.assertEqual(int.from_bytes(raw[:2], 'little'), machine)
                        self.assertGreater(int.from_bytes(raw[2:4], 'little'), 0)
                        self.assertEqual(int.from_bytes(raw[16:18], 'little'), 0, 'relocatable COFF required')
                    receipts.append({'target': compiled['target']['triple'], 'format': format_name,
                                     'bytes': len(raw), 'sha256': compiled['artifact_sha256'],
                                     'target_execution_verified': False})
        print('REAL_BUILD_MCP_CROSS ' + json.dumps(receipts))


if __name__ == '__main__':
    unittest.main()
