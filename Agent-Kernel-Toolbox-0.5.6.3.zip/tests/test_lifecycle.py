"""Real exec, kernel CPU limits, stale mm and owned exit-status regressions."""
import errno,json,os,resource,select,shutil,signal,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0,str(RUNTIME))
from observation_extension.native_runtime import ProcessSession,NativeRuntimeError
from observation_extension.runtime_host import RuntimeHost,SPECS
from observation_extension import native_runtime

class LifecycleTests(unittest.TestCase):
    def owned(self,argv,**options):
        p=ProcessSession.launch(argv,**options)
        def cleanup():
            if p.child.poll() is None:signal.pidfd_send_signal(p.pidfd,signal.SIGKILL);p.child.wait(timeout=3)
            p.close()
            if p.child.stdout:p.child.stdout.close()
        self.addCleanup(cleanup);return p

    def test_exec_preserves_instance_and_termination_but_not_memory_image(self):
        with tempfile.TemporaryDirectory() as directory:
            gate=Path(directory)/'exec'
            p=self.owned(['/bin/sh','-c','while [ ! -e "$1" ]; do sleep .01; done; exec /bin/sleep 30','sh',str(gate)],allow_memory=True,limits={'cpu_seconds':3})
            identity=p.validate_identity();gate.touch();deadline=time.monotonic()+3
            while not p.status()['image_changed']:
                if time.monotonic()>deadline:self.fail('exec did not occur')
                time.sleep(.01)
            self.assertEqual(p.validate_identity(),identity)
            self.assertEqual(p.resources()['limits']['cpu_seconds'],{'soft':3,'hard':4})
            with self.assertRaisesRegex(NativeRuntimeError,'process_image_changed'):p.read_memory(0,1)
            self.assertTrue(p.terminate_owned()['exited'])
            self.assertFalse(p.status()['alive'])

    def test_renamed_and_deleted_executable_are_not_new_processes(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'app';shutil.copyfile('/bin/sleep',path);path.chmod(0o700)
            p=self.owned([str(path),'30']);before=p.validate_identity()
            renamed=path.with_name('renamed');path.rename(renamed)
            self.assertEqual(p.validate_identity(),before);self.assertFalse(p.status()['image_changed']);p.abi()
            renamed.unlink();self.assertFalse(p.status()['image_changed']);p.abi()
            self.assertTrue(p.terminate_owned()['exited'])

    def test_short_commands_exit_status_and_no_fd_leak_over_mcp(self):
        with tempfile.TemporaryDirectory() as directory:
            host=RuntimeHost({'schema_version':1,'state_directory':directory+'/state','allowed_tools':list(SPECS),
                'profiles':{'true':{'argv':['/bin/true']},'exit7':{'argv':['/bin/sh','-c','exit 7']}}},bundle_root=ROOT)
            try:
                before=len(os.listdir('/proc/self/fd'))
                for index in range(30):
                    profile='true' if index%2==0 else 'exit7'
                    result=host.call('process.launch',{'profile':profile,'request_id':'launch-'+str(index)})
                    self.assertTrue(result['ok'],result);sid=result['data']['session_id'];p=host.processes[sid]
                    p.child.wait(timeout=3)
                    result=host.call('process.status',{'session_id':sid});self.assertTrue(result['ok'],result)
                    self.assertEqual(result['data']['returncode'],0 if profile=='true' else 7)
                    self.assertTrue(host.call('process.terminate',{'session_id':sid,'request_id':'done-'+str(index)})['ok'])
                    p.close();del host.processes[sid]
                self.assertEqual(len(os.listdir('/proc/self/fd')),before)
            finally:host.close()

    def test_inherited_cpu_and_descriptor_ceilings_are_never_raised(self):
        script='''
import resource,sys,json
sys.path.insert(0,sys.argv[1])
from observation_extension.native_runtime import ProcessSession
resource.setrlimit(resource.RLIMIT_CPU,(4,6))
resource.setrlimit(resource.RLIMIT_NOFILE,(32,32))
p=ProcessSession.launch(['/bin/sleep','30'],limits={'cpu_seconds':10,'open_files':256})
try:print(json.dumps(p.resources()['limits']))
finally:p.terminate_owned();p.close()
'''
        r=subprocess.run([sys.executable,'-c',script,str(RUNTIME)],capture_output=True,text=True,timeout=8)
        self.assertEqual(r.returncode,0,r.stderr);limits=json.loads(r.stdout)
        self.assertEqual(limits['cpu_seconds'],{'soft':4,'hard':6});self.assertEqual(limits['open_files'],{'soft':32,'hard':32})

    def test_cpu_time_is_not_wall_time_and_zero_grace_is_explicit(self):
        p=self.owned(['/bin/sleep','30'],limits={'cpu_seconds':1})
        time.sleep(1.1);self.assertTrue(p.status()['alive']);p.terminate_owned()
        p=self.owned([sys.executable,'-c','while True:pass'],limits={'cpu_seconds':1,'cpu_grace_seconds':0})
        self.assertEqual(p.child.wait(timeout=15),-signal.SIGKILL)
        self.assertEqual(p.status()['termination_signal'],'SIGKILL')
        self.assertFalse(p.status()['exit_cause_inferred_from_sigkill'])

    @unittest.skipUnless(shutil.which('gcc'),'C compiler needed')
    def test_ignored_soft_cpu_signal_reaches_hard_limit_with_multiple_threads(self):
        with tempfile.TemporaryDirectory() as directory:
            binary=Path(directory)/'app'
            subprocess.run(['gcc','-pthread',str(ROOT/'tests/fixtures/lifecycle.c'),'-o',str(binary)],check=True,timeout=10)
            p=self.owned([str(binary),'cpu'],limits={'cpu_seconds':1,'cpu_grace_seconds':1})
            self.assertEqual(p.child.wait(timeout=20),-signal.SIGKILL)
            self.assertFalse(p.status()['alive'])

    @unittest.skipUnless(shutil.which('gcc'),'C compiler needed')
    def test_same_binary_reexec_cannot_reopen_a_new_memory_image(self):
        with tempfile.TemporaryDirectory() as directory:
            binary=Path(directory)/'app';gate=Path(directory)/'continue'
            subprocess.run(['gcc','-no-pie','-pthread',str(ROOT/'tests/fixtures/lifecycle.c'),'-o',str(binary)],check=True,timeout=10)
            p=self.owned([str(binary),'first',str(gate)],allow_memory=True,stdout=subprocess.PIPE)
            self.assertTrue(select.select([p.child.stdout],[],[],3)[0]);address,value=p.child.stdout.readline().decode().split()
            self.assertEqual(p.read_value(int(address,16),8,'uint64')['value'],['7'])
            gate.touch();self.assertTrue(select.select([p.child.stdout],[],[],3)[0]);second,value=p.child.stdout.readline().decode().split()
            self.assertEqual(address,second);self.assertEqual(value,'11');self.assertFalse(p.status()['image_changed'])
            with self.assertRaisesRegex(NativeRuntimeError,'memory_image_changed_or_partial_read'):p.read_memory(int(address,16),8)
            self.assertTrue(p.status()['memory_binding_invalid']);self.assertTrue(p.terminate_owned()['exited'])

    def test_forged_birth_identity_refuses_signal_and_real_time_signal_status_is_valid(self):
        p=self.owned(['/bin/sleep','30']);original=p.identity['start_ticks'];p.identity['start_ticks']=str(int(original)+1)
        with self.assertRaisesRegex(NativeRuntimeError,'process_identity_changed'):p.terminate_owned()
        self.assertIsNone(p.child.poll());p.identity['start_ticks']=original
        signal.pidfd_send_signal(p.pidfd,signal.SIGRTMIN+1);p.child.wait(timeout=3)
        self.assertEqual(p.status()['termination_signal_number'],signal.SIGRTMIN+1)

    def test_exit_between_liveness_check_and_term_or_kill_is_confirmed(self):
        original=signal.pidfd_send_signal
        for selected in (False,True):
            for raced_signal in (signal.SIGTERM,signal.SIGKILL):
                with self.subTest(selected=selected,signal=raced_signal):
                    child=self.owned([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print("ready",flush=True);time.sleep(30)'],stdout=subprocess.PIPE)
                    self.assertTrue(select.select([child.child.stdout],[],[],3)[0]);self.assertEqual(child.child.stdout.readline(),b'ready\n')
                    target=ProcessSession.attach(child.pid,allow_terminate=True,expected_identity=child.identity) if selected else child
                    if selected:self.addCleanup(target.close)
                    triggered=False
                    def race(fd,signum,*args,**kwargs):
                        nonlocal triggered
                        if fd==target.pidfd and signum==raced_signal:
                            triggered=True;original(fd,signal.SIGKILL);child.child.wait(timeout=3)
                        return original(fd,signum,*args,**kwargs)
                    with patch.object(native_runtime.signal,'pidfd_send_signal',side_effect=race):
                        result=(target.terminate_selected if selected else target.terminate_owned)(grace_seconds=0)
                    self.assertTrue(triggered);self.assertTrue(result['exited']);self.assertFalse(target.status()['alive'])

    def test_tree_budget_is_rejected_without_fallback_and_failed_exec_is_known_no_dispatch(self):
        with self.assertRaisesRegex(NativeRuntimeError,'process_tree_cpu_budget_requires_delegated_cgroup'):
            ProcessSession.launch(['/bin/sleep','30'],limits={'cpu_seconds':1,'cpu_scope':'process_tree'})
        with tempfile.TemporaryDirectory() as directory:
            bad=Path(directory)/'bad';bad.write_bytes(b'not an executable');bad.chmod(0o700)
            host=RuntimeHost({'schema_version':1,'state_directory':directory+'/state','allowed_tools':list(SPECS),
                'profiles':{'bad':{'argv':[str(bad)]}}},bundle_root=ROOT)
            try:
                for request in ('first','second'):
                    result=host.call('process.launch',{'profile':'bad','request_id':request})
                    self.assertFalse(result['ok']);self.assertFalse(result['effect_unknown']);self.assertEqual(result['error'],'launch_executable_format_unsupported')
            finally:host.close()

    def test_partial_pipe_allocation_failure_leaks_no_descriptors(self):
        original=os.pipe2
        with tempfile.TemporaryDirectory() as directory:
            library=Path(directory)/'library';library.touch()
            policy=Path(directory)/'policy';policy.touch()
            for failure in (1,2,3):
                with self.subTest(allocation=failure):
                    before=set(os.listdir('/proc/self/fd'));calls=0
                    def allocate(flags):
                        nonlocal calls
                        calls+=1
                        if calls==failure:raise OSError(errno.EMFILE,'descriptor exhaustion')
                        return original(flags)
                    with patch.object(native_runtime.os,'pipe2',side_effect=allocate):
                        with self.assertRaises((OSError,NativeRuntimeError)):
                            ProcessSession.launch(['/bin/sleep','30'],render_library=str(library),render_policy=str(policy))
                    leaked=set(os.listdir('/proc/self/fd'))-before
                    # Clean a broken implementation too, so one case cannot mask the next.
                    for fd in leaked:
                        try:os.close(int(fd))
                        except OSError:pass
                    self.assertEqual(leaked,set())

    def test_startup_timeout_reaps_child_and_closes_stdout(self):
        original=subprocess.Popen;children=[]
        def spawn(*args,**kwargs):
            child=original(*args,**kwargs);children.append(child);return child
        before=len(os.listdir('/proc/self/fd'));start=time.monotonic()
        with patch.object(native_runtime,'_LIMIT_LAUNCHER','import time; time.sleep(30)'),patch.object(native_runtime.subprocess,'Popen',side_effect=spawn):
            with self.assertRaisesRegex(NativeRuntimeError,'launch_limits_or_exec_failed') as error:
                ProcessSession.launch(['/bin/sleep','30'],stdout=subprocess.PIPE,startup_timeout_ms=100)
        try:
            self.assertFalse(error.exception.effect_dispatched)
            self.assertEqual(len(children),1);self.assertIsNotNone(children[0].poll())
            self.assertTrue(children[0].stdout.closed)
            self.assertEqual(len(os.listdir('/proc/self/fd')),before)
            self.assertLess(time.monotonic()-start,3)
        finally:
            for child in children:
                if child.poll() is None:child.kill();child.wait(timeout=3)
                child.stdout.close()

if __name__=='__main__':unittest.main()
