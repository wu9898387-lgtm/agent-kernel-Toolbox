import hashlib
import io
import json
import os
from pathlib import Path
import plistlib
import random
import struct
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.app_routes import inspect_app, android_xml, AppRouteError, ANDROID


def binary_xml_fixture(root, utf8=True):
    strings = ['http://schemas.android.com/apk/res/android']
    def index(value):
        if value not in strings: strings.append(value)
        return strings.index(value)
    chunks = []
    def visit(node):
        attrs = []
        for key, value in node.attrib.items():
            namespace = 0xffffffff
            if key.startswith('{'):
                uri, key = key[1:].split('}', 1)
                namespace = index(uri)
            attrs.append(struct.pack('<IIIHBBI', namespace, index(key), index(value), 8, 0, 3, index(value)))
        name = index(node.tag)
        size = 36 + 20 * len(attrs)
        chunks.append(struct.pack('<HHIII', 0x102, 16, size, 1, 0xffffffff)
                      + struct.pack('<IIHHHHHH', 0xffffffff, name, 20, 20, len(attrs), 0, 0, 0) + b''.join(attrs))
        for child in node: visit(child)
        chunks.append(struct.pack('<HHIIIII', 0x103, 16, 24, 1, 0xffffffff, 0xffffffff, name))
    visit(root)
    def length8(value):
        return bytes([value]) if value < 128 else bytes([0x80 | (value >> 8), value & 255])
    data, offsets = bytearray(), []
    for value in strings:
        offsets.append(len(data))
        encoded = value.encode('utf-8' if utf8 else 'utf-16-le')
        units = len(value.encode('utf-16-le')) // 2
        data.extend(length8(units) + length8(len(encoded)) + encoded + b'\0' if utf8
                    else struct.pack('<H', units) + encoded + b'\0\0')
    while len(data) % 4: data.append(0)
    start = 28 + 4 * len(strings)
    pool = struct.pack('<HHIIIIII', 1, 28, start + len(data), len(strings), 0, 0x100 if utf8 else 0, start, 0)
    pool += b''.join(struct.pack('<I', value) for value in offsets) + data
    raw = pool + b''.join(chunks)
    return struct.pack('<HHI', 3, 8, len(raw) + 8) + raw


def manifest(scheme='sample', path='/settings'):
    root = ET.Element('manifest', {'package': 'org.example.fixture'})
    application = ET.SubElement(root, 'application')
    activity = ET.SubElement(application, 'activity', {ANDROID + 'name': '.Settings', ANDROID + 'exported': 'true'})
    intent = ET.SubElement(activity, 'intent-filter')
    ET.SubElement(intent, 'action', {ANDROID + 'name': 'android.intent.action.VIEW'})
    ET.SubElement(intent, 'category', {ANDROID + 'name': 'android.intent.category.BROWSABLE'})
    ET.SubElement(intent, 'data', {ANDROID + 'scheme': scheme, ANDROID + 'host': 'app', ANDROID + 'pathPrefix': path})
    return root


class AppManifestTests(unittest.TestCase):
    def inspect(self, kind, raw):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'artifact'
            path.write_bytes(raw)
            return inspect_app({'path': str(path), 'kind': kind, 'sha256': hashlib.sha256(raw).hexdigest()})

    def test_android_binary_and_plain_xml_route_equivalence(self):
        def apk(raw):
            stream = io.BytesIO()
            with zipfile.ZipFile(stream, 'w') as package: package.writestr('AndroidManifest.xml', raw)
            return stream.getvalue()
        rng = random.Random(20261102)
        for _ in range(16):
            root = manifest('sample' + str(rng.randrange(100000)), '/' + '路径' * rng.randrange(1, 75))
            expected = self.inspect('android_apk', apk(ET.tostring(root)))['routes']
            for utf8 in (True, False):
                self.assertEqual(self.inspect('android_apk', apk(binary_xml_fixture(root, utf8)))['routes'], expected)

    def test_apple_electron_windows_and_desktop_declarations(self):
        samples = [
            ('apple_plist', plistlib.dumps({'CFBundleIdentifier': 'org.example.app', 'CFBundleURLTypes': [{'CFBundleURLSchemes': ['sample']}]}, fmt=plistlib.FMT_BINARY)),
            ('electron_package', json.dumps({'name': 'fixture', 'build': {'protocols': {'schemes': ['sample']}}}).encode()),
            ('desktop_entry', b'[Desktop Entry]\nName=Fixture\nExec=ignored --never-execute\nMimeType=x-scheme-handler/sample;\n')]
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            archive.writestr('AppxManifest.xml', '<Package xmlns:uap="urn:fixture"><Identity Name="Fixture"/><uap:Protocol Name="sample"/></Package>')
        samples.append(('windows_appx', stream.getvalue()))
        for kind, raw in samples:
            with self.subTest(kind=kind):
                result = self.inspect(kind, raw)
                self.assertEqual(result['routes'][0]['scheme'], 'sample')
                self.assertFalse(result['runtimeVerified'])
                self.assertFalse(result['executionAuthorized'])

    def test_android_packaged_native_library_abi_is_read_from_elf(self):
        header = bytearray(64)
        header[:7] = b'\x7fELF\x02\x01\x01';header[18:20] = (183).to_bytes(2, 'little')
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            archive.writestr('AndroidManifest.xml', binary_xml_fixture(manifest()))
            archive.writestr('lib/arm64-v8a/libfixture.so', header)
        result = self.inspect('android_apk', stream.getvalue())
        library = result['packagedNativeLibraries'][0]
        self.assertEqual(library['declaredABIDirectory'], 'arm64-v8a')
        self.assertEqual(library['observedHeaderABI']['architecture'], 'aarch64')
        self.assertEqual(library['observedHeaderABI']['pointer_bits'], 64)

    def test_bad_manifests_digest_and_budgets_are_rejected(self):
        raw = binary_xml_fixture(manifest())
        for malformed in [raw[:4], raw[:-1], b'<?xml version="1.0"?><!DOCTYPE a><manifest/>']:
            with self.assertRaises(AppRouteError): android_xml(malformed)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'sample.desktop';path.write_bytes(b'bad')
            with self.assertRaisesRegex(AppRouteError, 'app_artifact_digest_mismatch'):
                inspect_app({'path': str(path), 'kind': 'desktop_entry', 'sha256': '0' * 64})
        result = self.inspect('electron_package', json.dumps({'build': {'protocols': {'schemes': ['sample'] * 200}}}).encode())
        self.assertTrue(result['truncated']);self.assertEqual(len(result['routes']), 128)

    @unittest.skipUnless(os.environ.get('RUNTIME_ANDROID_APK'), 'set RUNTIME_ANDROID_APK to the official pinned NewPipe fixture')
    def test_real_android_apk_binary_manifest(self):
        result = inspect_app({'path': os.environ['RUNTIME_ANDROID_APK'], 'kind': 'android_apk',
                              'sha256': '7b3ee61a449259e69d45e92628df1baacc639cf69c1438cc800468ed133f00d0'})
        self.assertEqual(result['appIdentity'], 'org.schabi.newpipe')
        self.assertTrue(any(route['component'] == 'org.schabi.newpipe.RouterActivity' for route in result['routes']))
        self.assertTrue(any(data.get('scheme') == 'vnd.youtube' for route in result['routes'] for data in route['data']))
        self.assertFalse(result['runtimeVerified'])


if __name__ == '__main__': unittest.main()
