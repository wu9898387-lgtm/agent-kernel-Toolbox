"""Real Ghidra/DIE recovery and cross-ISA p-code execution of owned fixtures.

RUNTIME_GHIDRA must name a supported headless installation launcher with its
required JDK configured. RUNTIME_DIEC may name a pinned user installation wrapper
which supplies its database/library locations. Tool binaries are not bundled.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

FIXTURES = ROOT / 'tests/fixtures/recovery'
sys.path.insert(0, str(RUNTIME))
from observation_extension.analysis_tools import AnalysisTools


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(shutil.which('gcc'), 'C compiler required for owned recovery fixtures')
class GhidraDIEIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.directory = Path(cls.temporary.name)
        cls.objects = {}
        # Fixture compilation is setup, not a target-runtime deadline test.
        # Leave room for host scheduling pauses without changing engine limits.
        for width, flags in ((64, []), (32, ['-m32'])):
            target = cls.directory / ('owned' + str(width) + '.o')
            subprocess.run([shutil.which('gcc'), *flags, '-g', '-O1', '-ffreestanding',
                '-fno-stack-protector', '-fno-pic', '-c', str(FIXTURES / 'ghidra_owned.c'),
                '-o', str(target)], check=True, capture_output=True, timeout=60)
            cls.objects[width] = target
        cls.native = cls.directory / 'owned-native.so'
        subprocess.run([shutil.which('gcc'), '-O1', '-shared', '-fPIC',
            str(FIXTURES / 'ghidra_owned.c'), '-o', str(cls.native)],
            check=True, capture_output=True, timeout=60)

    def run_engine(self, kind, target, operation, arguments=None):
        variable = 'RUNTIME_GHIDRA' if kind == 'ghidra' else 'RUNTIME_DIEC'
        launcher = Path(os.environ[variable]).resolve()
        with tempfile.TemporaryDirectory() as directory:
            profile = {'kind': kind, 'executable': str(launcher), 'sha256': digest(launcher),
                       'timeout_seconds': 120 if kind == 'ghidra' else 30}
            if arguments is not None:
                profile['arguments'] = arguments
            tools = AnalysisTools({'profiles': {'owned': profile},
                'digests': {'owned': digest(target)}}, Path(directory),
                {'owned': str(target)}, bundle_root=ROOT)
            result = tools.run('owned', 'owned', operation)
        self.assertTrue(result['success'], result['stdout'][-5000:] + result['stderr'][-5000:])
        self.assertFalse(result['target_executed'])
        self.assertFalse(result['target_execution_requested'])
        return result

    def test_owned_foreign_fixture_source_and_object_binding(self):
        metadata = json.loads((FIXTURES / 'ghidra_owned_aarch64.build.json').read_text())
        target = FIXTURES / 'ghidra_owned_aarch64.o'
        self.assertEqual(digest(target), metadata['object_sha256'])
        self.assertEqual(digest(FIXTURES / 'ghidra_owned_aarch64.S'), metadata['source_sha256'])
        raw = target.read_bytes()
        self.assertEqual(raw[:6], b'\x7fELF\x02\x01')
        self.assertEqual(int.from_bytes(raw[18:20], 'little'), 183)
        self.assertFalse(metadata['native_foreign_execution'])

    @unittest.skipUnless(os.environ.get('RUNTIME_DIEC'), 'set RUNTIME_DIEC for actual Detect It Easy')
    def test_real_diec_identifies_owned_elf_and_not_runtime_objects(self):
        result = self.run_engine('diec', self.objects[64], 'identify')
        self.assertIn('ELF64', json.dumps(result['identification']))
        self.assertEqual(result['target_sha256'], digest(self.objects[64]))

    @unittest.skipUnless(os.environ.get('RUNTIME_GHIDRA'), 'set RUNTIME_GHIDRA for actual Ghidra')
    def test_real_ghidra_compiler_layout_structured_code_and_typed_pcode(self):
        result = self.run_engine('ghidra', self.objects[64], 'decompile')
        recovery = result['artifacts']['files'][0]['recovery']
        self.assertEqual(recovery['language_id'], 'x86:LE:64:default')
        self.assertEqual(recovery['pointer_bits'], 64)
        self.assertEqual(recovery['byte_order'], 'little')
        self.assertEqual(recovery['program_sha256'], digest(self.objects[64]))
        functions = {row['name']: row for row in recovery['functions']}
        pure = functions['runtime_pure']
        self.assertTrue(pure['decompiled'])
        self.assertIn('if (', pure['pseudocode'])
        self.assertIn('while (', pure['pseudocode'])
        self.assertIn('return ', pure['pseudocode'])
        self.assertTrue(pure['source_file_offset'].startswith('0x'))
        self.assertIn('INT_ADD', {op['opcode'] for op in pure['pcode']})
        node = next(node for op in pure['pcode'] for node in op['input_nodes'])
        self.assertIn(node['space'], ['register', 'const', 'unique', 'ram'])
        self.assertGreater(node['bytes'], 0)
        layout = next(row for row in recovery['static_type_layouts'] if row['type'].endswith('/RuntimePayload'))
        self.assertEqual(layout['size'], 8)
        self.assertEqual([(row['name'], row['offset'], row['size']) for row in layout['fields']],
                         [('tag', 0, 4), ('count', 4, 4)])
        self.assertFalse(recovery['source_equivalence_proven'])
        self.assertFalse(recovery['object_identity_proven'])

    @unittest.skipUnless(os.environ.get('RUNTIME_GHIDRA'), 'set RUNTIME_GHIDRA for actual p-code VM')
    def test_real_shared_pcode_vm_executes_x64_i386_and_aarch64(self):
        native = ctypes.CDLL(str(self.native)).runtime_pure
        native.argtypes = [ctypes.c_int, ctypes.c_int]
        native.restype = ctypes.c_int
        expected = native(7, 5)
        self.assertEqual(expected, 19)
        languages = []
        for target in (self.objects[64], self.objects[32], FIXTURES / 'ghidra_owned_aarch64.o'):
            with self.subTest(target=target.name):
                result = self.run_engine('ghidra', target, 'emulate', ['runtime_pure','7','5','1000'])
                recovery = result['artifacts']['files'][0]['recovery']
                self.assertEqual(recovery['status'], 'completed', recovery)
                self.assertEqual(recovery['returned_u32'], expected)
                self.assertGreater(recovery['steps'], 1)
                self.assertLess(recovery['steps'], recovery['max_steps'])
                self.assertFalse(recovery['native_target_executed'])
                self.assertFalse(recovery['host_process_memory_access'])
                self.assertFalse(recovery['OS_syscalls_supported'])
                self.assertFalse(recovery['device_memory_supported'])
                self.assertEqual(recovery['write_scope'], 'private_emulator_stack')
                self.assertFalse(recovery['functional_equivalence_proven'])
                languages.append(recovery['language_id'])
        self.assertEqual(languages, ['x86:LE:64:default','x86:LE:32:default','AARCH64:LE:64:v8A'])

    @unittest.skipUnless(os.environ.get('RUNTIME_GHIDRA'), 'set RUNTIME_GHIDRA for actual bounded VM')
    def test_real_emulation_budget_and_invalid_pointer_never_become_native_execution(self):
        limited = self.run_engine('ghidra', self.objects[64], 'emulate', ['runtime_pure','7','5','1'])
        trace = limited['artifacts']['files'][0]['recovery']
        self.assertEqual(trace['status'], 'unknown')
        self.assertEqual(trace['reason'], 'step_budget_exhausted')
        self.assertEqual(trace['steps'], 1)
        invalid = self.run_engine('ghidra', self.objects[64], 'emulate', ['runtime_recover','0','5','1000'])
        rejected = invalid['artifacts']['files'][0]['recovery']
        self.assertEqual(rejected['status'], 'unknown')
        self.assertTrue(rejected['reason'].startswith('pcode_step_failed:'), rejected)
        self.assertIsNone(rejected['returned_u32'])
        self.assertFalse(rejected['host_process_memory_access'])


if __name__ == '__main__':
    unittest.main()
