import ctypes
import math
import os
from pathlib import Path
import random
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.abi import binary_abi, inspect_binary_abi, decode_memory, decode_registers, REGISTER_LAYOUTS, ABIError
from observation_extension.native_runtime import ProcessSession, NativeRuntimeError


def elf_header(bits, order, machine):
    raw = bytearray(64 if bits == 64 else 52)
    raw[:7] = b'\x7fELF' + bytes([2 if bits == 64 else 1, 1 if order == 'little' else 2, 1])
    raw[18:20] = machine.to_bytes(2, order)
    return bytes(raw)


class ABITests(unittest.TestCase):
    def test_elf_target_architectures_and_byte_orders(self):
        targets = [(3, 32, 'x86'), (62, 64, 'x86_64'), (40, 32, 'arm'), (183, 64, 'aarch64'),
                   (243, 64, 'riscv64'), (258, 64, 'loongarch64'), (8, 32, 'mips32'),
                   (21, 64, 'ppc64'), (22, 64, 's39064')]
        for machine, bits, arch in targets:
            for order in ['little', 'big']:
                with self.subTest(arch=arch, order=order):
                    actual = binary_abi(elf_header(bits, order, machine))
                    self.assertEqual((actual['pointer_bits'], actual['byte_order'], actual['architecture']), (bits, order, arch))
        self.assertEqual(binary_abi(elf_header(32, 'little', 62))['abi_variant'], 'x32')

    def test_pe_and_macho_without_running_samples(self):
        for machine, bits in [(0x14c, 32), (0x8664, 64), (0xaa64, 64)]:
            raw = bytearray(128);raw[:2] = b'MZ';raw[60:64] = (64).to_bytes(4, 'little')
            raw[64:68] = b'PE\0\0';raw[68:70] = machine.to_bytes(2, 'little')
            raw[88:90] = (0x10b if bits == 32 else 0x20b).to_bytes(2, 'little')
            self.assertEqual(binary_abi(bytes(raw))['pointer_bits'], bits)
        for magic, machine, bits, order in [(b'\xcf\xfa\xed\xfe', 0x100000c, 64, 'little'),
                                            (b'\xfe\xed\xfa\xce', 18, 32, 'big')]:
            self.assertEqual(binary_abi(magic + machine.to_bytes(4, order) + bytes(24))['pointer_bits'], bits)
        for raw in [b'', b'\x7fELF', b'MZ' + bytes(62), bytes(64)]:
            with self.assertRaises(ABIError): binary_abi(raw)

    def test_generated_integer_pointer_roundtrips_seed_20261102(self):
        rng = random.Random(20261102)
        for order, prefix in [('little', '<'), ('big', '>')]:
            for bits, unsigned, signed in [(8, 'B', 'b'), (16, 'H', 'h'), (32, 'I', 'i'), (64, 'Q', 'q')]:
                for _ in range(48):
                    a = rng.randrange(2**bits)
                    b = rng.randrange(-(2**(bits - 1)), 2**(bits - 1))
                    self.assertEqual(decode_memory(struct.pack(prefix + unsigned, a), f'uint{bits}', order, 64), [str(a)])
                    self.assertEqual(decode_memory(struct.pack(prefix + signed, b), f'int{bits}', order, 64), [str(b)])
                    if bits in (32, 64):
                        self.assertEqual(decode_memory(struct.pack(prefix + unsigned, a), 'pointer', order, bits), [hex(a)])
            self.assertEqual(decode_memory((2**128 - 1).to_bytes(16, order), 'uint128', order, 64), [str(2**128 - 1)])

    def test_text_float_and_invalid_boundaries(self):
        for order in ('little', 'big'):
            for bits in (16, 32):
                raw = '状态😀'.encode(f'utf-{bits}-' + ('le' if order == 'little' else 'be'))
                self.assertEqual(decode_memory(raw, f'utf{bits}', order, 64), '状态😀')
        self.assertEqual(decode_memory(struct.pack('>d', 1.25), 'float64', 'big', 32), [1.25])
        for raw, kind in [(b'\xff', 'utf8'), (b'\0', 'uint32'), (b'\0' * 257, 'uint8'),
                          (struct.pack('<d', math.inf), 'float64')]:
            with self.assertRaises(ABIError): decode_memory(raw, kind, 'little', 64)

    def test_register_layout_decoding_uses_target_width(self):
        for arch, (width, names, pc, _) in REGISTER_LAYOUTS.items():
            for order in ('little', 'big'):
                raw = b''.join((i + 123).to_bytes(width, order) for i in range(len(names)))
                registers, actual_pc, _fp = decode_registers(raw, {'architecture': arch, 'byte_order': order})
                self.assertEqual(registers[pc], hex(names.index(pc) + 123))
                self.assertEqual(actual_pc, names.index(pc) + 123)
                with self.assertRaisesRegex(ABIError, 'unexpected_register_layout'):
                    decode_registers(raw[:-1], {'architecture': arch, 'byte_order': order})


@unittest.skipUnless(sys.platform == 'linux' and shutil.which('as') and shutil.which('ld'), 'Linux assembler required')
class Live32BitTests(unittest.TestCase):
    def test_live_32bit_app_memory_pointer_text_and_registers_on_64bit_host(self):
        if os.uname().machine != 'x86_64':
            self.skipTest('This test exercises x86_64 kernel IA32 emulation')
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            obj, binary = directory / 'fixture.o', directory / 'fixture32'
            subprocess.run(['as', '--32', str(ROOT / 'tests/fixtures/native32.S'), '-o', str(obj)], check=True, timeout=10)
            subprocess.run(['ld', '-m', 'elf_i386', str(obj), '-o', str(binary)], check=True, timeout=10)
            symbols = {line.split()[2]: int(line.split()[0], 16)
                       for line in subprocess.check_output(['nm', str(binary)], text=True).splitlines() if len(line.split()) == 3}
            try:
                process = ProcessSession.launch([str(binary)], allow_memory=True, allow_debug=True, stdout=subprocess.PIPE)
            except (OSError, NativeRuntimeError) as error:
                if error.errno == 8:
                    self.skipTest('Host kernel rejects IA32 ELF execution (ENOEXEC); use the separately reported QEMU fixture check')
                raise
            try:
                self.assertEqual(process.child.stdout.readline(), b'native32-ready\n')
                self.assertEqual(process.abi()['pointer_bits'], 32)
                self.assertEqual(process.read_value(symbols['magic_value'], 4, 'uint32')['value'], ['305419896'])
                self.assertEqual(process.read_value(symbols['target_pointer'], 4, 'pointer')['value'], [hex(symbols['magic_value'])])
                self.assertEqual(process.read_value(symbols['text16'], 4, 'utf16')['value'], '状态')
                result = process.cpu_snapshot(max_frames=0)
                self.assertEqual(result['architecture'], 'x86')
                self.assertIn('eip', result['registers'])
                self.assertIn('TracerPid:\t0\n', Path(f'/proc/{process.pid}/status').read_text())
            finally:
                if process.child.poll() is None: process.terminate_owned()
                process.close();process.child.stdout.close()


if __name__ == '__main__': unittest.main()
