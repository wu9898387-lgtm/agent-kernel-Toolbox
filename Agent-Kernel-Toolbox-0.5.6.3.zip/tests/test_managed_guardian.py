"""Actual guardian/host/controller process death and bounded transport checks."""
import json
from contextlib import ExitStack
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
GUARDIAN = ROOT/'tools/managed_jvm_guardian.py'
# CI can deschedule the observing host for seconds. These outer waits and
# positive protocol budgets allow dispatch slack; the explicit 150ms negative
# watchdog cases and production guardian cleanup deadlines remain unchanged.
OBSERVE_TIMEOUT = 10


@unittest.skipUnless(sys.platform == 'linux' and hasattr(os, 'pidfd_open'), 'Linux pidfd required')
class ManagedGuardianTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def source(self, content):
        path = self.root/('controller'+str(len(list(self.root.iterdir())))+'.py')
        path.write_text(content)
        return path

    def launch(self, source, *, startup=10000, command=10000, extra_args=()):
        parent_fd = os.pidfd_open(os.getpid())
        read_fd = ready_fd = None
        child = None
        def close():
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=OBSERVE_TIMEOUT)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(timeout=OBSERVE_TIMEOUT)
            for pipe in (child.stdin, child.stdout, child.stderr):
                pipe.close()
        try:
            try:
                read_fd, ready_fd = os.pipe2(os.O_CLOEXEC)
                child = subprocess.Popen([sys.executable, '-I', '-S', str(GUARDIAN),
                    '--host-pidfd', str(parent_fd), '--ready-fd', str(ready_fd),
                    '--startup-ms', str(startup), '--command-ms', str(command), '--',
                    sys.executable, '-u', str(source), *extra_args], stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    pass_fds=(parent_fd, ready_fd), start_new_session=True, bufsize=0)
                self.addCleanup(close)
            finally:
                os.close(parent_fd)
                if ready_fd is not None:
                    os.close(ready_fd)
            self.assertTrue(select.select([read_fd], [], [], OBSERVE_TIMEOUT)[0], 'controller readiness fd timeout')
            raw = os.read(read_fd, 128)
            self.assertRegex(raw, rb'^[1-9][0-9]*\n$')
            return child, int(raw)
        finally:
            if read_fd is not None:
                os.close(read_fd)

    def line(self, child):
        self.assertTrue(select.select([child.stdout], [], [], OBSERVE_TIMEOUT)[0], 'controller frame timeout')
        return child.stdout.readline()

    def assert_gone(self, pid, timeout=OBSERVE_TIMEOUT):
        deadline = time.monotonic()+timeout
        while Path(f'/proc/{pid}').exists():
            self.assertLess(time.monotonic(), deadline, f'owned child {pid} not reaped')
            time.sleep(.01)

    def launch_with_receipts(self,source,*,bootstrap=None,extra_fds=()):
        with ExitStack()as descriptors:
            host=os.pidfd_open(os.getpid());descriptors.callback(os.close,host)
            ready_read,ready_write=os.pipe2(os.O_CLOEXEC);descriptors.callback(os.close,ready_write)
            self.addCleanup(os.close,ready_read)
            cleanup_read,cleanup_write=os.pipe2(os.O_CLOEXEC);descriptors.callback(os.close,cleanup_write)
            self.addCleanup(os.close,cleanup_read)
            args=['--host-pidfd',str(host),'--ready-fd',str(ready_write),
                  '--cleanup-fd',str(cleanup_write),'--',sys.executable,'-u',str(source)]
            prefix=[sys.executable,'-I','-S',str(GUARDIAN)]if bootstrap is None else[sys.executable,'-I','-S','-c',bootstrap]
            child=subprocess.Popen([*prefix,*args],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                pass_fds=(host,ready_write,cleanup_write,*extra_fds),start_new_session=True,bufsize=0)
            def close():
                if child.poll()is None:
                    child.terminate()
                    try:child.wait(timeout=OBSERVE_TIMEOUT)
                    except subprocess.TimeoutExpired:child.kill();child.wait(timeout=OBSERVE_TIMEOUT)
                for stream in(child.stdin,child.stdout,child.stderr):stream.close()
            self.addCleanup(close)
            return child,ready_read,cleanup_read

    def test_byte_transparent_frames_and_separate_controller_pid(self):
        source = self.source('''import os,sys
print('ready:'+str(os.getpid()),flush=True)
for line in sys.stdin.buffer:
 sys.stdout.buffer.write(line);sys.stdout.buffer.flush()
 if line==b'close\\n':break
''')
        child, pid = self.launch(source)
        self.assertEqual(self.line(child), ('ready:'+str(pid)+'\n').encode())
        payload = b'set\t123\tvalue\t7\t9\n'
        child.stdin.write(payload); child.stdin.flush()
        self.assertEqual(self.line(child), payload)
        child.stdin.write(b'close\n'); child.stdin.flush()
        self.assertEqual(self.line(child), b'close\n')
        self.assertEqual(child.wait(timeout=OBSERVE_TIMEOUT), 0, child.stderr.read().decode())
        self.assert_gone(pid)

    def test_stdin_eof_kills_and_reaps_escaped_owned_descendant(self):
        source = self.source('''import json,os,subprocess,time
p=subprocess.Popen(['/bin/sleep','30'],start_new_session=True)
print(json.dumps({'controller':os.getpid(),'target':p.pid}),flush=True)
time.sleep(30)
''')
        child, controller = self.launch(source)
        frame = json.loads(self.line(child))
        self.assertEqual(frame['controller'], controller)
        child.stdin.close()
        self.assertEqual(child.wait(timeout=OBSERVE_TIMEOUT), 0, child.stderr.read().decode())
        self.assert_gone(controller)
        self.assert_gone(frame['target'])

    def test_empty_argument_is_preserved_after_executable(self):
        source = self.source('''import json,sys
print(json.dumps(sys.argv[1:]),flush=True)
sys.stdin.readline()
''')
        child, _controller = self.launch(source, extra_args=('', 'value'))
        self.assertEqual(json.loads(self.line(child)), ['', 'value'])
        child.stdin.close()
        self.assertEqual(child.wait(timeout=OBSERVE_TIMEOUT), 0)

    def test_host_sigkill_is_detected_even_when_controller_is_stuck(self):
        controller = self.source('''import json,os,subprocess,time
p=subprocess.Popen(['/bin/sleep','30'],start_new_session=True)
print(json.dumps({'controller':os.getpid(),'target':p.pid}),flush=True)
time.sleep(30)
''')
        host = self.source('''import json,os,subprocess,sys,time
fd=os.pidfd_open(os.getpid());read,write=os.pipe2(os.O_CLOEXEC)
p=subprocess.Popen([sys.executable,'-I','-S',sys.argv[1],
 '--host-pidfd',str(fd),'--ready-fd',str(write),'--',sys.executable,'-u',sys.argv[2]],
 stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
 pass_fds=(fd,write),start_new_session=True)
os.close(fd);os.close(write)
pid=int(os.read(read,128));os.close(read)
value=json.loads(p.stdout.readline());value.update(guardian=p.pid)
print(json.dumps(value),flush=True)
time.sleep(30)
''')
        process = subprocess.Popen([sys.executable, '-u', host, GUARDIAN, controller],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            self.assertTrue(select.select([process.stdout], [], [], OBSERVE_TIMEOUT)[0])
            value = json.loads(process.stdout.readline())
            process.kill(); process.wait(timeout=OBSERVE_TIMEOUT)
            self.assert_gone(value['controller'])
            self.assert_gone(value['target'])
            deadline = time.monotonic()+OBSERVE_TIMEOUT
            while Path(f"/proc/{value['guardian']}/stat").exists():
                data = Path(f"/proc/{value['guardian']}/stat").read_text()
                # An exited helper adopted by a non-reaping PID1 is not called
                # running or reaped. Its owned controller/target were reaped.
                if data.rsplit(')',1)[1].split()[0] == 'Z':
                    break
                self.assertLess(time.monotonic(), deadline)
                time.sleep(.01)
        finally:
            if process.poll() is None:process.kill();process.wait(timeout=OBSERVE_TIMEOUT)
            process.stdout.close();process.stderr.close()

    def test_startup_and_pending_command_deadlines_terminate_controller(self):
        for startup, source in [(150, 'import time;time.sleep(30)\n'),
                                 (10000, 'import sys,time;print("ready",flush=True);sys.stdin.readline();time.sleep(30)\n')]:
            child, pid = self.launch(self.source(source), startup=startup, command=150)
            if startup > 150:
                self.assertEqual(self.line(child), b'ready\n')
                child.stdin.write(b'blocked\n');child.stdin.flush()
            self.assertEqual(child.wait(timeout=OBSERVE_TIMEOUT), 124)
            self.assertIn(b'managed_guardian_response_timeout', child.stderr.read())
            self.assert_gone(pid)

    def test_oversized_controller_response_closes_the_owned_group(self):
        child, pid = self.launch(self.source('print("x"*40000,flush=True)\n'))
        child.wait(timeout=OBSERVE_TIMEOUT)
        self.assertEqual(child.returncode, 70)
        self.assert_gone(pid)

    def test_optional_receipts_certify_escaped_descendant_cleanup_and_preserve_frames(self):
        source=self.source('''import json,os,subprocess,time
p=subprocess.Popen(['/bin/sleep','30'],start_new_session=True)
print(json.dumps({'controller':os.getpid(),'target':p.pid}),flush=True)
time.sleep(30)
''')
        child,ready,receipt=self.launch_with_receipts(source)
        self.assertTrue(select.select([ready],[],[],OBSERVE_TIMEOUT)[0])
        controller=int(os.read(ready,128))
        frame=json.loads(self.line(child));self.assertEqual(frame['controller'],controller)
        child.stdin.close();self.assertEqual(child.wait(timeout=OBSERVE_TIMEOUT),0)
        self.assertEqual(os.read(receipt,64),b'MP1 ARMED\nMP1 COMPLETE\n')
        self.assert_gone(controller);self.assert_gone(frame['target'])

    def test_armed_stop_before_spawn_emits_complete_without_starting_target(self):
        gate_read,gate_write=os.pipe2(os.O_CLOEXEC)
        marker=self.root/'target-started'
        source=self.source('from pathlib import Path\nPath('+repr(str(marker))+').write_text("started")\n')
        bootstrap=f'''import os,runpy,sys
namespace=runpy.run_path({str(GUARDIAN)!r},run_name='guardian_library')
scope=namespace['run'].__globals__;receipt=scope['_receipt']
def gated(fd,frame):
 result=receipt(fd,frame)
 if frame==b'MP1 ARMED\\n':os.read({gate_read},1)
 return result
scope['_receipt']=gated
sys.argv=[{str(GUARDIAN)!r},*sys.argv[1:]]
raise SystemExit(namespace['main']())
'''
        try:
            child,ready,receipt=self.launch_with_receipts(source,bootstrap=bootstrap,extra_fds=(gate_read,))
            self.assertTrue(select.select([receipt],[],[],OBSERVE_TIMEOUT)[0])
            self.assertEqual(os.read(receipt,64),b'MP1 ARMED\n')
            child.terminate();os.write(gate_write,b'R')
            self.assertEqual(child.wait(timeout=OBSERVE_TIMEOUT),0)
            self.assertEqual(os.read(receipt,64),b'MP1 COMPLETE\n')
            self.assertEqual(os.read(ready,128),b'')
            self.assertFalse(marker.exists())
        finally:
            os.close(gate_read);os.close(gate_write)


if __name__ == '__main__':
    unittest.main()
