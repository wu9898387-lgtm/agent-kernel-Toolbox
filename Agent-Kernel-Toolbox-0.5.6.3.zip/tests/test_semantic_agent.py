"""Actual Linux C application/Rust controller tests; no protocol mocks."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.semantic_agent import SemanticAgent, SemanticAgentError

CARGO = os.environ.get('RUNTIME_CARGO') or shutil.which('cargo')


@unittest.skipUnless(sys.platform == 'linux' and CARGO and shutil.which('gcc'),
                     'Linux, a C compiler and Rust >=1.89 are required for actual semantic agent tests')
class SemanticAgentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build_directory = tempfile.TemporaryDirectory()
        cls.build_root = Path(cls.build_directory.name)
        try:
            spec = importlib.util.spec_from_file_location('semantic_build', ROOT / 'native/runtime-agent/build.py')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            cls.metadata = module.build(cls.build_root, cargo=CARGO, cc=shutil.which('gcc'))
            cls.controller = cls.build_root / 'runtime-control'
            cls.demo = cls.build_root / 'runtime-agent-demo'
        except BaseException:
            cls.build_directory.cleanup()
            raise

    @classmethod
    def tearDownClass(cls):
        cls.build_directory.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.environment = self.root / 'env'
        self.session = os.urandom(16).hex()
        self.process = subprocess.Popen([self.demo, self.environment, self.session],
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.addCleanup(self._close_process)
        if not select.select([self.process.stdout], [], [], 3)[0]:
            self.fail('agent readiness timeout')
        self.ready = json.loads(self.process.stdout.readline())
        self.assertTrue(self.ready['ready'])
        status = self.run_controller('status')
        self.config = {'path': str(self.controller), 'sha256': self.metadata['artifacts']['runtime-control'],
                       'environment': str(self.environment), 'session': self.session,
                       'epoch': status['epoch'], 'pid': self.process.pid,
                       'build_id': self.metadata['build_id'], 'allowed_slots': [1, 2, 3, 4, 5]}
        self.agent = SemanticAgent(self.config, self.root)
        self.addCleanup(self.agent.close)

    def _close_process(self):
        if self.process.poll() is None:
            self.process.send_signal(signal.SIGCONT)
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=2)
        self.process.stdout.close()
        self.process.stderr.close()

    def run_controller(self, operation, *arguments):
        result = subprocess.run([self.controller, operation, self.environment, self.session, *map(str, arguments)],
                                capture_output=True, timeout=3)
        self.assertLess(len(result.stdout), 16384)
        return json.loads(result.stdout)

    def next_call(self, slot, expected=0, value=0):
        status = self.agent.status()
        return self.agent.call(slot, status['object_generation'], status['request_seq'] + 1, expected, value)

    def test_live_semantic_updates_state_conflicts_and_object_migration(self):
        initial = self.agent.status()
        self.assertEqual(initial['value'], 7)
        self.assertEqual(initial['object_size'], self.ready['object_size'])
        self.assertEqual(initial['field_offset'], self.ready['value_offset'])
        self.assertEqual(initial['build_id'], self.metadata['build_id'])
        self.assertEqual([v['slot'] for v in initial['callbacks']], [1, 2, 3, 4, 5])
        self.assertEqual(self.next_call(1)['value'], 7)
        changed = self.next_call(2, 7, 12)
        self.assertTrue(changed['ok'], changed)
        conflict = self.next_call(2, 7, 99)
        self.assertFalse(conflict['ok'])
        self.assertEqual(conflict['error'], 'semantic_state_conflict')
        self.assertEqual(self.agent.status()['value'], 12)
        self.assertEqual(self.next_call(3, 12, 5)['value'], 17)
        before_move = self.agent.status()
        self.assertTrue(self.next_call(4, 17)['ok'])
        after_move = self.agent.status()
        self.assertEqual(after_move['value'], 17)
        self.assertEqual(after_move['object_id'], before_move['object_id'])
        self.assertEqual(after_move['object_generation'], before_move['object_generation'])
        self.assertEqual(after_move['location_epoch'], before_move['location_epoch'] + 1)
        self.assertNotEqual(after_move['address'], before_move['address'])

    def test_stale_generation_sequence_epoch_and_unregistered_slot_are_not_dispatched(self):
        old = self.agent.status()
        self.assertTrue(self.next_call(5, 7, 21)['ok'])
        current = self.agent.status()
        stale = self.agent.call(1, old['object_generation'], current['request_seq'] + 1)
        self.assertEqual(stale['error'], 'semantic_stale_handle')
        self.assertFalse(stale['dispatched'])
        sequence = self.agent.call(1, current['object_generation'], current['request_seq'])
        self.assertEqual(sequence['error'], 'semantic_stale_sequence')
        unknown = self.run_controller('call', current['epoch'], current['request_seq'] + 1,
                                      current['object_generation'], 99, 0, 0, 100)
        self.assertEqual(unknown['error'], 'semantic_unknown_slot')
        stale_epoch = self.run_controller('call', current['epoch'] ^ 1, current['request_seq'] + 1,
                                          current['object_generation'], 1, 0, 0, 100)
        self.assertEqual(stale_epoch['error'], 'semantic_stale_epoch')
        self.assertEqual(self.agent.status()['value'], 21)

    def test_timeout_fences_pending_request_and_never_retries(self):
        before = self.agent.status()
        self.process.send_signal(signal.SIGSTOP)
        # waitpid confirms the application reached the stopped state before submission.
        waited, _ = os.waitpid(self.process.pid, os.WUNTRACED)
        self.assertEqual(waited, self.process.pid)
        result = self.agent.call(3, before['object_generation'], 1, 7, 5, timeout_ms=30)
        self.assertEqual(result['error'], 'semantic_outcome_unknown')
        self.assertTrue(result['dispatched'])
        pending = self.agent.status()
        self.assertTrue(pending['pending'])
        rejected = self.agent.call(3, before['object_generation'], 2, 7, 5, timeout_ms=30)
        self.assertEqual(rejected['error'], 'semantic_outcome_unresolved')
        self.assertFalse(rejected['dispatched'])
        self.process.send_signal(signal.SIGCONT)
        deadline = time.monotonic() + 2
        while True:
            after = self.agent.status()
            if not after['pending']:
                break
            self.assertLess(time.monotonic(), deadline)
            time.sleep(.002)
        self.assertEqual(after['value'], 12)
        repeated = self.agent.call(3, before['object_generation'], 1, 7, 5)
        self.assertEqual(repeated['error'], 'semantic_stale_sequence')
        self.assertEqual(self.agent.status()['value'], 12)

    def test_abi_and_private_environment_validation(self):
        self.process.send_signal(signal.SIGSTOP)
        os.waitpid(self.process.pid, os.WUNTRACED)
        with self.environment.open('r+b', buffering=0) as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            stream.seek(8)
            original = stream.read(4)
            stream.seek(8)
            stream.write(struct.pack('<I', 99))
            fcntl.flock(stream, fcntl.LOCK_UN)
            bad = self.run_controller('status')
            self.assertEqual(bad['error'], 'semantic_abi_mismatch')
            fcntl.flock(stream, fcntl.LOCK_EX)
            stream.seek(8)
            stream.write(original)
            fcntl.flock(stream, fcntl.LOCK_UN)
        self.environment.chmod(0o644)
        bad = self.run_controller('status')
        self.assertEqual(bad['error'], 'semantic_environment_not_private')
        self.environment.chmod(0o600)
        self.process.send_signal(signal.SIGCONT)
        self.assertTrue(self.agent.status()['ok'])

    def test_checked_overflow_and_fixed_target_identity(self):
        self.assertTrue(self.next_call(2, 7, 2**63-1)['ok'])
        overflow = self.next_call(3, 2**63-1, 1)
        self.assertEqual(overflow['error'], 'semantic_state_conflict')
        self.assertEqual(self.agent.status()['value'], 2**63-1)
        other = SemanticAgent(dict(self.config, epoch=self.config['epoch'] ^ 1), self.root)
        self.addCleanup(other.close)
        with self.assertRaisesRegex(SemanticAgentError, 'semantic_target_identity_changed'):
            other.status()
        with self.assertRaisesRegex(SemanticAgentError, 'semantic_invalid_call'):
            self.agent.call(99, 1, 1)

    def test_bridge_failure_after_dispatch_is_unknown(self):
        status = self.agent.status()
        for failure in (SemanticAgentError('semantic_invalid_response'), subprocess.TimeoutExpired('helper', 3), OSError('io')):
            with self.subTest(failure=type(failure).__name__):
                with patch.object(self.agent, '_run', side_effect=[status, failure]):
                    result = self.agent.call(2, 1, 1, 7, 9)
                self.assertEqual(result['status'], 'unknown')
                self.assertTrue(result['dispatched'])
        with patch.object(self.agent, '_run', side_effect=[status, {'ok': False, 'error': 'semantic_io_failed', 'dispatched': True}]):
            self.assertEqual(self.agent.call(2, 1, 1, 7, 9)['status'], 'unknown')
        with patch.object(self.agent, '_run', side_effect=[status, {'ok': False, 'error': 'semantic_state_conflict', 'dispatched': True}]):
            self.assertEqual(self.agent.call(2, 1, 1, 7, 9)['status'], 'rejected')

    def test_external_lock_does_not_block_target_shutdown_and_dead_process_is_rejected(self):
        with self.environment.open('r+b', buffering=0) as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            self.process.terminate()
            self.assertEqual(self.process.wait(timeout=1), 0)
            fcntl.flock(stream, fcntl.LOCK_UN)
        result = self.run_controller('status')
        self.assertFalse(result['ok'])
        self.assertIn(result['error'], ('semantic_agent_inactive', 'semantic_process_unavailable',
                                        'semantic_process_identity_changed'))

    def test_two_poll_threads_execute_one_request_once(self):
        executable = self.root / 'concurrent-test'
        subprocess.run([shutil.which('gcc'), '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                        '-pedantic', '-Wconversion', '-Wshadow', '-pthread',
                        str(ROOT / 'native/runtime-agent/agent.c'),
                        str(ROOT / 'native/runtime-agent/concurrent_test.c'), '-o', str(executable)],
                       check=True, timeout=30)
        result = subprocess.run([executable, self.root / 'concurrent-env', os.urandom(16).hex()],
                                capture_output=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr.decode())
        self.assertEqual(json.loads(result.stdout), {'ok': True, 'calls': 1, 'value': 8, 'ack_seq': 1})

    def test_concurrent_rust_controllers_cannot_duplicate_sequence(self):
        status = self.agent.status()
        command = [str(self.controller), 'call', str(self.environment), self.session,
                   str(status['epoch']), '1', '1', '3', '7', '1', '500']
        workers = [subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE) for _ in range(8)]
        try:
            replies = []
            for worker in workers:
                output, errors = worker.communicate(timeout=3)
                self.assertFalse(errors, errors)
                replies.append(json.loads(output))
            self.assertEqual(sum(reply['ok'] for reply in replies), 1, replies)
            self.assertTrue(all(reply.get('error', '') in ('', 'semantic_stale_sequence',
                                                         'semantic_outcome_unresolved') for reply in replies), replies)
            after = self.agent.status()
            self.assertEqual((after['request_seq'], after['ack_seq'], after['value']), (1, 1, 8))
        finally:
            for worker in workers:
                if worker.poll() is None:
                    worker.kill()
                worker.communicate(timeout=1)

    def test_long_running_service_and_input_limit(self):
        result = subprocess.run([self.controller, 'serve', self.environment, self.session],
                                input=b'status\nstatus\n', capture_output=True, timeout=3)
        replies = [json.loads(v) for v in result.stdout.splitlines()]
        self.assertEqual(len(replies), 2)
        self.assertTrue(all(v['ok'] for v in replies))
        too_long = subprocess.run([self.controller, 'serve', self.environment, self.session],
                                 input=b'x'*513+b'\nstatus\n', capture_output=True, timeout=3)
        self.assertEqual(too_long.returncode, 2)
        self.assertEqual(json.loads(too_long.stdout)['error'], 'semantic_line_limit')


if __name__ == '__main__':
    unittest.main()
