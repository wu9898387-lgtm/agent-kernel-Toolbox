"""Real angr/VEX native execution; no simulated solver is accepted as evidence."""
import copy
import hashlib
import json
import os
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_symbolic import NativeSymbolic, NativeSymbolicError, _validate_result

PYTHON = os.environ.get('RUNTIME_ANGR_PYTHON')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source(name, maximum=31):
    return {'name': name, 'bits': 32, 'minimum': 0, 'maximum': maximum}


class NativeSymbolicBoundaryTests(unittest.TestCase):
    def test_engine_witness_cannot_inject_native_arguments_or_fake_unsat(self):
        profile = {'arguments': [source('x')], 'return_bits': 32}
        valid = {'engine': 'angr', 'solver_status': 'sat', 'complete_exploration': True,
                 'paths': [{'witness_inputs': {'x': 13}, 'witness_return': 42}]}
        self.assertEqual(_validate_result(profile, 42, valid), valid)
        malformed = []
        value = copy.deepcopy(valid); value['paths'][0]['witness_inputs']['x'] = '--delete'; malformed.append(value)
        value = copy.deepcopy(valid); value['paths'][0]['witness_inputs']['x'] = True; malformed.append(value)
        value = copy.deepcopy(valid); value['paths'][0]['witness_inputs']['x'] = 32; malformed.append(value)
        value = copy.deepcopy(valid); value['paths'][0]['witness_return'] = 43; malformed.append(value)
        value = copy.deepcopy(valid); value['paths'][0]['witness_inputs']['injected'] = 1; malformed.append(value)
        malformed.append({'engine': 'angr', 'solver_status': 'unsat', 'complete_exploration': False, 'paths': []})
        for value in malformed:
            with self.subTest(value=value), self.assertRaises(NativeSymbolicError):
                _validate_result(profile, 42, value)

    def test_registry_permissions_domains_and_replay_templates_are_fixed(self):
        with tempfile.TemporaryDirectory() as directory:
            binary = str(Path('/bin/true').resolve())
            base = {'python': sys.executable, 'python_sha256': digest(Path(sys.executable).resolve()),
                'profiles': {'owned': {'binary': 'owned', 'binary_sha256': digest(binary),
                    'entry': 'owned_function', 'arguments': [source('input')], 'return_bits': 32}}}
            profiles = []
            p = copy.deepcopy(base); p['profiles']['owned']['arguments'][0]['maximum'] = -1; profiles.append(p)
            p = copy.deepcopy(base); p['profiles']['owned']['arguments'][0]['bits'] = True; profiles.append(p)
            p = copy.deepcopy(base); p['profiles']['owned']['entry'] = 'entry; touch /tmp/forbidden'; profiles.append(p)
            p = copy.deepcopy(base); p['profiles']['owned']['replay'] = {'allow_execute': False, 'arguments': []}; profiles.append(p)
            p = copy.deepcopy(base); p['profiles']['owned']['replay'] = {'allow_execute': True, 'arguments': ['@source:unknown']}; profiles.append(p)
            p = copy.deepcopy(base); p['profiles']['owned']['max_states'] = 100000; profiles.append(p)
            p = copy.deepcopy(base); p['profiles']['owned']['memory'] = [
                {'name': 'left', 'bits': 32, 'address': '0x1000'},
                {'name': 'right', 'bits': 32, 'address': '0x1002'}]; profiles.append(p)
            for config in profiles:
                with self.subTest(config=config), self.assertRaises(NativeSymbolicError):
                    NativeSymbolic(config, Path(directory) / 'state', {'owned': binary}, bundle_root=ROOT)
            adapter = NativeSymbolic(base, Path(directory) / 'state', {'owned': binary}, bundle_root=ROOT)
            with self.assertRaisesRegex(NativeSymbolicError, 'unknown_profile') as error:
                adapter.analyze('not_registered', 0)
            self.assertFalse(error.exception.effect_dispatched)
            for expected in (True, -1, 2**32):
                with self.subTest(expected=expected), self.assertRaisesRegex(NativeSymbolicError, 'return_constraint'):
                    adapter.analyze('owned', expected)


@unittest.skipUnless(PYTHON and shutil.which('gcc') and shutil.which('nm')
                     and sys.platform == 'linux' and platform.machine().lower() in ('x86_64', 'amd64'),
                     'set RUNTIME_ANGR_PYTHON to a real installed angr interpreter')
class NativeSymbolicEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name)
        cls.binary = cls.root / 'owned-native-symbolic'
        subprocess.run([shutil.which('gcc'), '-O0', '-g', '-fno-stack-protector', '-no-pie',
                        str(ROOT / 'tests/fixtures/recovery/native_symbolic.c'), '-o', str(cls.binary)],
                       check=True, timeout=20)
        cls.symbols = {line.split()[2]: int(line.split()[0], 16)
            for line in subprocess.check_output([shutil.which('nm'), str(cls.binary)], text=True).splitlines()
            if len(line.split()) == 3}
        cls.profile = {'binary': 'owned', 'binary_sha256': digest(cls.binary),
            'entry': 'owned_branch', 'arguments': [source('x'), source('y', 3)],
            'return_bits': 32, 'expected_architecture': 'AMD64',
            'max_steps': 32, 'max_states': 32, 'timeout_seconds': 30,
            'replay': {'allow_execute': True, 'arguments': ['branch', '@source:x', '@source:y']}}

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def adapter(self, profile=None):
        directory = Path(tempfile.mkdtemp(dir=self.root))
        return NativeSymbolic({'python': PYTHON,
            'python_sha256': digest(Path(PYTHON).resolve()),
            'profiles': {'owned': profile or self.profile}}, directory,
            {'owned': str(self.binary)}, bundle_root=ROOT)

    def test_actual_engine_abi_branch_solver_and_native_witness_replay(self):
        adapter = self.adapter()
        version = adapter.inspect()
        self.assertTrue(version['available'], version)
        self.assertEqual(version['engine'], 'angr')
        self.assertEqual(version['IR'], 'VEX')
        self.assertFalse(version['dependency_integrity_pinned'])
        result = adapter.analyze('owned', 42)
        self.assertEqual(result['solver_status'], 'sat', result)
        self.assertTrue(result['complete_exploration'], result)
        self.assertEqual(result['architecture'], 'AMD64')
        self.assertEqual(result['calling_convention'], 'SimCCSystemVAMD64')
        self.assertEqual(result['solver_timeout_ms'], 2000)
        self.assertTrue(result['native_replay_verified'])
        self.assertEqual(result['native_replay_return'], 42)
        self.assertEqual(result['paths'][0]['witness_inputs'], {'x': 13, 'y': 3})
        self.assertEqual(set(result['paths'][0]['data_taint_sources']), {'x', 'y'})
        self.assertFalse(result['host_or_live_memory_access'])

    def test_unconstrained_return_analysis_reports_all_feasible_native_paths(self):
        result = self.adapter().analyze('owned')
        self.assertEqual(result['solver_status'], 'analyzed', result)
        self.assertTrue(result['complete_exploration'])
        # y is restricted to [0,3], so the y>=4 branch is infeasible. The
        # engine must report the two actually reachable return paths.
        self.assertEqual(result['returned_paths'], 2)
        self.assertEqual(len(result['paths']), 2)
        self.assertTrue(result['native_replay_verified'])
        for path in result['paths']:
            witness = path['witness_inputs']
            native = subprocess.run([self.binary, 'branch', str(witness['x']), str(witness['y'])],
                                    check=True, capture_output=True, text=True, timeout=2)
            self.assertEqual(int(native.stdout), path['witness_return'])

    def test_exhaustive_unsat_is_limited_to_reported_function_domains(self):
        result = self.adapter().analyze('owned', 250)
        self.assertEqual(result['solver_status'], 'unsat', result)
        self.assertTrue(result['complete_exploration'])
        self.assertEqual(result['input_domains']['x']['maximum'], 31)
        self.assertFalse(result['target_execution_requested'])
        self.assertFalse(result['universal_native_program_proof'])

    def test_native_data_memory_taint_and_compiler_symbol_binding(self):
        profile = copy.deepcopy(self.profile)
        profile.update(entry='owned_memory', arguments=[source('x', 15)], memory=[
            {'name': 'cell', 'bits': 32, 'address': hex(self.symbols['owned_cell']), 'maximum': 20}])
        profile['replay']['arguments'] = ['memory', '@source:x', '@source:cell']
        result = self.adapter(profile).analyze('owned', 25)
        self.assertEqual(result['solver_status'], 'sat', result)
        self.assertTrue(result['native_replay_verified'])
        self.assertEqual(set(result['paths'][0]['data_taint_sources']), {'x', 'cell'})
        self.assertTrue(any(row['operation'] == 'mem_read'
            and row['address'] == hex(self.symbols['owned_cell']) and row['sources'] == ['cell']
            for row in result['paths'][0]['tainted_memory']))

    def test_control_dependencies_are_separate_from_constant_return_data(self):
        profile = copy.deepcopy(self.profile)
        profile.update(entry='owned_control', arguments=[source('x')])
        profile['replay']['arguments'] = ['control', '@source:x', '0']
        result = self.adapter(profile).analyze('owned', 111)
        self.assertEqual(result['solver_status'], 'sat', result)
        self.assertTrue(result['native_replay_verified'])
        self.assertEqual(result['paths'][0]['data_taint_sources'], [])
        self.assertEqual(result['paths'][0]['control_taint_sources'], ['x'])

    def test_step_budget_does_not_falsely_prove_unsat(self):
        profile = copy.deepcopy(self.profile)
        profile.update(entry='owned_loop', arguments=[{'name': 'x', 'bits': 32, 'minimum': 1, 'maximum': 2}],
                       max_steps=2)
        profile.pop('replay')
        result = self.adapter(profile).analyze('owned', 0)
        self.assertEqual(result['solver_status'], 'unknown', result)
        self.assertFalse(result['complete_exploration'])
        self.assertIn('native_symbolic_step_budget', result['incomplete_reasons'])
        self.assertFalse(result['target_execution_requested'])
        self.assertNotIn('status', result)  # not an unknown target side effect

    def test_unsupported_external_call_and_unmodeled_device_like_memory_are_unknown(self):
        for entry in ('owned_external', 'owned_unmodeled'):
            profile = copy.deepcopy(self.profile)
            profile.update(entry=entry, arguments=[source('x')])
            profile.pop('replay')
            result = self.adapter(profile).analyze('owned', 0)
            with self.subTest(entry=entry):
                self.assertEqual(result['solver_status'], 'unknown', result)
                self.assertFalse(result['complete_exploration'])
                self.assertFalse(result['target_executed'])

    def test_architecture_mismatch_and_code_memory_initialization_are_rejected(self):
        profile = copy.deepcopy(self.profile)
        profile['expected_architecture'] = 'ARMEL'
        profile.pop('replay')
        result = self.adapter(profile).analyze('owned')
        self.assertEqual(result['incomplete_reasons'], ['native_symbolic_architecture_mismatch'])
        profile['expected_architecture'] = 'AMD64'
        profile['memory'] = [{'name': 'code', 'bits': 32, 'address': hex(self.symbols['owned_branch'])}]
        result = self.adapter(profile).analyze('owned')
        self.assertEqual(result['solver_status'], 'unknown')
        self.assertEqual(result['incomplete_reasons'], ['native_symbolic_memory_requires_writable_data_segment'])

    def test_digest_pins_and_replay_failure_effect_are_explicit(self):
        profile = copy.deepcopy(self.profile)
        profile['binary_sha256'] = '0' * 64
        with self.assertRaises(NativeSymbolicError) as error:
            self.adapter(profile).analyze('owned', 42)
        self.assertFalse(error.exception.effect_dispatched)
        profile = copy.deepcopy(self.profile)
        profile['replay']['arguments'] = ['control', '@source:x', '0']
        with self.assertRaisesRegex(NativeSymbolicError, 'semantics_mismatch') as error:
            self.adapter(profile).analyze('owned', 42)
        self.assertTrue(error.exception.effect_dispatched)

    def test_persistent_journal_hashes_results_without_storing_witness_payload(self):
        adapter = self.adapter()
        result = adapter.analyze('owned', 42)
        self.assertEqual(result['solver_status'], 'sat')
        events = [json.loads(line) for line in (adapter.directory / 'native-symbolic.jsonl').read_text().splitlines()]
        self.assertEqual([row['phase'] for row in events], ['started', 'finished'])
        self.assertEqual(events[1]['previous_sha256'], events[0]['sha256'])
        self.assertNotIn('witness_inputs', json.dumps(events))
        for event in events:
            expected = event.pop('sha256')
            encoded = json.dumps(event, sort_keys=True, ensure_ascii=True, allow_nan=False, separators=(',', ':')).encode()
            self.assertEqual(hashlib.sha256(encoded).hexdigest(), expected)


if __name__ == '__main__':
    unittest.main()
