"""Toolbox integrity, complete operating facilities and single-source delivery."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RuntimeDistributionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.builder = load('runtime_distribution_builder', 'build-runtime.py')
        cls.verifier = load('runtime_distribution_verifier', 'verify-runtime.py')
        cls.raw = cls.builder.build()
        with zipfile.ZipFile(io.BytesIO(cls.raw)) as archive:
            cls.files = {name: archive.read(name) for name in archive.namelist()}

    def test_current_facilities_and_full_python_implementation_are_shipped_without_history(self):
        verified = self.verifier.verify(self.raw)
        self.assertEqual(verified['package_version'], '0.5.6.2')
        self.assertEqual(verified['python_members'], 49)
        forbidden_parts = {'validation', 'node_modules', '__pycache__', '.git'}
        forbidden_names = ('HISTORY', 'CHANGELOG', 'RELEASE', 'VALIDATION', 'ACCEPTANCE', 'STATUS', 'UPSTREAM', 'SOURCES')
        for name in self.files:
            self.assertFalse(forbidden_parts.intersection(Path(name).parts), name)
            self.assertFalse(Path(name).name.startswith(forbidden_names), name)
            self.assertFalse(name.startswith('src/'), name)
        for name in ('tools/check_installation.py', 'tools/runtime-platform.py',
                     'tools/native_probe.js', 'tools/managed_jvm_guardian.py',
                     'browser/runtime.mjs', 'native/managed-jvm/build.py',
                     'skills/agent-kernel-toolbox/SKILL.md', 'build-source.py',
                     'tools/check_runtime_mcp.py', 'tools/check_official_mcp.py',
                     'tools/check_browser_mcp.py', 'tools/check_package_contract.py',
                     'tools/benchmark_native_worker.py', 'requirements-validation.txt',
                     'tests/test_build_cli.py', 'tests/fixtures/compiler_metadata/layout.c',
                     'native/runtime-agent/demo.c', 'native/runtime-agent/concurrent_test.c',
                     'native/worker/worker_test.go', 'browser/extension.test.mjs',
                     'browser/route-evidence.test.mjs', 'examples/portable-objects/MANIFEST.json',
                     'v055-config.example.json'):
            self.assertIn(name, self.files)
        with zipfile.ZipFile(io.BytesIO(self.files['runtime-access.pyz'])) as archive:
            embedded = {name: archive.read(name) for name in archive.namelist()}
        if (ROOT / 'src').is_dir():
            source = {str(path.relative_to(ROOT / 'src')): path.read_bytes()
                      for path in (ROOT / 'src').rglob('*.py')}
        else:
            with zipfile.ZipFile(ROOT / 'runtime-access.pyz') as archive:
                source = {name: archive.read(name) for name in archive.namelist()}
        self.assertEqual(embedded, source)

    def test_repeated_build_and_pinned_digest(self):
        self.assertEqual(self.raw, self.builder.build())
        digest = hashlib.sha256(self.raw).hexdigest()
        self.assertTrue(self.verifier.verify(self.raw, digest)['expected_archive_digest_pinned'])
        with self.assertRaisesRegex(ValueError, 'archive_digest_mismatch'):
            self.verifier.verify(self.raw, '0' * 64)

    def test_untracked_python_change_is_rejected_even_if_outer_pyz_hash_is_updated(self):
        files = dict(self.files)
        with zipfile.ZipFile(io.BytesIO(files['runtime-access.pyz'])) as archive:
            inner = {name: archive.read(name) for name in archive.namelist()}
        inner['observation_extension/version.py'] += b'\n# unexpected change\n'
        files['runtime-access.pyz'] = self.builder.archive(inner)
        inventory = json.loads(files['CONTENTS.json'])
        inventory['files']['runtime-access.pyz'] = hashlib.sha256(files['runtime-access.pyz']).hexdigest()
        files['CONTENTS.json'] = json.dumps(inventory).encode()
        with self.assertRaisesRegex(ValueError, 'member_digest_mismatch'):
            self.verifier.verify(self.builder.archive(files))

    def test_directory_checks_shipped_files_without_reading_user_additions(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
            directory = Path(temporary)
            with zipfile.ZipFile(io.BytesIO(self.raw)) as archive:
                archive.extractall(directory)
            (directory / 'operator-config.json').write_text('not a package member')
            self.assertTrue(self.verifier.verify_directory(directory)['runtime_sources_verified'])
            (directory / 'tools/native_probe.js').unlink()
            with self.assertRaises(OSError):
                self.verifier.verify_directory(directory)

    def test_manifest_json_object_is_required(self):
        files = dict(self.files)
        files['runtime-manifest.json'] = b'[]'
        inventory = json.loads(files['CONTENTS.json'])
        inventory['files']['runtime-manifest.json'] = hashlib.sha256(b'[]').hexdigest()
        files['CONTENTS.json'] = json.dumps(inventory).encode()
        with self.assertRaisesRegex(ValueError, 'manifest_object_required'):
            self.verifier.verify(self.builder.archive(files))

    def test_malformed_pyz_has_controlled_directory_failure(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
            directory = Path(temporary)
            with zipfile.ZipFile(io.BytesIO(self.raw)) as archive:
                archive.extractall(directory)
            payload = b'not a ZIP'
            (directory / 'runtime-access.pyz').write_bytes(payload)
            inventory = json.loads((directory / 'CONTENTS.json').read_text())
            inventory['files']['runtime-access.pyz'] = hashlib.sha256(payload).hexdigest()
            (directory / 'CONTENTS.json').write_text(json.dumps(inventory))
            with self.assertRaisesRegex(ValueError, 'invalid_installed_toolbox'):
                self.verifier.verify_directory(directory)

    def test_compressed_oversized_member_and_release_growth_fail(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            info = zipfile.ZipInfo('oversized.txt')
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, b'0' * (self.verifier.MAX_FILE_BYTES + 1),
                             compress_type=zipfile.ZIP_DEFLATED)
        with self.assertRaisesRegex(ValueError, 'invalid_archive_entry'):
            self.verifier.verify(stream.getvalue())
        with patch.object(self.builder, 'MAX_ARCHIVE_BYTES', 1):
            with self.assertRaisesRegex(ValueError, 'runtime_archive_size_budget'):
                self.builder.build()


if __name__ == '__main__':
    unittest.main()
