import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {test} from 'node:test';

const source=fs.readFileSync(new URL('../tools/native_probe.js',import.meta.url),'utf8');
const functions=source.slice(source.indexOf('function flush()'),source.indexOf('function word('));
assert(functions.includes('function report()'));
function run(body,maxEvents=16,maxBytes=16384,drainBody=''){
  const context=vm.createContext({result:null});
  vm.runInContext(`
    const config={max_events:${maxEvents},max_bytes:${maxBytes},max_callback_us:5000000,environment_functions:[]};
    let sequence=0,recorded=0,bytes=0,dropped=0,instructions=0,callbackMs=0,stopped=false,pending=[],reason=null;
    let detachCount=0,unfollowCount=0,drainCount=0;const messages=[];
    const active=new Map([[11,1]]);const hooks=[{detach(){detachCount++;}}];
    const Process={getCurrentThreadId(){return 11;}};
    const Stalker={unfollow(){unfollowCount++;},flush(){}};
    function send(value){messages.push(value);}
    function nativeCallbackUs(){return 0;}
    function allocatorLoss(){return 0;}
    function drainAllocations(){drainCount++;${drainBody}}
    ${functions}
    ${body}
    result={recorded,bytes,dropped,stopped,reason,detachCount,unfollowCount,drainCount,messages};
  `,context,{timeout:1000});
  return JSON.parse(JSON.stringify(context.result));
}
test('hooks alone stop immediately at the event limit',()=>{
  const value=run(`for(let i=0;i<1000;i++)emit({kind:'object',object_id:String(i)});`);
  assert.equal(value.recorded,16);assert.equal(value.dropped,984);
  assert.equal(value.stopped,true);assert.equal(value.detachCount,1);assert.equal(value.unfollowCount,1);
  assert.equal(value.reason,'event_or_byte_budget');
});
test('an event that cannot fit stops below the byte threshold',()=>{
  const value=run(`for(let i=0;i<1000;i++)emit({kind:'object',object_id:String(i),data:'x'.repeat(100)});`,16384);
  assert(value.bytes<16384);assert(value.dropped>0);assert.equal(value.stopped,true);
  assert.equal(value.detachCount,1);assert.equal(value.reason,'event_or_byte_budget');
});
test('stop report drain reentry is bounded and terminal coverage survives',()=>{
  const value=run(`emit({kind:'object'});report();stop('operator_close');`,1,16384,
    `emit({kind:'allocation',address:'0x1000'});`);
  assert.equal(value.detachCount,1);assert.equal(value.unfollowCount,1);
  assert(value.drainCount<=3);assert.equal(value.recorded,1);
  assert(value.messages.some(x=>x.type==='coverage'&&x.stopped&&x.stop_reason==='event_or_byte_budget'));
  assert.equal(value.messages.filter(x=>x.type==='events').flatMap(x=>x.events).length,1);
});
test('below budget leaves hooks active and preserves event sequence',()=>{
  const value=run(`emit({kind:'object'});emit({kind:'allocation'});report();`);
  assert.equal(value.stopped,false);assert.equal(value.detachCount,0);assert.equal(value.dropped,0);
  assert.deepEqual(value.messages.filter(x=>x.type==='events').flatMap(x=>x.events).map(x=>x.seq),[1,2]);
});
