"""Real Kotlin coroutine recovery evidence; no simulated engine is accepted.

RUNTIME_JADX selects an installed JADX launcher. Optional RUNTIME_KOTLINC and
RUNTIME_R8 enable a fresh Kotlin/JVM self-check and D8 rebuild. The bundled APK is
an owned DEX-only analysis fixture, not an installable Android application.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

FIXTURES = ROOT / 'tests' / 'fixtures' / 'recovery'
sys.path.insert(0, str(RUNTIME))
from observation_extension.analysis_tools import AnalysisTools


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class KotlinRecoveryTests(unittest.TestCase):
    def test_bundled_fixture_integrity_and_declared_scope(self):
        metadata = json.loads((FIXTURES / 'kotlin-fixture-build.json').read_text())
        self.assertEqual(digest(FIXTURES / 'CoroutineFixture.kt'), metadata['source_sha256'])
        self.assertEqual(digest(FIXTURES / 'kotlin-fixture.apk'), metadata['apk_sha256'])
        self.assertEqual(digest(FIXTURES / 'kotlin-fixture.dex'), metadata['dex_sha256'])
        with zipfile.ZipFile(FIXTURES / 'kotlin-fixture.apk') as archive:
            self.assertEqual(archive.namelist(), ['classes.dex'])
            self.assertEqual(archive.read('classes.dex'), (FIXTURES / 'kotlin-fixture.dex').read_bytes())
        self.assertFalse(metadata['apk_installable'])
        self.assertFalse(metadata['art_execution_verified'])
        self.assertFalse(metadata['runtime_dependencies_embedded'])

    @unittest.skipUnless(os.environ.get('RUNTIME_JADX'), 'set RUNTIME_JADX for actual Kotlin DEX recovery')
    def test_real_jadx_coroutine_metadata_captured_state_and_closures(self):
        launcher = Path(os.environ['RUNTIME_JADX']).resolve()
        apk = FIXTURES / 'kotlin-fixture.apk'
        metadata = json.loads((FIXTURES / 'kotlin-fixture-build.json').read_text())
        self.assertEqual(digest(FIXTURES / 'CoroutineFixture.kt'), metadata['source_sha256'])
        self.assertEqual(digest(apk), metadata['apk_sha256'])
        with zipfile.ZipFile(apk) as archive:
            self.assertEqual(archive.namelist(), ['classes.dex'])
            self.assertEqual(hashlib.sha256(archive.read('classes.dex')).hexdigest(), metadata['dex_sha256'])
        with tempfile.TemporaryDirectory() as directory:
            config = {'profiles': {'jadx': {'kind': 'jadx', 'executable': str(launcher),
                       'sha256': digest(launcher), 'timeout_seconds': 90}},
                       'digests': {'fixture': digest(apk)}}
            result = AnalysisTools(config, Path(directory), {'fixture': str(apk)}, bundle_root=ROOT).run('jadx', 'fixture', 'decompile')
        self.assertTrue(result['success'], result['stderr'][-2048:])
        self.assertFalse(result['target_executed'])
        self.assertFalse(result['artifacts']['source_equivalence_proven'])
        self.assertFalse(result['artifacts']['dynamic_object_correspondence_proven'])
        recovered = '\n'.join(item['text'] for item in result['artifacts']['files'])
        # These are observed structural/state-machine properties, not a claim
        # that suspend source or recompilable Java has been reconstructed.
        for evidence in ['@Metadata', '@DebugMetadata', 'ContinuationImpl', 'SuspendLambda',
                         'COROUTINE_SUSPENDED', 'label', 'switch', 'I$0', 'L$0',
                         'class Nested', 'class Inner', 'new Runnable()', 'new Function1',
                         'offset', 'catch', 'IllegalArgumentException', 'touches']:
            with self.subTest(evidence=evidence):
                self.assertIn(evidence, recovered)
        self.assertFalse(metadata['art_execution_verified'])
        self.assertFalse(metadata['apk_installable'])

    @unittest.skipUnless(os.environ.get('RUNTIME_KOTLINC') and os.environ.get('RUNTIME_R8'),
                         'set RUNTIME_KOTLINC and RUNTIME_R8 for real compiler/JVM/D8 rebuild')
    def test_owned_kotlin_jvm_state_machine_and_dex_rebuild(self):
        specification = importlib.util.spec_from_file_location('build_kotlin_fixture', FIXTURES / 'build_kotlin_fixture.py')
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        with tempfile.TemporaryDirectory() as directory:
            rebuilt = builder.build(os.environ['RUNTIME_KOTLINC'], os.environ['RUNTIME_R8'], Path(directory) / 'output')
        pinned = json.loads((FIXTURES / 'kotlin-fixture-build.json').read_text())
        self.assertIn('coroutine-fixture-ok:', rebuilt['jvm_self_check'])
        if (rebuilt['compiler_jar_sha256'], rebuilt['r8_sha256']) == (pinned['compiler_jar_sha256'], pinned['r8_sha256']):
            self.assertEqual(rebuilt['dex_sha256'], pinned['dex_sha256'])
            self.assertEqual(rebuilt['apk_sha256'], pinned['apk_sha256'])
        self.assertFalse(rebuilt['art_execution_verified'])
        self.assertFalse(rebuilt['runtime_dependencies_embedded'])


if __name__ == '__main__':
    unittest.main()
