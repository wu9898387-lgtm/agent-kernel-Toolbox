"""Actual shared-memory writers, pinned barriers and transaction failure evidence."""
import copy
import errno
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
import observation_extension.coordinated_state as module
from observation_extension.coordinated_state import CoordinatedState,CoordinatedError
from observation_extension.native_runtime import ProcessSession


def pair(value):return ((~value&0xffffffff)<<32|value).to_bytes(8,'little')


@unittest.skipUnless(sys.platform=='linux'and hasattr(os,'pidfd_open')and shutil.which('gcc'),
                     'actual Linux pidfd and C compiler required')
class CoordinatedStateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build=tempfile.TemporaryDirectory();cls.binary=Path(cls.build.name)/'shared-writer'
        subprocess.run([shutil.which('gcc'),'-std=c11','-O2','-Wall','-Wextra','-Werror','-pthread',
            str(ROOT/'tests/fixtures/recovery/shared_writer.c'),'-o',str(cls.binary)],check=True,timeout=15)
        cls.sha=hashlib.sha256(cls.binary.read_bytes()).hexdigest()

    @classmethod
    def tearDownClass(cls):cls.build.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name);self.children=[];self.sessions=[]
        self.addCleanup(self.stop_children)

    def stop_children(self):
        for session in self.sessions:session.close()
        for child in self.children:
            if child.poll()is None:
                child.send_signal(signal.SIGCONT);child.terminate()
                try:child.wait(timeout=3)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=3)
            child.stdout.close()

    def fixture(self,mode='idle'):
        path=self.directory/('shared'+str(len(self.children)))
        child=subprocess.Popen([str(self.binary),str(path),mode],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        self.children.append(child)
        self.assertTrue(select.select([child.stdout],[],[],3)[0])
        info=json.loads(child.stdout.readline());address=int(info['address'],16)
        sessions={}
        for index,pid in enumerate(info['writers']):
            session=ProcessSession(pid,allow_memory=True);self.sessions.append(session);sessions[str(index)]=session
        profile={'writers':{key:{'pid':session.pid,'start_ticks':session.identity['start_ticks'],
            'exe_sha256':self.sha,'allow_pause':True}for key,session in sessions.items()},
            'writer_set_complete':True,'allow_patch':True,'max_pause_ms':1500,
            'regions':{'pair':{'size':16,'bindings':{key:{'address':hex(address),
                'mapping_fingerprint':session.memory_mapping(address,16)['mapping_fingerprint']}
                for key,session in sessions.items()},
                'fields':{'first':{'offset':0,'size':8,'byte_order':'little'},
                          'second':{'offset':8,'size':8,'byte_order':'little'}}}},
            'patches':{'update':[{'region':'pair','offset':0,'expected_hex':pair(7).hex(),'replacement_hex':pair(17).hex()},
                {'region':'pair','offset':8,'expected_hex':pair(11).hex(),'replacement_hex':pair(21).hex()}]}}
        return profile,sessions,path,address

    def backend(self,profile,**profiles):
        backend=CoordinatedState({'profiles':{'owned':profile,**profiles}},self.directory/'state',bundle_root=ROOT)
        self.addCleanup(backend.close);return backend

    def assert_running(self,sessions):
        for session in sessions.values():self.assertFalse(module._all_stopped(session))

    def test_capture_actual_two_writer_relations_and_private_bounded_artifact(self):
        profile,sessions,path,address=self.fixture('active');backend=self.backend(profile)
        captured=backend.capture('owned')
        self.assertEqual(captured['status'],'captured',captured)
        self.assertTrue(captured['cleanup']['complete'])
        for value in captured['regions']['pair']['fields'].values():
            number=int(value);self.assertEqual(number>>32,(~number)&0xffffffff)
        self.assertFalse(captured['writer_set_complete_proven'])
        self.assertFalse(captured['unknown_writers_or_DMA_quiesced'])
        self.assertFalse(captured['business_effect_confirmed'])
        self.assertLess(len(json.dumps(captured)),65536)
        self.assert_running(sessions)
        self.assertEqual(backend.release(captured['snapshot_handle'])['released'],True)
        self.assertEqual(backend.inspect()['snapshot_count'],0)

    def test_fixed_template_patch_verifies_all_aliases_and_consumes_snapshot(self):
        profile,sessions,path,address=self.fixture();backend=self.backend(profile)
        captured=backend.capture('owned');result=backend.patch('owned',captured['snapshot_handle'],'update')
        self.assertEqual(result['status'],'verified',result)
        self.assertEqual(path.read_bytes()[:16],pair(17)+pair(21))
        self.assertTrue(result['cleanup']['complete']);self.assert_running(sessions)
        with self.assertRaisesRegex(CoordinatedError,'snapshot_stale'):backend.patch('owned',captured['snapshot_handle'],'update')

    def test_changed_preimage_is_rejected_without_writing(self):
        profile,sessions,path,address=self.fixture('active');backend=self.backend(profile)
        captured=backend.capture('owned');time.sleep(.02)
        result=backend.patch('owned',captured['snapshot_handle'],'update')
        self.assertEqual((result['status'],result['reason']),('rejected','coordinated_snapshot_conflict'),result)
        self.assertFalse(result['memory_written']);self.assertFalse(result['persistent_target_fence'])
        self.assert_running(sessions)

    def test_every_thread_of_both_actual_writers_is_stopped_during_capture(self):
        profile,sessions,path,address=self.fixture('threads');backend=self.backend(profile)
        deadline=time.monotonic()+1
        while any(len(s.threads())<2 for s in sessions.values()):
            if time.monotonic()>deadline:self.fail('thread fixture not ready')
            time.sleep(.001)
        original=module._read_regions;counts=[]
        def validate(*args):
            for session in sessions.values():
                rows=session.threads();counts.append(len(rows))
                self.assertTrue(all(row['state'][:1]=='T'for row in rows))
            return original(*args)
        with patch.object(module,'_read_regions',side_effect=validate):result=backend.capture('owned')
        self.assertEqual(result['status'],'captured',result)
        self.assertTrue(all(count>=2 for count in counts));self.assert_running(sessions)

    def test_second_real_write_fault_rolls_back_and_verifies_full_preimage(self):
        profile,sessions,path,address=self.fixture();backend=self.backend(profile)
        captured=backend.capture('owned');original=module._write;calls=[]
        def fail_second(fd,at,data):
            calls.append(at)
            if len(calls)==2:raise OSError(errno.EIO,'injected second write failure')
            return original(fd,at,data)
        with patch.object(module,'_write',side_effect=fail_second):result=backend.patch('owned',captured['snapshot_handle'],'update')
        self.assertEqual(result['status'],'rolled_back',result)
        self.assertTrue(result['rollback_verified']);self.assertTrue(result['memory_written'])
        self.assertEqual(path.read_bytes()[:16],pair(7)+pair(11));self.assert_running(sessions)

    def test_lost_barrier_after_first_write_refuses_blind_rollback_and_fences_alias_restart(self):
        profile,sessions,path,address=self.fixture();backend=self.backend(profile,alias=copy.deepcopy(profile))
        captured=backend.capture('owned');original=module._write;calls=[]
        def lose_barrier(fd,at,data):
            count=original(fd,at,data);calls.append(at)
            if len(calls)==1:
                signal.pidfd_send_signal(sessions['1'].pidfd,signal.SIGCONT)
                deadline=time.monotonic()+.5
                while module._all_stopped(sessions['1'])and time.monotonic()<deadline:time.sleep(.001)
            return count
        with patch.object(module,'_write',side_effect=lose_barrier):result=backend.patch('owned',captured['snapshot_handle'],'update')
        self.assertEqual(result['status'],'unknown',result);self.assertFalse(result['rollback_verified'])
        self.assertEqual(len(calls),1,'unsafe rollback wrote after a writer escaped the barrier')
        self.assertTrue(result['persistent_target_fence'])
        self.assertEqual(path.read_bytes()[:8],pair(17))
        with self.assertRaisesRegex(CoordinatedError,'target_fenced'):backend.capture('alias')
        backend.close()
        reopened=self.backend(profile,alias=copy.deepcopy(profile))
        with self.assertRaisesRegex(CoordinatedError,'target_fenced'):reopened.capture('alias')
        self.assert_running(sessions)

    def test_prepaused_writer_is_preserved_while_other_writer_resumes(self):
        profile,sessions,path,address=self.fixture()
        signal.pidfd_send_signal(sessions['1'].pidfd,signal.SIGSTOP)
        deadline=time.monotonic()+1
        while not module._all_stopped(sessions['1']):
            if time.monotonic()>deadline:self.fail('fixture did not stop')
            time.sleep(.001)
        try:
            result=self.backend(profile).capture('owned')
            self.assertEqual(result['status'],'captured',result)
            self.assertEqual(result['cleanup']['resumed_writers'],['0'])
            self.assertEqual(result['cleanup']['preserved_paused_writers'],['1'])
            self.assertFalse(module._all_stopped(sessions['0']));self.assertTrue(module._all_stopped(sessions['1']))
        finally:signal.pidfd_send_signal(sessions['1'].pidfd,signal.SIGCONT)

    def test_observed_mapping_change_after_first_write_forbids_rollback(self):
        profile,sessions,path,address=self.fixture();backend=self.backend(profile)
        captured=backend.capture('owned');original=module._write;calls=[]
        def change_mapping(fd,at,data):
            count=original(fd,at,data);calls.append(at)
            if len(calls)==1:
                target=sessions['1'];signal.pidfd_send_signal(target.pidfd,signal.SIGCONT)
                signal.pidfd_send_signal(target.pidfd,signal.SIGUSR2)
                deadline=time.monotonic()+.5
                while True:
                    row=next(row for row in target.maps()if int(row['start'],16)<=address<int(row['end'],16))
                    if row['permissions']=='r--s':break
                    if time.monotonic()>deadline:raise OSError('fixture remap not observed')
                    time.sleep(.001)
                signal.pidfd_send_signal(target.pidfd,signal.SIGSTOP)
                while not module._all_stopped(target):
                    if time.monotonic()>deadline:raise OSError('fixture stop not observed')
                    time.sleep(.001)
            return count
        with patch.object(module,'_write',side_effect=change_mapping):result=backend.patch('owned',captured['snapshot_handle'],'update')
        self.assertEqual(result['status'],'unknown',result);self.assertFalse(result['rollback_verified'])
        self.assertEqual(len(calls),1);self.assertEqual(path.read_bytes()[:8],pair(17))
        self.assertTrue(result['persistent_target_fence']);self.assert_running(sessions)

    def test_declared_incomplete_or_denied_writer_never_stops_targets(self):
        profile,sessions,path,address=self.fixture()
        for field,value,code in [('writer_set_complete',False,'complete_writer_declaration'),
                                  ('writer_permission',False,'pause_not_authorized')]:
            p=copy.deepcopy(profile)
            if field=='writer_permission':p['writers']['1']['allow_pause']=value
            else:p[field]=value
            with patch.object(module.subprocess,'Popen')as launch:
                with self.assertRaisesRegex(CoordinatedError,code):self.backend(p).capture('owned')
                launch.assert_not_called()
            self.assert_running(sessions)

    def test_real_vvar_MMIO_semantics_and_changed_mapping_fingerprint_are_refused(self):
        profile,sessions,path,address=self.fixture()
        for kind in ('vvar','fingerprint'):
            p=copy.deepcopy(profile)
            for key,session in sessions.items():
                binding=p['regions']['pair']['bindings'][key]
                if kind=='vvar':
                    row=next(row for row in session.maps()if row['path']=='[vvar]')
                    binding.update(address=row['start'],mapping_fingerprint=row['mapping_fingerprint'])
                else:binding['mapping_fingerprint']='0'*64
            with patch.object(module.subprocess,'Popen')as launch:
                with self.assertRaisesRegex(CoordinatedError,'nonordinary_memory'if kind=='vvar'else'region_mapping_changed'):
                    self.backend(p).capture('owned')
                launch.assert_not_called()
            self.assert_running(sessions)

    def test_identity_and_ancestor_denial_and_invalid_templates_are_zero_dispatch(self):
        profile,sessions,path,address=self.fixture()
        p=copy.deepcopy(profile);p['writers']['0']['start_ticks']='0'
        with self.assertRaisesRegex(CoordinatedError,'writer_identity_changed'):self.backend(p).capture('owned')
        p=copy.deepcopy(profile);p['writers']['0']['pid']=os.getpid()
        with self.assertRaisesRegex(CoordinatedError,'preflight_failed'):self.backend(p).capture('owned')
        p=copy.deepcopy(profile);p['patches']['update'][1]['offset']=4
        with self.assertRaisesRegex(CoordinatedError,'overlapping_edits'):self.backend(p)
        self.assert_running(sessions)

    def test_host_SIGKILL_watchdog_resumes_both_writers_and_pending_fence_survives(self):
        profile,sessions,path,address=self.fixture('active')
        config=self.directory/'config.json';config.write_text(json.dumps({'profiles':{'owned':profile}}))
        source='''import json,sys,time\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nimport observation_extension.coordinated_state as m\nb=m.CoordinatedState(json.loads(Path(sys.argv[2]).read_text()),Path(sys.argv[3]),bundle_root=Path(sys.argv[4]))\ndef block(*args):\n print('STOPPED',flush=True);time.sleep(30)\nm._read_regions=block\nb.capture('owned')\n'''
        host=subprocess.Popen([sys.executable,'-c',source,str(RUNTIME),str(config),str(self.directory/'state'),str(ROOT)],
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            self.assertTrue(select.select([host.stdout],[],[],4)[0])
            line=host.stdout.readline()
            if line!=b'STOPPED\n':self.fail(host.stderr.read(4096).decode())
            self.assertTrue(all(module._all_stopped(s)for s in sessions.values()))
            before=path.read_bytes()[:16];host.kill();host.wait(timeout=3)
            deadline=time.monotonic()+3
            while any(module._all_stopped(s)for s in sessions.values()):
                if time.monotonic()>deadline:self.fail('independent watchdog failed to resume writers')
                time.sleep(.005)
            time.sleep(.01);self.assertNotEqual(path.read_bytes()[:16],before)
            backend=self.backend(profile)
            with self.assertRaisesRegex(CoordinatedError,'target_fenced'):backend.capture('owned')
        finally:
            if host.poll()is None:host.kill();host.wait(timeout=3)
            host.stdout.close();host.stderr.close()

    def test_watchdog_lease_expiry_is_unknown_and_recovery_does_not_resume_prepaused(self):
        profile,sessions,path,address=self.fixture();profile['max_pause_ms']=100
        backend=self.backend(profile);original=module._read_regions
        def delayed(*args):time.sleep(.15);return original(*args)
        with patch.object(module,'_read_regions',side_effect=delayed):result=backend.capture('owned')
        self.assertEqual(result['status'],'unknown',result)
        self.assertEqual(result['reason'],'coordinated_barrier_expired')
        self.assertTrue(result['persistent_target_fence']);self.assert_running(sessions)

    def test_crashed_watchdog_is_unknown_and_live_host_settles_its_resume_debt(self):
        profile,sessions,path,address=self.fixture();backend=self.backend(profile)
        start=module._Barrier.start
        def crash(barrier):
            start(barrier);barrier.child.kill();barrier.child.wait(timeout=1)
        with patch.object(module._Barrier,'start',crash):result=backend.capture('owned')
        self.assertEqual(result['status'],'unknown',result)
        self.assertIn('coordinated_watchdog_failed',result['cleanup']['errors'])
        self.assert_running(sessions)

    def test_startup_failure_and_repeated_capture_release_do_not_leak_descriptors(self):
        profile,sessions,path,address=self.fixture();backend=self.backend(profile)
        before=len(os.listdir('/proc/self/fd'))
        with patch.object(module.subprocess,'Popen',side_effect=OSError(errno.EMFILE,'injected startup failure')):
            with self.assertRaisesRegex(CoordinatedError,'preflight_failed')as failure:backend.capture('owned')
        self.assertFalse(failure.exception.effect_dispatched);self.assert_running(sessions)
        for _ in range(3):
            result=backend.capture('owned');self.assertEqual(result['status'],'captured',result)
            backend.release(result['snapshot_handle'])
        self.assertEqual(len(os.listdir('/proc/self/fd')),before)
        self.assertEqual(list((self.directory/'state').glob('barrier-*')),[])
        with self.assertRaisesRegex(CoordinatedError,'invalid_snapshot_handle'):backend.patch('owned',None,'update')

    def test_instance_scope_ignores_profile_alias_but_tracks_writer_identity(self):
        profile,sessions,path,address=self.fixture();alias=copy.deepcopy(profile);alias['allow_patch']=False
        backend=self.backend(profile,alias=alias)
        self.assertEqual(backend.instance_scope('owned'),backend.instance_scope('alias'))
        self.assertTrue(backend.instance_scope('owned').startswith('coordinated:'))
        self.assertEqual(backend.close()['cleanup_errors'],[])


if __name__=='__main__':unittest.main()
