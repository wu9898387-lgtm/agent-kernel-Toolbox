"""Real optimized/LTO compiler publication ABI, never fake probe messages."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.native_probe import NativeProbe
from observation_extension.program_monitor import number
PYTHON=Path(os.environ.get('RUNTIME_FRIDA_PYTHON','/workspace/work/toolchains/frida-venv/bin/python'))


@unittest.skipUnless(PYTHON.exists() and shutil.which('gcc') and shutil.which('nm'),'Frida Python and GCC/nm needed')
class OptimizedPublicationTests(unittest.TestCase):
    def test_lto_retains_publication_argument_values_and_lifetime_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);source=root/'app.c';binary=root/'app'
            source.write_text('''#include "probe.h"
#include <unistd.h>
static unsigned long a[8],b[8];
__attribute__((noinline,used,externally_visible)) void sdk_work(void){
 ra_probe_object(91,a,sizeof a,7,3);ra_probe_move(91,b,sizeof b,7);ra_probe_retire(91,7);
}
int main(void){sdk_work();usleep(100000);return 0;}
''')
            subprocess.run(['gcc','-g','-O3','-flto','-fno-inline','-rdynamic','-Wall','-Wextra','-Werror',
                '-I',str(ROOT/'native/probe-sdk'),str(source),str(ROOT/'native/probe-sdk/probe.c'),'-o',str(binary)],
                check=True,capture_output=True,timeout=30)
            symbols=subprocess.check_output(['nm','-S','--defined-only',str(binary)],text=True,timeout=5)
            size=next(int(row.split()[1],16) for row in symbols.splitlines() if row.split()[-1]=='sdk_work')
            digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
            probe=NativeProbe({'python':str(PYTHON),'python_sha256':digest(PYTHON),'profiles':{'sdk':{
                'executable':str(binary),'sha256':digest(binary),'functions':{'sdk_work':size},'entry_function':'sdk_work',
                'registration_hooks':{'define':'ra_probe_object','move':'ra_probe_move','retire':'ra_probe_retire'},
                'lifetime_ms':8000,'max_events':1024,'max_bytes':1048576,'max_instructions':2000,'max_callback_us':500000}}},
                root/'state',bundle_root=ROOT)
            try:
                try:opened=probe.open('sdk')
                except Exception:
                    for value in probe.sessions.values():
                        path=value.get('log')
                        if path and Path(path).exists():print(Path(path).read_text(),flush=True)
                    raise
                session=opened['probe_session'];events=[];cursor=0;deadline=time.monotonic()+12
                while time.monotonic()<deadline:
                    page=probe.poll(session,cursor=cursor,max_events=128);events.extend(page['events']);cursor=page['next_cursor']
                    if page['state']=='closed' and len(page['events'])<128:break
                    time.sleep(.01)
                rows=[e for e in events if e['kind']=='object']
                self.assertEqual([e['operation'] for e in rows],['define','move','retire'])
                self.assertEqual([number(e['object_id']) for e in rows],[91,91,91])
                self.assertEqual([number(e['generation']) for e in rows],[7,7,7])
                self.assertEqual(number(rows[0]['type_slot']),3)
                self.assertEqual(number(rows[0]['size']),64);self.assertEqual(number(rows[1]['size']),64)
                self.assertNotEqual(rows[0]['address'],rows[1]['address'])
                self.assertTrue(probe.close(session)['closed'])
            finally:probe.close()
