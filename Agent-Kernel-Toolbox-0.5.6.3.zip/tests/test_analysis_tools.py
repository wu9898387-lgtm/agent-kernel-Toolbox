"""Adapter boundaries plus optional real JADX multi-DEX integration.

The generated fake launcher tests exercise protocol/limits only, never engine
recovery claims. The ELF test compiles and inspects a real local executable.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.analysis_tools import AnalysisTools, AnalysisToolError, _directory_size


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class AnalysisToolTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.state = self.root / 'state'
        self.state.mkdir(mode=0o700)
        self.target = self.root / 'app.apk'
        self.target.write_bytes(b'PK\x03\x04fixture is data, never a command')

    def tearDown(self):
        self.temporary.cleanup()

    def tools(self, kind, executable, **options):
        profile = {'kind': kind, 'executable': str(Path(executable).resolve()),
                   'sha256': digest(executable), **options}
        config = {'profiles': {'test': profile}, 'digests': {'app': digest(self.target)}}
        return AnalysisTools(config, self.state, {'app': str(self.target)}, bundle_root=ROOT)

    def launcher(self, source):
        path = self.root / 'fake-adapter'
        path.write_text('#!/usr/bin/python3\n' + source)
        path.chmod(0o700)
        return path

    def test_missing_registered_dependency_stays_unavailable(self):
        tools = AnalysisTools({'profiles': {'missing': {'kind': 'jadx',
            'executable': str(self.root / 'does-not-exist'), 'sha256': '0'*64}}},
            self.state, {})
        result = tools.inspect()
        self.assertFalse(result['profiles'][0]['available'])
        self.assertEqual(result['profiles'][0]['operations'], [])
        self.assertIn('arbitrary native symbolic execution', result['unimplemented'])

    def test_unregistered_command_and_target_execution_are_denied(self):
        launcher = self.launcher('raise AssertionError("must never launch")\n')
        tools = self.tools('gdb', launcher)
        for operation, code in [('shell', 'analysis_operation_not_allowed'),
                                ('step', 'analysis_target_execution_denied')]:
            with self.subTest(operation=operation), self.assertRaisesRegex(AnalysisToolError, code):
                tools.run('test', 'app', operation)
        events = [json.loads(line) for line in (self.state / 'analysis-tools.jsonl').read_text().splitlines()]
        self.assertEqual([x['state'] for x in events], ['started', 'failed', 'started', 'failed'])
        for left, right in zip(events, events[1:]):
            self.assertEqual(right['previous_sha256'], left['sha256'])
        for event in events:
            expected = event.pop('sha256')
            self.assertEqual(hashlib.sha256(json.dumps(event, sort_keys=True, ensure_ascii=True,
                allow_nan=False, separators=(',', ':')).encode()).hexdigest(), expected)

    def test_changed_input_and_launcher_digest_are_refused(self):
        launcher = self.launcher('print("unused")\n')
        tools = self.tools('readelf', launcher)
        self.target.write_bytes(b'changed')
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_digest_mismatch'):
            tools.run('test', 'app', 'inspect')
        tools = self.tools('readelf', launcher)
        launcher.write_text('#!/usr/bin/python3\nprint("changed")\n')
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_digest_mismatch'):
            tools.run('test', 'app', 'inspect')

    def test_protocol_jadx_arguments_and_generated_java_are_bounded(self):
        launcher = self.launcher('''import pathlib,sys
assert '--no-res' in sys.argv
assert sys.argv[sys.argv.index('--threads-count')+1] == '1'
out=pathlib.Path(sys.argv[sys.argv.index('-d')+1])
(out/'Example.java').write_text('class Example { int read() { return 7; } }')
''')
        result = self.tools('jadx', launcher).run('test', 'app', 'decompile')
        self.assertTrue(result['success'])
        self.assertFalse(result['target_executed'])
        self.assertFalse(result['artifacts']['source_equivalence_proven'])
        self.assertIn('return 7', result['artifacts']['files'][0]['text'])
        self.assertEqual(list(self.state.glob('analysis-*')), [self.state / 'analysis-tools.jsonl'])

    def test_ghidra_budget_and_java_state_stay_in_private_working_directory(self):
        launcher = self.launcher('''import json,os,pathlib,resource,sys
out=pathlib.Path(sys.argv[sys.argv.index('RuntimeAccessExport.java')+1])
out.write_text('{"schema_version":1}')
print(json.dumps({'nofile':resource.getrlimit(resource.RLIMIT_NOFILE)[0],
 'address_space':resource.getrlimit(resource.RLIMIT_AS)[0],
 'java':os.environ['JAVA_TOOL_OPTIONS'],'heap':os.environ['GHIDRA_HEADLESS_MAXMEM'],
 'directory':os.getcwd()}))
''')
        result = self.tools('ghidra', launcher).run('test', 'app', 'decompile')
        settings = json.loads(result['stdout'])
        self.assertEqual(settings['heap'], '768M')
        self.assertLessEqual(settings['nofile'], 1024)
        self.assertLessEqual(settings['address_space'], 6*1024**3)
        self.assertIn('-Duser.home="' + settings['directory'] + '"', settings['java'])
        self.assertIn('-Djava.io.tmpdir="' + settings['directory'] + '"', settings['java'])

    def test_failed_decompiler_reports_exit_without_masking_it_as_missing_artifact(self):
        launcher = self.launcher('import sys; print("engine_failed"); sys.exit(2)\n')
        for kind in ('ghidra', 'jadx'):
            with self.subTest(kind=kind):
                result = self.tools(kind, launcher).run('test', 'app', 'decompile')
                self.assertFalse(result['success'])
                self.assertEqual(result['exit_code'], 2)
                self.assertEqual(result['artifacts']['files'], [])
                self.assertIn('engine_failed', result['stdout'])

    def test_generated_budget_tolerates_only_entries_removed_after_directory_listing(self):
        for remove in ('directory', 'file', 'both'):
            directory = self.root / ('racing-' + remove)
            directory.mkdir()
            project = directory / 'project.rep'
            project.mkdir()
            (project / 'temporary').write_bytes(b'project-cache')
            cache = directory / 'ghidra.cache'
            cache.write_bytes(b'cached-metadata')
            (directory / 'retained').write_bytes(b'12345')
            listed = list(os.walk(directory, followlinks=False))
            # This is the real headless -deleteProject/cache-cleanup race:
            # names were listed, then disappeared before lstat examines them.
            if remove in ('directory', 'both'):
                shutil.rmtree(project)
            if remove in ('file', 'both'):
                cache.unlink()
            expected = 5 + (0 if remove in ('directory','both') else len(b'project-cache'))
            expected += 0 if remove in ('file','both') else len(b'cached-metadata')
            with self.subTest(remove=remove), patch(
                    'observation_extension.analysis_tools.os.walk', return_value=listed):
                self.assertEqual(_directory_size(directory), expected)
        with patch.object(Path, 'lstat', side_effect=PermissionError('denied')):
            with self.assertRaises(PermissionError):
                _directory_size(self.root / 'racing-both')

    def test_generated_budget_still_rejects_live_symlinks_and_special_files(self):
        for kind in ('file-link', 'directory-link', 'fifo'):
            directory = self.root / kind
            directory.mkdir()
            if kind == 'file-link':
                (directory / 'unexpected').symlink_to(self.target)
            elif kind == 'directory-link':
                (directory / 'unexpected').symlink_to(self.state, target_is_directory=True)
            else:
                os.mkfifo(directory / 'unexpected', 0o600)
            with self.subTest(kind=kind), self.assertRaisesRegex(
                    AnalysisToolError, 'analysis_generated_file_type'):
                _directory_size(directory)

    def test_ghidra_emulation_never_accepts_unbounded_or_command_arguments(self):
        launcher = self.launcher('raise AssertionError("must never launch")\n')
        for arguments in ([], ['runtime_pure','7','5','100001'],
                          ['runtime_pure; system(1)','7','5','100'],
                          ['runtime_pure','2147483648','5','100']):
            tools = self.tools('ghidra', launcher, arguments=arguments)
            with self.subTest(arguments=arguments), self.assertRaisesRegex(
                    AnalysisToolError, 'analysis_ghidra_invalid_emulation_profile') as error:
                tools.run('test','app','emulate')
            self.assertFalse(error.exception.effect_dispatched)

    def test_output_flood_and_deadline_kill_the_process_group(self):
        for source, code in [('import sys; sys.stdout.write("x"*300000)\n', 'analysis_tool_output_limit'),
                             ('import time; time.sleep(5)\n', 'analysis_tool_timeout')]:
            launcher = self.launcher(source)
            tools = self.tools('readelf', launcher, timeout_seconds=1)
            with self.subTest(code=code), self.assertRaisesRegex(AnalysisToolError, code):
                tools.run('test', 'app', 'inspect')
        self.assertFalse(any(self.state.glob('analysis-*/')))

    def test_protocol_frida_active_duration_is_independent_of_overall_deadline(self):
        script = self.root / 'fixed-probe.js'
        script.write_text('/* registered probe; fake launcher only validates argv */\n')
        launcher = self.launcher('''import sys
assert sys.argv[sys.argv.index('-t')+1] == '2.25'
assert '--kill-on-exit' in sys.argv
print('protocol arguments verified')
''')
        result = self.tools('frida', launcher, allow_execute=True, timeout_seconds=15,
            frida_duration_seconds=2.25, script=str(script), script_sha256=digest(script)).run('test', 'app', 'instrument')
        self.assertTrue(result['success'])
        self.assertEqual(result['frida_duration_seconds'], 2.25)
        self.assertEqual(result['overall_deadline_seconds'], 15)
        self.assertIsNone(result['target_executed'])

    def test_frida_active_duration_scope_type_and_bounds_are_validated(self):
        launcher = self.launcher('raise AssertionError("must not launch")\n')
        for value in (0, -1, True, '2', 5, 6):
            with self.subTest(value=value), self.assertRaisesRegex(AnalysisToolError, 'invalid_analysis_frida_duration'):
                self.tools('frida', launcher, timeout_seconds=5, frida_duration_seconds=value)
        with self.assertRaisesRegex(AnalysisToolError, 'invalid_analysis_frida_duration'):
            self.tools('readelf', launcher, timeout_seconds=5, frida_duration_seconds=2)

    def test_protocol_completed_frida_output_cannot_override_original_five_second_hard_deadline(self):
        script = self.root / 'fixed-probe.js'
        script.write_text('/* fixed test probe; no real engine claim */\n')
        launcher = self.launcher('''import sys,time
assert sys.argv[sys.argv.index('-t')+1] == '2'
print('agent-ready; guarded-write; all business outputs observed',flush=True)
time.sleep(9)
''')
        tools = self.tools('frida', launcher, allow_execute=True, timeout_seconds=5,
                           script=str(script), script_sha256=digest(script))
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_tool_timeout') as error:
            tools.run('test', 'app', 'instrument')
        self.assertTrue(error.exception.effect_dispatched)
        events = [json.loads(line) for line in (self.state / 'analysis-tools.jsonl').read_text().splitlines()]
        self.assertEqual(events[-1]['state'], 'failed')
        self.assertFalse(any(self.state.glob('analysis-*/')))

    def test_protocol_recovery_symlink_is_rejected(self):
        launcher = self.launcher('''import os,pathlib,sys
out=pathlib.Path(sys.argv[sys.argv.index('-d')+1])
(out/'X.java').symlink_to('/etc/passwd')
''')
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_generated_file_type'):
            self.tools('jadx', launcher).run('test', 'app', 'decompile')

    def test_executing_timeout_is_uncertain_but_preflight_is_not_dispatched(self):
        launcher = self.launcher('import time; time.sleep(5)\n')
        tools = self.tools('gdb', launcher, timeout_seconds=1, allow_execute=True)
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_tool_timeout') as error:
            tools.run('test', 'app', 'step')
        self.assertTrue(error.exception.effect_dispatched)
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_operation_not_allowed') as error:
            tools.run('test', 'app', 'shell')
        self.assertFalse(error.exception.effect_dispatched)
        offline = self.tools('readelf', launcher, timeout_seconds=1)
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_tool_timeout') as error:
            offline.run('test', 'app', 'inspect')
        self.assertFalse(error.exception.effect_dispatched)

    def test_protocol_rr_record_replay_and_trace_ownership(self):
        launcher = self.launcher('''import pathlib,sys
if sys.argv[1] == 'record':
 trace=pathlib.Path(sys.argv[sys.argv.index('-o')+1]);trace.mkdir()
 (trace/'events').write_text('bounded test trace')
else:
 assert sys.argv[1:3] == ['replay', '-a']
 assert (pathlib.Path(sys.argv[3])/'events').read_text() == 'bounded test trace'
print('protocol completed')
''')
        tools = self.tools('rr', launcher, allow_execute=True)
        recorded = tools.run('test', 'app', 'record')
        self.assertTrue(recorded['success'])
        self.assertTrue(recorded['target_execution_requested'])
        self.assertIsNone(recorded['target_executed'])
        self.assertFalse(recorded['business_effect_confirmed'])
        self.assertTrue((self.state / recorded['trace_id']).is_dir())
        replayed = tools.run('test', 'app', 'replay')
        self.assertTrue(replayed['success'])
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_rr_trace_already_exists'):
            tools.run('test', 'app', 'record')

    def test_protocol_fixed_pwndbg_or_gef_init_uses_pinned_installation_path(self):
        extension = self.root / 'trusted debugger extension.py'
        extension.write_text('# trusted Pwndbg/GEF entry point protocol fixture\n')
        launcher = self.launcher('import json,sys; print(json.dumps(sys.argv[1:]))\n')
        tools = self.tools('gdb', launcher, init_script=str(extension), init_sha256=digest(extension))
        result = tools.run('test', 'app', 'inspect')
        argv = json.loads(result['stdout'])
        self.assertEqual(argv[argv.index('-x')+1], str(extension))
        self.assertIn('set auto-load off', argv)
        self.assertFalse(result['target_execution_requested'])
        self.assertTrue(result['effectful_tool_requested'])
        self.assertFalse(result['debugger_extension']['dependency_integrity_pinned'])
        extension.write_text('# changed after installation\n')
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_digest_mismatch') as error:
            tools.run('test', 'app', 'inspect')
        self.assertFalse(error.exception.effect_dispatched)

    def test_protocol_debugger_extension_timeout_is_effectful_without_target_execution(self):
        extension = self.root / 'init.py'
        extension.write_text('# trusted debugger extension\n')
        launcher = self.launcher('import time; time.sleep(5)\n')
        tools = self.tools('gdb', launcher, timeout_seconds=1,
                           init_script=str(extension), init_sha256=digest(extension))
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_tool_timeout') as error:
            tools.run('test', 'app', 'inspect')
        self.assertTrue(error.exception.effect_dispatched)
        with self.assertRaisesRegex(AnalysisToolError, 'invalid_analysis_debugger_init'):
            self.tools('readelf', launcher, init_script=str(extension), init_sha256=digest(extension))

    def test_signal_aborted_effectful_engine_is_unknown_and_offline_exit_is_known(self):
        launcher = self.launcher('import os,signal; os.write(2, b"private-target-detail\\n"); os.kill(os.getpid(), signal.SIGTERM)\n')
        tools = self.tools('gdb', launcher, allow_execute=True)
        with self.assertRaisesRegex(AnalysisToolError, 'analysis_target_control_unresolved') as error:
            tools.run('test', 'app', 'step')
        self.assertTrue(error.exception.effect_dispatched)
        self.assertEqual(error.exception.diagnostics['termination_signal'], 15)
        self.assertEqual(error.exception.diagnostics['stderr_sha256'], hashlib.sha256(b'private-target-detail\n').hexdigest())
        journal = (self.state / 'analysis-tools.jsonl').read_text()
        self.assertNotIn('private-target-detail', journal)
        self.assertEqual(json.loads(journal.splitlines()[-1])['diagnostics']['exit_code'], -15)
        result = self.tools('readelf', launcher).run('test', 'app', 'inspect')
        self.assertFalse(result['success'])
        self.assertLess(result['exit_code'], 0)
        self.assertFalse(result['effectful_tool_requested'])

    def test_profile_structure_rejects_unbounded_or_ambiguous_operations(self):
        executable = Path('/usr/bin/true').resolve()
        base = {'kind': 'readelf', 'executable': str(executable), 'sha256': digest(executable)}
        for field, value in [('kind', []), ('timeout_seconds', float('inf')),
                             ('arguments', ['a']*17), ('operations', ['shell'])]:
            profile = {**base, field: value}
            with self.subTest(field=field), self.assertRaises((AnalysisToolError, ValueError)):
                AnalysisTools({'profiles': {'test': profile}}, self.state, {})

    @unittest.skipUnless(shutil.which('gcc') and shutil.which('readelf') and shutil.which('objdump'),
                         'real local ELF build and binutils unavailable')
    def test_real_elf_symbols_disassembly_and_version(self):
        source = self.root / 'owned.c'
        source.write_text('int semantic_read(int a) { return a + 5; } int main(void) { return semantic_read(2); }\n')
        self.target = self.root / 'owned'
        subprocess.run([shutil.which('gcc'), '-g', '-O0', str(source), '-o', str(self.target)],
                       check=True, timeout=20)
        readelf = self.tools('readelf', shutil.which('readelf'))
        inspected = readelf.run('test', 'app', 'inspect')
        self.assertTrue(inspected['success'])
        self.assertFalse(inspected['target_executed'])
        self.assertIn('semantic_read', inspected['stdout'])
        self.assertIn('ELF Header', inspected['stdout'])
        version = readelf.inspect()['profiles'][0]['version']
        self.assertTrue(version['probed'])
        self.assertEqual(version['exit_code'], 0)
        disassembly = self.tools('objdump', shutil.which('objdump')).run('test', 'app', 'disassemble')
        self.assertTrue(disassembly['success'])
        self.assertIn('semantic_read', disassembly['stdout'])

    @unittest.skipUnless(os.environ.get('RUNTIME_JADX') and os.environ.get('RUNTIME_MULTIDEX_APK'),
                         'set RUNTIME_JADX and RUNTIME_MULTIDEX_APK for real multi-DEX recovery')
    def test_real_jadx_multidex_exception_nested_anonymous_and_lambda_recovery(self):
        self.target = Path(os.environ['RUNTIME_MULTIDEX_APK']).resolve()
        tools = self.tools('jadx', os.environ['RUNTIME_JADX'], timeout_seconds=90)
        result = tools.run('test', 'app', 'decompile')
        self.assertTrue(result['success'], result['stderr'][-2048:])
        sources = '\n'.join(item['text'] for item in result['artifacts']['files'])
        self.assertIn('try', sources)
        self.assertIn('catch', sources)
        self.assertIn('class', sources)
        self.assertIn('class Extra', sources)
        self.assertIn('class Nested', sources)
        self.assertIn('class Inner', sources)
        self.assertIn('finally', sources)
        self.assertGreaterEqual(len(result['artifacts']['files']), 2)
        self.assertFalse(result['artifacts']['source_equivalence_proven'])
        self.assertFalse(result['target_executed'])


if __name__ == '__main__':
    unittest.main()
