"""Linux integration/regression checks; no third-party Python dependencies."""
import base64
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_runtime import (ProcessSession, NativeRuntimeError,
    MAX_MEMORY_READ, MAX_SESSION_MEMORY)
from observation_extension.runtime_host import RuntimeHost, SPECS
from observation_extension.runtime_mcp import MCPServer
from observation_extension.runtime_state import canonical


class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.process = ProcessSession.attach(os.getpid(), allow_memory=True)
        self.addCleanup(self.process.close)

    def test_boundary_and_overlapping_matches(self):
        data = b'x' * (MAX_MEMORY_READ - 2) + b'ababa' + b'x' * MAX_MEMORY_READ + b'ababa'
        buffer = ctypes.create_string_buffer(data)
        address = ctypes.addressof(buffer)
        result = self.process.search_memory(address, len(data), b'aba')
        self.assertEqual([int(v, 16) - address for v in result['matches']],
                         [MAX_MEMORY_READ - 2, MAX_MEMORY_READ, len(data) - 5, len(data) - 3])
        self.assertEqual(result['read_prefix_sha256'], hashlib.sha256(data).hexdigest())
        self.assertEqual(result['bytes_read'], len(data))
        self.assertFalse(result['atomic_snapshot'])

    def test_match_cap_is_explicit(self):
        buffer = ctypes.create_string_buffer(b'a' * 100)
        result = self.process.search_memory(ctypes.addressof(buffer), 100, b'a', max_matches=2)
        self.assertEqual(len(result['matches']), 2)
        self.assertTrue(result['truncated'])
        self.assertEqual(result['bytes_read'], 100)

    def test_code_address_resolves_to_file_mapping(self):
        address = ctypes.cast(ctypes.CDLL(None).printf, ctypes.c_void_p).value
        result = self.process.resolve_address(address)
        mapping = result['mapping']
        self.assertIn('x', mapping['permissions'])
        self.assertEqual(int(result['backing_file_offset'], 16),
                         address - int(mapping['start'], 16) + int(mapping['offset'], 16))
        self.assertFalse(result['runtime_code_matches_file_proven'])
        with self.assertRaisesRegex(NativeRuntimeError, 'address_not_mapped'):
            self.process.resolve_address(0)

    def test_read_identity_and_permissions_and_budget(self):
        buffer = ctypes.create_string_buffer('状态标签'.encode())
        result = self.process.read_memory(ctypes.addressof(buffer), len(buffer))
        self.assertEqual(base64.b64decode(result['data']), buffer.raw)
        self.assertEqual(result['identity'], self.process.identity)
        self.process.memory_consumed = MAX_SESSION_MEMORY - 1
        with self.assertRaisesRegex(NativeRuntimeError, 'memory_budget'):
            self.process.search_memory(ctypes.addressof(buffer), 2, b'a')
        with ProcessSession.attach(os.getpid()) as denied:
            with self.assertRaisesRegex(NativeRuntimeError, 'memory_not_authorized'):
                denied.search_memory(ctypes.addressof(buffer), 2, b'a')
        with self.assertRaisesRegex(NativeRuntimeError, 'range_not_in_readable_mapping'):
            self.process.search_memory(0, 1, b'a')


class ResourceTests(unittest.TestCase):
    def child(self, script, **options):
        # This is a resource-behavior fixture, not a cold-start latency check.
        options.setdefault('startup_timeout_ms', 15000)
        process = ProcessSession.launch([sys.executable, '-I', '-u', '-c', script],
                                        stdout=subprocess.PIPE, **options)
        def cleanup():
            if process.child.poll() is None:
                process.terminate_owned()
            process.close()
            process.child.stdout.close()
        self.addCleanup(cleanup)
        return process

    def test_effective_limits_and_failed_allocation(self):
        limits = {'cpu_seconds': 3, 'address_space_bytes': 96 * 1024 * 1024,
                  'open_files': 64, 'cpu_affinity': [min(os.sched_getaffinity(0))]}
        script = "import time\ntry:\n x=bytearray(256*1024*1024)\n print('unbounded')\nexcept MemoryError:\n print('bounded')\ntime.sleep(30)"
        process = self.child(script, limits=limits)
        self.assertEqual(process.child.stdout.readline(), b'bounded\n')
        actual = process.resources()
        self.assertEqual(actual['limits']['address_space_bytes']['hard'], limits['address_space_bytes'])
        self.assertEqual(actual['limits']['cpu_seconds']['soft'], 3)
        self.assertEqual(actual['limits']['core_bytes']['hard'], 0)
        self.assertEqual(actual['cpu_affinity'], limits['cpu_affinity'])
        self.assertEqual(process.validate_identity()['executable'], str(Path(sys.executable).resolve()))

    def test_cpu_budget_stops_busy_child(self):
        # A fresh Python interpreter may spend >=1s in site initialization on
        # some hosts. Use a POSIX shell fixture to measure target CPU enforcement
        # without testing interpreter cold-start overhead.
        process = ProcessSession.launch(['/bin/sh','-c',"printf 'ready\\n'; while :; do :; done"],
                                        stdout=subprocess.PIPE, limits={'cpu_seconds': 1},
                                        startup_timeout_ms=15000)
        self.addCleanup(process.close)
        self.addCleanup(process.child.stdout.close)
        self.addCleanup(lambda: process.terminate_owned() if process.child.poll() is None else None)
        self.assertEqual(process.child.stdout.readline(), b'ready\n')
        # RLIMIT_CPU counts scheduled user+system CPU, not elapsed host time.
        self.assertEqual(process.child.wait(timeout=30), -signal.SIGXCPU)

    def test_register_capture_detaches_and_child_continues(self):
        process = self.child("import time; print('ready'); time.sleep(30)", allow_debug=True)
        self.assertEqual(process.child.stdout.readline(), b'ready\n')
        result = process.cpu_snapshot(max_frames=0)
        self.assertTrue(result['registers'])
        status = Path(f'/proc/{process.pid}/status').read_text()
        self.assertIn('TracerPid:\t0\n', status)
        self.assertIsNone(process.child.poll())
        self.assertFalse(process.inspect()['debug_cleanup_unresolved'])

    def test_invalid_limits_rejected_before_spawn(self):
        for limits in [{'cpu_seconds': True}, {'cpu_seconds': 0}, {'cpu_affinity': []},
                       {'address_space_bytes': 10}, {'arbitrary': 1}]:
            with self.subTest(limits=limits), self.assertRaises(NativeRuntimeError):
                ProcessSession.launch(['/bin/sleep', '20'], limits=limits)


class HostTests(unittest.TestCase):
    @unittest.skipUnless((ROOT/'browser/node_modules/playwright').is_dir(),'Playwright required')
    def test_browser_field_transport_preflight_refusal_does_not_fence(self):
        class Page(BaseHTTPRequestHandler):
            def log_message(self,*_):pass
            def do_GET(self):
                self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers()
                self.wfile.write(b'<label for=q>Query</label><input id=q value=initial><input type=submit value=Go>')
        server=ThreadingHTTPServer(('127.0.0.1',0),Page)
        threading.Thread(target=server.serve_forever,daemon=True).start();self.addCleanup(server.server_close);self.addCleanup(server.shutdown)
        base=f'http://127.0.0.1:{server.server_port}'
        host=RuntimeHost({**self.config,'state_directory':self.directory.name+'/form-state',
            'browser':{'allowedOrigins':[base],'headless':True,'executablePath':os.environ.get('RUNTIME_CHROMIUM','/usr/bin/chromium'),
                       'includeEditableText':True,'allowTextInput':True}},bundle_root=ROOT)
        self.addCleanup(host.close)
        opened=host.call('browser.open',{'url':base,'request_id':'open-fields'});self.assertTrue(opened['ok'],opened);page=opened['data']['pageId']
        fields=host.call('browser.fields',{'page_id':page,'query':'Query'})['data'];field=fields['fields'][0]
        args={'page_id':page,'snapshot_id':fields['snapshotId'],'node_id':field['nodeId'],'text':'first','request_id':'fill-first'}
        self.assertTrue(host.call('browser.set_text',args)['data']['textVerified'])
        refused=host.call('browser.set_text',{**args,'request_id':'refuse-consumed'})
        self.assertFalse(refused['ok']);self.assertEqual(refused['error'],'stale_field_snapshot');self.assertFalse(refused['effect_unknown'])
        fields=host.call('browser.fields',{'page_id':page,'query':'Query'})['data'];field=fields['fields'][0]
        accepted=host.call('browser.set_text',{'page_id':page,'snapshot_id':fields['snapshotId'],'node_id':field['nodeId'],'text':'second','request_id':'fill-second'})
        self.assertTrue(accepted['ok'],accepted);self.assertTrue(accepted['data']['textVerified'])
        controls=host.call('browser.controls',{'page_id':page,'query':'Go','role':'button','limit':1})['data'];node=controls['frames'][0]['nodes'][0]
        host.call('browser.fields',{'page_id':page})
        refused=host.call('browser.invoke',{'page_id':page,'snapshot_id':controls['snapshotId'],'node_id':node['nodeId'],'request_id':'refuse-old-control'})
        self.assertFalse(refused['ok']);self.assertEqual(refused['error'],'stale_snapshot');self.assertFalse(refused['effect_unknown'])
        self.assertTrue(host.call('browser.controls',{'page_id':page,'query':'Go'})['ok'])

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.config = {'schema_version': 1, 'state_directory': self.directory.name + '/state',
                       'allowed_tools': list(SPECS), 'profiles': {}, 'targets': {}, 'binaries': {}}
        self.host = RuntimeHost(self.config, bundle_root=ROOT)
        self.addCleanup(self.host.close)

    def test_receipt_chain_and_payload_integrity(self):
        previous = None
        for tool in ['runtime.status', 'runtime.audit', 'runtime.status']:
            result = self.host.call(tool, {})
            self.assertTrue(result['ok'], result)
            evidence = dict(result['evidence'])
            self.assertEqual(evidence['previous_receipt_sha256'], previous)
            self.assertEqual(evidence['data_sha256'], hashlib.sha256(canonical(result['data'])).hexdigest())
            digest = evidence.pop('receipt_sha256')
            self.assertEqual(digest, hashlib.sha256(canonical(evidence)).hexdigest())
            self.assertFalse(evidence['persistent'])
            previous = digest

    def test_nested_validation_precedes_effect_journal(self):
        result = self.host.call('browser.block_request', {
            'request_id': 'invalid-rule', 'rule': {'origin': 'https://example.com',
            'pathPrefix': '/', 'resourceTypes': [123]}})
        self.assertEqual(result['error'], 'invalid_tool_arguments')
        self.assertEqual(self.host.state.db.execute('SELECT count(*) FROM effects').fetchone()[0], 0)
        for options in [{'maxNodes': 0}, {'maxNodes': True}, {'extra': 'x'}, {'query': 1}]:
            result = self.host.call('browser.query', {'page_id': 'p', 'options': options})
            self.assertEqual(result['error'], 'invalid_tool_arguments')

    def test_host_hex_search_and_bad_encoding(self):
        process = ProcessSession.attach(os.getpid(), allow_memory=True)
        self.host.processes['self-test'] = process
        buffer = ctypes.create_string_buffer(b'\x00\xff\x00\xff')
        args = {'session_id': 'self-test', 'address': hex(ctypes.addressof(buffer)),
                'size': 4, 'needle': '00ff', 'encoding': 'hex'}
        result = self.host.call('process.search_memory', args)
        self.assertTrue(result['ok'], result)
        self.assertEqual(len(result['data']['matches']), 2)
        self.assertEqual(result['evidence']['session_id'], 'self-test')
        self.assertEqual(self.host.call('process.search_memory', {**args, 'encoding': 'regex'})['error'],
                         'invalid_tool_arguments')

    def test_app_and_binary_registry_routes_are_fixed(self):
        path = Path(self.directory.name) / 'fixture.desktop'
        raw = b'[Desktop Entry]\nName=Fixture\nMimeType=x-scheme-handler/fixture;\n'
        path.write_bytes(raw)
        config = {**self.config, 'state_directory': self.directory.name + '/apps-state',
                  'apps': {'fixture': {'path': str(path), 'kind': 'desktop_entry', 'sha256': hashlib.sha256(raw).hexdigest()}},
                  'binaries': {'python': str(Path(sys.executable).resolve())}}
        host = RuntimeHost(config, bundle_root=ROOT)
        self.addCleanup(host.close)
        result = host.call('app.routes', {'app': 'fixture'})
        self.assertTrue(result['ok'], result)
        self.assertEqual(result['data']['routes'][0]['scheme'], 'fixture')
        self.assertEqual(host.call('app.routes', {'app': 'unregistered'})['error'], 'unregistered_app')
        self.assertTrue(host.call('binary.abi', {'binary': 'python'})['ok'])

    def test_mcp_stdio_negotiation_and_readonly_catalog(self):
        requests = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
                'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {}}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'},
            {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'runtime.status'}}]
        source = io.BytesIO(b''.join(json.dumps(r).encode() + b'\n' for r in requests))
        sink = io.BytesIO()
        self.assertEqual(MCPServer(self.host).serve(source, sink), 0)
        responses = [json.loads(r) for r in sink.getvalue().splitlines()]
        tools = {t['name']: t for t in responses[1]['result']['tools']}
        self.assertTrue(tools['browser.query']['annotations']['readOnlyHint'])
        self.assertTrue(tools['process.search_memory']['annotations']['readOnlyHint'])
        self.assertIn('evidence', responses[2]['result']['structuredContent'])

    @unittest.skipUnless((ROOT / 'browser/node_modules/playwright').is_dir(), 'run npm ci in browser first')
    def test_python_node_browser_transport(self):
        class Page(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write('<button role="tab" aria-selected="true" onclick="this.setAttribute(\'aria-selected\',\'false\')">状态标签</button>'.encode())
            def log_message(self, *_):
                pass
        server = ThreadingHTTPServer(('127.0.0.1', 0), Page)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base = f'http://127.0.0.1:{server.server_port}'
        config = {**self.config, 'state_directory': self.directory.name + '/browser-state',
                  'browser': {'allowedOrigins': [base], 'headless': True,
                              'executablePath': os.environ.get('RUNTIME_CHROMIUM', '/usr/bin/chromium')}}
        host = RuntimeHost(config, bundle_root=ROOT)
        self.addCleanup(host.close)
        opened = host.call('browser.open', {'url': base + '/', 'request_id': 'open-fixture'})
        self.assertTrue(opened['ok'], opened)
        page_id = opened['data']['pageId']
        queried = host.call('browser.query', {'page_id': page_id, 'options': {'query': '状态'}})
        self.assertTrue(queried['ok'], queried)
        self.assertEqual(queried['data']['frames'][0]['nodes'][0]['states']['selected'], 'true')
        self.assertEqual(queried['evidence']['page_id'], page_id)
        self.assertEqual(queried['evidence']['previous_receipt_sha256'], opened['evidence']['receipt_sha256'])
        snapshot = host.call('browser.snapshot', {'page_id': page_id})
        node = snapshot['data']['frames'][0]['nodes'][0]
        invoked = host.call('browser.invoke', {'page_id': page_id, 'snapshot_id': snapshot['data']['snapshotId'],
                            'node_id': node['nodeId'], 'request_id': 'invoke-fixture'})
        self.assertTrue(invoked['ok'], invoked)
        self.assertFalse(invoked['data']['businessEffectConfirmed'])
        after = host.call('browser.query', {'page_id': page_id, 'options': {'query': '状态'}})
        self.assertEqual(after['data']['frames'][0]['nodes'][0]['states']['selected'], 'false')


if __name__ == '__main__':
    unittest.main()
