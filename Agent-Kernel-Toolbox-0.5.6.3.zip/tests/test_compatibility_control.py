"""Registered owned-app environment shims, with real guarded Frida execution."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.compatibility_control import CompatibilityControl, CompatibilityControlError
from observation_extension.analysis_tools import AnalysisTools

FRIDA = os.environ.get('RUNTIME_FRIDA')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def configuration(executable, binary, probes):
    return {'frida': {'executable': str(executable), 'sha256': digest(executable)},
            'profiles': {'owned': {'binary': 'owned', 'sha256': digest(binary),
                'allow_execute': True, 'allow_replace': True, 'side_effect_free': True,
                'registry': {'entries': 'compatibility_probe_registry',
                             'count': 'compatibility_probe_count', 'layout': 'compatibility_probe_layout'},
                'probes': probes, 'postcondition': 'compatibility-stable value=42 environment=0 timing=1',
                'timeout_seconds': 6}}}


class CompatibilityBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.binary = self.root / 'target'
        self.binary.write_bytes(b'never executed')
        self.config = configuration(Path(sys.executable).resolve(), self.binary, [{
            'symbol': 'environment_probe', 'code_prefix_bytes': 8,
            'code_prefix_sha256': '0' * 64, 'expected_result': 13, 'replacement': 0}])

    def service(self, config=None):
        return CompatibilityControl(config or self.config, self.root / 'state', {'owned': str(self.binary)})

    def test_independent_execute_replace_and_pure_probe_grants(self):
        for key in ('allow_execute', 'allow_replace', 'side_effect_free'):
            cfg = copy.deepcopy(self.config)
            cfg['profiles']['owned'][key] = False
            with self.subTest(key=key), self.assertRaisesRegex(CompatibilityControlError, 'not_authorized') as error:
                self.service(cfg).run('owned')
            self.assertFalse(error.exception.effect_dispatched)
        with self.assertRaisesRegex(CompatibilityControlError, 'unregistered_profile'):
            self.service().run('unknown')

    def test_scripts_addresses_invalid_signatures_and_unbounded_probes_are_rejected(self):
        for fields in [{'symbol': 'environment_probe;eval(1)'}, {'replacement': True},
                       {'expected_result': 2**31}, {'code_prefix_bytes': 0},
                       {'code_prefix_bytes': 65}, {'address': '0x1234'}]:
            cfg = copy.deepcopy(self.config)
            cfg['profiles']['owned']['probes'][0].update(fields)
            with self.subTest(fields=fields), self.assertRaises(CompatibilityControlError):
                self.service(cfg)
        cfg = copy.deepcopy(self.config)
        cfg['profiles']['owned']['script'] = '/arbitrary/script.js'
        with self.assertRaises(CompatibilityControlError):
            self.service(cfg)
        cfg = copy.deepcopy(self.config)
        cfg['profiles']['owned']['probes'] *= 2
        with self.assertRaisesRegex(CompatibilityControlError, 'invalid_probe'):
            self.service(cfg)

    def test_missing_agent_receipt_cannot_turn_stdout_into_verified_patch(self):
        response = {'stdout': self.config['profiles']['owned']['postcondition'], 'stderr': '',
                    'success': True, 'exit_code': 0, 'script_sha256': '0'*64, 'target_sha256': digest(self.binary)}
        with patch.object(AnalysisTools, 'run', return_value=response):
            result = self.service().run('owned')
        self.assertEqual(result['status'], 'unknown')
        self.assertIsNone(result['modifications_started'])
        self.assertFalse(result['business_effect_confirmed'])


@unittest.skipUnless(FRIDA and shutil.which('gcc') and shutil.which('nm'),
                     'set RUNTIME_FRIDA for real registered compatibility-probe execution')
class ActualCompatibilityControlTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name)
        cls.binary = cls.root / 'owned-compatibility-app'
        subprocess.run([shutil.which('gcc'), '-std=c11', '-g', '-O0', '-fno-inline', '-fno-pie',
            '-no-pie', '-rdynamic', '-Wall', '-Wextra', '-Werror',
            str(ROOT / 'tests/fixtures/recovery/compatibility_target.c'), '-o', str(cls.binary)],
            check=True, timeout=20)
        raw = cls.binary.read_bytes()
        symbols = {row.split()[2]: int(row.split()[0], 16)
                   for row in subprocess.check_output(['nm', str(cls.binary)], text=True).splitlines()
                   if len(row.split()) == 3}
        if raw[:6] != b'\x7fELF\x02\x01':
            raise unittest.SkipTest('compiler fixture prefix metadata currently supports native ELF64-LE')
        phoff = struct.unpack_from('<Q', raw, 32)[0]
        phsize, phcount = struct.unpack_from('<HH', raw, 54)
        def prefix(symbol):
            address = symbols[symbol]
            for index in range(phcount):
                kind, _flags, offset, vaddr, _paddr, filesz, _memsz, _align = struct.unpack_from(
                    '<IIQQQQQQ', raw, phoff + index * phsize)
                if kind == 1 and vaddr <= address and address + 8 <= vaddr + filesz:
                    return hashlib.sha256(raw[offset + address - vaddr:offset + address - vaddr + 8]).hexdigest()
            raise AssertionError('compiler symbol does not belong to a file-backed load segment')
        cls.config = configuration(Path(FRIDA).resolve(), cls.binary, [
            {'symbol': symbol, 'code_prefix_bytes': 8, 'code_prefix_sha256': prefix(symbol),
             'expected_result': expected, 'replacement': replacement}
            for symbol, expected, replacement in [('environment_probe', 13, 0), ('timing_probe', 17, 1)]])

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def service(self, name, config=None):
        return CompatibilityControl(config or self.config, self.root / name,
                                    {'owned': str(self.binary)}, bundle_root=ROOT)

    def test_baseline_exit77_becomes_stable_under_verified_environment_and_timing_model(self):
        self.assertEqual(subprocess.run([self.binary], timeout=2).returncode, 77)
        before = digest(self.binary)
        result = self.service('successful').run('owned')
        self.assertEqual(result['status'], 'verified', result)
        self.assertTrue(result['modifications_started'])
        self.assertTrue(result['business_postcondition_observed'])
        self.assertTrue(result['cleanup']['exit_confirmed'])
        checked = next(row for row in result['events'] if row['event'] == 'compatibility-preconditions')
        self.assertEqual([row['original_result'] for row in checked['checked']], [13, 17])
        used = [row for row in result['events'] if row['event'] == 'compatibility-probe-used']
        self.assertEqual([(row['symbol'], row['modeled_result']) for row in used],
                         [('environment_probe', 0), ('timing_probe', 1)])
        self.assertFalse(result['global_clock_replacement'])
        self.assertFalse(result['automatic_detection_discovery'])
        self.assertFalse(result['universal_crash_freedom_proven'])
        self.assertEqual(digest(self.binary), before)
        self.assertEqual(subprocess.run([self.binary], timeout=2).returncode, 77)
        journal = [json.loads(row) for row in (self.root / 'successful/analysis-tools.jsonl').read_text().splitlines()]
        self.assertEqual([row['state'] for row in journal], ['started', 'finished'])
        self.assertFalse(any((self.root / 'successful').glob('analysis-*/')))

    def test_wrong_code_prefix_or_original_result_refuses_before_any_replacement(self):
        for key, value, reason in [('code_prefix_sha256', '0'*64, 'probe_code_precondition_mismatch'),
                                   ('expected_result', 999, 'probe_result_precondition_mismatch')]:
            cfg = copy.deepcopy(self.config)
            cfg['profiles']['owned']['probes'][1][key] = value
            result = self.service(key, cfg).run('owned')
            with self.subTest(key=key):
                self.assertEqual(result['status'], 'rejected', result)
                self.assertEqual(result['rejection_reason'], reason)
                self.assertFalse(result['modifications_started'])
                self.assertTrue(result['cleanup']['exit_confirmed'])
                self.assertFalse(result['business_postcondition_observed'])
                self.assertFalse(any(row['event'] == 'compatibility-applied' for row in result['events']))

    def test_nonregistered_export_does_not_authorize_replacement(self):
        cfg = copy.deepcopy(self.config)
        cfg['profiles']['owned']['probes'][0]['symbol'] = 'main'
        result = self.service('not-registered', cfg).run('owned')
        self.assertEqual(result['status'], 'rejected', result)
        self.assertEqual(result['rejection_reason'], 'probe_not_compiler_registered')
        self.assertFalse(result['modifications_started'])
        self.assertFalse(result['business_effect_confirmed'])


if __name__ == '__main__':
    unittest.main()
