"""Actual GCC DWARF and pinned pyelftools; all fixtures are harmless and owned."""
import hashlib
import importlib.resources
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.compiler_metadata import CompilerMetadata,CompilerMetadataError,_json,MAX_REPORT,MAX_NODES,_nodes
from observation_extension.analysis_tools import AnalysisToolError
from observation_extension.policy import _json_copy


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class CompilerMetadataBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name)
        self.artifact=self.directory/'owned.elf';self.artifact.write_bytes(b'owned harmless non-ELF')
        self.profile={'path':str(self.artifact),'sha256':digest(self.artifact)}
        self.sequence=0

    def service(self,profile=None,**engine):
        self.sequence+=1
        service=CompilerMetadata({'profiles':{'owned':profile or self.profile},**engine},self.directory/('state'+str(self.sequence)))
        self.addCleanup(service.close);return service

    def test_unknown_without_engine_and_registered_artifact_only(self):
        service=self.service();result=service.extract('owned')
        self.assertEqual(result['status'],'unknown');self.assertFalse(result['target_executed'])
        self.assertEqual(result['artifact']['sha256'],digest(self.artifact))
        with self.assertRaises(CompilerMetadataError):service.extract('../owned')
        service.close()
        with self.assertRaises(CompilerMetadataError):service.extract('owned')
        self.assertFalse(CompilerMetadataError.effect_dispatched)

    def test_profile_limits_pins_and_non_ram_files_are_rejected(self):
        for changed in ({'max_types':33},{'timeout_seconds':0},{'max_file_bytes':True},{'expected_bits':128},{'types':['a']*17},{'expected_machine':'shell;cmd'}):
            with self.subTest(changed=changed),self.assertRaises(CompilerMetadataError):self.service({**self.profile,**changed})
        for profile in ({**self.profile,'sha256':'0'*64},{**self.profile,'max_file_bytes':1},{**self.profile,'path':'/dev/zero'}):
            with self.subTest(profile=profile),self.assertRaises(CompilerMetadataError):self.service(profile).extract('owned')
        link=self.directory/'symlink';link.symlink_to(self.artifact)
        with self.assertRaises(CompilerMetadataError):self.service({**self.profile,'path':str(link)}).extract('owned')
        with self.assertRaises(CompilerMetadataError):self.service(python=sys.executable)

    def test_worker_budget_is_unknown_with_no_target_effect_and_temporary_cleanup(self):
        service=self.service(python=sys.executable,python_sha256=digest(sys.executable))
        with patch('observation_extension.analysis_tools._execute',side_effect=AnalysisToolError('analysis_tool_timeout')):
            result=service.extract('owned')
        self.assertEqual(result['status'],'unknown');self.assertIsNone(result['engine']['available'])
        self.assertFalse(result['target_executed'])
        self.assertFalse([p for p in service.directory.glob('compiler-*') if p.is_dir()])
        journal=(service.directory/'compiler-metadata.jsonl').read_text()
        self.assertIn('extract_finished',journal);self.assertNotIn('owned harmless non-ELF',journal)


@unittest.skipUnless(os.environ.get('RUNTIME_PYELFTOOLS_PYTHON') and shutil.which('gcc'),'pinned pyelftools Python and GCC required')
class CompilerMetadataRealTests(unittest.TestCase):
    service=CompilerMetadataBoundaryTests.service
    @classmethod
    def setUpClass(cls):
        cls.engine_python=os.environ['RUNTIME_PYELFTOOLS_PYTHON']
        cls.engine=json.loads(subprocess.check_output([cls.engine_python,'-I','-c',
            'import elftools,hashlib,pathlib,json,sys;print(json.dumps({"python":sys.executable,"python_sha256":hashlib.sha256(pathlib.Path(sys.executable).read_bytes()).hexdigest(),"pyelftools_version":elftools.__version__,"pyelftools_module_sha256":hashlib.sha256(pathlib.Path(elftools.__file__).read_bytes()).hexdigest()}))'],text=True,timeout=15))

    def setUp(self):
        CompilerMetadataBoundaryTests.setUp(self)
        self.artifact=self.directory/'owned-pie'
        fixture=ROOT/'tests/fixtures/compiler_metadata/layout.c'
        subprocess.run(['gcc','-g','-O0','-fPIE','-pie','-Wl,--build-id=sha1',str(fixture),'-o',str(self.artifact)],check=True,capture_output=True,timeout=15)
        self.profile={'path':str(self.artifact),'sha256':digest(self.artifact),'types':['Packet','BitFields'],'variables':['GLOBAL_PACKET','GLOBAL_BITS'],'timeout_seconds':30}

    def extract(self,**profile):return self.service({**self.profile,**profile},**self.engine).extract('owned')

    def test_real_struct_offsets_widths_anonymous_union_arrays_match_compiler(self):
        expected=json.loads(subprocess.check_output([str(self.artifact)],text=True,timeout=5))
        result=self.extract();self.assertIn(result['status'],('completed','partial'),result)
        self.assertEqual(result['artifact']['sha256'],digest(self.artifact));self.assertRegex(result['artifact']['build_id'],r'^[0-9a-f]+$')
        types={x['id']:x for x in result['types']};packet=next(x for x in types.values() if x['name']=='Packet')
        self.assertEqual(packet['byte_size'],expected['packet_size'])
        members={x['name']:x for x in packet['members'] if x['name']}
        for name,width in [('sequence',4),('nested',6),('payload',4),('values',12)]:
            self.assertTrue(members[name]['known'],members[name]);self.assertEqual(members[name]['byte_offset'],expected[name]);self.assertEqual(members[name]['byte_size'],width)
        anonymous=[x for x in packet['members'] if x['anonymous']]
        self.assertEqual(len(anonymous),2)
        recovered={}
        for parent in anonymous:
            for member in types[parent['type_id']]['members']:
                recovered[member['name']]=parent['byte_offset']+member['byte_offset']
        self.assertEqual(recovered['counter'],expected['counter']);self.assertEqual(recovered['number'],expected['number'])
        union=next(x for x in types.values() if x['kind']=='union_type')
        self.assertTrue(union['overlapping_members']);self.assertTrue(all(x['overlapping_storage'] for x in union['members']))
        self.assertTrue(all(x['id'].startswith(result['artifact']['sha256']+':die:') for x in types.values()))
        variable=next(x for x in result['variables'] if x['name']=='GLOBAL_PACKET')
        self.assertEqual(variable['byte_size'],expected['packet_size']);self.assertFalse(variable['object_identity'])
        self.assertLessEqual(len(_json(result)),MAX_REPORT);self.assertLessEqual(_nodes(result),MAX_NODES)

    def test_real_pie_and_exec_storage_requires_verified_live_load_bias(self):
        result=self.extract();self.assertEqual(result['elf']['type'],'ET_DYN')
        for report in [result]:
            location=next(x for x in report['variables'] if x['name']=='GLOBAL_PACKET')['location']
            self.assertEqual(location['kind'],'module_relative',report)
            self.assertTrue(location['load_bias_required']);self.assertIsNone(location['live_address'])
            self.assertEqual(int(location['elf_virtual_address'],16)-int(report['elf']['image_base_vaddr'],16),int(location['module_relative_offset'],16))
            self.assertTrue(all({'p_vaddr','p_offset','p_memsz','p_filesz','p_align'}<=set(x) for x in report['elf']['load_segments']))
        executable=self.directory/'owned-exec'
        subprocess.run(['gcc','-g','-O0','-no-pie',str(ROOT/'tests/fixtures/compiler_metadata/layout.c'),'-o',str(executable)],check=True,capture_output=True,timeout=15)
        report=self.extract(path=str(executable),sha256=digest(executable))
        self.assertEqual(report['elf']['type'],'ET_EXEC');self.assertGreater(int(report['elf']['image_base_vaddr'],16),0)
        self.assertIsNone(next(x for x in report['variables'] if x['name']=='GLOBAL_PACKET')['location']['live_address'])

    def test_bitfields_are_unknown_and_optimized_constant_is_not_live_storage(self):
        report=self.extract();bits=next(x for x in report['types'] if x['name']=='BitFields')
        for member in bits['members'][:2]:
            self.assertFalse(member['known']);self.assertIsNone(member['byte_offset']);self.assertEqual(member['reason'],'bitfield_not_byte_addressable')
        self.assertFalse(bits['layout_known']);self.assertIn('bitfield_layout_not_exported',report['loss'])
        stack=self.extract(variables=['LOCAL_STACK'])
        self.assertEqual(stack['variables'][0]['location']['kind'],'unknown')
        self.assertEqual(stack['variables'][0]['location']['reason'],'unsupported_dwarf_expression')
        self.assertIn('unsupported_dwarf_expression',stack['loss'])
        optimized=self.directory/'owned-optimized'
        subprocess.run(['gcc','-g','-O2','-fPIE','-pie',str(ROOT/'tests/fixtures/compiler_metadata/layout.c'),'-o',str(optimized)],check=True,capture_output=True,timeout=15)
        report=self.extract(path=str(optimized),sha256=digest(optimized),variables=['OPTIMIZED_CONSTANT'])
        self.assertEqual(report['variables'][0]['location']['kind'],'unknown')
        self.assertEqual(report['variables'][0]['location']['reason'],'constant_without_static_storage')

    def test_no_dwarf_bad_elf_and_expected_bits_fail_explicitly(self):
        stripped=self.directory/'owned-stripped';shutil.copyfile(self.artifact,stripped)
        subprocess.run(['strip','--strip-debug',str(stripped)],check=True,capture_output=True,timeout=10)
        report=self.extract(path=str(stripped),sha256=digest(stripped))
        self.assertEqual(report['status'],'unknown');self.assertEqual(report['reason'],'compiler_metadata_no_dwarf')
        report=self.extract(expected_bits=32)
        self.assertEqual(report['status'],'error');self.assertEqual(report['reason'],'compiler_metadata_elf_bits_mismatch')
        bad=self.directory/'bad.elf';bad.write_bytes(b'harmless invalid elf')
        report=self.extract(path=str(bad),sha256=digest(bad));self.assertEqual(report['status'],'error')
        obj32=self.directory/'owned32.o'
        subprocess.run(['gcc','-m32','-g','-c',str(ROOT/'tests/fixtures/compiler_metadata/layout.c'),'-o',str(obj32)],check=True,capture_output=True,timeout=15)
        report=self.extract(path=str(obj32),sha256=digest(obj32),expected_bits=32)
        self.assertEqual(report['elf']['class_bits'],32);self.assertEqual(report['elf']['machine'],'EM_386')
        self.assertEqual(report['elf']['type'],'ET_REL')
        self.assertTrue(all(x['location']['kind']=='unknown' for x in report['variables']))

    def test_real_engine_pin_mismatches_and_requested_budget_loss(self):
        for key,value,reason in [('pyelftools_version','impossible','compiler_metadata_version_mismatch'),('pyelftools_module_sha256','0'*64,'compiler_metadata_module_mismatch')]:
            report=self.service(self.profile,**{**self.engine,key:value}).extract('owned')
            self.assertEqual(report['reason'],reason);self.assertFalse(report['target_executed'])
        report=self.extract(max_types=1)
        self.assertEqual(report['status'],'partial');self.assertIn('type_budget',report['loss'])
        report=self.extract(types=['MissingCompilerType'],variables=['MissingVariable'])
        self.assertIn('requested_type_not_found',report['loss']);self.assertIn('requested_variable_not_found',report['loss'])

    def test_real_large_dwarf_obeys_key_value_node_budget_and_loses_references_explicitly(self):
        # Eight-dimensional arrays are compact JSON but have many small nodes.
        # This GCC artifact previously returned 4,781 gate nodes in 46,337 bytes.
        source=self.directory/'large-layout.c';binary=self.directory/'large-owned'
        source.write_text('struct Big {\n'+'\n'.join(
            'int f%d[%d][1][1][1][1][1][1][1];'%(i,i+1) for i in range(128))+
            '\n}; struct Big GLOBAL; int main(void){return GLOBAL.f0[0][0][0][0][0][0][0][0];}\n')
        subprocess.run(['gcc','-g','-O0','-fPIE','-pie',str(source),'-o',str(binary)],check=True,capture_output=True,timeout=15)
        report=self.extract(path=str(binary),sha256=digest(binary),types=['Big'],variables=['GLOBAL'],max_types=32,max_variables=32)
        self.assertEqual(_nodes({'a':[1,{'b':2}]}),7)
        self.assertEqual(MAX_NODES,3400)
        self.assertLessEqual(_nodes(report),MAX_NODES);self.assertLessEqual(len(_json(report)),MAX_REPORT)
        self.assertEqual(_json_copy(report),report)  # The actual endpoint guard.
        self.assertEqual(report['status'],'partial');self.assertFalse(report['coverage']['complete'])
        self.assertIn('report_budget',report['loss']);self.assertIn('type_reference_not_exported',report['loss'])
        exported={row['id'] for row in report['types']}
        for row in report['types']:
            if row.get('type_id') is not None:self.assertIn(row['type_id'],exported)
            for member in row['members']:
                if member['type_id'] is not None:self.assertIn(member['type_id'],exported)
                if member.get('reason')=='type_reference_not_exported':
                    self.assertFalse(member['known']);self.assertIsNone(member['byte_size'])
        for variable in report['variables']:
            if variable['type_id'] is not None:self.assertIn(variable['type_id'],exported)

    def test_real_zipapp_worker_and_journal_are_reproducible_no_target_execution(self):
        package=self.directory/'compiler.pyz'
        with zipfile.ZipFile(package,'w') as archive:
            archive.writestr('observation_extension/__init__.py','')
            for name in ('compiler_metadata','malware_triage','analysis_tools'):
                archive.writestr(f'observation_extension/{name}.py',
                    importlib.resources.files('observation_extension').joinpath(f'{name}.py').read_bytes())
            archive.writestr('__main__.py','import json,sys\nfrom observation_extension.compiler_metadata import CompilerMetadata\nc=CompilerMetadata(json.load(open(sys.argv[1])),sys.argv[2]);print(json.dumps(c.extract("owned")));c.close()\n')
        config=self.directory/'config.json';config.write_text(json.dumps({'profiles':{'owned':self.profile},**self.engine}))
        result=json.loads(subprocess.check_output([sys.executable,str(package),str(config),str(self.directory/'zip-state')],text=True,timeout=70))
        self.assertIn(result['status'],('completed','partial'),result);self.assertFalse(result['target_executed'])
        self.assertTrue(result['coverage']['dwarf_present']);self.assertFalse(result['live_addresses_returned'])
        self.assertFalse(result['coverage']['external_debug_files_followed'])

if __name__=='__main__':unittest.main()
