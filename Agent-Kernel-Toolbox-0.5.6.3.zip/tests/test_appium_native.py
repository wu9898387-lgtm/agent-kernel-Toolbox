"""W3C/native-source contract tests; these do not claim real OS driver validation."""
import json
from pathlib import Path
import sys
import threading
import unittest
import tempfile
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0,str(RUNTIME))
from observation_extension.appium_native import NativeAppium,AppiumError
from observation_extension.runtime_host import RuntimeHost,SPECS
from observation_extension.runtime_mcp import MCPServer


class AppiumContractTests(unittest.TestCase):
    def test_duplicate_automation_id_uses_observed_xpath(self):
        client=NativeAppium({'endpoint':'http://127.0.0.1:4723','platform':'windows','allow_actions':True,
            'capabilities':{'appium:automationName':'Wincore','appium:app':'C:\\fixture.exe'}})
        source='<Window><Button Name="First" AutomationId="duplicate"/><Button Name="Second" AutomationId="duplicate"/></Window>'
        client.source=lambda:source;client.session_id='fixture'
        snapshot=client.snapshot();node=next(n for n in snapshot['nodes'] if n['name']=='Second')
        calls=[]
        def request(method,path,body):
            calls.append(body)
            return {'element-6066-11e4-a52e-4f735466cecf':'observed'} if path.endswith('/element') else None
        client.request=request
        self.assertEqual(client.action(snapshot['snapshot_id'],node['node_id'])['status'],'acknowledged')
        self.assertEqual(calls[0],{'using':'xpath','value':'/Window[1]/Button[2]'})

    def test_unknown_native_effect_fences_target_but_allows_explicit_cleanup(self):
        with tempfile.TemporaryDirectory() as directory:
            host=RuntimeHost({'schema_version':1,'state_directory':directory+'/state','allowed_tools':list(SPECS),
                'appium_targets':{'app':{'platform':'windows','endpoint':'http://127.0.0.1:4723',
                    'capabilities':{'appium:automationName':'Windows','appium:app':'C:\\fixture.exe'},'allow_actions':True}}})
            try:
                with patch.object(NativeAppium,'open',return_value={'native_context_only':True}), \
                     patch.object(NativeAppium,'action',return_value={'status':'unknown','dispatched':True}), \
                     patch.object(NativeAppium,'close',return_value={'status':'acknowledged','driver_session_ended':True}):
                    opened=host.call('appium.open',{'target':'app','request_id':'open-remote'})
                    self.assertTrue(opened['ok'],opened);session=opened['data']['remote_session']
                    uncertain=host.call('appium.invoke',{'remote_session':session,'snapshot_id':'snapshot','node_id':'control','request_id':'uncertain-native'})
                    self.assertTrue(uncertain['unknown_effect'])
                    blocked=host.call('appium.open',{'target':'app','request_id':'attempt-bypass'})
                    self.assertFalse(blocked['ok']);self.assertEqual(blocked['error'],'scope_outcome_unresolved')
                    closed=host.call('appium.close',{'remote_session':session,'request_id':'cleanup-remote'})
                    self.assertTrue(closed['ok'],closed)
            finally:host.close()

    def test_native_driver_contract_for_all_three_platforms(self):
        for platform,driver in [('windows','Windows'),('windows','Wincore'),('macos','Mac2'),('android','UiAutomator2')]:
            state={'value':'initial','clicked':False,'package':'com.example.app','context':'NATIVE_APP','route':False}
            class Driver(BaseHTTPRequestHandler):
                def log_message(self,*_):pass
                def reply(self,value):
                    raw=json.dumps({'value':value}).encode();self.send_response(200);self.end_headers();self.wfile.write(raw)
                def do_GET(self):
                    if self.path.endswith('/current_package'):self.reply(state['package']);return
                    if self.path.endswith('/context'):self.reply(state['context']);return
                    if platform=='android':
                        source=f'<hierarchy><android.widget.EditText package="com.example.app" text="{state["value"]}" enabled="true"/><android.widget.Button package="com.example.app" text="Settings"/><android.widget.EditText package="com.example.app" password="true" text="PASSWORD_SECRET"/></hierarchy>'
                    elif platform=='windows':
                        source=f'<Window><Edit Name="Input" AutomationId="editor" Value.Value="{state["value"]}"/><Button Name="Settings" AutomationId="settings"/><PasswordBox Name="PASSWORD_SECRET"/></Window>'
                    else:
                        source=f'<AppiumAUT><XCUIElementTypeTextView name="Input" value="{state["value"]}"/><XCUIElementTypeButton name="Settings"/><XCUIElementTypeSecureTextField value="PASSWORD_SECRET"/></AppiumAUT>'
                    self.reply(source)
                def do_POST(self):
                    body=json.loads(self.rfile.read(int(self.headers.get('content-length','0'))))
                    if self.path=='/session':self.reply({'sessionId':'owned-fixture','capabilities':{}});return
                    if self.path.endswith('/element'):
                        if platform=='windows':assert body['using']=='accessibility id'
                        self.reply({'element-6066-11e4-a52e-4f735466cecf':'element'});return
                    if self.path.endswith('/value'):state['value']=body['text']
                    if self.path.endswith('/click'):state['clicked']=True
                    if self.path.endswith('/execute/sync'):
                        assert body['script']=='mobile: deepLink';state['route']=True
                    self.reply(None)
                def do_DELETE(self):self.reply(None)
            server=ThreadingHTTPServer(('127.0.0.1',0),Driver);threading.Thread(target=server.serve_forever,daemon=True).start()
            caps={'platformName':platform,'appium:automationName':driver}
            caps.update({'appium:app':'C:\\fixture.exe'} if platform=='windows' else {'appium:bundleId':'org.example.fixture'} if platform=='macos' else {'appium:appPackage':'com.example.app','appium:udid':'contract-device'})
            client=NativeAppium({'endpoint':f'http://127.0.0.1:{server.server_port}','platform':platform,'capabilities':caps,
                'allow_actions':True,'allow_text_input':True,'include_editable_text':True,'routes':{'settings':'sample://settings'}})
            try:
                self.assertTrue(client.open()['native_context_only'])
                snapshot=client.snapshot();self.assertNotIn('PASSWORD_SECRET',json.dumps(snapshot))
                entry=next(n for n in snapshot['nodes'] if n['editable'] and not n['redacted'])
                self.assertEqual(client.action(snapshot['snapshot_id'],entry['node_id'],text='native-input')['status'],'acknowledged')
                self.assertEqual(client.wait_for('native-input')['status'],'matched')
                with self.assertRaisesRegex(AppiumError,'stale_native_app_snapshot'):client.action(snapshot['snapshot_id'],entry['node_id'])
                snapshot=client.snapshot();button=next(n for n in snapshot['nodes'] if n['name']=='Settings')
                client.action(snapshot['snapshot_id'],button['node_id']);self.assertTrue(state['clicked'])
                if platform=='android':
                    client.route('settings');self.assertTrue(state['route'])
                    state['context']='WEBVIEW_com.example.app'
                    with self.assertRaisesRegex(AppiumError,'native_appium_target_scope_changed'):client.snapshot()
                client.close()
            finally:server.shutdown();server.server_close()

    def test_remote_scope_and_desktop_root_are_not_implicitly_allowed(self):
        with self.assertRaisesRegex(AppiumError,'appium_requires_https_or_loopback'):
            NativeAppium({'endpoint':'http://untrusted.example','platform':'windows','capabilities':{}})
        with self.assertRaisesRegex(AppiumError,'selected_windows_app_required'):
            NativeAppium({'endpoint':'http://127.0.0.1:4723','platform':'windows',
                          'capabilities':{'appium:automationName':'Windows','appium:app':'Root'}})

    def test_native_input_subtrees_are_private_without_editable_read_grant(self):
        cases=[('windows','Windows',{'appium:app':'C:\\fixture.exe'},
                '<Window><Edit Name="Input" Value.Value="PRIVATE_VALUE"><Text Name="PRIVATE_DESCENDANT"/></Edit></Window>'),
               ('macos','Mac2',{'appium:bundleId':'org.example.fixture'},
                '<AppiumAUT><XCUIElementTypeTextView value="PRIVATE_VALUE"><XCUIElementTypeStaticText name="PRIVATE_DESCENDANT"/></XCUIElementTypeTextView></AppiumAUT>')]
        for platform,driver,scope,xml in cases:
            client=NativeAppium({'endpoint':'http://127.0.0.1:4723','platform':platform,
                'capabilities':{'appium:automationName':driver,**scope}})
            client.source=lambda value=xml:value
            result=client.snapshot()
            self.assertNotIn('PRIVATE_VALUE',json.dumps(result))
            self.assertNotIn('PRIVATE_DESCENDANT',json.dumps(result))

    def test_ios_registration_requires_exact_bundle_and_device_without_reset(self):
        endpoint='http://127.0.0.1:4723'
        caps={'platformName':'iOS','appium:automationName':'XCUITest','appium:bundleId':'org.example.fixture','appium:udid':'fixed-device'}
        with self.assertRaisesRegex(AppiumError,'ios_platform_name_required'):
            NativeAppium({'platform':'ios','endpoint':endpoint,'capabilities':{**caps,'platformName':'Windows'}})
        with self.assertRaisesRegex(AppiumError,'selected_ios_device_required'):
            NativeAppium({'platform':'ios','endpoint':endpoint,'capabilities':{**caps,'appium:udid':'auto'}})
        with self.assertRaisesRegex(AppiumError,'selected_ios_bundle_required'):
            NativeAppium({'platform':'ios','endpoint':endpoint,'capabilities':{**caps,'appium:bundleId':''}})
        for extra in ({'browserName':'Safari'},{'appium:app':'http://example.invalid/app.ipa'},
                      {'appium:fullReset':True},{'appium:autoAcceptAlerts':True},
                      {'appium:defaultActiveApplication':'com.apple.springboard'}):
            with self.subTest(extra=extra),self.assertRaisesRegex(AppiumError,'ios_session_side_effect_not_authorized'):
                NativeAppium({'platform':'ios','endpoint':endpoint,'capabilities':{**caps,**extra}})
        self.assertEqual(NativeAppium({'platform':'ios','endpoint':endpoint,'capabilities':caps}).config['platform'],'ios')

    def test_ios_w3c_loopback_session_native_controls_deeplink_and_scope_change(self):
        state={'bundle':'org.example.fixture','context':'NATIVE_APP','value':'before','actions':[], 'clicked':False}
        class Driver(BaseHTTPRequestHandler):
            def log_message(self,*_):pass
            def reply(self,value):
                raw=json.dumps({'value':value}).encode()
                self.send_response(200);self.end_headers();self.wfile.write(raw)
            def do_GET(self):
                if self.path.endswith('/context'):self.reply(state['context']);return
                if self.path.endswith('/source'):
                    self.reply('<AppiumAUT><XCUIElementTypeSearchField name="Find" value="'+state['value']+'"/>'
                               '<XCUIElementTypeButton label="Run"/>'
                               '<XCUIElementTypeSecureTextField name="PRIVATE" value="secret"/></AppiumAUT>');return
                self.send_error(404)
            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers.get('content-length','0'))))
                state['actions'].append((self.path,body))
                if self.path=='/session':self.reply({'sessionId':'ios-fixture','capabilities':{}});return
                if self.path.endswith('/execute/sync'):
                    if body['script']=='mobile: activeAppInfo':self.reply({'bundleId':state['bundle'],'pid':123});return
                    if body['script']=='mobile: deepLink':
                        assert body['args']==[{'url':'sample://settings','bundleId':'org.example.fixture'}]
                        self.reply(None);return
                if self.path.endswith('/element'):
                    self.reply({'element-6066-11e4-a52e-4f735466cecf':'observed'});return
                if self.path.endswith('/clear'):self.reply(None);return
                if self.path.endswith('/value'):state['value']=body['text'];self.reply(None);return
                if self.path.endswith('/click'):state['clicked']=True;self.reply(None);return
                self.send_error(404)
            def do_DELETE(self):self.reply(None)
        server=ThreadingHTTPServer(('127.0.0.1',0),Driver)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        config={'platform':'ios','endpoint':f'http://127.0.0.1:{server.server_port}',
                'capabilities':{'platformName':'iOS','appium:automationName':'XCUITest',
                                'appium:bundleId':'org.example.fixture','appium:udid':'fixture-device'},
                'allow_actions':True,'include_editable_text':True,'allow_text_input':True,
                'routes':{'settings':'sample://settings'}}
        client=NativeAppium(config)
        try:
            self.assertTrue(client.open()['native_context_only'])
            snap=client.snapshot()
            self.assertNotIn('secret',json.dumps(snap))
            search=next(n for n in snap['nodes'] if n['role']=='XCUIElementTypeSearchField')
            self.assertTrue(search['editable'])
            self.assertEqual(client.action(snap['snapshot_id'],search['node_id'],text='after')['status'],'acknowledged')
            self.assertEqual(client.wait_for('after')['status'],'matched')
            with self.assertRaisesRegex(AppiumError,'stale_native_app_snapshot'):
                client.action(snap['snapshot_id'],search['node_id'])
            snap=client.snapshot()
            button=next(n for n in snap['nodes'] if n['name']=='Run')
            state['bundle']='com.apple.springboard'
            before=len(state['actions'])
            with self.assertRaisesRegex(AppiumError,'native_appium_target_scope_changed'):
                client.action(snap['snapshot_id'],button['node_id'])
            self.assertFalse(any(path.endswith('/element') for path,_ in state['actions'][before:]))
            self.assertFalse(any(path.endswith('/click') for path,_ in state['actions'][before:]))
            with self.assertRaisesRegex(AppiumError,'native_appium_target_scope_changed'):client.route('settings')
            state['bundle']='org.example.fixture'
            state['context']='WEBVIEW_org.example.fixture'
            with self.assertRaisesRegex(AppiumError,'native_appium_target_scope_changed'):client.snapshot()
            state['context']='NATIVE_APP'
            self.assertEqual(client.action(snap['snapshot_id'],button['node_id'])['status'],'acknowledged')
            self.assertTrue(state['clicked'])
            self.assertEqual(client.route('settings')['status'],'acknowledged')
            self.assertEqual(client.close()['driver_session_ended'],True)
            # Verify the same remote iOS driver is reachable through the actual
            # model-facing MCP host, not only through the standalone adapter.
            with tempfile.TemporaryDirectory() as directory:
                host=RuntimeHost({'schema_version':1,'state_directory':directory+'/state',
                                  'allowed_tools':['appium.open','appium.snapshot','appium.route','appium.close'],
                                  'appium_targets':{'ios-test':config}})
                try:
                    mcp=MCPServer(host)
                    init=mcp.handle({'jsonrpc':'2.0','id':1,'method':'initialize',
                                     'params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{}}})
                    self.assertEqual(init['result']['serverInfo']['version'],'0.5.6.2')
                    mcp.handle({'jsonrpc':'2.0','method':'notifications/initialized'})
                    def call(name, args):
                        reply=mcp.handle({'jsonrpc':'2.0','id':2,'method':'tools/call',
                                          'params':{'name':name,'arguments':args}})
                        result=reply['result']['structuredContent']
                        self.assertTrue(result['ok'],result)
                        return result['data']
                    remote=call('appium.open',{'target':'ios-test','request_id':'ios-mcp-open'})['remote_session']
                    self.assertTrue(call('appium.snapshot',{'remote_session':remote})['nodes'])
                    self.assertEqual(call('appium.route',{'remote_session':remote,'route':'settings',
                                                           'request_id':'ios-mcp-route'})['status'],'acknowledged')
                    self.assertTrue(call('appium.close',{'remote_session':remote,
                                                         'request_id':'ios-mcp-close'})['driver_session_ended'])
                finally:host.close()
        finally:server.shutdown();server.server_close()

    def test_ios_sensitive_input_is_uneditable_even_when_input_is_granted(self):
        caps={'platformName':'iOS','appium:automationName':'XCUITest','appium:bundleId':'org.example.fixture','appium:udid':'fixture'}
        client=NativeAppium({'platform':'ios','endpoint':'http://127.0.0.1:4723','capabilities':caps,
                             'allow_actions':True,'include_editable_text':True,'allow_text_input':True})
        client.session_id='fixed';client.scope=lambda:{'bundleId':'org.example.fixture','context':'NATIVE_APP'}
        client.source=lambda:'<AppiumAUT><XCUIElementTypeSecureTextField name="Secret" value="PRIVATE"/></AppiumAUT>'
        snap=client.snapshot()
        self.assertNotIn('PRIVATE',json.dumps(snap))
        with self.assertRaisesRegex(AppiumError,'native_app_control_unavailable'):
            node=snap['nodes'][0]
            client.action(snap['snapshot_id'],node['node_id'],text='leak')


    def test_native_text_write_grant_does_not_require_value_read_grant(self):
        client=NativeAppium({'endpoint':'http://127.0.0.1:4723','platform':'windows',
                             'capabilities':{'appium:automationName':'Wincore','appium:app':'C:\\fixture.exe'},
                             'allow_actions':True,'allow_text_input':True,'include_editable_text':False})
        client.session_id='fixture'
        client.source=lambda:'<Window><Edit Name="PRIVATE_NAME" Value.Value="PRIVATE_VALUE"/><PasswordBox Name="PRIVATE_PASSWORD"/></Window>'
        observed=[]
        def request(method,path,body=None):
            observed.append((path,body))
            if path.endswith('/element'):return {'element-6066-11e4-a52e-4f735466cecf':'e'}
            return None
        client.request=request
        snap=client.snapshot()
        self.assertNotIn('PRIVATE_NAME',json.dumps(snap))
        self.assertNotIn('PRIVATE_VALUE',json.dumps(snap))
        entry=next(n for n in snap['nodes'] if n['role']=='Edit')
        self.assertTrue(entry['redacted'])
        self.assertEqual(client.action(snap['snapshot_id'],entry['node_id'],text='replacement')['status'],'acknowledged')
        self.assertIn(('/session/fixture/element/e/value',{'text':'replacement'}),observed)
        snap=client.snapshot();password=next(n for n in snap['nodes'] if n['role']=='PasswordBox')
        with self.assertRaisesRegex(AppiumError,'native_app_control_unavailable'):
            client.action(snap['snapshot_id'],password['node_id'],text='no')



if __name__=='__main__':unittest.main()
