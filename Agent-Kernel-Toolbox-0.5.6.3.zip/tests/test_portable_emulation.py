"""Actual cross-ISA private-buffer effects, p-code float ops and fail-closed limits."""
import copy
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.portable_emulation import PortableEmulation,PortableEmulationError
from observation_extension.policy import _json_copy

GHIDRA=os.environ.get('RUNTIME_GHIDRA')
AS=os.environ.get('RUNTIME_AARCH64_AS','/workspace/work/toolchains/aarch64-binutils/usr/bin/aarch64-linux-gnu-as')
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def base_profile():
    return {'executable':'/operator/analyzeHeadless','sha256':'0'*64,
        'binary':'/operator/target.o','binary_sha256':'1'*64,'script_sha256':'2'*64,
        'function':'portable_array','abi':'sysv_amd64_buffer_i32',
        'regions':[{'id':'buffer','address':0x60000000,'initial_hex':struct.pack('<iii',1,-2,3).hex(),'writable':True}],
        'arguments':[{'region':'buffer','offset':0},{'i32':3}],
        'max_steps':512,'max_memory_events':64,'timeout_seconds':120}


class PortableProfileTests(unittest.TestCase):
    def test_strict_operator_profiles_refuse_raw_code_and_unsafe_RAM(self):
        p=base_profile();PortableEmulation.validate(p)
        for change in ({'max_steps':True},{'max_steps':4097},{'max_memory_events':0},
                       {'function':'x;system("bad")'},{'abi':'guess'},{'script':'/any.java'},
                       {'regions':[{'id':'buffer','address':0,'initial_hex':'00','writable':True}]},
                       {'arguments':[{'address':0x60000000},{'i32':3}]},
                       {'arguments':[{'region':'buffer','offset':12},{'i32':3}]},
                       {'regions':[p['regions'][0],{**p['regions'][0],'id':'overlap'}]}):
            with self.subTest(change=change):
                with self.assertRaises(PortableEmulationError):PortableEmulation.validate({**p,**change})


@unittest.skipUnless(GHIDRA and shutil.which('gcc') and Path(AS).is_file(),
                     'RUNTIME_GHIDRA, gcc and AArch64 assembler required for real cross-ISA execution')
class PortableEmulationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory();cls.root=Path(cls.temporary.name)
        try:
            source=ROOT/'tests/fixtures/recovery/portable_memory.c'
            cls.x64=cls.root/'memory-x64.o';cls.arm64=cls.root/'memory-aarch64.o';cls.native=cls.root/'oracle.so'
            subprocess.run([shutil.which('gcc'),'-g','-O1','-ffreestanding','-fno-stack-protector','-fno-pic',
                '-fno-builtin','-fno-tree-vectorize','-c',str(source),'-o',str(cls.x64)],check=True,capture_output=True,timeout=20)
            subprocess.run([shutil.which('gcc'),'-O1','-shared','-fPIC','-fno-tree-vectorize',
                str(source),'-o',str(cls.native)],check=True,capture_output=True,timeout=20)
            environment=dict(os.environ)
            libraries=str(Path(AS).parent.parent/'lib/x86_64-linux-gnu')
            if Path(libraries).is_dir():environment['LD_LIBRARY_PATH']=libraries
            subprocess.run([AS,'-g',str(ROOT/'tests/fixtures/recovery/portable_memory_aarch64.S'),'-o',str(cls.arm64)],
                           check=True,capture_output=True,timeout=20,env=environment)
            cls.oracle=ctypes.CDLL(str(cls.native))
            cls.launcher=Path(GHIDRA).resolve()
        except BaseException:cls.temporary.cleanup();raise

    @classmethod
    def tearDownClass(cls):cls.temporary.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name)

    def profile(self,isa='x64',function='portable_array',initial=None):
        target=self.x64 if isa=='x64'else self.arm64
        p={**base_profile(),'executable':str(self.launcher),'sha256':digest(self.launcher),
            'binary':str(target),'binary_sha256':digest(target),'script_sha256':digest(ROOT/'tools/RuntimeAccessEmulateMemory.java'),
            'abi':'sysv_amd64_buffer_i32'if isa=='x64'else 'aapcs64_buffer_i32','function':function}
        if initial is not None:p['regions']=[{**p['regions'][0],'initial_hex':initial.hex()}]
        return p

    def run_profile(self,p):
        backend=PortableEmulation({'profiles':{'fixture':p}},self.directory,bundle_root=ROOT)
        self.addCleanup(backend.close)
        try:result=backend.run('fixture')
        except PortableEmulationError as error:self.fail(str(error)+' '+json.dumps(getattr(error,'diagnostics',None)))
        self.assertFalse(result['native_target_executed']);self.assertFalse(result['host_process_memory_access'])
        self.assertFalse(result['hardware_trace']);self.assertLess(len(json.dumps(result,separators=(',',':')).encode()),65536)
        _json_copy(result)
        self.assertEqual(list(self.directory.iterdir()),[])
        return result

    def test_real_integer_array_memory_effects_match_native_oracle_on_two_ISAs(self):
        values=(ctypes.c_int*3)(1,-2,3);oracle=self.oracle.portable_array
        oracle.argtypes=[ctypes.POINTER(ctypes.c_int),ctypes.c_int];oracle.restype=ctypes.c_int
        expected=oracle(values,3);expected_bytes=bytes(values)
        self.assertEqual((expected,list(values)),(26,[8,6,12]))
        for isa in ('x64','aarch64'):
            with self.subTest(isa=isa):
                result=self.run_profile(self.profile(isa))
                self.assertEqual(result['status'],'completed',result['reason']);self.assertEqual(result['returned_u32'],expected)
                self.assertEqual(bytes.fromhex(result['regions'][0]['final_hex']),expected_bytes)
                events=[e for e in result['memory_events']if e['region']=='buffer']
                self.assertGreaterEqual(sum(e['kind']=='read'for e in events),3)
                self.assertEqual([e['offset']for e in events if e['kind']=='write'],[0,4,8])
                self.assertEqual(result['regions'][0]['final_sha256'],hashlib.sha256(expected_bytes).hexdigest())
                self.assertEqual(len(result['trace'])+result['trace_steps_omitted'],result['steps'])
                self.assertTrue(all(e['step_completed']for e in result['trace']))
                nodes=[n for step in result['trace']for op in step['pcode']for n in op['inputs']]
                self.assertTrue(all(set(n)=={'space','offset','bytes'}for n in nodes))
                print('PCODE_RAM_REAL',json.dumps({'isa':isa,'steps':result['steps'],'return':expected,'final_hex':expected_bytes.hex(),'memory_accesses':result['memory_accesses']}))

    def test_real_finite_f32_memory_uses_engine_FLOAT_ops_on_two_ISAs(self):
        initial=struct.pack('<fff',1.25,-2.5,0.0);values=(ctypes.c_float*3).from_buffer_copy(initial)
        oracle=self.oracle.portable_float;oracle.argtypes=[ctypes.POINTER(ctypes.c_float),ctypes.c_int];oracle.restype=ctypes.c_int
        self.assertEqual(oracle(values,3),3);self.assertEqual(list(values),[3.5,-4.0,1.0])
        for isa in ('x64','aarch64'):
            with self.subTest(isa=isa):
                result=self.run_profile(self.profile(isa,'portable_float',initial))
                self.assertEqual(result['status'],'completed',result['reason'])
                self.assertEqual(result['regions'][0]['final_hex'],bytes(values).hex())
                opcodes={op['opcode']for step in result['trace']for op in step['pcode']}
                self.assertIn('FLOAT_ADD',opcodes);self.assertFalse(result['floating_point_AOT_implemented'])
                print('PCODE_FLOAT_REAL',json.dumps({'isa':isa,'final_hex':bytes(values).hex(),'steps':result['steps'],'FLOAT_ops':sorted(op for op in opcodes if op.startswith('FLOAT_'))}))

    def test_readonly_private_RAM_OOB_and_ELF_image_writes_remain_unknown(self):
        readonly=self.profile();readonly['regions'][0]['writable']=False
        for p in (readonly,self.profile(function='portable_oob'),self.profile(function='portable_imagewrite')):
            with self.subTest(function=p['function'],writable=p['regions'][0]['writable']):
                result=self.run_profile(p);self.assertEqual(result['status'],'unknown')
                self.assertIsNone(result['returned_u32']);self.assertEqual(digest(p['binary']),p['binary_sha256'])
                self.assertTrue('write_outside_'in result['reason']or result['reason'].startswith('pcode_step_failed:'),result['reason'])
                if not p['regions'][0]['writable']:self.assertEqual(result['regions'][0]['final_hex'],p['regions'][0]['initial_hex'])

    def test_step_memory_event_and_syscall_limits_are_unknown_not_completion(self):
        for p,reason in (({**self.profile(),'max_steps':1},'step_budget_exhausted'),
                         ({**self.profile(),'max_memory_events':1},'memory_event_budget_exhausted'),
                         (self.profile(function='portable_syscall'),'syscall_userop_or_nested_call_unsupported')):
            with self.subTest(reason=reason):
                result=self.run_profile(p);self.assertEqual(result['status'],'unknown');self.assertIsNone(result['returned_u32'])
                self.assertIn(reason,result['reason'])

    def test_pins_and_ISA_are_checked_before_any_engine_execution(self):
        for change in ({'binary_sha256':'0'*64},{'sha256':'0'*64},{'script_sha256':'0'*64},{'abi':'aapcs64_buffer_i32'}):
            with self.subTest(change=change):
                backend=PortableEmulation({'profiles':{'fixture':{**self.profile(),**change}}},self.directory,bundle_root=ROOT)
                with self.assertRaises(PortableEmulationError)as caught:backend.run('fixture')
                self.assertFalse(caught.exception.effect_dispatched)
                self.assertEqual(list(self.directory.iterdir()),[])


if __name__=='__main__':unittest.main()
