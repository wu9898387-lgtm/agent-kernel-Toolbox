"""Real owned scanner observations and non-evaluating strace parser checks."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.file_activity import FileActivity,FileActivityError


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parser():
    spec=importlib.util.spec_from_file_location('file_activity_agent',ROOT/'tools/file_activity_agent.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


class FileActivityParserTests(unittest.TestCase):
    def test_c_escaping_and_malformed_input_are_data_not_code(self):
        module=parser()
        self.assertEqual(module._decode(r'\x2f\x74\x6d\x70\x2f\x61'),'/tmp/a')
        for value in [r'\u002f',r'\xzz',r'\n','\0']:
            with self.assertRaises(ValueError):module._decode(value)
        source=b'not a syscall\n123 100.000001 read(0x3, 0x123, 0x4) = 0x4 <0.000001>\n'
        result=module.parse_trace(source,{'cwd':'/tmp','roots':['/tmp']},1000000)
        self.assertEqual(result['parse_issues']['unparsed_lines'],1)
        self.assertEqual(result['summary']['distinct_paths'],0)
        self.assertFalse(result['observed_scan_pattern']['matched'])

    def test_unfinished_clone_is_joined_before_child_fd_inheritance(self):
        source=(r'100 100.000001 execve(0x1, 0x2, 0x3) = 0 <0.000001>'+'\n'+
          r'100 100.000002 openat(AT_FDCWD<\x2f\x74\x6d\x70>, "\x2f\x74\x6d\x70\x2f\x61", O_RDONLY) = 3<\x2f\x74\x6d\x70\x2f\x61> <0.000001>'+'\n'+
          r'100 100.000003 clone(child_stack=NULL, flags=SIGCHLD <unfinished ...>'+'\n'+
          r'101 100.000004 read(0x3, 0x123, 0x4) = 0x4 <0.000001>'+'\n'+
          r'100 100.000005 <... clone resumed>) = 101 <0.000002>'+'\n')
        result=parser().parse_trace(source.encode(),{'cwd':'/tmp','roots':['/tmp']},1000000)
        child=next(row for row in result['actors'] if row['tid']==101)
        self.assertEqual(child['parent_tid'],100)
        event=next(row for row in result['events'] if row['syscall']=='read')
        self.assertEqual(event['path']['sha256'],hashlib.sha256(b'/tmp/a').hexdigest())
        self.assertEqual(result['summary']['read_bytes_observed'],4)
        self.assertEqual(result['parse_issues']['orphan_resumes'],0)

    def test_threads_share_fd_and_cwd_tables_without_inventing_tgid(self):
        def quoted(value):return '"'+''.join('\\x%02x'%byte for byte in value.encode())+'"'
        lines=[
            'execve(0x1, 0x2, 0x3) = 0',
            'openat(AT_FDCWD, '+quoted('/tmp/a')+', O_RDONLY) = 3',
            'clone(child_stack=NULL, flags=CLONE_FILES|CLONE_FS|CLONE_THREAD|CLONE_VM) = 101',
            'close(3) = 0',
            'openat(AT_FDCWD, '+quoted('/tmp/b')+', O_RDONLY) = 3',
            'read(0x3, 0x123, 0x4) = 0x4',
            'chdir('+quoted('/tmp/sub')+') = 0',
            'openat(AT_FDCWD, '+quoted('c')+', O_RDONLY) = 4']
        tids=[100,100,100,101,101,100,101,100]
        raw='\n'.join(f'{tid} 100.{i:06d} {line} <0.000001>' for i,(tid,line) in enumerate(zip(tids,lines)))+'\n'
        result=parser().parse_trace(raw.encode(),{'cwd':'/tmp','roots':['/tmp'],'show_paths':True},1000000)
        thread=next(row for row in result['actors'] if row['tid']==101)
        self.assertEqual(thread['pid'],100)
        read=next(row for row in result['events'] if row['syscall']=='read')
        self.assertEqual(read['path']['path'],'/tmp/b')
        self.assertEqual(result['events'][-1]['path']['path'],'/tmp/sub/c')

    def test_unknown_clone_sharing_does_not_guess_inherited_paths(self):
        raw=(b'100 100.000001 execve(0x1, 0x2, 0x3) = 0\n'
             b'100 100.000002 openat(AT_FDCWD, "/tmp/a", O_RDONLY) = 3\n'
             b'100 100.000003 clone(...) = 101\n'
             b'101 100.000004 read(0x3, 0x123, 0x4) = 0x4\n')
        result=parser().parse_trace(raw,{'cwd':'/tmp','roots':['/tmp']},1000000)
        child=next(row for row in result['actors'] if row['tid']==101)
        self.assertIsNone(child['pid'])
        self.assertEqual(result['parse_issues']['unknown_clone_semantics'],1)
        read=next(row for row in result['events'] if row['syscall']=='read')
        self.assertNotIn('path',read)


@unittest.skipUnless(sys.platform=='linux' and shutil.which('gcc') and shutil.which('strace'),'Linux C compiler and strace required')
class FileActivityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build=tempfile.TemporaryDirectory()
        cls.binary=Path(cls.build.name)/'owned-scanner'
        subprocess.run([shutil.which('gcc'),'-O0','-g','-Wall','-Wextra','-Werror',
            str(ROOT/'tests/fixtures/file_activity_scanner.c'),'-o',str(cls.binary)],check=True,timeout=20)
        cls.strace=Path(shutil.which('strace')).resolve()

    @classmethod
    def tearDownClass(cls):cls.build.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.data=self.root/'private-directory'
        self.data.mkdir()
        self.secret='FILE_CONTENT_MUST_NOT_APPEAR_8f28ea'
        for i in range(12):(self.data/('private-file-'+str(i))).write_text(self.secret*4)
        self.clients=[]
        self.addCleanup(lambda:[client.close() for client in self.clients])

    def config(self,mode='scan',**options):
        return {'strace':{'path':str(self.strace),'sha256':digest(self.strace)},
            'profiles':{'owned':{'argv':[str(self.binary),mode,str(next(self.data.iterdir()) if mode=='single' else self.data)],
                # Success fixtures may wait for CI scheduling; budget-failure
                # cases override this explicitly below.
                'sha256':digest(self.binary),'roots':[str(self.data)],'allow_capture':True,
                'duration_ms':10000,**options}}}

    def client(self,mode='scan',**options):
        result=FileActivity(self.config(mode,**options),self.root/('state'+str(len(self.clients))),ROOT)
        self.clients.append(result);return result

    def test_real_scanner_and_single_file_have_different_observed_patterns(self):
        scan=self.client().capture('owned');single=self.client('single').capture('owned')
        self.assertEqual(scan['binary_sha256'],digest(self.binary))
        self.assertGreaterEqual(scan['summary']['distinct_paths'],12)
        self.assertGreaterEqual(scan['summary']['enumeration_calls'],2)
        self.assertGreaterEqual(scan['summary']['read_calls'],24)
        self.assertTrue(scan['observed_scan_pattern']['matched'])
        self.assertFalse(scan['observed_scan_pattern']['maliciousness_proven'])
        self.assertEqual(single['summary']['distinct_paths'],1)
        self.assertFalse(single['observed_scan_pattern']['matched'])
        self.assertTrue(scan['capture_cleanup_confirmed'])
        self.assertLessEqual(len(scan['events']),64)
        self.assertLess(len(json.dumps(scan,ensure_ascii=True).encode()),65536)

    def test_default_path_privacy_and_operator_authorized_reveal(self):
        hidden=self.client().capture('owned')
        encoded=json.dumps(hidden,ensure_ascii=True)
        self.assertNotIn(self.secret,encoded)
        self.assertNotIn('private-file-',encoded)
        self.assertNotIn(str(self.data),encoded)
        self.assertFalse(hidden['file_contents_captured'])
        self.assertFalse(hidden['directory_entry_buffers_captured'])
        visible=self.client(show_paths=True).capture('owned')
        paths=[event['path'] for event in visible['events'] if 'path' in event]
        self.assertTrue(any('path' in value and value['path'].startswith(str(self.data)) for value in paths))
        self.assertTrue(all(value['redacted'] for value in paths if not value['in_scope']))
        self.assertNotIn(self.secret,json.dumps(visible))

    def test_real_child_is_attributed_to_owned_root(self):
        result=self.client('child').capture('owned')
        child=next(actor for actor in result['actors'] if actor['relation']=='descendant_process')
        self.assertEqual(child['parent_tid'],result['root_pid'])
        self.assertNotEqual(child['pid'],result['root_pid'])
        self.assertTrue(any(event['pid']==child['pid'] and event['in_scope'] for event in result['events']))
        self.assertTrue(result['capture_cleanup_confirmed'])

    def test_duration_and_event_budgets_return_explicit_partial_observations(self):
        slow=self.client('slow',duration_ms=60).capture('owned')
        self.assertEqual(slow['stop_reason'],'duration_budget')
        self.assertFalse(slow['coverage_complete'])
        self.assertTrue(slow['capture_cleanup_confirmed'])
        flood=self.client('repeat',max_events=32,duration_ms=1000).capture('owned')
        self.assertEqual(flood['stop_reason'],'event_budget')
        self.assertTrue(flood['truncated'])
        self.assertIsNone(flood['lost_event_count'])
        self.assertTrue(flood['capture_cleanup_confirmed'])

    def test_missing_tool_invalid_hash_symlink_and_privilege_are_preflight(self):
        config=self.config();config['profiles']['owned']['sha256']='0'*64
        client=FileActivity(config,self.root/'bad-hash',ROOT)
        with self.assertRaises(FileActivityError) as error:client.capture('owned')
        self.assertFalse(error.exception.effect_dispatched)
        linked=self.root/'symlink';linked.symlink_to(self.binary)
        config=self.config();config['profiles']['owned']['argv'][0]=str(linked)
        with self.assertRaises(FileActivityError) as error:FileActivity(config,self.root/'linked',ROOT).capture('owned')
        self.assertFalse(error.exception.effect_dispatched)
        privileged=self.root/'privileged';shutil.copyfile(self.binary,privileged);privileged.chmod(0o4755)
        config=self.config();config['profiles']['owned']['argv'][0]=str(privileged)
        with self.assertRaisesRegex(FileActivityError,'privileged_target_denied'):FileActivity(config,self.root/'priv',ROOT).capture('owned')
        unavailable=FileActivity({'strace':{'path':str(self.root/'missing'),'sha256':'0'*64},'profiles':{}},self.root/'missing-state',ROOT)
        self.assertFalse(unavailable.inspect()['strace']['available'])

    def test_profile_cannot_be_widened_by_capture_parameters(self):
        client=self.client(allow_capture=False)
        with self.assertRaisesRegex(FileActivityError,'not_authorized'):client.capture('owned')
        with self.assertRaisesRegex(FileActivityError,'unknown_profile'):client.capture('/bin/sh')
        client.close()
        with self.assertRaisesRegex(FileActivityError,'closed'):client.capture('owned')

    def test_host_sigkill_stops_and_reaps_only_spawned_tracees(self):
        host=self.root/'host.py';pid_file=self.root/'capture-pids'
        # The worker is independent and watches a stable inherited host pidfd.
        # A strace target snapshot is discovered only below this private state
        # directory; this test never signals an existing unrelated process.
        config=self.config('slow',duration_ms=5000)
        host.write_text('''import json,sys
sys.path.insert(0,sys.argv[1])
from observation_extension.file_activity import FileActivity
c=FileActivity(json.loads(sys.argv[3]),sys.argv[2],sys.argv[4])
c.capture('owned')
''')
        state=self.root/'host-state'
        process=subprocess.Popen([sys.executable,str(host),str(RUNTIME),str(state),json.dumps(config),str(ROOT)],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        traced_pid=None;descriptor=None
        try:
            deadline=time.monotonic()+3
            while traced_pid is None:
                for log in state.glob('file-activity-*/trace.log'):
                    line=log.read_text().splitlines()
                    if line:traced_pid=int(line[0].split()[0]);break
                self.assertLess(time.monotonic(),deadline,'strace target did not start')
                time.sleep(.01)
            descriptor=os.pidfd_open(traced_pid)
            process.kill();process.wait(timeout=2)
            self.assertTrue(select.select([descriptor],[],[],3)[0],'owned target survived host SIGKILL')
            deadline=time.monotonic()+3
            while Path(f'/proc/{traced_pid}').exists():
                self.assertLess(time.monotonic(),deadline,'worker did not reap its tracee')
                time.sleep(.01)
        finally:
            if process.poll() is None:process.kill();process.wait(timeout=2)
            if descriptor is not None:
                if not select.select([descriptor],[],[],0)[0]:signal.pidfd_send_signal(descriptor,signal.SIGKILL)
                os.close(descriptor)


if __name__=='__main__':unittest.main()
