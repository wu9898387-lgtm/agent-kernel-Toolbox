"""Cooperative memory correctness checks; no arbitrary-process memory access."""
import ctypes
import hashlib
import sys
from pathlib import Path
import struct
import threading
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.object_runtime import ObjectRuntime, ObjectRuntimeError, plan_probes


class Memory:
    def __init__(self):
        self.data = bytearray(512)
        self.reads = 0
        self.writes = 0
        self.generations = {'a': 'g1', 'b': 'g2'}

    def read(self, address, size):
        self.reads += 1
        return bytes(self.data[address:address + size])

    def write(self, address, raw):
        self.writes += 1
        self.data[address:address + len(raw)] = raw
        return len(raw)

    def runtime(self, **kwargs):
        return ObjectRuntime(self.read, self.write, build_id='build-1',
                             mapping_generation=self.generations.get, **kwargs)


def bind(runtime, allocation='a', object_id='obj', **kwargs):
    return runtime.bind_object(object_id, allocation, 0, 16, type_id='Counter',
        build_id='build-1', fields={'value': {'offset': 0, 'type': 'uint64', 'writable': True},
                                  'tag': {'offset': 12, 'type': 'bytes', 'size': 4}},
        evidence={'source': 'compiler', 'artifact': 'layout-1'}, **kwargs)


class ObjectRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.memory = Memory()
        self.memory.data[:8] = (7).to_bytes(8, 'little')
        self.runtime = self.memory.runtime()
        self.runtime.register_allocation('a', 0, 64, generation='g1',
            kind='private_cow', writable=True, provenance={'source': 'runtime_allocator'})
        self.handle = bind(self.runtime)

    def test_multiple_objects_share_allocation_without_sharing_identity(self):
        second = self.runtime.bind_object('other', 'a', 16, 16, type_id='Counter',
            build_id='build-1', fields={'value': {'offset': 0, 'type': 'uint64'}},
            evidence={'source': 'runtime'})
        self.assertNotEqual(second, self.handle)
        self.assertEqual(self.runtime.resolve(self.handle)['allocation_id'], 'a')
        self.assertEqual(self.runtime.resolve(second)['address'], '0x10')

    def test_semantic_snapshot_does_not_copy_padding(self):
        self.memory.data[8:12] = b'XXXX'
        result = self.runtime.snapshot(self.handle)
        self.assertEqual(result['fields']['value'], '7')
        self.assertEqual(result['fields']['tag'], {'encoding': 'hex', 'value': '00000000'})
        self.assertEqual(result['consistency'], 'non_atomic')
        self.assertEqual(self.memory.reads, 2)
        self.assertEqual(len(result['semantic_sha256']), 64)

    def test_allocation_retirement_and_address_reuse_do_not_revive_handle(self):
        self.runtime.retire_allocation('a')
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_handle_not_live'):
            self.runtime.resolve(self.handle)
        self.memory.generations['new'] = 'g3'
        self.runtime.register_allocation('new', 0, 64, generation='g3', writable=True)
        fresh = bind(self.runtime, 'new', 'new-object')
        self.assertNotEqual(fresh, self.handle)
        with self.assertRaisesRegex(ObjectRuntimeError, 'allocation_identity_reused_or_limit'):
            self.runtime.register_allocation('a', 64, 64, generation='g4')
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_identity_reused_or_limit'):
            bind(self.runtime, 'new', 'obj')

    def test_retired_object_identity_cannot_be_reused(self):
        self.runtime.retire_object(self.handle)
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_handle_not_live'):
            self.runtime.snapshot(self.handle)
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_identity_reused_or_limit'):
            bind(self.runtime)

    def test_mapping_generation_change_refuses_stale_reads_and_writes(self):
        self.memory.generations['a'] = 'remapped'
        with self.assertRaisesRegex(ObjectRuntimeError, 'mapping_generation_changed'):
            self.runtime.snapshot(self.handle)
        with self.assertRaisesRegex(ObjectRuntimeError, 'mapping_generation_changed'):
            self.runtime.patch(self.handle, 'value', bytes(8), bytes(8))
        self.assertEqual(self.memory.reads, 0)
        self.assertEqual(self.memory.writes, 0)

    def test_mapping_change_during_read_is_rejected(self):
        def read(address, size):
            self.memory.generations['a'] = 'remapped'
            return self.memory.read(address, size)
        self.runtime._read = read
        with self.assertRaisesRegex(ObjectRuntimeError, 'mapping_generation_changed'):
            self.runtime.snapshot(self.handle)

    def test_mmio_unknown_and_device_never_touch_backend(self):
        for kind in ('mmio', 'unknown', 'device'):
            with self.subTest(kind=kind):
                memory = Memory()
                runtime = memory.runtime()
                runtime.register_allocation('a', 0, 64, generation='g1', kind=kind, writable=True)
                handle = bind(runtime)
                self.assertEqual(runtime.resolve(handle)['kind'], kind)
                with self.assertRaisesRegex(ObjectRuntimeError, 'ordinary_memory_access_forbidden'):
                    runtime.snapshot(handle)
                with self.assertRaisesRegex(ObjectRuntimeError, 'ordinary_memory_access_forbidden'):
                    runtime.patch(handle, 'value', bytes(8), bytes(8))
                self.assertEqual((memory.reads, memory.writes), (0, 0))

    def test_exact_patch_precondition_and_readback(self):
        before = bytes(self.memory.data[:8])
        replacement = (99).to_bytes(8, 'little')
        result = self.runtime.patch(self.handle, 'value', before, replacement)
        self.assertEqual(result['status'], 'verified')
        self.assertEqual(self.runtime.snapshot(self.handle)['fields']['value'], '99')
        rejected = self.runtime.patch(self.handle, 'value', before, (42).to_bytes(8, 'little'))
        self.assertEqual(rejected['status'], 'rejected')
        self.assertFalse(rejected['memory_written'])
        self.assertEqual(self.memory.writes, 1)

    def test_partial_write_rolls_back_before_resuming_writer(self):
        events = []
        before = bytes(self.memory.data[:8])
        self.runtime.register_writer('application', lambda epoch, deadline: events.append('stop') or True,
            lambda epoch: events.append(bytes(self.memory.data[:8])) or True)
        original = self.memory.write
        def write(address, raw):
            if self.memory.writes == 0:
                original(address, raw[:1])
                return 1
            return original(address, raw)
        self.runtime._write = write
        result = self.runtime.patch(self.handle, 'value', before, (9).to_bytes(8, 'little'))
        self.assertEqual(result['status'], 'rolled_back')
        self.assertTrue(result['rollback_verified'])
        self.assertEqual(events, ['stop', before])

    def test_write_exception_attempts_rollback(self):
        before = bytes(self.memory.data[:8])
        original = self.memory.write
        def write(address, raw):
            if self.memory.writes == 0:
                original(address, raw[:1])
                raise OSError('partial system write')
            return original(address, raw)
        self.runtime._write = write
        result = self.runtime.patch(self.handle, 'value', before, (9).to_bytes(8, 'little'))
        self.assertEqual(result['status'], 'rolled_back')
        self.assertEqual(self.memory.data[:8], before)

    def test_failed_rollback_fences_future_mutations(self):
        self.runtime._write = lambda address, raw: 0
        result = self.runtime.patch(self.handle, 'value', (7).to_bytes(8, 'little'), (9).to_bytes(8, 'little'))
        self.assertEqual(result['status'], 'unknown')
        self.assertFalse(result['rollback_verified'])
        self.assertTrue(self.runtime.audit()['unresolved'])
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_runtime_unresolved'):
            self.runtime.patch(self.handle, 'value', bytes(8), bytes(8))

    def test_missing_shared_writer_declaration_refuses_write(self):
        memory = Memory()
        runtime = memory.runtime()
        runtime.register_allocation('a', 0, 64, generation='g1', kind='shared', writable=True)
        handle = bind(runtime)
        with self.assertRaisesRegex(ObjectRuntimeError, 'shared_mapping_writers_not_coordinated'):
            runtime.patch(handle, 'value', bytes(8), bytes(8))
        self.assertEqual(memory.writes, 0)

    def test_uncoordinated_shared_snapshot_is_only_non_atomic_observation(self):
        for kind in ('shared', 'file_shared'):
            with self.subTest(kind=kind):
                memory = Memory()
                runtime = memory.runtime()
                runtime.register_allocation('a', 0, 64, generation='g1', kind=kind)
                handle = bind(runtime)
                observed = runtime.snapshot(handle)
                self.assertEqual(observed['consistency'], 'non_atomic')
                reads = memory.reads
                with runtime.checkpoint():
                    with self.assertRaisesRegex(ObjectRuntimeError, 'shared_mapping_writers_not_coordinated'):
                        runtime.snapshot(handle)
                self.assertEqual(memory.reads, reads)

    def test_shared_source_migration_requires_complete_registered_writer_set(self):
        cases = [({}, ()),
                 ({'all_writers_declared': True}, ()),
                 ({'all_writers_declared': True, 'writer_ids': ['peer']}, ()),
                 ({'writer_ids': ['peer']}, ('peer',))]
        for kind in ('shared', 'file_shared'):
            for flags, registered in cases:
                with self.subTest(kind=kind, flags=flags):
                    memory = Memory()
                    runtime = memory.runtime()
                    runtime.register_allocation('a', 0, 64, generation='g1', kind=kind, **flags)
                    runtime.register_allocation('b', 128, 64, generation='g2', kind='private_cow', writable=True)
                    for writer in registered:
                        runtime.register_writer(writer, lambda e, d: True, lambda e: True)
                    handle = bind(runtime)
                    published = []
                    with self.assertRaisesRegex(ObjectRuntimeError, 'shared_mapping_writers_not_coordinated'):
                        runtime.relocate(handle, 'b', 0, publish=lambda o, n: published.append(n) or True,
                                         revert=lambda o, n: True)
                    self.assertEqual(published, [])
                    self.assertEqual((memory.reads, memory.writes), (0, 0))
                    self.assertEqual(runtime.resolve(handle)['allocation_id'], 'a')

    def test_coordinated_readonly_shared_source_can_snapshot_and_migrate(self):
        for kind in ('shared', 'file_shared'):
            with self.subTest(kind=kind):
                memory = Memory()
                memory.data[:8] = (73).to_bytes(8, 'little')
                quiescent = [False]
                def read(address, size):
                    if address < 64:
                        self.assertTrue(quiescent[0], 'shared source read outside its writer barrier')
                    return memory.read(address, size)
                runtime = ObjectRuntime(read, memory.write, build_id='build-1',
                                        mapping_generation=memory.generations.get)
                runtime.register_allocation('a', 0, 64, generation='g1', kind=kind,
                    all_writers_declared=True, writer_ids=['peer'])
                runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
                def quiesce(epoch, deadline):
                    quiescent[0] = True
                    return True
                def resume(epoch):
                    quiescent[0] = False
                    return True
                runtime.register_writer('peer', quiesce, resume)
                handle = bind(runtime)
                with runtime.checkpoint():
                    snapshot = runtime.snapshot(handle)
                    self.assertEqual(snapshot['consistency'], 'registered_writer_checkpoint')
                self.assertFalse(quiescent[0])
                result = runtime.relocate(handle, 'b', 0, publish=lambda o, n: quiescent[0],
                                          revert=lambda o, n: True)
                self.assertEqual(result['status'], 'verified')
                self.assertFalse(quiescent[0])
                self.assertEqual(runtime.snapshot(handle)['fields']['value'], '73')

    def test_shared_source_writer_rejection_prevents_snapshot_or_migration_reads(self):
        memory = Memory()
        runtime = memory.runtime()
        runtime.register_allocation('a', 0, 64, generation='g1', kind='shared',
            all_writers_declared=True, writer_ids=['peer'])
        runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        runtime.register_writer('peer', lambda e, d: False, lambda e: True)
        handle = bind(runtime)
        with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_writer_not_quiescent'):
            runtime.relocate(handle, 'b', 0, publish=lambda o, n: True, revert=lambda o, n: True)
        self.assertEqual((memory.reads, memory.writes), (0, 0))

    def test_shared_mapping_coordinates_all_declared_writers(self):
        memory = Memory()
        runtime = memory.runtime()
        runtime.register_allocation('a', 0, 64, generation='g1', kind='file_shared', writable=True,
            writer_ids=['application', 'peer-process'], all_writers_declared=True)
        handle = bind(runtime)
        events = []
        for writer in ('application', 'peer-process'):
            runtime.register_writer(writer, lambda epoch, deadline, w=writer: events.append('stop-' + w) or True,
                lambda epoch, w=writer: events.append('resume-' + w) or True)
        result = runtime.patch(handle, 'value', bytes(8), (9).to_bytes(8, 'little'))
        self.assertEqual(result['status'], 'verified')
        self.assertEqual(events, ['stop-application', 'stop-peer-process', 'resume-peer-process', 'resume-application'])
        self.assertTrue(result['unknown_writers_excluded'])

    def test_rejected_quiesce_is_resumed_and_body_never_runs(self):
        events = []
        self.runtime.register_writer('one', lambda e, d: events.append('one-stop') or True,
            lambda e: events.append('one-resume') or True)
        self.runtime.register_writer('missing', lambda e, d: events.append('two-stop') or False,
            lambda e: events.append('two-resume') or True)
        with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_writer_not_quiescent'):
            with self.runtime.checkpoint():
                self.fail('checkpoint body ran with missing writer')
        self.assertEqual(events, ['one-stop', 'two-stop', 'two-resume', 'one-resume'])
        self.assertFalse(self.runtime.audit()['unresolved'])

    def test_resume_failure_fences_runtime(self):
        self.runtime.register_writer('one', lambda e, d: True, lambda e: False)
        with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_resume_unresolved'):
            with self.runtime.checkpoint():
                pass
        self.assertTrue(self.runtime.audit()['unresolved'])
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_runtime_unresolved'):
            with self.runtime.checkpoint():
                pass

    def test_registry_cannot_change_inside_checkpoint(self):
        with self.runtime.checkpoint():
            with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_registry_frozen'):
                self.runtime.register_writer('late', lambda e, d: True, lambda e: True)
            with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_registry_frozen'):
                self.runtime.retire_object(self.handle)
            self.assertEqual(self.runtime.snapshot(self.handle)['consistency'], 'registered_writer_checkpoint')

    def test_deadline_expiry_prevents_write(self):
        clock = [100]
        self.runtime._clock = lambda: clock[0]
        with self.runtime.checkpoint(max_hold_ms=1):
            clock[0] += 1_000_000
            with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_lease_expired_or_absent'):
                self.runtime.patch(self.handle, 'value', bytes(8), bytes(8))
        self.assertEqual(self.memory.writes, 0)

    def test_migration_copies_fields_preserves_padding_and_live_handle(self):
        self.runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        self.memory.data[136:140] = b'KEEP'
        self.memory.data[12:16] = b'test'
        holder = {'address': 0}
        def publish(old, new):
            self.assertEqual(holder['address'], old)
            holder['address'] = new
            return True
        def revert(old, new):
            holder['address'] = old
            return True
        previous = self.runtime.snapshot(self.handle)
        result = self.runtime.relocate(self.handle, 'b', 0, publish=publish, revert=revert,
            expected_semantic_sha256=previous['semantic_sha256'])
        self.assertEqual(result['status'], 'verified')
        self.assertEqual(holder['address'], 128)
        self.assertEqual(self.runtime.resolve(self.handle)['address'], '0x80')
        self.assertEqual(self.runtime.resolve(self.handle)['location_epoch'], 2)
        self.assertEqual(self.runtime.snapshot(self.handle)['semantic_sha256'], previous['semantic_sha256'])
        self.assertEqual(self.memory.data[136:140], b'KEEP')
        self.assertEqual(len(self.runtime.resolve(self.handle)['address_history']), 2)

    def test_failed_migration_publication_restores_reference_and_target(self):
        self.runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        holder = {'address': 0}
        def publish(old, new):
            holder['address'] = new
            raise OSError('lost acknowledgement')
        def revert(old, new):
            holder['address'] = old
            return True
        result = self.runtime.relocate(self.handle, 'b', 0, publish=publish, revert=revert)
        self.assertEqual(result['status'], 'rolled_back')
        self.assertEqual(holder['address'], 0)
        self.assertEqual(self.runtime.resolve(self.handle)['address'], '0x0')
        self.assertEqual(self.memory.data[128:144], bytes(16))

    def test_migration_does_not_revert_or_write_after_publish_expires_lease(self):
        self.runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        clock = [100]
        self.runtime._clock = lambda: clock[0]
        events = []
        def publish(old, new):
            events.append('published')
            clock[0] += 1_000_000_000
            return True
        def revert(old, new):
            events.append('reverted_after_expiry')
            return True
        result = self.runtime.relocate(self.handle, 'b', 0, publish=publish, revert=revert)
        self.assertEqual(result['status'], 'unknown')
        self.assertFalse(result['rollback_verified'])
        self.assertTrue(result['memory_written'])
        self.assertEqual(events, ['published'])
        self.assertEqual(self.memory.writes, 2, 'expired lease must prohibit all rollback writes')
        self.assertEqual(self.memory.data[128:136], (7).to_bytes(8, 'little'))
        self.assertTrue(self.runtime.audit()['unresolved'])
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_runtime_unresolved'):
            self.runtime.patch(self.handle, 'value', bytes(8), bytes(8))

    def test_failed_reference_revert_fences_migration(self):
        self.runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        result = self.runtime.relocate(self.handle, 'b', 0, publish=lambda o, n: False,
                                       revert=lambda o, n: False)
        self.assertEqual(result['status'], 'unknown')
        self.assertTrue(self.runtime.audit()['unresolved'])

    def test_external_reference_is_not_faked_as_identity_or_migrated(self):
        handle = self.runtime.bind_object('ref', 'a', 16, 8, type_id='ReferenceHolder',
            build_id='build-1', fields={'ptr': {'offset': 0, 'type': 'object_ref', 'size': 8, 'writable': True}},
            evidence={'source': 'debug_info'})
        result = self.runtime.snapshot(handle)
        self.assertFalse(result['fields']['ptr']['object_identity_established'])
        self.runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        with self.assertRaisesRegex(ObjectRuntimeError, 'migration_external_references_unsupported'):
            self.runtime.relocate(handle, 'b', 0, publish=lambda o, n: True, revert=lambda o, n: True)
        with self.assertRaisesRegex(ObjectRuntimeError, 'field_write_not_authorized'):
            self.runtime.patch(handle, 'ptr', bytes(8), bytes(8))

    def test_build_mismatch_and_overlaps_are_rejected(self):
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_layout_build_mismatch'):
            self.runtime.bind_object('bad', 'a', 16, 8, type_id='Counter', build_id='wrong',
                fields={'n': {'offset': 0, 'type': 'uint64'}}, evidence={'source': 'compiler'})
        with self.assertRaisesRegex(ObjectRuntimeError, 'overlapping_live_allocations'):
            self.runtime.register_allocation('b', 32, 64, generation='g2')
        with self.assertRaisesRegex(ObjectRuntimeError, 'overlapping_object_fields'):
            self.runtime.bind_object('bad', 'a', 16, 8, type_id='Counter', build_id='build-1',
                fields={'n': {'offset': 0, 'type': 'uint64'}, 'x': {'offset': 0, 'type': 'uint8'}},
                evidence={'source': 'compiler'})

    def test_migration_cannot_overwrite_another_live_object(self):
        self.runtime.register_allocation('b', 128, 64, generation='g2', writable=True)
        bind(self.runtime, 'b', 'occupied')
        with self.assertRaisesRegex(ObjectRuntimeError, 'migration_overwrites_live_object'):
            self.runtime.relocate(self.handle, 'b', 0, publish=lambda o, n: True, revert=lambda o, n: True)
        self.assertEqual(self.memory.writes, 0)

    def test_snapshot_cannot_claim_checkpoint_after_read_deadline(self):
        clock = [100]
        self.runtime._clock = lambda: clock[0]
        original = self.memory.read
        def read(address, size):
            clock[0] += 1_000_000
            return original(address, size)
        self.runtime._read = read
        with self.runtime.checkpoint(max_hold_ms=1):
            with self.assertRaisesRegex(ObjectRuntimeError, 'checkpoint_lease_expired_or_absent'):
                self.runtime.snapshot(self.handle)

    def test_interrupting_partial_write_still_rolls_back(self):
        original = self.memory.write
        before = bytes(self.memory.data[:8])
        def write(address, raw):
            if self.memory.writes == 0:
                original(address, raw[:1])
                raise KeyboardInterrupt()
            return original(address, raw)
        self.runtime._write = write
        with self.assertRaises(KeyboardInterrupt):
            self.runtime.patch(self.handle, 'value', before, (99).to_bytes(8, 'little'))
        self.assertEqual(self.memory.data[:8], before)
        self.assertFalse(self.runtime.audit()['unresolved'])

    def test_malformed_handle_and_field_are_rejected(self):
        malformed = dict(self.handle, object_id=[])
        with self.assertRaisesRegex(ObjectRuntimeError, 'invalid_object_handle'):
            self.runtime.resolve(malformed)
        with self.assertRaisesRegex(ObjectRuntimeError, 'invalid_field_name'):
            self.runtime.patch(self.handle, [], bytes(8), bytes(8))
        with self.assertRaisesRegex(ObjectRuntimeError, 'invalid_allocation_id'):
            self.runtime.retire_allocation([])

    def test_returned_audit_and_provenance_do_not_mutate_runtime(self):
        result = self.runtime.resolve(self.handle)
        result['address_history'][0]['address'] = 'wrong'
        result['provenance']['source'] = 'wrong'
        result['evidence']['source'] = 'wrong'
        audit = self.runtime.audit()
        audit['events'][0]['kind'] = 'wrong'
        self.assertEqual(self.runtime.resolve(self.handle)['address_history'][0]['address'], '0x0')
        self.assertEqual(self.runtime.resolve(self.handle)['provenance']['source'], 'runtime_allocator')
        self.assertEqual(self.runtime.resolve(self.handle)['evidence']['source'], 'compiler')
        self.assertEqual(self.runtime.audit()['events'][0]['kind'], 'private_cow')

    def test_external_observation_and_internal_agent_share_object_identity(self):
        for source in ('external_observation', 'internal_agent'):
            result = self.runtime.observe(self.handle, address=0, generation='g1',
                build_id='build-1', source=source, observation={'status': 'ready', 'text': 'external data'})
            self.assertFalse(result['causal_identity_proven'])
            self.assertEqual(len(result['observation_sha256']), 64)
        observations = self.runtime.resolve(self.handle)['observations']
        self.assertEqual(len(observations), 2)
        self.assertEqual(observations[0]['observation_sha256'], observations[1]['observation_sha256'])
        with self.assertRaisesRegex(ObjectRuntimeError, 'observation_identity_scope_mismatch'):
            self.runtime.observe(self.handle, address=32, generation='g1', build_id='build-1',
                source='external_observation', observation={})
        with self.assertRaisesRegex(ObjectRuntimeError, 'observation_identity_scope_mismatch'):
            self.runtime.observe(self.handle, address=0, generation='old', build_id='build-1',
                source='internal_agent', observation={})

    def test_real_ctypes_allocation_reads_and_writes_exact_field(self):
        storage = ctypes.create_string_buffer(32)
        address = ctypes.addressof(storage)
        storage.raw = struct.pack('<Q', 7) + bytes(24)
        def read(at, size):
            self.assertTrue(address <= at and at + size <= address + 32)
            return ctypes.string_at(at, size)
        def write(at, raw):
            self.assertTrue(address <= at and at + len(raw) <= address + 32)
            ctypes.memmove(at, raw, len(raw))
            return len(raw)
        runtime = ObjectRuntime(read, write, build_id='build-1')
        runtime.register_allocation('a', address, 32, generation='ctypes-lifetime-1', writable=True)
        handle = bind(runtime)
        result = runtime.patch(handle, 'value', struct.pack('<Q', 7), struct.pack('<Q', 1234))
        self.assertEqual(result['status'], 'verified')
        self.assertEqual(struct.unpack('<Q', storage.raw[:8])[0], 1234)
        self.assertEqual(runtime.audit()['mapping_validation'], 'application_reported')

    def test_real_cooperative_writer_stays_stable_during_checkpoint(self):
        data_lock = threading.Lock()
        started = threading.Event()
        finished = threading.Event()
        def writer():
            while not finished.is_set():
                with data_lock:
                    value = int.from_bytes(self.memory.data[:8], 'little') + 1
                    self.memory.data[:8] = value.to_bytes(8, 'little')
                started.set()
                time.sleep(.001)
        worker = threading.Thread(target=writer)
        worker.start()
        try:
            self.assertTrue(started.wait(1))
            self.runtime.register_writer('thread', lambda e, d: data_lock.acquire(timeout=max(0, (d - time.monotonic_ns()) / 1e9)),
                lambda e: data_lock.release() or True)
            with self.runtime.checkpoint():
                before = self.runtime.snapshot(self.handle)['fields']['value']
                time.sleep(.01)
                after = self.runtime.snapshot(self.handle)['fields']['value']
                self.assertEqual(before, after)
        finally:
            finished.set()
            worker.join(1)
        self.assertFalse(worker.is_alive())


class ProbePlannerTests(unittest.TestCase):
    def test_budget_selects_higher_utility_per_cost_and_adjusts_density(self):
        candidates = [{'id': 'cheap', 'cost_ns': 10, 'utility': 5},
                      {'id': 'expensive', 'cost_ns': 50, 'utility': 2},
                      {'id': 'extra', 'cost_ns': 20, 'utility': 3}]
        tight = plan_probes(candidates, 10, 1000)
        self.assertEqual([p['id'] for p in tight['selected']], ['cheap'])
        self.assertEqual(tight['selected'][0]['samples_per_window'], 1)
        broad = plan_probes(candidates, 100, 1000)
        self.assertEqual(broad['selected_count'], 3)
        self.assertLessEqual(broad['estimated_cost_ns'], broad['budget_ns'])
        faster = plan_probes(candidates[:1], 100, 1000)
        self.assertGreater(faster['selected'][0]['samples_per_window'], tight['selected'][0]['samples_per_window'])

    def test_zero_budget_and_minimum_interval(self):
        candidates = [{'id': 'probe', 'cost_ns': 10, 'utility': 1, 'minimum_interval_ns': 600}]
        self.assertEqual(plan_probes(candidates, 0, 1000)['selected_count'], 0)
        result = plan_probes(candidates, 100, 1000)
        self.assertEqual(result['selected'][0]['samples_per_window'], 1)
        self.assertEqual(result['estimated_cost_ns'], 10)

    def test_budget_invariant_over_varied_inputs(self):
        for budget in range(0, 101):
            for count in range(0, 10):
                candidates = [{'id': str(i), 'cost_ns': i * 3 + 1, 'utility': i % 3 + 1}
                              for i in range(count)]
                result = plan_probes(candidates, budget, 100, max_probes=4)
                self.assertLessEqual(result['estimated_cost_ns'], budget)
                self.assertLessEqual(result['selected_count'], 4)
                self.assertEqual(len({p['id'] for p in result['selected']}), result['selected_count'])

    def test_bad_cost_or_duplicate_id_refused(self):
        for candidates in ([{'id': 'p', 'cost_ns': 0, 'utility': 1}],
                           [{'id': 'p', 'cost_ns': 1, 'utility': 1}] * 2):
            with self.assertRaises(ObjectRuntimeError):
                plan_probes(candidates, 10, 100)


if __name__ == '__main__':
    unittest.main()
