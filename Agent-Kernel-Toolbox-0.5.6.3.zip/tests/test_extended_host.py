"""Actual new adapters through RuntimeHost/MCP policy and durable effect scopes.

The fault-injected test checks only host fencing; real engines have separate
optional tests below. A protocol result is never counted as engine evidence.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.runtime_host import RuntimeHost, SPECS
from observation_extension.runtime_state import canonical


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_fixture(name, relative):
    spec = importlib.util.spec_from_file_location('extended_host_' + name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tracing_profiles():
    return {'profiles': {
        'counter': {'backend': 'perf_counter', 'event': 'task_clock', 'allow_capture': True},
        'sample': {'backend': 'perf_sample', 'event': 'cpu_clock', 'allow_capture': True,
                   'max_samples': 16, 'sample_cost_ns': 1000, 'perturbation_budget_ns': 16000},
        'hardware_counter': {'backend': 'perf_counter', 'event': 'cpu_cycles', 'allow_capture': True},
        'denied': {'backend': 'perf_counter', 'event': 'task_clock'}}}


class HostCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)

    def config(self, **extra):
        return {'schema_version': 1, 'state_directory': str(self.directory / 'state'),
                'allowed_tools': list(SPECS), **extra}

    def host(self, config=None):
        host = RuntimeHost(config or self.config(), bundle_root=ROOT)
        self.addCleanup(self._close_host, host)
        return host

    def _close_host(self, host):
        self.assertEqual(host.close()['cleanup_errors'], [])

    def call(self, host, name, arguments=None, *, request=None):
        values = dict(arguments or {})
        if request is not None:
            values['request_id'] = request
        result = host.call(name, values)
        self.assertTrue(result['ok'], result)
        self.assertIn('evidence', result)
        self.assertEqual(result['evidence']['data_sha256'], hashlib.sha256(canonical(result['data'])).hexdigest())
        return result

    def busy(self, host, profile='busy'):
        result = self.call(host, 'process.launch', {'profile': profile}, request='start-' + profile)
        key = result['data']['session_id']
        self.addCleanup(self._terminate_busy, host, key)
        return key

    def _terminate_busy(self, host, key):
        process = host.processes.get(key)
        if process is not None and process.child.poll() is None:
            result = host.call('process.terminate', {'session_id': key, 'request_id': 'cleanup-' + key})
            if not result['ok']:
                process.terminate_owned()


class ExtendedBoundaryHostTests(HostCase):
    def test_invalid_extended_arguments_and_allowlist_denials_do_not_create_intents(self):
        host = self.host()
        cases = [('trace.capture', {'session_id': 'missing', 'profile': 'sample', 'duration_ms': 1001}),
                 ('symbolic.analyze', {'profile': 'owned', 'expected_return': True}),
                 ('structure.decompile', {'profile': 'owned', 'structurer': 'invented'}),
                 ('machine.resume', {'machine_session': 'missing', 'wait_ready': 'yes'}),
                 ('managed.set_field', {'managed_session': 'missing', 'object_id': '1',
                    'field': 'value', 'expected': True, 'value': 2})]
        for index, (tool, arguments) in enumerate(cases):
            values = {**arguments, 'request_id': 'invalid-' + str(index)} if SPECS[tool][3] else arguments
            result = host.call(tool, values)
            with self.subTest(tool=tool):
                self.assertEqual(result['error'], 'invalid_tool_arguments', result)
                self.assertFalse(result.get('effect_unknown', False))
        audit = self.call(host, 'runtime.audit')['data']
        self.assertEqual(audit['effects'], [])
        self.assertEqual(host.extended_backends, {})
        denied = self.host(self.config(state_directory=str(self.directory / 'denied'),
            allowed_tools=['runtime.audit']))
        result = denied.call('symbolic.analyze', {'profile': 'owned', 'expected_return': 42,
                                                'request_id': 'not-allowlisted'})
        self.assertFalse(result['ok'])
        self.assertFalse(result['effect_dispatched'])
        self.assertEqual(self.call(denied, 'runtime.audit')['data']['effects'], [])

    @unittest.skipUnless(sys.platform == 'linux', 'owned Linux process scopes required')
    def test_trace_independent_grant_and_known_refusal_do_not_fence_target(self):
        config = self.config(linux_tracing=tracing_profiles(), profiles={
            'busy': {'argv': ['/bin/sh', '-c', 'while :; do :; done'], 'allow_debug': True},
            'granted': {'argv': ['/bin/sh', '-c', 'while :; do :; done'],
                        'allow_debug': True, 'allow_tracing': True}})
        host = self.host(config)
        key = self.busy(host)
        for request in ('denial-one', 'denial-two'):
            result = host.call('trace.capture', {'session_id': key, 'profile': 'counter', 'request_id': request})
            self.assertEqual(result['error'], 'tracing_not_authorized')
            self.assertFalse(result['effect_unknown'])
            self.assertEqual(result['error_details']['code'], 'tracing_not_authorized')
        granted = self.busy(host, 'granted')
        refusal = host.call('trace.capture', {'session_id': granted, 'profile': 'denied', 'request_id': 'profile-denied'})
        self.assertEqual(refusal['error'], 'tracing_capture_not_authorized')
        self.assertFalse(refusal['effect_unknown'])
        audit = self.call(host, 'runtime.audit')['data']
        self.assertTrue(all(row['status'] == 'done' for row in audit['effects']))

    def test_unknown_effects_preserve_cleanup_and_same_binary_alias_fence(self):
        host = self.host(self.config(compatibility_control={'profiles': {
            'first': {'sha256': 'a' * 64}, 'alias': {'sha256': 'a' * 64}}}))
        class ManagedFault:
            def set_field(self, *args): return {'status': 'unknown', 'dispatched': True}
            def invoke(self, *args): raise AssertionError('must be fenced')
            def close(self): return {'target_exit_confirmed': True}
        class MachineFault:
            def command(self, *args): return {'status': 'unknown', 'dispatched': True}
            def pause(self, *args): raise AssertionError('must be fenced')
            def close_session(self, *args): return {'owned_emulator_reaped': True}
            def close(self): return {'cleanup_errors': []}
        class CompatibilityFault:
            calls = 0
            def run(self, *args):
                self.calls += 1
                return {'status': 'unknown', 'modifications_started': True}
        host.managed_sessions['managed-owned'] = ManagedFault()
        host.extended_backends['whole_system'] = MachineFault()
        compatibility = CompatibilityFault()
        host.extended_backends['compatibility_control'] = compatibility
        uncertain = self.call(host, 'managed.set_field', {'managed_session': 'managed-owned',
            'object_id': '1', 'field': 'value', 'expected': 7, 'value': 9}, request='managed-unknown')
        self.assertTrue(uncertain['unknown_effect'])
        blocked = host.call('managed.invoke', {'managed_session': 'managed-owned', 'object_id': '1',
            'method': 'bump', 'expected': 9, 'argument': 1, 'request_id': 'managed-retry'})
        self.assertEqual(blocked['error'], 'scope_outcome_unresolved')
        self.assertTrue(self.call(host, 'managed.close', {'managed_session': 'managed-owned'},
                                 request='managed-cleanup')['data']['target_exit_confirmed'])
        uncertain = self.call(host, 'machine.command', {'machine_session': 'machine-owned',
            'command': 'increment'}, request='machine-unknown')
        self.assertTrue(uncertain['unknown_effect'])
        blocked = host.call('machine.pause', {'machine_session': 'machine-owned', 'request_id': 'machine-retry'})
        self.assertEqual(blocked['error'], 'scope_outcome_unresolved')
        self.assertTrue(self.call(host, 'machine.close', {'machine_session': 'machine-owned'},
                                 request='machine-cleanup')['data']['owned_emulator_reaped'])
        self.assertTrue(self.call(host, 'compatibility.run', {'profile': 'first'},
                                 request='compat-unknown')['unknown_effect'])
        alias = host.call('compatibility.run', {'profile': 'alias', 'request_id': 'compat-alias'})
        self.assertEqual(alias['error'], 'scope_outcome_unresolved')
        self.assertEqual(compatibility.calls, 1)
        audit = self.call(host, 'runtime.audit')['data']
        self.assertEqual(sum(row['status'] == 'unknown' for row in audit['effects']), 3)


@unittest.skipUnless(sys.platform == 'linux', 'actual Linux perf adapter required')
class ActualTracingHostTests(HostCase):
    def trace_config(self):
        return self.config(linux_tracing=tracing_profiles(), profiles={'busy': {
            'argv': ['/bin/sh', '-c', 'while :; do :; done'], 'allow_debug': True, 'allow_tracing': True}})

    def test_real_owned_perf_sampling_and_kernel_error_metadata(self):
        host = self.host(self.trace_config())
        capabilities = self.call(host, 'trace.inspect')['data']
        self.assertFalse(capabilities['target_permissions_granted'])
        self.assertFalse(capabilities['hardware_execution_trace_observed'])
        key = self.busy(host)
        if not capabilities['software_and_pmu_probes']['cpu_cycles']['available']:
            # A real kernel refusal must retain errno and remain known. The
            # successful software capture below uses the same process scope.
            hardware = host.call('trace.capture', {'session_id': key, 'profile': 'hardware_counter',
                'duration_ms': 20, 'request_id': 'unavailable-hardware-counter'})
            self.assertFalse(hardware['ok'], hardware)
            self.assertIsInstance(hardware['error_details']['errno'], int)
            self.assertIsInstance(hardware['error_details']['operation'], str)
            self.assertFalse(hardware['effect_unknown'])
        result = host.call('trace.capture', {'session_id': key, 'profile': 'sample',
            'duration_ms': 100, 'request_id': 'sample-owned'})
        if not capabilities['software_and_pmu_probes']['cpu_clock']['available']:
            self.assertFalse(result['ok'], result)
            self.assertIsInstance(result['error_details']['operation'], str)
            self.assertIsInstance(result['error_details']['errno'], int)
            self.assertFalse(result['effect_unknown'])
            self.skipTest('real perf_event_open unavailable: ' + json.dumps(result['error_details']))
        self.assertTrue(result['ok'], result)
        data = result['data']
        self.assertEqual(data['backend'], 'perf_sample')
        self.assertGreater(data['value'], 0)
        self.assertGreater(len(data['samples']), 0)
        self.assertLessEqual(len(data['samples']), 16)
        self.assertLessEqual(data['estimated_probe_cost_ns'], 16000)
        self.assertFalse(data['kernel_execution_included'])
        self.assertTrue(data['capture_cleaned_up'])
        self.assertFalse(data['target_business_effect_confirmed'])
        audit = self.call(host, 'runtime.audit')['data']
        self.assertTrue(any(row['tool'] == 'trace.capture' and row['status'] == 'done' for row in audit['effects']))

    def test_new_software_trace_backend_through_actual_zipapp_stdio_MCP(self):
        archive = self.directory / 'runtime.pyz'
        if RUNTIME.is_file():
            archive.write_bytes(RUNTIME.read_bytes())
        else:
            with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_STORED) as package:
                for source in sorted(RUNTIME.rglob('*.py')):
                    package.write(source, str(source.relative_to(RUNTIME)))
        config = self.trace_config()
        path = self.directory / 'config.json'
        path.write_text(json.dumps(config))
        child = subprocess.Popen([sys.executable, str(archive), 'serve', '--config', str(path),
                                  '--bundle-root', str(ROOT)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)
        identifier = 0
        session = None
        def send(method, params=None, notify=False):
            nonlocal identifier
            identifier += 1
            message = {'jsonrpc': '2.0', 'method': method, 'params': params or {}}
            if not notify:
                message['id'] = identifier
            child.stdin.write(json.dumps(message).encode() + b'\n')
            child.stdin.flush()
            if notify:
                return None
            self.assertTrue(select.select([child.stdout], [], [], 15)[0], 'packaged MCP response deadline')
            response = json.loads(child.stdout.readline())
            self.assertEqual(response['id'], identifier)
            return response['result']
        def call(name, arguments=None):
            result = send('tools/call', {'name': name, 'arguments': arguments or {}})
            return result['structuredContent']
        unavailable = None
        try:
            initialized = send('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                                               'clientInfo': {'name': 'extended-package-check'}})
            self.assertEqual(initialized['serverInfo']['version'], '0.5.6.2')
            send('notifications/initialized', notify=True)
            launched = call('process.launch', {'profile': 'busy', 'request_id': 'package-launch'})
            self.assertTrue(launched['ok'], launched)
            session = launched['data']['session_id']
            captured = call('trace.capture', {'session_id': session, 'profile': 'counter',
                                             'duration_ms': 60, 'request_id': 'package-counter'})
            if captured['ok']:
                self.assertGreater(captured['data']['value'], 0)
                self.assertTrue(captured['data']['capture_cleaned_up'])
                self.assertFalse(captured['data']['target_business_effect_confirmed'])
            else:
                self.assertFalse(captured['effect_unknown'])
                self.assertIsInstance(captured['error_details']['errno'], int)
                unavailable = captured['error_details']
            ended = call('process.terminate', {'session_id': session, 'request_id': 'package-stop'})
            self.assertTrue(ended['ok'], ended)
            session = None
            audit = call('runtime.audit')
            self.assertTrue(any(row['tool'] == 'trace.capture' for row in audit['data']['effects']))
        finally:
            if session is not None and child.poll() is None:
                call('process.terminate', {'session_id': session, 'request_id': 'package-finally-stop'})
            child.stdin.close()
            try:
                child.wait(timeout=8)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait(timeout=3)
            errors = child.stderr.read().decode('utf-8', 'replace')
            child.stdout.close(); child.stderr.close()
        self.assertEqual(child.returncode, 0, errors)
        if unavailable:
            self.skipTest('packaged perf event unavailable: ' + json.dumps(unavailable))


@unittest.skipUnless(os.environ.get('RUNTIME_ANGR_PYTHON') and shutil.which('gcc'),
                     'set RUNTIME_ANGR_PYTHON for actual native symbolic and SAILR host execution')
class ActualNativeAnalysisHostTests(HostCase):
    def test_real_native_constraint_replay_and_actual_SAILR_selection_through_host(self):
        binary = self.directory / 'owned-native-analysis'
        subprocess.run([shutil.which('gcc'), '-O0', '-g', '-fno-stack-protector', '-no-pie',
            str(ROOT / 'tests/fixtures/recovery/native_symbolic.c'), '-o', str(binary)], check=True, timeout=20)
        interpreter = os.environ['RUNTIME_ANGR_PYTHON']
        config = self.config(binaries={'owned': str(binary)},
            native_symbolic={'python': interpreter, 'python_sha256': digest(Path(interpreter).resolve()),
                'profiles': {'score': {'binary': 'owned', 'binary_sha256': digest(binary), 'entry': 'owned_branch',
                    'arguments': [{'name': 'x', 'bits': 32, 'maximum': 31},
                                  {'name': 'y', 'bits': 32, 'maximum': 3}], 'return_bits': 32,
                    'replay': {'allow_execute': True, 'arguments': ['branch', '@source:x', '@source:y']}}}},
            structured_recovery={'python': interpreter, 'python_sha256': digest(Path(interpreter).resolve()),
                'profiles': {'structure': {'binary': 'owned', 'sha256': digest(binary),
                    'function': 'owned_branch', 'structurers': ['sailr'], 'timeout_seconds': 60}}})
        host = self.host(config)
        solved = self.call(host, 'symbolic.analyze', {'profile': 'score', 'expected_return': 42},
                           request='native-solve')['data']
        self.assertEqual(solved['solver_status'], 'sat', solved)
        self.assertTrue(solved['native_replay_verified'])
        self.assertEqual(solved['native_replay_return'], 42)
        self.assertFalse(solved['universal_native_program_proof'])
        recovered = self.call(host, 'structure.decompile', {'profile': 'structure', 'structurer': 'sailr'})['data']
        self.assertEqual(recovered['status'], 'decompiled', recovered)
        self.assertTrue(recovered['algorithm']['actual_class'].endswith('.SAILRStructurer'))
        self.assertIn('owned_branch', recovered['pseudocode'])
        self.assertFalse(recovered['source_equivalence_proven'])
        denied = host.call('structure.decompile', {'profile': 'structure', 'structurer': 'phoenix'})
        self.assertFalse(denied['ok'])
        self.assertFalse(denied['effect_unknown'])


@unittest.skipUnless(os.environ.get('RUNTIME_GDB') and shutil.which('gcc') and sys.platform == 'linux',
                     'set RUNTIME_GDB for actual native GDB record/reverse through host')
class ActualNativeDebugHostTests(HostCase):
    def test_real_record_reverse_and_forward_state_through_host(self):
        binary = self.directory / 'owned-record-reverse'
        subprocess.run([shutil.which('gcc'), '-g', '-nostdlib', '-no-pie',
            str(ROOT / 'tests/fixtures/recovery/record_reverse.S'), '-o', str(binary)], check=True, timeout=20)
        executable = str(Path(os.environ['RUNTIME_GDB']).resolve())
        profile = {'kind': 'gdb', 'executable': executable, 'sha256': digest(executable),
            'binary': 'owned', 'binary_sha256': digest(binary), 'entry': 'record_entry',
            'register': 'rax', 'steps': 2, 'allow_execute': True, 'timeout_seconds': 12}
        for env, key in [('RUNTIME_GDB_LIBRARIES', 'library_directory'), ('RUNTIME_GDB_DATA', 'data_directory')]:
            if os.environ.get(env): profile[key] = os.environ[env]
        host = self.host(self.config(binaries={'owned': str(binary)}, native_debug={'profiles': {'owned': profile}}))
        result = self.call(host, 'debug_native.record_reverse', {'profile': 'owned'}, request='reverse-native')['data']
        self.assertEqual(result['status'], 'verified', result)
        self.assertEqual(result['states']['before']['register_value'], 7)
        self.assertEqual(result['states']['forward']['register_value'], 36)
        self.assertEqual(result['states']['before'], result['states']['reverse'])
        self.assertEqual(result['states']['forward'], result['states']['replay'])
        self.assertTrue(result['cleanup']['target_exit_confirmed'])
        self.assertFalse(result['all_process_state_equivalence_proven'])


@unittest.skipUnless(os.environ.get('RUNTIME_QEMU_ROOT') and shutil.which('gcc') and shutil.which('ld'),
                     'set RUNTIME_QEMU_ROOT for actual whole-machine host control')
class ActualWholeMachineHostTests(HostCase):
    def test_real_boot_RAM_register_checkpoint_restore_and_close_through_host(self):
        fixture = load_fixture('machine_test', 'tests/test_whole_system.py')
        builder = load_fixture('machine_builder', 'tools/build_machine_fixture.py')
        kernel = self.directory / 'kernel.elf'
        builder.build(kernel)
        profile = fixture.profile(os.environ['RUNTIME_QEMU_ROOT'], kernel)
        host = self.host(self.config(whole_system={'profiles': {'owned': profile}}))
        opened = self.call(host, 'machine.open', {'profile': 'owned'}, request='machine-open')['data']
        key = opened['session_id']
        self.assertFalse(opened['running'])
        self.call(host, 'machine.resume', {'machine_session': key, 'wait_ready': True}, request='machine-ready')
        self.call(host, 'machine.command', {'machine_session': key, 'command': 'increment'}, request='machine-first')
        self.call(host, 'machine.pause', {'machine_session': key}, request='machine-pause-one')
        state = self.call(host, 'machine.read_ram', {'machine_session': key, 'region': 'state'}, request='machine-read-one')['data']
        self.assertEqual(int.from_bytes(bytes.fromhex(state['data_hex'])[:4], 'little'), 8)
        self.assertFalse(state['host_physical_memory'])
        checkpoint = self.call(host, 'machine.checkpoint', {'machine_session': key}, request='machine-checkpoint')['data']
        self.call(host, 'machine.resume', {'machine_session': key}, request='machine-resume-two')
        self.call(host, 'machine.command', {'machine_session': key, 'command': 'increment'}, request='machine-second')
        self.call(host, 'machine.pause', {'machine_session': key}, request='machine-pause-two')
        restored = self.call(host, 'machine.restore', {'machine_session': key,
            'checkpoint_id': checkpoint['checkpoint_id']}, request='machine-restore')['data']
        self.assertEqual(restored['machine_epoch'], 2)
        self.assertTrue(restored['prior_guest_addresses_require_revalidation'])
        state = self.call(host, 'machine.read_ram', {'machine_session': key, 'region': 'state'}, request='machine-read-restored')['data']
        self.assertEqual(int.from_bytes(bytes.fromhex(state['data_hex'])[:4], 'little'), 8)
        denied = host.call('machine.read_ram', {'machine_session': key, 'region': 'MMIO', 'request_id': 'machine-device-refused'})
        self.assertEqual(denied['error'], 'machine_unregistered_ram_region')
        self.assertFalse(denied['effect_unknown'])
        registers = self.call(host, 'machine.registers', {'machine_session': key}, request='machine-registers')['data']
        self.assertEqual(registers['architecture'], 'i386')
        self.assertTrue(self.call(host, 'machine.close', {'machine_session': key},
                                 request='machine-close')['data']['owned_emulator_reaped'])


class ActualManagedJvmHostTests(HostCase):
    @classmethod
    def setUpClass(cls):
        fixture = load_fixture('managed_test', 'tests/test_managed_jvm.py')
        if not fixture.HAS_JDI or not sys.platform.startswith('linux') or not hasattr(os, 'pidfd_open'):
            raise unittest.SkipTest('a Linux JDK with compiler/JDI/pidfd is required for real managed host control')
        fixture.ManagedJvmTests.setUpClass()
        cls.addClassCleanup(fixture.ManagedJvmTests.tearDownClass)
        cls.managed_profile = copy.deepcopy(fixture.ManagedJvmTests.config)

    def test_real_live_object_updates_method_and_checked_HotSwap_through_host(self):
        host = self.host(self.config(managed_jvms={'owned': self.managed_profile}))
        opened = self.call(host, 'managed.open', {'profile': 'owned'}, request='managed-open')['data']
        key, initial = opened['managed_session'], opened['snapshot']
        object_id = initial['object_id']
        self.assertEqual(initial['values']['value'], 7)
        self.assertFalse(initial['physical_address_known'])
        changed = self.call(host, 'managed.set_field', {'managed_session': key, 'object_id': object_id,
            'field': 'value', 'expected': 7, 'value': 9}, request='managed-write')['data']
        self.assertEqual(changed['status'], 'verified')
        self.assertFalse(changed['business_effect_confirmed'])
        invoked = self.call(host, 'managed.invoke', {'managed_session': key, 'object_id': object_id,
            'method': 'bump', 'expected': 9, 'argument': 3}, request='managed-invoke')['data']
        self.assertEqual(invoked['value'], 12)
        self.assertEqual(invoked['snapshot']['object_id'], object_id)
        refused = self.call(host, 'managed.set_field', {'managed_session': key, 'object_id': object_id,
            'field': 'value', 'expected': 7, 'value': 99}, request='managed-stale-state')['data']
        self.assertFalse(refused['ok'])
        self.assertFalse(refused['dispatched'])
        patched = self.call(host, 'managed.redefine', {'managed_session': key, 'object_id': object_id,
            'expected_epoch': 0, 'patch': 'double', 'expected': 12}, request='managed-patch')['data']
        self.assertEqual(patched['status'], 'redefined')
        self.assertEqual(patched['class_epoch'], 1)
        self.assertTrue(patched['existing_frames_may_use_old_bytecode'])
        invoked = self.call(host, 'managed.invoke', {'managed_session': key, 'object_id': object_id,
            'method': 'bump', 'expected': 12, 'argument': 3}, request='managed-after-patch')['data']
        self.assertEqual(invoked['value'], 18)
        self.assertFalse(invoked['business_effect_confirmed'])
        ended = self.call(host, 'managed.close', {'managed_session': key}, request='managed-close')['data']
        self.assertTrue(ended['target_exit_confirmed'])
        self.assertNotIn(key, host.managed_sessions)


if __name__ == '__main__':
    unittest.main()
