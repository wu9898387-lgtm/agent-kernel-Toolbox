"""Native UI journal regression tests with owned PIDs and an injected adapter.

No desktop application is accessed. The real process identities, RuntimeHost,
and SQLite journal are exercised; the adapter records bounded synthetic effects.
"""
from contextlib import contextmanager
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_accessibility import AccessibilityError
from observation_extension.native_runtime import ProcessSession
from observation_extension.runtime_host import RuntimeHost
from observation_extension.runtime_state import RuntimeState


@unittest.skipUnless(sys.platform == 'linux' and hasattr(os, 'pidfd_open'), 'Linux pidfd required')
class NativeFenceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.children = []
        self.addCleanup(self._cleanup_children)
        self.effects = []
        self.fault = None
        self.targets = {}
        for name in ('first', 'second'):
            child = subprocess.Popen([sys.executable, '-I', '-S', '-c', 'import time; time.sleep(30)'])
            self.children.append(child)
            with ProcessSession.attach(child.pid) as reader:
                identity = reader.validate_identity()
            self.targets[name] = {'pid': child.pid, 'expected_identity': identity,
                                  'allow_terminate': True, 'allow_text_input': True}
        self.targets['alias'] = dict(self.targets['first'])
        self.config = {'schema_version': 1, 'state_directory': str(self.directory / 'state'),
                       'allowed_tools': ['process.attach', 'process.status', 'process.terminate', 'process.suspend_for',
                                         'native.open', 'native.invoke', 'native.set_text', 'native.focus'],
                       'targets': self.targets}
        owner = self

        class Adapter:
            def __init__(self, pid, **permissions):
                self.pid = pid
                self.permissions = permissions

            def _effect(self, tool):
                fault, owner.fault = owner.fault, None
                if fault == 'preflight':
                    raise AccessibilityError('injected_preflight_refusal', effect_dispatched=False)
                owner.effects.append({'pid': self.pid, 'tool': tool})
                if fault == 'exception':
                    raise AccessibilityError('injected_receipt_lost', effect_dispatched=True)
                return {'status': 'unknown' if fault == 'result' else 'acknowledged'}

            def invoke(self, _snapshot, _node, _index):
                return self._effect('native.invoke')

            def set_text(self, _snapshot, _node, _text):
                return self._effect('native.set_text')

            def focus(self, _snapshot, _node):
                return self._effect('native.focus')

            def close(self):
                pass

        adapter = patch('observation_extension.native_accessibility.NativeAccessibility', Adapter)
        adapter.start()
        self.addCleanup(adapter.stop)

    def _cleanup_children(self):
        for child in self.children:
            if child.poll() is None:
                child.terminate()
            child.wait(timeout=3)

    @contextmanager
    def host(self):
        host = RuntimeHost(self.config, bundle_root=ROOT)
        try:
            yield host
        finally:
            self.assertEqual(host.close()['cleanup_errors'], [])

    def attach(self, host, target='first'):
        result = host.call('process.attach', {'target': target})
        self.assertTrue(result['ok'], result)
        session = result['data']['session_id']
        opened = host.call('native.open', {'session_id': session})
        self.assertTrue(opened['ok'], opened)
        return session

    def effect(self, host, session, request, tool='native.invoke'):
        args = {'session_id': session, 'snapshot_id': 'synthetic-snapshot',
                'node_id': 'synthetic-node', 'request_id': request}
        if tool == 'native.set_text':
            args['text'] = 'bounded fixture value'
        return host.call(tool, args)

    def assert_blocked(self, response, code='scope_outcome_unresolved'):
        self.assertFalse(response['ok'], response)
        self.assertEqual(response['error'], code, response)
        self.assertIs(response['effect_unknown'], False)

    def check_repeated_attachment_and_restart(self, tool):
        with self.host() as host:
            first = self.attach(host)
            self.fault = 'exception'
            uncertain = self.effect(host, first, 'lost', tool)
            self.assertIs(uncertain['effect_unknown'], True)
            self.assert_blocked(self.effect(host, first, 'same-session', tool))
            second = self.attach(host)
            self.assertNotEqual(first, second)
            self.assert_blocked(self.effect(host, second, 'new-session', tool))
            alias = self.attach(host, 'alias')
            self.assert_blocked(self.effect(host, alias, 'alias-session', tool))
            effects = host.state.audit()['effects']
            self.assertEqual(len(effects), 1)
            self.assertEqual(effects[0]['status'], 'unknown')
        with self.host() as host:
            restarted = self.attach(host)
            self.assert_blocked(self.effect(host, restarted, 'after-restart', tool))
            self.assertEqual(host.state.audit()['effects'], effects)
        self.assertEqual(self.effects, [{'pid': self.children[0].pid, 'tool': tool}])

    def test_invoke_unknown_survives_attachment_alias_and_restart(self):
        self.check_repeated_attachment_and_restart('native.invoke')

    def test_text_unknown_survives_attachment_alias_and_restart(self):
        self.check_repeated_attachment_and_restart('native.set_text')

    def test_focus_unknown_survives_attachment_alias_and_restart(self):
        self.check_repeated_attachment_and_restart('native.focus')

    def test_unknown_result_fences_other_native_write_tools_for_same_instance(self):
        with self.host() as host:
            first = self.attach(host)
            self.fault = 'result'
            uncertain = self.effect(host, first, 'lost-text', 'native.set_text')
            self.assertTrue(uncertain['ok'])
            self.assertTrue(uncertain['unknown_effect'])
            second = self.attach(host, 'alias')
            self.assert_blocked(self.effect(host, second, 'invoke'))
            self.assert_blocked(self.effect(host, second, 'focus', 'native.focus'))
        self.assertEqual(len(self.effects), 1)

    def test_distinct_instance_and_explicit_cleanup_remain_available(self):
        with self.host() as host:
            first = self.attach(host)
            self.fault = 'exception'
            self.effect(host, first, 'lost')
            second = self.attach(host, 'second')
            self.assertTrue(self.effect(host, second, 'other-instance')['ok'])
            self.assertTrue(host.call('process.status', {'session_id': first})['ok'])
            terminated = host.call('process.terminate', {'session_id': first, 'request_id': 'cleanup'})
            self.assertTrue(terminated['ok'], terminated)
            self.assertTrue(any(row['request_id'] == 'lost' and row['status'] == 'unknown'
                                for row in host.state.audit()['effects']))
        self.assertEqual(len(self.effects), 2)
        self.children[0].wait(timeout=3)

    def test_ui_unknown_preserves_shared_fence_with_process_control_effects(self):
        with self.host() as host:
            first = self.attach(host)
            self.fault = 'exception'
            self.effect(host, first, 'lost-ui')
            for session in (first, self.attach(host, 'alias')):
                response = host.call('process.suspend_for', {
                    'session_id': session, 'milliseconds': 1, 'request_id': 'control-' + session})
                self.assert_blocked(response)
            self.assertEqual(len(host.state.audit()['effects']), 1)
        self.assertEqual(len(self.effects), 1)

    def test_legacy_unresolved_native_effects_require_offline_reconciliation(self):
        for status in ('pending', 'unknown'):
            with self.subTest(status=status):
                self.config['state_directory'] = str(self.directory / status)
                with self.host() as host:
                    host.state.begin('legacy', 'native.invoke', 'process:old-session', {})
                    if status == 'unknown':
                        host.state.finish('legacy', known=False)
                    session = self.attach(host, 'second')
                    self.assert_blocked(self.effect(host, session, 'new-native'),
                                        'legacy_process_outcome_requires_reconciliation')
                    self.assertTrue(host.call('process.status', {'session_id': session})['ok'])
                    self.assertEqual(len(host.state.audit()['effects']), 1)
                state = RuntimeState(self.config['state_directory'])
                try:
                    state.reconcile('legacy', 'no_effect_observed')
                finally:
                    state.close()
                with self.host() as host:
                    session = self.attach(host, 'second')
                    self.assertTrue(self.effect(host, session, 'after-reconciliation')['ok'])
                    self.assert_blocked(self.effect(host, session, 'legacy'), 'request_replay')
        self.assertEqual(len(self.effects), 2)

    def test_offline_reconciliation_resolves_stable_scope_without_allowing_replay(self):
        with self.host() as host:
            session = self.attach(host)
            self.fault = 'exception'
            self.effect(host, session, 'lost')
        state = RuntimeState(self.config['state_directory'])
        try:
            state.reconcile('lost', 'effect_observed')
        finally:
            state.close()
        with self.host() as host:
            session = self.attach(host, 'alias')
            self.assertTrue(self.effect(host, session, 'confirmed-followup')['ok'])
            self.assert_blocked(self.effect(host, session, 'lost'), 'request_replay')
        self.assertEqual(len(self.effects), 2)

    def test_known_preflight_refusal_does_not_fence_a_new_session(self):
        with self.host() as host:
            first = self.attach(host)
            self.fault = 'preflight'
            denied = self.effect(host, first, 'refused')
            self.assertFalse(denied['ok'])
            self.assertFalse(denied['effect_unknown'])
            self.assertTrue(self.effect(host, self.attach(host), 'next')['ok'])
        self.assertEqual(len(self.effects), 1)

    def test_unknown_session_is_rejected_before_writing_an_effect_intent(self):
        with self.host() as host:
            self.assert_blocked(self.effect(host, 'unregistered-session', 'bad-session'),
                                'unknown_process_session')
            self.assertEqual(host.state.audit()['effects'], [])
        self.assertEqual(self.effects, [])


if __name__ == '__main__':
    unittest.main()
