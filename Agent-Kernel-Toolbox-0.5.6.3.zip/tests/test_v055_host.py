"""0.5.5 adapters must work through the same policy, journal and MCP boundary."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.runtime_host import RuntimeHost, SPECS
from observation_extension.runtime_state import canonical

MODULE = {'schema_version': 1, 'width': 8, 'inputs': ['x'],
          'instructions': [{'id': 'one', 'op': 'const', 'value': 1},
                           {'id': 'sum', 'op': 'add', 'args': ['x', 'one']}], 'result': 'sum'}


class HostV055Tests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.config = {'schema_version': 1, 'state_directory': self.temporary.name + '/state',
                       'allowed_tools': list(SPECS), 'ir_modules': {'increment': MODULE}}

    def host(self, config=None):
        host = RuntimeHost(config or self.config, bundle_root=ROOT)
        self.addCleanup(host.close)
        return host

    def test_ir_interpret_analyze_solve_record_through_policy(self):
        host = self.host()
        result = host.call('ir.evaluate', {'module': 'increment', 'inputs': [255]})
        self.assertTrue(result['ok'], result)
        self.assertEqual(result['data']['value'], 0)
        analyzed = host.call('ir.analyze', {'module': 'increment', 'taint_sources': ['x']})
        self.assertTrue(analyzed['ok'], analyzed)
        solved = host.call('ir.solve', {'module': 'increment', 'constraints': [
            {'name': 'sum', 'op': 'eq', 'value': 5}], 'input_bits': 4})
        self.assertTrue(solved['ok'], solved)
        self.assertEqual(solved['data']['inputs'], {'x': 4})
        exhausted = host.call('ir.solve', {'module': 'increment', 'constraints': [
            {'name': 'x', 'op': 'eq', 'value': 15}], 'input_bits': 4, 'max_cases': 1})
        self.assertEqual(exhausted['data']['status'], 'unknown')
        self.assertFalse(exhausted['unknown_effect'])
        recorded = host.call('ir.record', {'module': 'increment', 'inputs': [10], 'reverse_steps': 1})
        self.assertTrue(recorded['ok'], recorded)
        self.assertNotIn('sum', recorded['data']['reverse_state']['state'])
        self.assertFalse(host.call('ir.evaluate', {'module': 'increment', 'inputs': [1, 2]})['ok'])

    @unittest.skipUnless(shutil.which('gcc'), 'GCC required for real AOT execution')
    def test_real_aot_and_jit_through_host_and_pin_required(self):
        compiler = str(Path(shutil.which('gcc')).resolve())
        self.config['translation'] = {'compiler': compiler,
            'compiler_sha256': hashlib.sha256(Path(compiler).read_bytes()).hexdigest()}
        host = self.host()
        compiled = host.call('ir.compile', {'module': 'increment'})
        self.assertTrue(compiled['ok'], compiled)
        executed = host.call('ir.run', {'module': 'increment', 'inputs': [255]})
        self.assertTrue(executed['ok'], executed)
        self.assertEqual(executed['data']['value'], 0)
        self.assertTrue(executed['data']['oracle_checked'])
        invalid = {**self.config, 'state_directory': self.temporary.name + '/invalid',
                   'translation': {'compiler': compiler, 'compiler_sha256': None}}
        refused = self.host(invalid).call('ir.compile', {'module': 'increment'})
        self.assertEqual(refused['error'], 'pinned_translation_compiler_required')

    @unittest.skipUnless(shutil.which('readelf'), 'binutils required')
    def test_actual_registered_static_engine(self):
        executable = str(Path(shutil.which('readelf')).resolve())
        binary = str(Path('/bin/true').resolve())
        self.config['binaries'] = {'fixture': binary}
        self.config['analysis_tools'] = {'profiles': {'elf': {'kind': 'readelf',
            'executable': executable, 'sha256': hashlib.sha256(Path(executable).read_bytes()).hexdigest()}},
            'digests': {'fixture': hashlib.sha256(Path(binary).read_bytes()).hexdigest()}}
        host = self.host()
        inspected = host.call('analysis.tools', {})
        self.assertTrue(inspected['ok'], inspected)
        result = host.call('analysis.run', {'profile': 'elf', 'binary': 'fixture',
                                          'operation': 'inspect', 'request_id': 'inspect-fixture'})
        self.assertTrue(result['ok'], result)
        self.assertTrue(result['data']['success'], result)
        self.assertIn('ELF Header', result['data']['stdout'])

    def test_persistent_call_log_includes_denials_errors_and_restart(self):
        self.config['allowed_tools'] = ['runtime.status', 'runtime.audit']
        host = RuntimeHost(self.config)
        try:
            self.assertTrue(host.call('runtime.status', {})['ok'])
            denied = host.call('ir.inspect', {'module': 'increment'})
            self.assertFalse(denied['ok'])
            with self.assertRaisesRegex(RuntimeError, 'unknown_tool'):
                host.call('unknown.tool', {'not_saved': 'private-payload'})
        finally:
            host.close()
        reopened = self.host()
        result = reopened.call('runtime.audit', {})
        calls = list(reversed(result['data']['calls']))
        self.assertTrue(any(row['tool'] == 'ir.inspect' and row['phase'] == 'returned' for row in calls))
        self.assertTrue(any(row['tool'] == 'unknown.tool' and row['phase'] == 'raised' for row in calls))
        self.assertNotIn('private-payload', json.dumps(result))
        for previous, current in zip(calls, calls[1:]):
            self.assertEqual(current['previous_receipt_sha256'], previous['receipt_sha256'])
        for row in calls:
            record = dict(row)
            digest = record.pop('receipt_sha256')
            self.assertEqual(digest, hashlib.sha256(canonical(record)).hexdigest())

    def test_probe_budget_and_cpu_environment_tools(self):
        host = self.host()
        result = host.call('probes.plan', {'candidates': [
            {'id': 'fields', 'cost_ns': 20, 'utility': 5},
            {'id': 'trace', 'cost_ns': 100, 'utility': 1}], 'budget_ns': 40, 'window_ns': 1000})
        self.assertTrue(result['ok'], result)
        self.assertLessEqual(result['data']['estimated_cost_ns'], 40)
        self.assertTrue(host.call('cpu.environment', {})['ok'])

    def test_unconfigured_engine_is_known_preflight_refusal(self):
        host = self.host()
        for request in ('missing-one', 'missing-two'):
            result = host.call('symbolic.analyze', {'profile': 'missing', 'request_id': request})
            self.assertEqual(result['error'], 'native_symbolic_not_configured')
            self.assertFalse(result['effect_unknown'])
        effects = host.call('runtime.audit', {})['data']['effects']
        self.assertEqual([row['status'] for row in effects], ['done', 'done'])

    def test_capture_mapping_change_is_rejected_before_next_read(self):
        host = self.host()
        class Process:
            render_policy = None
            fingerprint = 'first'
            reads = 0
            def memory_mapping(self, address, size):
                return {'mapping_fingerprint': self.fingerprint, 'memory_kind': 'private_cow',
                        'other_writers_possible': False}
            def _read_memory_bytes(self, address, size):
                self.reads += 1
                return b'1234'
            def validate_identity(self): return {'test_target': True}
            def close(self): pass
        process = Process()
        host.processes['fixture'] = process
        captured = host.call('process.capture_memory', {'session_id': 'fixture', 'address': '0x1000', 'size': 4})
        self.assertTrue(captured['ok'], captured)
        process.fingerprint = 'remapped'
        changed = host.call('process.diff_memory', {'session_id': 'fixture',
            'capture_id': captured['data']['capture_id']})
        self.assertEqual(changed['error'], 'memory_capture_mapping_changed')
        self.assertEqual(process.reads, 1)

    def test_packaged_mcp_new_ir_tools_and_release_version(self):
        import importlib.util
        import io
        import subprocess
        import zipfile
        spec = importlib.util.spec_from_file_location('v055_builder', ROOT / 'build-source.py')
        builder = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(builder)
        archive = zipfile.ZipFile(io.BytesIO(builder.build()))
        executable = Path(self.temporary.name) / 'runtime-access.pyz'
        executable.write_bytes(archive.read('runtime-access.pyz'))
        config_file = Path(self.temporary.name) / 'config.json'
        config_file.write_text(json.dumps(self.config))
        requests = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
                'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'v055-check'}}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {
                'name': 'ir.evaluate', 'arguments': {'module': 'increment', 'inputs': [255]}}}]
        process = subprocess.run([sys.executable, str(executable), 'serve', '--config', str(config_file)],
            input=('\n'.join(json.dumps(row) for row in requests) + '\n').encode(),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10, check=True)
        responses = [json.loads(row) for row in process.stdout.splitlines()]
        self.assertEqual(responses[0]['result']['serverInfo']['version'], '0.5.6.2')
        self.assertEqual(responses[1]['result']['structuredContent']['data']['value'], 0)

    def test_semantic_unknown_fences_same_agent_but_allows_status(self):
        host = self.host()
        class Client:
            def status(self): return {'ok': True, 'pending': True}
            def call(self, *args, **kwargs): return {'status': 'unknown', 'dispatched': True}
            def close(self): pass
        host.config['semantic_agents'] = {'fixture': {}}
        host.semantic_agents['fixture'] = Client()
        args = {'agent': 'fixture', 'slot': 1, 'generation': 1, 'request_sequence': 1,
                'request_id': 'semantic-uncertain'}
        first = host.call('semantic.call', args)
        self.assertTrue(first['unknown_effect'], first)
        second = host.call('semantic.call', {**args, 'request_id': 'semantic-second'})
        self.assertEqual(second['error'], 'scope_outcome_unresolved')
        host.config['semantic_agents']['alias'] = {}
        host.semantic_agents['alias'] = Client()
        alias = host.call('semantic.call', {**args, 'agent': 'alias', 'request_id': 'semantic-alias'})
        self.assertEqual(alias['error'], 'scope_outcome_unresolved')
        self.assertTrue(host.call('semantic.status', {'agent': 'fixture'})['ok'])


if __name__ == '__main__':
    unittest.main()
