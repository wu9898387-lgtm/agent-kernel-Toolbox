"""Independent CLI processes share the host journal; failures never imply replay."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

CLI = ROOT / 'tools/runtime-platform.py'
MODULE = {'schema_version': 1, 'width': 64, 'inputs': ['x', 'y'],
          'instructions': [{'id': 'sum', 'op': 'add', 'args': ['x', 'y']}], 'result': 'sum'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(os.name == 'posix', 'durable local host requires POSIX')
class BuildCLITests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.state = self.directory / 'state'
        self.source = self.directory / 'input.json'
        self.source.write_text(json.dumps(MODULE))
        profile = {'module_path': str(self.source), 'module_sha256': digest(self.source),
                   'target': 'x86_64-linux-gnu', 'allow_compile': True}
        self.config = {'profiles': {'local': profile, 'alias': dict(profile)}}
        self.config_file = self.directory / 'build.json'
        self.marker = self.directory / 'compiler-starts'

    def write_config(self):
        self.config_file.write_text(json.dumps(self.config))
        self.config_file.chmod(0o600)

    def failure_compiler(self):
        compiler = self.directory / 'owned-failing-compiler'
        compiler.write_text('#!' + sys.executable + '\nfrom pathlib import Path\nimport sys\n'
                           f'with Path({str(self.marker)!r}).open("a") as log: log.write("started\\n")\n'
                           'sys.exit(3)\n')
        compiler.chmod(0o500)
        self.config.update(compiler=str(compiler), compiler_sha256=digest(compiler))
        self.write_config()

    def invoke(self, action, *, profile='local', request_id=None, expected=0):
        args = [sys.executable, str(CLI), action]
        if action != 'detect':
            args += ['--config', str(self.config_file), '--state-directory', str(self.state)]
        if action in ('plan', 'compile'):
            args += ['--profile', profile]
        if request_id is not None:
            args += ['--request-id', request_id]
        result = subprocess.run(args, capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def journal(self, command='audit', *extra):
        result = subprocess.run([sys.executable, str(RUNTIME), command,
                                 '--state-directory', str(self.state), *extra],
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def test_detect_inspect_plan_remain_read_only_and_do_not_bind_state(self):
        self.failure_compiler()
        self.assertFalse(self.invoke('detect')['data']['compiler_invoked'])
        self.assertFalse(self.invoke('inspect')['data']['compiler_invoked'])
        self.assertTrue(self.invoke('plan')['data']['source_digest_verified'])
        self.assertFalse(self.marker.exists())
        self.assertFalse(self.state.exists())

    def test_compile_requires_explicit_request_id_before_any_dispatch(self):
        self.failure_compiler()
        result = subprocess.run([sys.executable, str(CLI), 'compile', '--config', str(self.config_file),
                                 '--state-directory', str(self.state), '--profile', 'local'],
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertIn('requires --request-id', result.stderr)
        self.assertFalse(self.marker.exists())
        self.assertFalse(self.state.exists())

    def test_real_failed_compiler_is_fenced_across_restart_and_profile_alias(self):
        self.failure_compiler()
        failed = self.invoke('compile', request_id='uncertain', expected=2)
        self.assertEqual(failed['error'], 'translation_tool_failed')
        self.assertTrue(failed['effect_dispatched'])
        self.assertTrue(failed['effect_unknown'])
        self.assertEqual(self.marker.read_text(), 'started\n')
        refused = self.invoke('compile', profile='alias', request_id='next', expected=2)
        self.assertEqual(refused['error'], 'scope_outcome_unresolved')
        self.assertFalse(refused['effect_unknown'])
        replay = self.invoke('compile', request_id='uncertain', expected=2)
        self.assertEqual(replay['error'], 'request_replay')
        self.assertEqual(self.marker.read_text(), 'started\n')
        effects = self.journal()['effects']
        self.assertEqual(len(effects), 1)
        self.assertEqual((effects[0]['request_id'], effects[0]['status']), ('uncertain', 'unknown'))

    def test_offline_reconciliation_unblocks_scope_but_never_old_request_id(self):
        self.failure_compiler()
        self.invoke('compile', request_id='uncertain', expected=2)
        audit = self.journal('reconcile', '--request-id', 'uncertain', '--disposition', 'effect_observed')
        self.assertEqual(audit['effects'][0]['status'], 'done')
        retry = self.invoke('compile', profile='alias', request_id='reviewed-next', expected=2)
        self.assertTrue(retry['effect_unknown'])
        self.assertTrue(retry['effect_dispatched'])
        self.assertEqual(self.marker.read_text(), 'started\nstarted\n')
        replay = self.invoke('compile', request_id='uncertain', expected=2)
        self.assertEqual(replay['error'], 'request_replay')

    def test_pin_refusal_is_known_zero_dispatch_and_keeps_request_history(self):
        self.failure_compiler()
        self.config['compiler_sha256'] = '0' * 64
        self.write_config()
        refused = self.invoke('compile', request_id='bad-pin', expected=2)
        self.assertEqual(refused['error'], 'translation_compiler_digest_mismatch')
        self.assertFalse(refused['effect_unknown'])
        self.assertFalse(refused['effect_dispatched'])
        self.assertFalse(self.marker.exists())
        self.assertEqual(self.journal()['effects'][0]['status'], 'done')
        replay = self.invoke('compile', request_id='bad-pin', expected=2)
        self.assertEqual(replay['error'], 'request_replay')

    def test_config_change_cannot_replace_existing_unresolved_journal(self):
        self.failure_compiler()
        self.invoke('compile', request_id='uncertain', expected=2)
        self.config['timeout_seconds'] = 11
        self.write_config()
        refused = self.invoke('compile', request_id='changed-config', expected=2)
        self.assertEqual(refused['error'], 'state_config_changed_or_host_already_running')
        self.assertFalse(refused['effect_unknown'])
        self.assertEqual(self.marker.read_text(), 'started\n')
        self.assertEqual(self.journal()['effects'][0]['status'], 'unknown')

    def test_compile_uses_owned_regular_config_and_does_not_follow_symlinks(self):
        self.failure_compiler()
        target = self.directory / 'actual-build.json'
        self.config_file.rename(target)
        self.config_file.symlink_to(target)
        refused = self.invoke('compile', request_id='symlink', expected=2)
        self.assertFalse(refused['ok'])
        self.assertFalse(refused['effect_unknown'])
        self.assertFalse(self.marker.exists())
        self.assertFalse(self.state.exists())

    @unittest.skipUnless(sys.platform == 'linux' and shutil.which('gcc'), 'real Linux GCC required')
    def test_real_object_and_cache_survive_independent_cli_processes(self):
        compiler = str(Path(shutil.which('gcc')).resolve())
        self.config.update(compiler=compiler, compiler_sha256=digest(compiler))
        for profile in self.config['profiles'].values():
            profile['target'] = 'host'
        self.write_config()
        first = self.invoke('compile', request_id='build-1')
        second = self.invoke('compile', profile='alias', request_id='build-2')
        self.assertFalse(first['data']['cache_hit'])
        self.assertTrue(second['data']['cache_hit'])
        self.assertEqual(first['data']['artifact_sha256'], digest(second['data']['artifact_path']))
        self.assertEqual(Path(second['data']['artifact_path']).read_bytes()[:4], b'\x7fELF')
        self.assertFalse(second['data']['target_execution_verified'])
        self.assertEqual([effect['status'] for effect in self.journal()['effects']], ['done', 'done'])


if __name__ == '__main__':
    unittest.main()
