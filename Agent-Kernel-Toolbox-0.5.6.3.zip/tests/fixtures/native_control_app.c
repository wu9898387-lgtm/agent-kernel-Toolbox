#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

volatile uint64_t native_value = 7;
volatile char native_label[64] = "home";

int main(int argc, char **argv) {
    uint64_t last = 0;
    puts("native-ready");
    fflush(stdout);
    for (;;) {
        uint64_t value = native_value;
        if (value != last) {
            if (argc > 1) {
                FILE *output = fopen(argv[1], "w");
                if (output) {
                    fprintf(output, "%llu %s", (unsigned long long)value, (const char *)native_label);
                    fclose(output);
                }
            }
            last = value;
        }
        for (volatile int index = 0; index < 200000; ++index) {}
        usleep(1000);
    }
}
