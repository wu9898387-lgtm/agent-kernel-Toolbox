// Real cross-compiled executables for offline PE/Mach-O analysis; never run here.
const char app_endpoint[] = "https://app.example.invalid/api/settings?token=fixture";
const char app_route[] = "/settings";
__attribute__((noinline)) const char *settings_handler(void) { return app_endpoint; }
__attribute__((noinline)) const char *route_handler(void) { return app_route; }
int entry(void) { return settings_handler()[0] + route_handler()[0]; }
