/* Owned fixture whose selected region is genuinely translated by Frida Stalker. */
#include <stdio.h>
#include <unistd.h>

__attribute__((noinline, visibility("default"))) int trace_leaf(int value) {
    return value ^ 0x5a;
}

__attribute__((noinline, visibility("default"))) int trace_region(int count) {
    volatile int total = 0;
    for (int index = 0; index < count; index++) {
        total += (index & 1) ? trace_leaf(index) : index;
    }
    return total;
}

int main(void) {
    int value = trace_region(12);
    printf("stalker-result=%d\n", value);
    fflush(stdout);
    for (int index = 0; index < 100; index++) usleep(100000);
    return 0;
}
