#!/usr/bin/env python3
"""Build the owned Kotlin DEX fixture using explicit external toolchain paths.

Downloads nothing and vendors no compiler/runtime. The APK is a DEX-only analysis
archive, not an installable Android application. JVM self-checks execute the
owned class files; they do not establish execution of the generated DEX on ART.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(arguments, timeout=90):
    result = subprocess.run([str(item) for item in arguments], stdin=subprocess.DEVNULL,
                            capture_output=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', 'replace')[-8192:])
    return result.stdout.decode('utf-8', 'replace')


def archive(path, entries):
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name, raw in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            target.writestr(info, raw)


def build(kotlinc, r8, output, java=None):
    kotlinc, r8, output = Path(kotlinc).resolve(strict=True), Path(r8).resolve(strict=True), Path(output).absolute()
    java = Path(java or shutil.which('java')).resolve(strict=True)
    source = ROOT / 'CoroutineFixture.kt'
    stdlib = kotlinc.parent.parent / 'lib' / 'kotlin-stdlib.jar'
    if not stdlib.is_file():
        raise ValueError('Kotlin distribution kotlin-stdlib.jar missing')
    version = subprocess.run([str(kotlinc), '-version'], capture_output=True, timeout=30)
    if version.returncode:
        raise RuntimeError('Kotlin compiler version probe failed')
    compiler_version = (version.stdout + version.stderr).decode('utf-8', 'replace').strip()
    output.mkdir(mode=0o700, parents=True, exist_ok=True)
    if any((output / name).exists() for name in ('kotlin-fixture.dex', 'kotlin-fixture.apk', 'kotlin-fixture-build.json')):
        raise ValueError('Use a fresh output directory; existing fixture artifacts are never overwritten')
    with tempfile.TemporaryDirectory(prefix='kotlin-build-', dir=output) as temporary:
        temporary = Path(temporary)
        classes, dex = temporary / 'classes', temporary / 'dex'
        classes.mkdir(); dex.mkdir()
        run([kotlinc, source, '-jvm-target', '1.8', '-Xlambdas=class', '-d', classes])
        checked = run([java, '-cp', str(classes) + os.pathsep + str(stdlib),
                       'runtimeaccess.kotlinfixture.CoroutineFixtureKt'])
        if not checked.startswith('coroutine-fixture-ok:'):
            raise RuntimeError('JVM fixture self-check did not report success')
        class_files = {str(path.relative_to(classes)): path.read_bytes() for path in classes.rglob('*.class')}
        classes_jar = temporary / 'owned-classes.jar'
        archive(classes_jar, class_files)
        run([java, '-cp', r8, 'com.android.tools.r8.D8', '--min-api', '26',
             '--lib', stdlib, '--output', dex, classes_jar])
        dex_files = sorted(dex.glob('classes*.dex'))
        if len(dex_files) != 1 or not dex_files[0].read_bytes().startswith(b'dex\n'):
            raise RuntimeError('Expected one genuine DEX artifact')
        dex_output, apk_output = output / 'kotlin-fixture.dex', output / 'kotlin-fixture.apk'
        dex_output.write_bytes(dex_files[0].read_bytes())
        archive(apk_output, {'classes.dex': dex_output.read_bytes()})
        metadata = {'schema_version': 1, 'source_sha256': sha256(source),
                    'kotlinc_launcher_sha256': sha256(kotlinc), 'kotlin_stdlib_sha256': sha256(stdlib),
                    'r8_sha256': sha256(r8), 'compiler_version': compiler_version,
                    'compiler_jar_sha256': sha256(kotlinc.parent.parent / 'lib' / 'kotlin-compiler.jar'), 'jvm_target': '1.8',
                    'dex_min_api': 26, 'class_names': sorted(class_files), 'jvm_self_check': checked.strip(),
                    'dex_sha256': sha256(dex_output), 'apk_sha256': sha256(apk_output),
                    'apk_installable': False, 'art_execution_verified': False,
                    'runtime_dependencies_embedded': False}
        (output / 'kotlin-fixture-build.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
        return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kotlinc', type=Path, required=True)
    parser.add_argument('--r8', type=Path, required=True)
    parser.add_argument('--java', type=Path)
    parser.add_argument('--output-directory', type=Path, required=True)
    arguments = parser.parse_args()
    print(json.dumps(build(arguments.kotlinc, arguments.r8, arguments.output_directory, arguments.java), sort_keys=True))


if __name__ == '__main__':
    main()
