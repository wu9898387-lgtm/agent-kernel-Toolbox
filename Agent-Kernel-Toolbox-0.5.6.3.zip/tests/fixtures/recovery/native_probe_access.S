.text
.globl probe_access
.type probe_access,@function
probe_access:
    movq (%rdi), %rax
    movq %rax, 8(%rdi)
    addq (%rdi,%rsi,8), %rax
    movq probe_global(%rip), %rcx
    leaq 16(%rdi), %rdx
    pxor %xmm0, %xmm0
    ret
.size probe_access,.-probe_access
.section .note.GNU-stack,"",@progbits
