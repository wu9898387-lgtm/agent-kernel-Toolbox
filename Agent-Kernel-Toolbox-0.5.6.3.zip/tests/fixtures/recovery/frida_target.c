/* Owned-only integration fixture for fixed Frida function/field instrumentation. */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

struct RuntimeObject {
    uint64_t identity;
    int32_t value;
    int32_t state;
};

__attribute__((visibility("default"))) volatile struct RuntimeObject runtime_object = {
    UINT64_C(0x05550001), 7, 0
};

/* The compiler supplies field locations; the agent does not guess offsets. */
__attribute__((visibility("default"))) const uint32_t runtime_layout[] = {
    sizeof(struct RuntimeObject), offsetof(struct RuntimeObject, identity),
    offsetof(struct RuntimeObject, value), offsetof(struct RuntimeObject, state)
};

__attribute__((noinline, visibility("default"))) int semantic_tick(int delta) {
    runtime_object.value += delta;
    runtime_object.state += 1;
    return runtime_object.value;
}

int main(void) {
    for (int i = 0; i < 16; ++i) {
        semantic_tick(1);
        usleep(20000);
    }
    printf("owned-final pid=%ld value=%d state=%d\n", (long)getpid(), runtime_object.value, runtime_object.state);
    fflush(stdout);
    if (runtime_object.value != 25 || runtime_object.state != 16) return 3;
    /* Keep the owned program alive for Frida --kill-on-exit, but bound its
       lifetime independently if the instrumentation client fails. */
    for (int i = 0; i < 100; ++i) usleep(100000);
    return 0;
}
