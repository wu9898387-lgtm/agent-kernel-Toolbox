ENTRY(_start)
SECTIONS {
  . = 0x100000;
  .multiboot : { *(.multiboot) }
  .text : { *(.text) }
  .rodata : { *(.rodata) }
  . = 0x200000;
  .state : { *(.state) }
  .bss : { *(.bss) *(COMMON) }
}
