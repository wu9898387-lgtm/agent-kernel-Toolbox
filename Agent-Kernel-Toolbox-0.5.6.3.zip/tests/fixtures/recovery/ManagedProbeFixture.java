package runtimeaccess.probe;

import java.lang.ref.WeakReference;

/** Owned allocation/GC/retirement fixture; no address is exposed. */
public final class ManagedProbeFixture {
    public static final class Node {
        public int value;
        public long generation=1;
        public int 数字=3;
        public Node(int value) { this.value=value; }
    }
    private static WeakReference<Node> retired;
    private static long retiredTag;
    private static void retire() {
        Node value=new Node(9);
        retiredTag=RuntimeProbe.tag(value);
        RuntimeProbe.event(value,3,9);
        retired=new WeakReference<>(value);
    }
    public static void main(String[] args) throws Exception {
        System.out.println("PROBE_READY "+ProcessHandle.current().pid());
        Node root=new Node(41);
        long tag=RuntimeProbe.tag(root);
        RuntimeProbe.event(root,1,root.value);
        retire();
        // Reflective creation is one source JVMTI VMObjectAlloc can observe;
        // bytecode new is deliberately not claimed to be exhaustively observed.
        Object reflection=Node.class.getConstructor(int.class).newInstance(5);
        if(reflection==null)throw new AssertionError();
        for(int attempt=0;attempt<8;attempt++) {
            System.gc();
            Thread.sleep(15);
            if(retired.get()==null)break;
        }
        if(RuntimeProbe.identity(root)!=tag || retired.get()!=null || retiredTag==tag)
            throw new AssertionError("identity_or_retirement_failed");
        root.value++;
        RuntimeProbe.event(root,2,root.value);
        for(int i=0;i<300;i++)RuntimeProbe.event(root,4,i);
        RuntimeProbe.event(root,5,42);
        System.out.println("PROBE_RESULT stable=true retired=true value="+root.value);
    }
}
