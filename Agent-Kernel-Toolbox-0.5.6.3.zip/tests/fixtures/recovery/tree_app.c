#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static double cpu(void) {
    struct timespec t; clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);
    return (double)t.tv_sec+(double)t.tv_nsec/1000000000.0;
}
static double usage_ms(int who) {
    struct rusage usage;
    if(getrusage(who,&usage)) _exit(10);
    return (double)usage.ru_utime.tv_sec*1000.0+(double)usage.ru_utime.tv_usec/1000.0
          +(double)usage.ru_stime.tv_sec*1000.0+(double)usage.ru_stime.tv_usec/1000.0;
}
static void burn(double seconds) {
    volatile unsigned long counter=0;
    double until=cpu()+seconds;
    while(cpu()<until) counter++;
    (void)counter;
}
static void *thread_burn(void *unused) {
    (void)unused;burn(.5);return NULL;
}
static void record(const char *path) {
    int fd=open(path,O_WRONLY|O_CREAT|O_APPEND|O_CLOEXEC,0600);
    char line[64]; int size=snprintf(line,sizeof(line),"%ld\n",(long)getpid());
    if(fd<0 || write(fd,line,(size_t)size)!=size) _exit(9);
    close(fd);
}
static void delay(long ms) {
    struct timespec t={ms/1000,(ms%1000)*1000000L};
    while(nanosleep(&t,&t)<0 && errno==EINTR) { }
}
int main(int argc,char **argv) {
    if(argc!=3) return 2;
    record(argv[2]);
    if(!strcmp(argv[1],"limits")) {
        struct rlimit a,f; getrlimit(RLIMIT_AS,&a); getrlimit(RLIMIT_NOFILE,&f);
        void *too_big=malloc(128UL*1024*1024);
        int files[100],n=0;
        while(n<100 && (files[n]=open("/dev/null",O_RDONLY))>=0)n++;
        printf("{\"address_space_bytes\":%llu,\"open_files\":%llu,\"opened\":%d,\"allocation_denied\":%s}\n",
               (unsigned long long)a.rlim_cur,(unsigned long long)f.rlim_cur,n,too_big?"false":"true");
        for(int i=0;i<n;i++)close(files[i]);
        free(too_big); return 0;
    }
    if(!strcmp(argv[1],"orphan") || !strcmp(argv[1],"escape")) {
        pid_t child=fork(); if(child<0)return 3;
        if(child>0)return 0;
        if(setsid()<0)_exit(4);
        record(argv[2]);
        child=fork(); if(child<0)_exit(3);
        if(child==0) { if(setsid()<0)_exit(4);record(argv[2]); }
        if(!strcmp(argv[1],"escape")) for(;;)pause();
        delay(child==0?450:250); _exit(0);
    }
    if(!strcmp(argv[1],"threads")) {
        pthread_t a,b;double started=cpu();
        if(pthread_create(&a,NULL,thread_burn,NULL) || pthread_create(&b,NULL,thread_burn,NULL))return 6;
        pthread_join(a,NULL);pthread_join(b,NULL);
        printf("{\"threads\":2,\"fixture_cpu_milliseconds\":%.3f,"
               "\"fixture_self_cpu_milliseconds\":%.3f,\"fixture_children_cpu_milliseconds\":%.3f}\n",
               (cpu()-started)*1000.0,usage_ms(RUSAGE_SELF),usage_ms(RUSAGE_CHILDREN));
        return 0;
    }
    int count=!strcmp(argv[1],"short")?4:!strcmp(argv[1],"count")?5:3;
    double started=cpu();
    for(int i=0;i<count;i++) {
        pid_t child=fork(); if(child<0)return 3;
        if(child==0) {
            if(setsid()<0)_exit(4);
            record(argv[2]);
            if(!strcmp(argv[1],"short")) {burn(.08);_exit(0);}
            if(!strcmp(argv[1],"rss")) {
                volatile unsigned char *p=malloc(12UL*1024*1024);
                if(!p)_exit(5);
                for(size_t n=0;n<12UL*1024*1024;n+=4096)p[n]=1;
                for(;;)pause();
            }
            if(!strcmp(argv[1],"count"))for(;;)pause();
            for(;;)burn(.1);
        }
    }
    while(wait(NULL)>0) { }
    struct rusage usage;getrusage(RUSAGE_CHILDREN,&usage);
    double waited=(double)usage.ru_utime.tv_sec+(double)usage.ru_utime.tv_usec/1000000.0
                 +(double)usage.ru_stime.tv_sec+(double)usage.ru_stime.tv_usec/1000000.0;
    printf("{\"children\":%d,\"fixture_cpu_milliseconds\":%.3f,"
           "\"fixture_self_cpu_milliseconds\":%.3f,\"fixture_children_cpu_milliseconds\":%.3f}\n",
           count,(waited+cpu()-started)*1000.0,usage_ms(RUSAGE_SELF),usage_ms(RUSAGE_CHILDREN));
    return 0;
}
