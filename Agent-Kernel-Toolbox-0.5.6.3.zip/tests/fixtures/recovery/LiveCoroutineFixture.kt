package runtimeaccess.livecoroutine

import java.lang.management.ManagementFactory
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED
import kotlin.coroutines.intrinsics.suspendCoroutineUninterceptedOrReturn
import kotlin.coroutines.resume
import kotlin.coroutines.startCoroutine

class Factor(@JvmField val bias: Int)

/** This is an owned continuation root, deliberately exported for the JDI SDK. */
@JvmField var ROOT: Continuation<Int>? = null

/** The JDI profile stops only at this explicit application safe point. */
fun ready() {}

suspend fun calculate(seed: Int): Int {
    val factor = Factor(4)
    var local = seed + 1
    val first = suspendCoroutineUninterceptedOrReturn<Int> { continuation ->
        ROOT = continuation
        COROUTINE_SUSPENDED
    }
    local += first
    val second = suspendCoroutineUninterceptedOrReturn<Int> { continuation ->
        ROOT = continuation
        COROUTINE_SUSPENDED
    }
    return factor.bias + local + second
}

private fun collect(label: String) {
    fun count(): Long = ManagementFactory.getGarbageCollectorMXBeans().sumOf {
        it.collectionCount.coerceAtLeast(0L)
    }
    val before = count()
    System.gc()
    val after = count()
    println("live-coroutine-gc:$label:$before:$after")
}

fun main() {
    var outcome: Int? = null
    var failure: Throwable? = null
    val completion = object : Continuation<Int> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<Int>) {
            result.fold({ outcome = it }, { failure = it })
        }
    }
    val program: suspend () -> Int = { calculate(2) }
    program.startCoroutine(completion)
    check(ROOT != null && outcome == null)
    ready()
    collect("first")
    checkNotNull(ROOT).resume(10)
    check(outcome == null && failure == null)
    ready()
    collect("second")
    checkNotNull(ROOT).resume(20)
    check(failure == null)
    println("live-coroutine-result=${checkNotNull(outcome)}")
    // Preserve the completed continuation for final identity and state evidence.
    ready()
    Thread.sleep(10000)
}
