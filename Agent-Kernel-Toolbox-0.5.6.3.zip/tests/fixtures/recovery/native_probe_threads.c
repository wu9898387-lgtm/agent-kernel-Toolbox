#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <unistd.h>
volatile uint64_t probe_global=31;
extern uint64_t probe_access(uint64_t *,uint64_t);
static pthread_barrier_t gate;
typedef struct {unsigned id;unsigned long tid;uintptr_t address;uint64_t returned;} Work;
__attribute__((noinline)) void *probe_thread_work(void *argument)
{
    Work *work=argument;
    uint64_t *data=malloc(64);
    data[0]=100+work->id;
    data[1]=200+work->id;
    pthread_barrier_wait(&gate);
    work->returned=probe_access(data,1);
    work->address=(uintptr_t)data;
    work->tid=(unsigned long)syscall(SYS_gettid);
    free(data);
    return NULL;
}
int main(int argc,char **argv)
{
    if(argc!=2)return 2;
    Work work[2]={{.id=1},{.id=2}};pthread_t threads[2];
    pthread_barrier_init(&gate,NULL,2);
    for(unsigned i=0;i<2;i++)pthread_create(&threads[i],NULL,probe_thread_work,&work[i]);
    for(unsigned i=0;i<2;i++)pthread_join(threads[i],NULL);
    FILE *file=fopen(argv[1],"w");
    if(file){fprintf(file,"[{\"tid\":%lu,\"address\":\"0x%lx\",\"returned\":%lu},{\"tid\":%lu,\"address\":\"0x%lx\",\"returned\":%lu}]",
        work[0].tid,(unsigned long)work[0].address,(unsigned long)work[0].returned,
        work[1].tid,(unsigned long)work[1].address,(unsigned long)work[1].returned);fclose(file);}
    usleep(300000);return 0;
}
