/* Owned offline analysis fixture; no syscalls or foreign memory are required. */
struct RuntimePayload {
    unsigned int tag;
    int count;
};

__attribute__((noinline)) int runtime_pure(int value, int factor) {
    int result = 0;
    for (int i = 0; i < factor; ++i) {
        if ((i & 1) == 0) result += value;
        else result -= 1;
    }
    if (value < 0) result -= factor;
    return result;
}

__attribute__((noinline)) int runtime_recover(struct RuntimePayload *payload, int limit) {
    int result = runtime_pure(payload->count, limit);
    if (payload->tag == 0x0555) payload->count = result;
    return result;
}
