/* Owned fixture: registered compatibility probes, never process-wide clocks. */
#define _DEFAULT_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

#define PROBE_INT_VOID UINT32_C(0x49563031)

__attribute__((noinline, visibility("default"))) int environment_probe(void) {
    return 13; /* The application's stock environment model rejects this setup. */
}

__attribute__((noinline, visibility("default"))) int timing_probe(void) {
    return 17; /* Unsupported scheduler/timing-model identifier, not a clock hook. */
}

struct ProbeRegistration {
    const char *name;
    int (*callback)(void);
    uint32_t signature;
};

__attribute__((visibility("default"))) const struct ProbeRegistration compatibility_probe_registry[] = {
    {"environment_probe", environment_probe, PROBE_INT_VOID},
    {"timing_probe", timing_probe, PROBE_INT_VOID}
};
__attribute__((visibility("default"))) const uint32_t compatibility_probe_count = 2;
__attribute__((visibility("default"))) const uint32_t compatibility_probe_layout[] = {
    sizeof(struct ProbeRegistration), offsetof(struct ProbeRegistration, name),
    offsetof(struct ProbeRegistration, callback), offsetof(struct ProbeRegistration, signature),
    PROBE_INT_VOID
};

int main(void) {
    int environment = environment_probe();
    int timing = timing_probe();
    if (environment != 0) return 77;
    if (timing != 1) return 78;
    int value = 0;
    for (int index=0; index<42; ++index) {
        value++;
        usleep(1000);
    }
    printf("compatibility-stable value=%d environment=%d timing=%d pid=%ld\n",
           value, environment, timing, (long)getpid());
    fflush(stdout);
    /* The instrumentation CLI owns shutdown; retain an independent bound. */
    for (int index=0; index<100; ++index) usleep(100000);
    return value == 42 ? 0 : 79;
}
