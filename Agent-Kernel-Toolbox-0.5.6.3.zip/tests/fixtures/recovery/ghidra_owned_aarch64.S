/* Same bounded integer function as ghidra_owned.c, assembled for a foreign ISA.
 * This fixture is executed only in Ghidra's p-code VM on an x86-64 host. */
    .text
    .global runtime_pure
    .type runtime_pure, %function
runtime_pure:
    mov w2, #0
    mov w3, #0
    cmp w1, #0
    b.le .Lfinish
.Lloop:
    tst w3, #1
    b.ne .Lodd
    add w2, w2, w0
    b .Lnext
.Lodd:
    sub w2, w2, #1
.Lnext:
    add w3, w3, #1
    cmp w3, w1
    b.lt .Lloop
.Lfinish:
    cmp w0, #0
    b.ge .Ldone
    sub w2, w2, w1
.Ldone:
    mov w0, w2
    ret
    .size runtime_pure, .-runtime_pure
