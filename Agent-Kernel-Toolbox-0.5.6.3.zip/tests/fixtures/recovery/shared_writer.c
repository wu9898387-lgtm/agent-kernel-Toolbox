#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <unistd.h>

static volatile sig_atomic_t done;
static volatile sig_atomic_t remap;
static void stop(int signum){(void)signum;done=1;}
static void change(int signum){(void)signum;remap=1;}
static uint64_t pair(uint32_t value){return ((uint64_t)(~value)<<32)|value;}
static void *heartbeat(void *memory){
    while(!done){__atomic_add_fetch((uint64_t*)memory,1,__ATOMIC_RELAXED);usleep(1000);}
    return NULL;
}

int main(int argc,char **argv){
    if(argc!=3)return 2;
    int fd=open(argv[1],O_RDWR|O_CREAT|O_EXCL,0600);
    if(fd<0||ftruncate(fd,4096))return 3;
    uint64_t *memory=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    if(memory==MAP_FAILED)return 4;
    memory[0]=pair(7);memory[1]=pair(11);memory[2]=0;memory[3]=0;
    signal(SIGTERM,stop);signal(SIGINT,stop);signal(SIGUSR2,change);
    if(prctl(PR_SET_PTRACER,PR_SET_PTRACER_ANY)&&errno!=EINVAL&&errno!=ENOSYS)return 5;
    pid_t child=fork();
    if(child<0)return 6;
    int slot=child==0?1:0;
    if(child==0){
        if(prctl(PR_SET_PDEATHSIG,SIGTERM)||getppid()==1)return 7;
        if(prctl(PR_SET_PTRACER,PR_SET_PTRACER_ANY)&&errno!=EINVAL&&errno!=ENOSYS)return 8;
    }else{
        printf("{\"writers\":[%ld,%ld],\"address\":\"0x%lx\"}\n",(long)getpid(),(long)child,(unsigned long)memory);
        fflush(stdout);
    }
    uint32_t value=(uint32_t)memory[slot];
    pthread_t thread;int threaded=strcmp(argv[2],"threads")==0;
    if(threaded&&pthread_create(&thread,NULL,heartbeat,memory+2+slot))return 9;
    int readonly=0;
    while(!done){
        if(remap&&!readonly&&!threaded){if(mprotect(memory,4096,PROT_READ))return 10;readonly=1;}
        if(!readonly){
            if(strcmp(argv[2],"active")==0||threaded)__atomic_store_n(memory+slot,pair(++value),__ATOMIC_RELEASE);
            if(!threaded)__atomic_add_fetch(memory+2+slot,1,__ATOMIC_RELAXED);
        }
        usleep(1000);
    }
    if(threaded)pthread_join(thread,NULL);
    if(child>0){kill(child,SIGTERM);while(waitpid(child,NULL,0)<0&&errno==EINTR){}}
    munmap(memory,4096);close(fd);return 0;
}
