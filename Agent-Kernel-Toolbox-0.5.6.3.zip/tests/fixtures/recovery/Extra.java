package runtimeaccess.fixture;

public class Extra {
    public int divide(int value, int divisor) { return value / divisor; }
}
