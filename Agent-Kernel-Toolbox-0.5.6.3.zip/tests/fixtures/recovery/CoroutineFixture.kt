package runtimeaccess.kotlinfixture

import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.startCoroutine
import kotlin.coroutines.suspendCoroutine

/** Owned recovery fixture; tick() drives real suspension without wall-clock races. */
class CoroutineFixture(private val base: Int) {
    var latest: Int = 0
        private set
    var touches: Int = 0
        private set
    private var pending: Continuation<Int>? = null
    private var pendingValue: Int = 0

    class Nested(private val factor: Int) {
        fun multiply(value: Int): Int = factor * value
    }
    inner class Inner {
        fun readBase(): Int = base
    }
    fun closure(offset: Int): (Int) -> Int = { value -> base + offset + value }
    fun anonymousAction(): Runnable = object : Runnable {
        override fun run() { latest = base }
    }

    private suspend fun awaitIncrement(value: Int): Int = suspendCoroutine { continuation ->
        check(pending == null)
        pendingValue = value
        pending = continuation
    }

    fun tick(fail: Boolean = false) {
        val continuation = checkNotNull(pending)
        pending = null
        if (fail) continuation.resumeWithException(IllegalArgumentException("fixture failure"))
        else continuation.resume(pendingValue + 1)
    }

    suspend fun load(seed: Int): Int {
        val local = base + seed
        val multiplier = Nested(base)
        return try {
            val first = awaitIncrement(local)
            val second = awaitIncrement(first)
            latest = second
            multiplier.multiply(second) + local
        } catch (failure: IllegalArgumentException) {
            -1
        } finally {
            touches++
        }
    }
}

fun main() {
    val fixture = CoroutineFixture(3)
    check(fixture.closure(7)(2) == 12)
    check(fixture.Inner().readBase() == 3)
    check(CoroutineFixture.Nested(2).multiply(3) == 6)
    fixture.anonymousAction().run()
    check(fixture.latest == 3)

    var completed: Result<Int>? = null
    val program: suspend () -> Int = { fixture.load(4) }
    val observer = object : Continuation<Int> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<Int>) { completed = result }
    }
    program.startCoroutine(observer)
    check(completed == null)
    fixture.tick()
    check(completed == null)
    fixture.tick()
    check(completed!!.getOrThrow() == 34)
    check(fixture.latest == 9 && fixture.touches == 1)

    completed = null
    program.startCoroutine(observer)
    check(completed == null)
    fixture.tick(fail = true)
    check(completed!!.getOrThrow() == -1)
    check(fixture.touches == 2)
    println("coroutine-fixture-ok: two suspensions, closure, exception and finally")
}
