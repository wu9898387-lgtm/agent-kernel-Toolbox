#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

volatile uint64_t probe_global = 11;
typedef struct ProbeObject { uint64_t value; uint64_t mirrored; uint8_t reserved[48]; } ProbeObject;
extern uint64_t probe_access(uint64_t *p, uint64_t index);
__attribute__((noinline,used)) void ra_probe_object(uint64_t id,void *p,size_t n,uint64_t g,uint32_t t)
{ __asm__ volatile(""::"r"(id),"r"(p),"r"(n),"r"(g),"r"(t):"memory"); }
__attribute__((noinline,used)) void ra_probe_retire(uint64_t id,uint64_t g)
{ __asm__ volatile(""::"r"(id),"r"(g):"memory"); }
__attribute__((noinline,used)) void ra_probe_move(uint64_t id,void *p,size_t n,uint64_t g)
{ __asm__ volatile(""::"r"(id),"r"(p),"r"(n),"r"(g):"memory"); }

__attribute__((noinline)) void probe_work(const char *oracle, int loops)
{
    ProbeObject *object=malloc(sizeof(ProbeObject));
    uint64_t *p=(uint64_t*)object;
    struct timespec observed_time;
    clock_gettime(CLOCK_MONOTONIC,&observed_time);
    p[0]=17;p[1]=23;
    ra_probe_object(71,p,64,1,3);
    uint64_t returned=probe_access(p,1);
    uintptr_t first=(uintptr_t)p;
    ra_probe_retire(71,1);
    free(p);
    uint64_t *reused=malloc(64);
    uintptr_t second=(uintptr_t)reused;
    ra_probe_object(72,reused,64,2,3);
    uint64_t *grown=realloc(reused,512);
    if(grown){ra_probe_move(72,grown,512,2);reused=grown;}
    void *zero=calloc(4,16);
    volatile size_t impossible=(size_t)-1;
    void *failed=realloc(reused,impossible);
    if(failed)reused=failed;
    void *zero_result=realloc(reused,0);
    if(zero_result)free(zero_result);
    free(zero);
    void (*volatile release)(void*)=free;release(NULL);
    void *map=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(map!=MAP_FAILED)munmap(map,4096);
    FILE *f=fopen(oracle,"w");
    if(f){fprintf(f,"{\"first\":\"0x%lx\",\"reused\":\"0x%lx\",\"global\":\"0x%lx\",\"returned\":%lu}",
        (unsigned long)first,(unsigned long)second,(unsigned long)&probe_global,(unsigned long)returned);fclose(f);}
    uint64_t local[2]={1,2};
    for(int i=0;i<loops;i++)probe_access(local,1);
}
int main(int argc,char **argv)
{
    if(argc<2)return 2;
    probe_work(argv[1],argc>2?atoi(argv[2]):1);
    if(argc>3)sleep(20);
    usleep(300000);
    return 0;
}
