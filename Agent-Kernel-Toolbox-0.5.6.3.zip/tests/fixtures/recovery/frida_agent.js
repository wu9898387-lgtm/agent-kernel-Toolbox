/* Installer-pinned fixture, only used with the matching owned C application.
 * Frida 17 API. No scanning, external process attach or arbitrary evaluation.
 */
'use strict';
const module = Process.mainModule;
const object = module.getExportByName('runtime_object');
const layout = module.getExportByName('runtime_layout');
const size = layout.readU32();
const identityOffset = layout.add(4).readU32();
const valueOffset = layout.add(8).readU32();
const stateOffset = layout.add(12).readU32();
if (size !== 16 || identityOffset + 8 > size || valueOffset + 4 > size || stateOffset + 4 > size) {
  throw new Error('compiler layout mismatch');
}
function snapshot() {
  return {
    object_identity: object.add(identityOffset).readU64().toString(),
    address: object.toString(),
    value: object.add(valueOffset).readS32(),
    state: object.add(stateOffset).readS32(),
    compiler_field_offset: valueOffset
  };
}
function record(event, details) {
  console.log(JSON.stringify(Object.assign({ event: event }, snapshot(), details)));
}
let patched = false;
Interceptor.attach(module.getExportByName('semantic_tick'), {
  onEnter(args) {
    this.delta = args[0].toInt32();
    if (!patched) {
      const before = object.add(valueOffset).readS32();
      if (before !== 7 || snapshot().object_identity !== '89456641') {
        throw new Error('expected object state mismatch');
      }
      object.add(valueOffset).writeS32(9);
      if (object.add(valueOffset).readS32() !== 9) throw new Error('write readback mismatch');
      patched = true;
      record('guarded-write', { expected: before, replacement: 9 });
    }
    record('function-enter', { argument: this.delta });
  },
  onLeave(returnValue) {
    record('function-leave', { returned: returnValue.toInt32() });
  }
});
Interceptor.flush();
rpc.exports = { snapshot: snapshot };
record('agent-ready', { layout_source: 'compiler offsetof/sizeof export' });
