package runtimeaccess.managed;

public class ManagedFixture {
    public static class Node {
        public int value = 7;
        public long state = 0;
        public boolean enabled = true;
        public final String label = "owned-jvm-object";
        public int bump(int delta) {
            value += delta;
            state++;
            System.gc();
            return value;
        }
    }
    public static volatile Node ROOT = new Node();
    public static void ready() { }
    public static void main(String[] arguments) throws Exception {
        for (int count = 0; count < 1000; count++) {
            ready();
            System.out.println("managed-state=" + ROOT.value);
            Thread.sleep(10);
        }
    }
}
