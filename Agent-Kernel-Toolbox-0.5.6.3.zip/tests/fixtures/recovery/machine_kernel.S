/* Owned multiboot1 guest: RAM counter plus explicit UART semantic command. */
.section .multiboot,"a"
.align 4
.long 0x1badb002
.long 0x00000003
.long -(0x1badb002 + 0x00000003)

.section .text
.global _start
_start:
    cli
    mov $stack_top, %esp
    mov $0x3fb, %dx
    mov $0x80, %al
    out %al, %dx
    mov $0x3f8, %dx
    mov $1, %al
    out %al, %dx
    mov $0x3f9, %dx
    xor %al, %al
    out %al, %dx
    mov $0x3fb, %dx
    mov $3, %al
    out %al, %dx
    mov $ready, %esi
    call puts
poll:
    mov $0x3fd, %dx
    in %dx, %al
    test $1, %al
    jz poll
    mov $0x3f8, %dx
    in %dx, %al
    cmp $'i', %al
    jne poll
    incl counter
    mov $ack, %esi
    call puts
    jmp poll
puts:
    lodsb
    test %al, %al
    jz finished
    push %eax
wait_tx:
    mov $0x3fd, %dx
    in %dx, %al
    test $0x20, %al
    jz wait_tx
    pop %eax
    mov $0x3f8, %dx
    out %al, %dx
    jmp puts
finished:
    ret

.section .rodata
ready: .asciz "owned-machine-ready\n"
ack: .asciz "incremented\n"

.section .state,"aw"
.global counter
counter: .long 7
magic: .long 0x05550001

.section .bss
.align 16
stack: .skip 16384
stack_top:

.section .note.GNU-stack,"",@progbits
