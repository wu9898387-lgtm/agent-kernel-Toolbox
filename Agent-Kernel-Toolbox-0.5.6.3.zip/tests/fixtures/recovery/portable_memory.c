int portable_array(int *values,int count) {
    int sum=0;
    for(int index=0;index<count;index++) {
        values[index]+=index+7;
        sum+=values[index];
    }
    return sum;
}
int portable_float(float *values,int count) {
    for(int index=0;index<count;index++)values[index]=values[index]*2.0f+1.0f;
    return count;
}
int portable_oob(int *values,int count) {values[count]=99;return 0;}
volatile int portable_global=1;
int portable_imagewrite(int *values,int count) {
    (void)values;(void)count;portable_global=9;return 0;
}
int portable_syscall(int *values,int count) {
    (void)values;(void)count;
    __asm__ volatile("syscall");return 0;
}
