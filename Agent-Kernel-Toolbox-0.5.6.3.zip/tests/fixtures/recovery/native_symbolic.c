/* Owned native code used to check angr/VEX results against real execution. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

volatile uint32_t owned_cell = 7;

__attribute__((noinline)) uint32_t owned_branch(uint32_t x, uint32_t y) {
    if (x == 13 && y < 4) return x * 3 + y;
    return (x ^ y) + 5;
}

__attribute__((noinline)) uint32_t owned_memory(uint32_t x) {
    return owned_cell + x;
}

__attribute__((noinline)) uint32_t owned_control(uint32_t x) {
    if (x == 13) return 111;
    return 222;
}

__attribute__((noinline)) uint32_t owned_loop(uint32_t x) {
    volatile uint32_t cursor = x;
    while (cursor) cursor++;
    return cursor;
}

__attribute__((noinline)) uint32_t owned_external(uint32_t x) {
    (void)write(STDOUT_FILENO, "unsupported", 11);
    return x;
}

__attribute__((noinline)) uint32_t owned_unmodeled(uint32_t x) {
    volatile uint32_t *address = (volatile uint32_t *)(uintptr_t)UINT32_C(0xfedc0000);
    return *address + x;
}

int main(int argc, char **argv) {
    if (argc != 4) return 2;
    uint32_t x = (uint32_t)strtoul(argv[2], NULL, 10);
    uint32_t y = (uint32_t)strtoul(argv[3], NULL, 10);
    uint32_t value;
    if (argv[1][0] == 'b') value = owned_branch(x, y);
    else if (argv[1][0] == 'm') { owned_cell = y; value = owned_memory(x); }
    else if (argv[1][0] == 'c') value = owned_control(x);
    else return 3;
    printf("%u\n", value);
    return 0;
}
