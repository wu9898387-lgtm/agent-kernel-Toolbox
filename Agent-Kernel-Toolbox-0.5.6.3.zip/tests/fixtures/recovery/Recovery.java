package runtimeaccess.fixture;

public class Recovery {
    private int value = 3;
    public class Inner {
        public int read() { return value; }
    }
    public static class Nested {
        public int plus(int input) { return input + 1; }
    }
    public Runnable anonymous() {
        return new Runnable() {
            public void run() { value++; }
        };
    }
    public Runnable closure(int amount) {
        return () -> value += amount;
    }
    public int guarded(int divisor) {
        try {
            return new Extra().divide(value, divisor);
        } catch (ArithmeticException ex) {
            return -1;
        } finally {
            value++;
        }
    }
}
