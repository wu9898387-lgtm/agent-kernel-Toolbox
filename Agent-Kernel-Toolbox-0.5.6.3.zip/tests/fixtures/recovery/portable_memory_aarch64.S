.text
.global portable_array
.type portable_array,%function
portable_array:
    mov x2,#0
    mov w3,#0
    cmp w1,#0
    b.le 2f
1:  ldr w4,[x0,x2,lsl #2]
    add w4,w4,w2
    add w4,w4,#7
    str w4,[x0,x2,lsl #2]
    add w3,w3,w4
    add x2,x2,#1
    cmp w2,w1
    b.lt 1b
2:  mov w0,w3
    ret
.size portable_array,.-portable_array
.global portable_float
.type portable_float,%function
portable_float:
    mov x2,#0
    fmov s1,#2.0
    fmov s2,#1.0
    cmp w1,#0
    b.le 4f
3:  ldr s0,[x0,x2,lsl #2]
    fmul s0,s0,s1
    fadd s0,s0,s2
    str s0,[x0,x2,lsl #2]
    add x2,x2,#1
    cmp w2,w1
    b.lt 3b
4:  mov w0,w1
    ret
.size portable_float,.-portable_float
