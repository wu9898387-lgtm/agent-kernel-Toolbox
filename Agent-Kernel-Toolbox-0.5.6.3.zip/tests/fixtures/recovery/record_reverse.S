/* Owned syscall-free recording interval; Linux x86-64 entry and termination. */
.section .text
.global _start
.global record_entry
_start:
    mov $7, %rax
record_entry:
    add $5, %rax
    imul $3, %rax
    xor $6, %rax
    mov $60, %rax
    xor %rdi, %rdi
    syscall
.section .note.GNU-stack,"",@progbits
