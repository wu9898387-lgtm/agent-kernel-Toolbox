/* Owned, benign traversal fixture. It reads a prefix without printing content. */
#define _DEFAULT_SOURCE
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static int one(const char *path) {
    char bytes[32];
    int descriptor = open(path, O_RDONLY | O_CLOEXEC);
    if (descriptor < 0) return 2;
    (void)read(descriptor, bytes, sizeof(bytes));
    (void)pread(descriptor, bytes, 1, 0);
    close(descriptor);
    return 0;
}

static int scan(const char *path) {
    DIR *directory = opendir(path);
    if (!directory) return 3;
    struct dirent *entry;
    while ((entry = readdir(directory)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char name[4096];
        if (snprintf(name, sizeof(name), "%s/%s", path, entry->d_name) <= 0) return 4;
        struct stat info;
        if (stat(name, &info) == 0 && S_ISREG(info.st_mode)) (void)one(name);
    }
    closedir(directory);
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 3) return 1;
    if (strcmp(argv[1], "single") == 0) return one(argv[2]);
    if (strcmp(argv[1], "child") == 0) {
        pid_t child = fork();
        if (child == 0) _exit(scan(argv[2]));
        int status = 0;
        if (child < 0 || waitpid(child, &status, 0) < 0) return 5;
        return WIFEXITED(status) ? WEXITSTATUS(status) : 6;
    }
    if (strcmp(argv[1], "slow") == 0) { usleep(3000000); return scan(argv[2]); }
    if (strcmp(argv[1], "repeat") == 0) { for (int i = 0; i < 10000; ++i) (void)scan(argv[2]); return 0; }
    return scan(argv[2]);
}
