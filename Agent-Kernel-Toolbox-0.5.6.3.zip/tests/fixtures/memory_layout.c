#include <stdint.h>
#include <string.h>
#include <unistd.h>

int main(void) {
    unsigned char output[64] = {'A','K','T','1'};
    uint32_t number = UINT32_C(0x12345678);
    int64_t negative = -INT64_C(9223372036854775807);
    uintptr_t pointer = (uintptr_t)output;
    uint16_t text[] = {0x72b6, 0x6001, 0};
    uint16_t endian = 1;
    output[4] = sizeof(void *) * 8;
    output[5] = *(unsigned char *)&endian == 1 ? 1 : 2;
    memcpy(output + 8, &number, sizeof(number));
    memcpy(output + 12, &negative, sizeof(negative));
    memcpy(output + 20, &pointer, sizeof(pointer));
    memcpy(output + 28, text, sizeof(text));
    return write(1, output, sizeof(output)) == sizeof(output) ? 0 : 1;
}
