#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <unistd.h>

int main(void) {
    int server=socket(AF_INET,SOCK_STREAM,0), client=socket(AF_INET,SOCK_STREAM,0);
    int udp=socket(AF_INET,SOCK_DGRAM,0), pair[2];
    struct sockaddr_in addr={.sin_family=AF_INET,.sin_addr.s_addr=htonl(INADDR_LOOPBACK)};
    socklen_t size=sizeof(addr);
    if(server<0 || client<0 || udp<0 || socketpair(AF_UNIX,SOCK_STREAM,0,pair))return 1;
    if(bind(server,(void*)&addr,size) || listen(server,1) || getsockname(server,(void*)&addr,&size))return 2;
    if(connect(client,(void*)&addr,size) || accept(server,0,0)<0)return 3;
    unsigned tcp_port=ntohs(addr.sin_port);addr.sin_port=0;
    if(bind(udp,(void*)&addr,size) || getsockname(udp,(void*)&addr,&size))return 4;
    printf("{\"tcp_port\":%u,\"udp_port\":%u}\n",tcp_port,ntohs(addr.sin_port));fflush(stdout);
    for(;;)pause();
}
