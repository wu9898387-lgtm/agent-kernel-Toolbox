/* Owned neutral environment-usage fixture. No environment-detection verdict. */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/random.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <time.h>
#include <unistd.h>

static void *worker(void *ignored) {
    (void)ignored;
    struct timespec now;
    (void)syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &now);
    return NULL;
}

int main(int argc, char **argv) {
    if (argc != 3) return 1;
    if (strcmp(argv[1], "slow") == 0) usleep(3000000);
    if (strcmp(argv[1], "repeat") == 0) {
        struct timespec probe;
        for (int index = 0; index < 10000; ++index)
            (void)syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &probe);
    }
    char buffer[128];
    int file = open(argv[2], O_RDONLY | O_CLOEXEC);
    if (file < 0) return 2;
    (void)read(file, buffer, sizeof(buffer));
    close(file);
    struct utsname name;
    struct sysinfo information;
    struct timespec now;
    cpu_set_t affinity;
    (void)uname(&name);
    (void)sysinfo(&information);
    (void)syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &now);
    (void)getrandom(buffer, 16, 0);
    (void)sched_getaffinity(0, sizeof(affinity), &affinity);
    (void)prctl(PR_GET_NAME, buffer, 0, 0, 0);
    (void)ioctl(0, FIONREAD, buffer);
    void *memory = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (memory == MAP_FAILED) return 3;
    (void)mprotect(memory, 4096, PROT_READ);
    (void)munmap(memory, 4096);
    int listener = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (listener < 0 || bind(listener, (struct sockaddr *)&address, sizeof(address)) < 0) return 4;
    socklen_t length = sizeof(address);
    if (getsockname(listener, (struct sockaddr *)&address, &length) < 0 || listen(listener, 1) < 0) return 5;
    int sender = socket(AF_INET, SOCK_STREAM, 0);
    if (sender < 0 || connect(sender, (struct sockaddr *)&address, sizeof(address)) < 0) return 6;
    int receiver = accept(listener, NULL, NULL);
    const char *secret = "NETWORK_PAYLOAD_MUST_NOT_APPEAR_12b7";
    (void)send(sender, secret, strlen(secret), 0);
    (void)recv(receiver, buffer, sizeof(buffer), 0);
    close(receiver);close(sender);close(listener);
    pthread_t thread;
    if (pthread_create(&thread, NULL, worker, NULL) == 0) pthread_join(thread, NULL);
    return 0;
}
