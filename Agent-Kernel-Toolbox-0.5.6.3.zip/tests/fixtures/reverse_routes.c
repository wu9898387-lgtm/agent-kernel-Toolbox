#include <stdio.h>

__attribute__((noinline)) static void settings_handler(void) {
    puts("https://app.example.invalid/interface/settings");
    puts("/settings");
}

int main(void) {
    settings_handler();
    return 0;
}
