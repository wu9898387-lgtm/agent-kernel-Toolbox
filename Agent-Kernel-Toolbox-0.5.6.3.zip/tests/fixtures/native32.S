.global _start, magic_value, target_pointer, text16
.section .text
_start:
    xor %ebp,%ebp
    mov $4,%eax
    mov $1,%ebx
    mov $ready,%ecx
    mov $14,%edx
    int $0x80
again:
    mov $29,%eax
    int $0x80
    jmp again
.section .data
ready: .ascii "native32-ready\n"
.balign 4
magic_value: .long 0x12345678
target_pointer: .long magic_value
text16: .byte 0xb6,0x72,0x01,0x60
.section .note.GNU-stack,"",@progbits
