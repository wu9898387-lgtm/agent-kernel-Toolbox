/* Owned, harmless compiler layout oracle; no device or target access. */
extern int printf(const char *, ...);
typedef unsigned int Word;
struct Nested { short code; unsigned char bytes[3]; };
union Payload { Word number; unsigned char bytes[4]; };
struct Packet {
    int sequence;
    struct Nested nested;
    union Payload payload;
    Word values[3];
    struct { long counter; int flag; };
    union { int number; float ratio; };
};
struct BitFields { unsigned int low:3; unsigned int high:5; int ordinary; };
struct Packet GLOBAL_PACKET = { .sequence=17, .nested={.code=5}, .values={1,2,3}, .counter=23, .flag=1, .number=4 };
struct BitFields GLOBAL_BITS = { .low=2, .high=4, .ordinary=7 };
static const int OPTIMIZED_CONSTANT = 31;
int main(void) {
    volatile int LOCAL_STACK = GLOBAL_PACKET.sequence;
    printf("{\"packet_size\":%lu,\"sequence\":%lu,\"nested\":%lu,\"payload\":%lu,\"values\":%lu,\"counter\":%lu,\"number\":%lu}\n",
      (unsigned long)sizeof(struct Packet),
      (unsigned long)__builtin_offsetof(struct Packet,sequence),
      (unsigned long)__builtin_offsetof(struct Packet,nested),
      (unsigned long)__builtin_offsetof(struct Packet,payload),
      (unsigned long)__builtin_offsetof(struct Packet,values),
      (unsigned long)__builtin_offsetof(struct Packet,counter),
      (unsigned long)__builtin_offsetof(struct Packet,number));
    return LOCAL_STACK == OPTIMIZED_CONSTANT;
}
