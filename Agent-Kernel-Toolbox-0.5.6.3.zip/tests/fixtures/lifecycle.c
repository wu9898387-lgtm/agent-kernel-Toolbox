#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>

volatile uint64_t marker=7;
static void *busy(void *unused) { (void)unused;for(;;){} return NULL; }
int main(int argc,char **argv) {
    if(argc>1 && !strcmp(argv[1],"cpu")) {
        signal(SIGXCPU,SIG_IGN);pthread_t threads[4];
        for(int i=0;i<4;i++)if(pthread_create(&threads[i],NULL,busy,NULL))return 2;
        for(;;)pause();
    }
    if(argc!=3)return 3;
    if(!strcmp(argv[1],"second"))marker=11;
    printf("%p %llu\n",(void*)&marker,(unsigned long long)marker);fflush(stdout);
    if(!strcmp(argv[1],"first")) {
        while(access(argv[2],F_OK))usleep(1000);
        execl(argv[0],argv[0],"second",argv[2],NULL);return 4;
    }
    for(;;)pause();
}
