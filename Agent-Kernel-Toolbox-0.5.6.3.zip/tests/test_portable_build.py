"""Pinned installation planning and actual cross-ISA/object-format code generation."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.abi import ABIError, binary_abi
from observation_extension.portable_build import PortableBuild, PortableBuildError, detect_host, select_host_target
from observation_extension.translation import TranslationEngine, TranslationError, target_catalog

MODULE = {'schema_version': 1, 'width': 64, 'inputs': ['x', 'y'],
          'instructions': [{'id': 'sum', 'op': 'add', 'args': ['x', 'y']},
                           {'id': 'r', 'op': 'xor', 'args': ['sum', 'y']}], 'result': 'r'}


def digest(path):
    result = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


class PlatformPlanningTests(unittest.TestCase):
    def test_host_os_architecture_pointer_and_libc_are_independent(self):
        examples = [('Darwin', 'arm64', 64, 'little', '', 'aarch64-apple-darwin'),
                    ('Darwin', 'x86_64', 64, 'little', '', 'x86_64-apple-darwin'),
                    ('Windows', 'AMD64', 64, 'little', '', 'x86_64-pc-windows-msvc'),
                    ('Linux', 'riscv64', 64, 'little', 'glibc', 'riscv64-linux-gnu'),
                    ('Linux', 'aarch64', 64, 'little', 'musl', 'aarch64-linux-musl')]
        for *host, expected in examples:
            with self.subTest(host=host):
                value = select_host_target(*host)
                self.assertEqual(value['target']['triple'], expected)
                self.assertFalse(value['native_cpu_tuning_enabled'])
        for host in [('Linux', 'aarch64', 32, 'little', 'glibc'),
                     ('Linux', 'x86_64', 64, 'big', 'glibc'),
                     ('Linux', 'armv7l', 32, 'little', 'glibc'),
                     ('Linux', 'x86_64', 64, 'little', ''),
                     ('UnknownOS', 'x86_64', 64, 'little', 'glibc')]:
            self.assertEqual(select_host_target(*host)['status'], 'unavailable')

    def test_current_host_detection_never_claims_target_execution(self):
        result = detect_host()
        self.assertFalse(result['target_execution_verified'])
        self.assertFalse(result['compiler_invoked'])
        self.assertEqual(result['object_compiler_host_supported'], os.name == 'posix')

    def test_coff_relocatable_header_boundaries(self):
        header = bytearray(60)
        header[:2] = (0x8664).to_bytes(2, 'little')
        header[2:4] = (1).to_bytes(2, 'little')
        self.assertEqual(binary_abi(bytes(header))['format'], 'COFF')
        for mutate in (lambda h: h.__setitem__(slice(2, 4), (0).to_bytes(2, 'little')),
                       lambda h: h.__setitem__(slice(16, 18), (240).to_bytes(2, 'little')),
                       lambda h: h.__setitem__(slice(18, 20), (2).to_bytes(2, 'little'))):
            value = header.copy(); mutate(value)
            with self.assertRaises(ABIError): binary_abi(bytes(value))
        with self.assertRaises(ABIError): binary_abi(bytes(header[:59]))


class RegisteredBuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.source = self.directory / 'downloaded-ir.json'
        self.source.write_text(json.dumps(MODULE))
        self.config = {'profiles': {'owned': {'module_path': str(self.source), 'module_sha256': digest(self.source),
                                            'target': 'aarch64-apple-darwin'}}}

    def service(self, config=None):
        return PortableBuild(config or self.config, self.directory / 'cache')

    def test_plan_checks_downloaded_bytes_without_compiling_or_executing(self):
        with patch('observation_extension.portable_build.TranslationEngine', side_effect=AssertionError('compiler invoked')):
            result = self.service().plan('owned')
        self.assertEqual(result['target']['object_format'], 'Mach-O')
        self.assertTrue(result['source_digest_verified'])
        self.assertFalse(result['compiler_invoked'])
        self.assertFalse(result['input_executed'])
        self.assertFalse((self.directory / 'cache').exists())

    def test_compile_defaults_off_and_configuration_cannot_add_flags(self):
        self.source.unlink()
        with self.assertRaisesRegex(PortableBuildError, 'compile_not_authorized') as refused:
            self.service().compile('owned')
        self.assertFalse(refused.exception.effect_dispatched)
        config = copy.deepcopy(self.config)
        config['profiles']['owned']['flags'] = ['-include', '/etc/passwd']
        with self.assertRaisesRegex(PortableBuildError, 'invalid_profile'): self.service(config)
        config = copy.deepcopy(self.config); config['compiler_driver'] = ['cc', '-Xclang']
        with self.assertRaisesRegex(PortableBuildError, 'invalid_compiler_driver'): self.service(config)

    def test_digest_symlink_and_unvalidated_IR_are_rejected(self):
        self.source.write_text(json.dumps({**MODULE, 'width': 32}))
        with self.assertRaisesRegex(PortableBuildError, 'digest_mismatch'): self.service().plan('owned')
        actual = self.directory / 'real.json'; self.source.rename(actual); self.source.symlink_to(actual)
        with self.assertRaisesRegex(PortableBuildError, 'regular'): self.service().plan('owned')
        self.source.unlink(); self.source.write_text('{"schema_version":1,"schema_version":1}')
        self.config['profiles']['owned']['module_sha256'] = digest(self.source)
        with self.assertRaisesRegex(PortableBuildError, 'invalid_word_ir'): self.service().plan('owned')

    def test_unknown_host_does_not_choose_a_different_OS(self):
        self.config['profiles']['owned']['target'] = 'host'
        with patch('observation_extension.portable_build.detect_host', return_value={'status': 'unavailable'}):
            with self.assertRaisesRegex(PortableBuildError, 'host_target_unavailable'):
                self.service().plan('owned')

    def test_effect_scope_unifies_profile_path_and_host_aliases_without_source_or_compiler_access(self):
        self.source.unlink()
        self.config.update(compiler=str(self.directory / 'unavailable-compiler'), compiler_sha256='1' * 64)
        self.config['profiles']['alias'] = {**self.config['profiles']['owned'],
            'module_path': str(self.directory / 'other-unavailable-source.json'), 'target': 'host',
            'allow_compile': True}
        host = {'status': 'selected', 'target': target_catalog()['aarch64-apple-darwin']}
        with patch('observation_extension.portable_build.detect_host', return_value=host), \
             patch('observation_extension.portable_build._read_module', side_effect=AssertionError('source read')), \
             patch('observation_extension.portable_build.TranslationEngine', side_effect=AssertionError('compiler invoked')):
            service = self.service()
            original = service.effect_scope('owned')
            self.assertRegex(original, r'^[0-9a-f]{64}$')
            self.assertEqual(original, service.effect_scope('alias'))
            for key, value in [('module_sha256', '2' * 64), ('target', 'x86_64-apple-darwin'),
                               ('compiler_sha256', '3' * 64), ('compiler_driver', 'zig-cc')]:
                changed = copy.deepcopy(self.config)
                if key in ('module_sha256', 'target'):
                    changed['profiles']['owned'][key] = value
                else:
                    changed[key] = value
                with self.subTest(identity_field=key):
                    self.assertNotEqual(original, self.service(changed).effect_scope('owned'))
        self.assertFalse((self.directory / 'cache').exists())

    def test_effect_scope_unknown_profile_or_host_is_preflight_failure(self):
        service = self.service()
        with self.assertRaisesRegex(PortableBuildError, 'unknown_profile') as unknown:
            service.effect_scope('unregistered')
        self.assertFalse(unknown.exception.effect_dispatched)
        self.config['profiles']['owned']['target'] = 'host'
        with patch('observation_extension.portable_build.detect_host', return_value={'status': 'unavailable'}):
            with self.assertRaisesRegex(PortableBuildError, 'host_target_unavailable') as unsupported:
                self.service().effect_scope('owned')
        self.assertFalse(unsupported.exception.effect_dispatched)

    @unittest.skipUnless(sys.platform == 'linux' and shutil.which('cc'), 'Linux C compiler required')
    def test_fixed_profile_actual_object_compile_cache_and_source_revalidation(self):
        compiler = str(Path(shutil.which('cc')).resolve())
        self.config.update(compiler=compiler, compiler_sha256=digest(compiler))
        self.config['profiles']['owned'].update(target='host', allow_compile=True)
        service = self.service()
        first = service.compile('owned'); second = service.compile('owned')
        self.assertEqual(first['artifact_abi']['format'], 'ELF')
        self.assertFalse(first['cache_hit']); self.assertTrue(second['cache_hit'])
        self.assertFalse(first['target_execution_verified'])
        self.assertEqual(digest(first['artifact_path']), first['artifact_sha256'])
        self.source.write_text(json.dumps({**MODULE, 'width': 32}))
        with self.assertRaisesRegex(PortableBuildError, 'digest_mismatch'): service.compile('owned')

    @unittest.skipUnless(sys.platform == 'linux' and shutil.which('cc'), 'Linux C compiler required')
    def test_cli_detect_plan_and_actual_compile(self):
        compiler = str(Path(shutil.which('cc')).resolve())
        self.config.update(compiler=compiler, compiler_sha256=digest(compiler))
        self.config['profiles']['owned'].update(target='host', allow_compile=True)
        path = self.directory / 'build.json'; path.write_text(json.dumps(self.config))
        prefix = [sys.executable, str(ROOT / 'tools/runtime-platform.py')]
        result = subprocess.run(prefix + ['detect'], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertFalse(json.loads(result.stdout)['data']['compiler_invoked'])
        for action in ('plan', 'compile'):
            result = subprocess.run(prefix + [action, '--config', str(path), '--state-directory',
                str(self.directory / 'cli-cache'), '--profile', 'owned']
                + (['--request-id', 'cli-build-001'] if action == 'compile' else []),
                capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertFalse(json.loads(result.stdout)['data']['target_execution_verified'])

    @unittest.skipUnless(sys.platform == 'linux' and shutil.which('cc'), 'Linux C compiler required')
    def test_compiler_that_ignores_foreign_target_cannot_publish_host_object(self):
        compiler = self.directory / 'wrong-clang'
        cc = str(Path(shutil.which('cc')).resolve())
        compiler.write_text('#!' + sys.executable + '\nimport os,sys\n'
            'if "--version" in sys.argv:\n print("clang deliberately wrong fixture");sys.exit(0)\n'
            'args=[x for x in sys.argv[1:] if not x.startswith("--target=")]\n'
            f'os.execv({cc!r},[{cc!r}]+args)\n')
        compiler.chmod(0o500)
        engine = TranslationEngine(str(compiler), self.directory / 'wrong-cache')
        with self.assertRaisesRegex(TranslationError, 'output_(format|abi)_mismatch'):
            engine.compile(MODULE, target='x86_64-apple-darwin', kind='object')
        self.assertFalse(list((self.directory / 'wrong-cache').glob('*.json')))

    @unittest.skipUnless(sys.platform == 'linux' and shutil.which('cc'), 'Linux C compiler required')
    def test_compile_error_dispatch_flag_tracks_actual_compilation_child(self):
        compiler = self.directory / 'failing-clang'
        compiler.write_text('#!' + sys.executable + '\nimport sys\n'
                           'if "--version" in sys.argv: print("clang failing fixture");sys.exit(0)\n'
                           'sys.exit(3)\n')
        compiler.chmod(0o500)
        self.config.update(compiler=str(compiler), compiler_sha256=digest(compiler))
        self.config['profiles']['owned']['allow_compile'] = True
        with self.assertRaisesRegex(PortableBuildError, 'tool_failed') as compiled:
            self.service().compile('owned')
        self.assertTrue(compiled.exception.effect_dispatched)
        self.config['compiler_sha256'] = '0' * 64
        with self.assertRaisesRegex(PortableBuildError, 'compiler_digest_mismatch') as refused:
            self.service().compile('owned')
        self.assertFalse(refused.exception.effect_dispatched)

    @unittest.skipUnless(sys.platform == 'linux', 'POSIX compiler subprocess required')
    def test_version_probe_failure_after_real_marker_is_dispatched(self):
        marker = self.directory / 'compiler-executed'
        compiler = self.directory / 'version-failing-compiler'
        compiler.write_text('#!' + sys.executable + '\nfrom pathlib import Path\nimport sys\n'
                           f'Path({str(marker)!r}).write_text("version-process-ran")\n'
                           'sys.exit(3)\n')
        compiler.chmod(0o500)
        self.config.update(compiler=str(compiler), compiler_sha256=digest(compiler))
        self.config['profiles']['owned']['allow_compile'] = True
        with self.assertRaisesRegex(PortableBuildError, 'tool_failed') as dispatched:
            self.service().compile('owned')
        self.assertEqual(marker.read_text(), 'version-process-ran')
        self.assertTrue(dispatched.exception.effect_dispatched)

        marker.unlink()
        self.config['compiler_sha256'] = '0' * 64
        with self.assertRaisesRegex(PortableBuildError, 'compiler_digest_mismatch') as preflight:
            self.service().compile('owned')
        self.assertFalse(preflight.exception.effect_dispatched)
        self.assertFalse(marker.exists())


ZIG = os.environ.get('RUNTIME_ZIG') or shutil.which('zig')


@unittest.skipUnless(sys.platform == 'linux' and ZIG, 'set RUNTIME_ZIG for actual Zig/Clang multi-target compilation')
class ActualCrossTargetTests(unittest.TestCase):
    def test_same_IR_real_ELF_MachO_COFF_objects_on_CISC_and_RISC(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            engine = TranslationEngine(str(Path(ZIG).resolve()), Path(directory) / 'cache', compiler_driver='zig-cc', timeout=30)
            targets = ['x86_64-linux-gnu', 'i686-linux-gnu', 'aarch64-linux-gnu', 'armv7-linux-gnueabihf',
                       'riscv64-linux-gnu', 'mips-linux-gnu', 'powerpc64-linux-gnu',
                       'x86_64-linux-musl', 'aarch64-linux-musl',
                       'x86_64-apple-darwin', 'aarch64-apple-darwin',
                       'x86_64-pc-windows-msvc', 'aarch64-pc-windows-msvc']
            receipts = []; keys = set()
            expected_machines = {'x86_64-linux-gnu': 62, 'aarch64-linux-gnu': 183, 'riscv64-linux-gnu': 243,
                                 'i686-linux-gnu': 3, 'armv7-linux-gnueabihf': 40,
                                 'mips-linux-gnu': 8, 'powerpc64-linux-gnu': 21,
                                 'x86_64-linux-musl': 62, 'aarch64-linux-musl': 183,
                                 'x86_64-apple-darwin': 0x1000007, 'aarch64-apple-darwin': 0x100000c,
                                 'x86_64-pc-windows-msvc': 0x8664, 'aarch64-pc-windows-msvc': 0xaa64}
            for target in targets:
                with self.subTest(target=target):
                    built = engine.compile(MODULE, target=target, kind='object')
                    raw = Path(built['path']).read_bytes(); details = target_catalog()[target]
                    self.assertEqual(built['artifact_abi']['format'], details['object_format'])
                    # Independent format/machine reads, not only our ABI parser.
                    offset = 18 if details['object_format'] == 'ELF' else 4 if details['object_format'] == 'Mach-O' else 0
                    size = 4 if details['object_format'] == 'Mach-O' else 2
                    self.assertEqual(int.from_bytes(raw[offset:offset + size], details['byte_order']), expected_machines[target])
                    self.assertFalse(built['target_execution_verified'])
                    self.assertTrue(built['linking_required'])
                    self.assertNotIn(built['cache_key'], keys); keys.add(built['cache_key'])
                    receipts.append({'target': target, 'format': details['object_format'], 'bytes': len(raw),
                                     'sha256': built['sha256'], 'machine': expected_machines[target],
                                     'pointer_bits': details['pointer_bits'], 'byte_order': details['byte_order'],
                                     'observed_abi_variant': built['artifact_abi']['abi_variant']})
            print('REAL_CROSS_TARGET_OBJECTS ' + json.dumps(receipts, sort_keys=True))

    @unittest.skipUnless(sys.platform == 'linux' and shutil.which('cc') and os.uname().machine == 'x86_64', 'native x86_64 C linker required')
    def test_actual_generated_host_object_links_and_runs_against_independent_oracle(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            directory = Path(directory)
            engine = TranslationEngine(str(Path(ZIG).resolve()), directory / 'cache', compiler_driver='zig-cc', timeout=30)
            built = engine.compile(MODULE, target='x86_64-linux-gnu', kind='object')
            launcher = directory / 'owned-launcher.c'
            launcher.write_text('#include <stdio.h>\n'
                'extern int runtime_ir_eval(const unsigned long long *,unsigned long long *);\n'
                'int main(void){\n'
                ' const unsigned long long pairs[][2]={{0,0},{1,2},{18446744073709551615ULL,1},'
                '{9223372036854775808ULL,18446744073709551615ULL}};\n'
                ' for(unsigned i=0;i<4;i++){unsigned long long result=0;'
                ' if(runtime_ir_eval(pairs[i],&result))return 3;printf("%llu\\n",result);}return 0;}\n')
            executable = directory / 'owned-launcher'
            compiled = subprocess.run([shutil.which('cc'), str(launcher), built['path'], '-o', str(executable)],
                capture_output=True, text=True, timeout=20)
            self.assertEqual(compiled.returncode, 0, compiled.stderr)
            result = subprocess.run([str(executable)], capture_output=True, text=True, timeout=2)
            self.assertEqual(result.returncode, 0, result.stderr)
            pairs = [(0, 0), (1, 2), (2**64 - 1, 1), (2**63, 2**64 - 1)]
            expected = [((x + y) % (2**64)) ^ y for x, y in pairs]
            self.assertEqual([int(value) for value in result.stdout.splitlines()], expected)
            print('REAL_HOST_OBJECT_EXECUTION ' + json.dumps({'target': 'x86_64-linux-gnu',
                'object_sha256': built['sha256'], 'linker_exit_code': 0, 'run_exit_code': 0,
                'actual_values': [int(value) for value in result.stdout.splitlines()],
                'independent_modular_arithmetic_oracle': True, 'other_target_execution_verified': False}))


if __name__ == '__main__':
    unittest.main()
