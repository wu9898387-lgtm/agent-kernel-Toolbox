import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.native_runtime import ProcessSession,NativeRuntimeError
from observation_extension.native_control import write_memory,suspend_for,set_cpu_affinity,cpu_sample
from observation_extension.runtime_host import RuntimeHost,SPECS


@unittest.skipUnless(sys.platform=='linux' and shutil.which('gcc'),'Linux C compiler required')
class NativeControlTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory=tempfile.TemporaryDirectory()
        cls.binary=Path(cls.directory.name)/'native-app'
        subprocess.run(['gcc','-O0','-no-pie',str(ROOT/'tests/fixtures/native_control_app.c'),'-o',str(cls.binary)],check=True,timeout=10)
        cls.symbols={line.split()[2]:int(line.split()[0],16) for line in subprocess.check_output(['nm',str(cls.binary)],text=True).splitlines() if len(line.split())==3}

    @classmethod
    def tearDownClass(cls):cls.directory.cleanup()

    def launch(self,**options):
        process=ProcessSession.launch([str(self.binary)],stdout=subprocess.PIPE,**options)
        self.assertTrue(select.select([process.child.stdout],[],[],3)[0])
        self.assertEqual(process.child.stdout.readline(),b'native-ready\n')
        def cleanup():
            if process.child.poll() is None:process.terminate_owned()
            process.close();process.child.stdout.close()
        self.addCleanup(cleanup)
        return process

    def test_native_memory_write_diff_and_business_state_over_mcp_host(self):
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)/'app-state'
            region={'value':{'address':hex(self.symbols['native_value']),'size':8}}
            config={'schema_version':1,'state_directory':directory+'/state','allowed_tools':list(SPECS),
                    'profiles':{'app':{'argv':[str(self.binary),str(output)],'allow_memory':True,'allow_control':True,
                        'allow_memory_write':True,'write_regions':region,'control_cpu_set':[min(os.sched_getaffinity(0))]}}}
            if os.environ.get('RUNTIME_NATIVE_HELPER'):
                helper=Path(os.environ['RUNTIME_NATIVE_HELPER'])
                config['native_helper']={'path':str(helper),'sha256':hashlib.sha256(helper.read_bytes()).hexdigest()}
            host=RuntimeHost(config,bundle_root=ROOT)
            session=None
            try:
                launched=host.call('process.launch',{'profile':'app','request_id':'launch-native'})
                self.assertTrue(launched['ok'],launched)
                session=launched['data']['session_id']
                # exec handoff precedes ld.so relocations/RELRO and APP startup.
                # Observe this fixture's initial business state before binding a
                # capture to its final data VMA; transient mapping rejection is
                # intentional and must not be bypassed by this regression.
                deadline=time.monotonic()+3
                while not output.exists() or output.read_text()!='7 home':
                    if time.monotonic()>deadline:self.fail('native APP initial-state readiness deadline')
                    time.sleep(0.002)
                args={'session_id':session,'address':hex(self.symbols['native_value']),'size':8}
                capture=host.call('process.capture_memory',args)
                self.assertTrue(capture['ok'],capture)
                order=host.processes[session].abi()['byte_order']
                patched=host.call('process.write_memory',{'session_id':session,'region':'value','offset':0,
                    'data_hex':(9).to_bytes(8,order).hex(),'expected_sha256':capture['data']['sha256'],'request_id':'patch-native'})
                self.assertTrue(patched['ok'],patched)
                self.assertEqual(patched['data']['status'],'verified')
                deadline=time.monotonic()+3
                while not output.exists() or output.read_text()!='9 home':
                    if time.monotonic()>deadline:self.fail('native APP did not observe patched data')
                    time.sleep(0.01)
                diff=host.call('process.diff_memory',{'session_id':session,'capture_id':capture['data']['capture_id']})
                self.assertTrue(diff['ok'],diff);self.assertEqual(diff['data']['changed_bytes'],1)
                rejected=host.call('process.write_memory',{'session_id':session,'region':'value','offset':0,
                    'data_hex':(10).to_bytes(8,order).hex(),'expected_sha256':capture['data']['sha256'],'request_id':'stale-patch'})
                self.assertEqual(rejected['data']['status'],'rejected')
                affinity=host.call('process.set_cpu_affinity',{'session_id':session,'cpus':[min(os.sched_getaffinity(0))],'request_id':'limit-native-cpu'})
                self.assertTrue(affinity['ok'],affinity)
                sample=host.call('process.cpu_sample',{'session_id':session,'interval_ms':200})
                self.assertTrue(sample['ok'],sample);self.assertTrue(sample['data']['threads'])
                pause=host.call('process.suspend_for',{'session_id':session,'milliseconds':30,'request_id':'pause-native'})
                self.assertTrue(pause['ok'],pause);self.assertTrue(pause['data']['resumed'])
                if 'native_helper' in config:self.assertEqual(pause['data']['watchdog_backend'],'compiled_go')
                released=host.call('process.release_capture',{'session_id':session,'capture_id':capture['data']['capture_id']})
                self.assertTrue(released['data']['released'])
            finally:
                if session:
                    result=host.call('process.terminate',{'session_id':session,'request_id':'terminate-native'})
                    self.assertTrue(result['ok'],result)
                host.close()

    def test_scopes_and_executable_memory_are_refused(self):
        denied=self.launch(allow_memory=True)
        with self.assertRaisesRegex(NativeRuntimeError,'owned_process_control_not_authorized'):
            suspend_for(denied,10)
        process=self.launch(allow_memory=True,allow_memory_write=True,allow_control=True,
            write_regions={'code':{'address':hex(self.symbols['main']),'size':8}})
        with self.assertRaisesRegex(NativeRuntimeError,'write_requires_unique_writable_nonexecutable_mapping'):
            write_memory(process,'code',0,b'12345678',hashlib.sha256(b'12345678').hexdigest())
        with self.assertRaisesRegex(NativeRuntimeError,'cpu_affinity_outside_operator_scope'):
            set_cpu_affinity(process,[min(os.sched_getaffinity(0))])

    def test_pause_then_register_capture_detaches_cleanly(self):
        process=self.launch(allow_memory=True,allow_control=True,allow_debug=True)
        self.assertTrue(suspend_for(process,20)['resumed'])
        registers=process.cpu_snapshot(max_frames=0)
        self.assertTrue(registers['registers'])
        self.assertIn('TracerPid:\t0\n',Path(f'/proc/{process.pid}/status').read_text())

    def test_partial_write_is_rolled_back_before_app_resumes(self):
        process=self.launch(allow_memory=True,allow_control=True,allow_memory_write=True,
            write_regions={'value':{'address':hex(self.symbols['native_value']),'size':8}})
        address=self.symbols['native_value'];before=process._read_memory_bytes(address,8)
        original=os.pwrite;calls=0
        def partial(fd,data,offset):
            nonlocal calls
            calls+=1
            return original(fd,data[:1],offset) if calls==1 else original(fd,data,offset)
        with patch('observation_extension.native_control.os.pwrite',side_effect=partial):
            result=write_memory(process,'value',0,(9).to_bytes(8,process.abi()['byte_order']),hashlib.sha256(before).hexdigest())
        self.assertEqual(result['status'],'rolled_back');self.assertTrue(result['rollback_verified'])
        self.assertEqual(process._read_memory_bytes(address,8),before)
        self.assertFalse(process.threads()[0]['state'].startswith('T'))

    def test_independent_watchdog_resumes_after_controller_sigkill(self):
        script="""
import json,sys,time
sys.path.insert(0,sys.argv[1])
from observation_extension.native_runtime import ProcessSession
from observation_extension.native_control import stopped_owned
process=ProcessSession.launch([sys.argv[2]],allow_control=True,stdout=__import__('subprocess').DEVNULL)
with stopped_owned(process):
 print(json.dumps({'pid':process.pid,'identity':process.identity}),flush=True)
 time.sleep(60)
"""
        controller=subprocess.Popen([sys.executable,'-c',script,str(RUNTIME),str(self.binary)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        target=None
        try:
            self.assertTrue(select.select([controller.stdout],[],[],5)[0])
            record=json.loads(controller.stdout.readline())
            target=ProcessSession.attach(record['pid'],expected_identity=record['identity'],allow_terminate=True)
            self.assertTrue(target.threads()[0]['state'].startswith('T'))
            controller.kill();controller.wait(timeout=3)
            deadline=time.monotonic()+4
            while any(t['state'].startswith('T') for t in target.threads()):
                if time.monotonic()>deadline:self.fail('watchdog did not resume orphaned native APP')
                time.sleep(0.02)
        finally:
            if controller.poll() is None:controller.kill();controller.wait(timeout=3)
            if target:target.terminate_selected();target.close()
            controller.stdout.close();controller.stderr.close()


if __name__=='__main__':unittest.main()
