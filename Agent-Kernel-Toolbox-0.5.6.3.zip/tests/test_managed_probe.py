"""Real JVMTI allocation/tag/free/GC, bounded loss and owned JVM cleanup."""
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import zipfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.managed_jvm import classpath_sha256
from observation_extension.managed_probe import ManagedProbe,ManagedProbeError,parse_events,_nodes
from observation_extension.policy import _json_copy

JAVA=Path(os.environ.get('RUNTIME_JAVA','/usr/lib/jvm/java-21-openjdk-amd64/bin/java')).resolve()
HEADER_CANDIDATES=[Path(os.environ.get('RUNTIME_JAVA_HOME',str(JAVA.parent.parent))),
                   Path('/workspace/work/toolchains/jdk-25.0.5+8')]
HEADERS=next((p for p in HEADER_CANDIDATES if (p/'include/jvmti.h').is_file()),None)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(sys.platform.startswith('linux') and JAVA.is_file() and HEADERS and shutil.which('gcc') and hasattr(os,'pidfd_open'),
                     'Linux JDK runtime, JDK JVMTI headers, gcc and pidfd required')
class ManagedProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory();cls.root=Path(cls.temporary.name)
        try:
            spec=importlib.util.spec_from_file_location('managed_probe_builder',ROOT/'native/managed-probe/build.py')
            builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
            cls.agent=builder.build(HEADERS,cls.root/'agent')
            cls.classes=cls.root/'classes';cls.classes.mkdir()
            slow=cls.root/'SlowProbe.java'
            slow.write_text('''package runtimeaccess.probe;
public final class SlowProbe {
 public static void main(String[] args) throws Exception {
  System.out.println("PROBE_READY "+ProcessHandle.current().pid());
  Object value=new SlowProbe();RuntimeProbe.tag(value);
  RuntimeProbe.event(value,1,0);Thread.sleep(30000);
 }
}''')
            wrong=cls.root/'WrongProbe.java'
            wrong.write_text('''package runtimeaccess.probe;
public final class WrongProbe {
 public static void main(String[] args) {
  System.out.println("PROBE_READY");
  try {RuntimeProbe.tag("not_registered");throw new AssertionError();}
  catch(IllegalArgumentException expected) {}
  try {RuntimeProbe.event(new WrongProbe(),1,2);throw new AssertionError();}
  catch(IllegalStateException expected) {}
 }
}''')
            capacity=cls.root/'CapacityProbe.java'
            capacity.write_text('''package runtimeaccess.probe;
public final class CapacityProbe {
 public static void main(String[] args) {
  System.out.println("PROBE_READY");
  for(int i=0;i<2050;i++)RuntimeProbe.tag(new CapacityProbe());
 }
}''')
            sampled=cls.root/'SampledProbe.java'
            sampled.write_text('''package runtimeaccess.probe;
import java.lang.ref.WeakReference;
import java.lang.ref.Reference;
public final class SampledProbe {
 public static final class Plain { public int value; Plain(int v){value=v;} }
 private static WeakReference<Plain> retired;
 private static long retiredTag;
 private static volatile Throwable failure;
 private static void retire(){
  Plain value=new Plain(9);retiredTag=RuntimeProbe.identity(value);
  if(retiredTag==0)throw new AssertionError("ordinary_new_not_sampled");
  retired=new WeakReference<>(value);RuntimeProbe.event(value,103,9);
 }
 public static void main(String[] args)throws Exception {
  Plain historic=new Plain(-1);
  if(!RuntimeProbe.startAllocationSampling(0)){System.out.println("SAMPLING_UNAVAILABLE");return;}
  // Existing thread sampling state may lag interval changes. This explicit new
  // thread observes the new interval; errors still fail the owning JVM main.
  Thread worker=new Thread(()->{try{observe();}catch(Throwable error){failure=error;}});
  worker.start();worker.join();if(failure!=null)throw new AssertionError(failure);
  Reference.reachabilityFence(historic);
 }
 private static void observe()throws Exception {
  Plain root=new Plain(41);Plain[] array=new Plain[17];
  long rootTag=RuntimeProbe.identity(root),arrayTag=RuntimeProbe.identity(array);
  if(rootTag==0||arrayTag==0||rootTag==arrayTag)throw new AssertionError("direct_new_or_array_not_sampled");
  RuntimeProbe.event(root,101,41);RuntimeProbe.event(array,104,17);retire();
  for(int i=0;i<8&&retired.get()!=null;i++){System.gc();Thread.sleep(15);}
  System.gc();
  if(RuntimeProbe.identity(root)!=rootTag||RuntimeProbe.identity(array)!=arrayTag||retired.get()!=null)
   throw new AssertionError("sampled_identity_or_retirement_failed");
  RuntimeProbe.event(root,102,42);Reference.reachabilityFence(root);Reference.reachabilityFence(array);
 }
}''')
            many=cls.root/'ManyEventsProbe.java'
            many.write_text('''package runtimeaccess.probe;
public final class ManyEventsProbe {
 public static void main(String[] args) {
  Object value=new ManyEventsProbe();RuntimeProbe.tag(value);
  for(int i=0;i<1500;i++)RuntimeProbe.event(value,7,i);
 }
}''')
            denied=cls.root/'DeniedSamplingProbe.java'
            denied.write_text('''package runtimeaccess.probe;
public final class DeniedSamplingProbe {
 public static void main(String[] args) {
  try {RuntimeProbe.startAllocationSampling(0);throw new AssertionError();}
  catch(IllegalStateException expected) {}
 }
}''')
            wrong_interval=cls.root/'WrongIntervalProbe.java'
            wrong_interval.write_text('''package runtimeaccess.probe;
public final class WrongIntervalProbe {
 public static void main(String[] args) {
  try {RuntimeProbe.startAllocationSampling(1);throw new AssertionError();}
  catch(IllegalArgumentException expected) {}
 }
}''')
            subprocess.run([str(JAVA),'com.sun.tools.javac.Main','-g','-encoding','UTF-8','-d',str(cls.classes),
                str(ROOT/'native/managed-probe/RuntimeProbe.java'),
                str(ROOT/'tests/fixtures/recovery/ManagedProbeFixture.java'),str(slow),str(wrong),str(capacity),
                str(sampled),str(many),str(denied),str(wrong_interval)],check=True,timeout=20)
            cls.profile={'java':str(JAVA),'java_sha256':digest(JAVA),
                'agent':cls.agent['agent'],'agent_sha256':cls.agent['agent_sha256'],
                'class_path':str(cls.classes),'class_path_sha256':classpath_sha256(cls.classes),
                'main_class':'runtimeaccess.probe.ManagedProbeFixture','allow_run':True,
                'event_budget':1024,'wall_ms':5000,'class_prefix':'Lruntimeaccess/probe/'}
        except BaseException:cls.temporary.cleanup();raise

    @classmethod
    def tearDownClass(cls):cls.temporary.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name)

    def client(self,profile=None):
        client=ManagedProbe({'profiles':{'fixture':profile or self.profile}},self.directory,bundle_root=ROOT)
        self.addCleanup(client.close);return client

    def guardian_launcher(self,bootstrap,extra_fds=(),hold_receipt=None):
        """Work-only fault injection around the unchanged guardian program."""
        original=subprocess.Popen
        def launch(argv,**kwargs):
            if not (isinstance(argv,list) and len(argv)>3 and str(argv[3]).endswith('/guardian.py')):
                return original(argv,**kwargs)
            if hold_receipt is not None:
                hold_receipt.append(os.dup(int(argv[argv.index('--cleanup-fd')+1])))
            kwargs['pass_fds']=(*kwargs.get('pass_fds',()),*extra_fds)
            return original([*argv[:3],'-c',bootstrap,*argv[3:]],**kwargs)
        return launch

    def gone(self,pid):
        deadline=time.monotonic()+4
        while Path(f'/proc/{pid}/stat').exists():
            state=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[0]
            if state=='Z':return
            self.assertLess(time.monotonic(),deadline,f'owned process {pid} still running')
            time.sleep(.01)

    def test_real_JVMTI_GC_identity_ObjectFree_and_runtime_metadata(self):
        client=self.client();result=client.run('fixture')
        self.assertEqual(result['status'],'completed');self.assertTrue(result['native_capture_complete'])
        events=result['events'];kinds={e['kind']for e in events}
        self.assertTrue({'vm_object_alloc','gc_start','gc_finish','object_free'}<=kinds)
        semantic={e['event_code']:e for e in events if e['kind']=='semantic'and e['event_code']!=4}
        self.assertEqual(semantic[1]['tag'],semantic[2]['tag'])
        self.assertEqual(semantic[2]['state_code'],42);self.assertEqual(semantic[5]['state_code'],42)
        self.assertTrue(any(e['kind']=='object_free'and e['tag']==semantic[3]['tag']for e in events))
        self.assertNotEqual(semantic[3]['tag'],semantic[1]['tag'])
        metadata=next(e for e in events if e['kind']=='class_metadata')
        self.assertEqual(metadata['class_signature'],'Lruntimeaccess/probe/ManagedProbeFixture$Node;')
        self.assertEqual({(f['name'],f['signature'])for f in metadata['fields']},{('value','I'),('generation','J'),('数字','I')})
        self.assertFalse(result['physical_addresses_exposed']);self.assertFalse(result['object_contents_captured'])
        self.assertNotIn('prefix',result['stdout']);self.assertEqual(result['cleanup'],{'guardian_reaped':True,'target_exited':True})
        self.assertTrue(client.release(result['capture_handle'])['released'])
        self.assertEqual(list(self.directory.iterdir()),[])
        print('JVMTI_REAL',json.dumps({'summary':result['summary'],'root_tag':semantic[1]['tag'],'retired_tag':semantic[3]['tag'],'kinds':sorted(kinds)}))

    def test_budget_reports_event_loss_without_unbounded_event_output(self):
        p={**self.profile,'event_budget':5};result=self.client(p).run('fixture')
        self.assertEqual(len(result['events']),5);self.assertGreater(result['events_lost'],300)
        self.assertFalse(result['capture_complete']);self.assertEqual(result['summary']['generated'],result['summary']['retained']+result['summary']['lost'])

    def test_object_tag_capacity_is_bounded_independently_of_event_loss(self):
        p={**self.profile,'event_budget':5,'main_class':'runtimeaccess.probe.CapacityProbe'}
        result=self.client(p).run('fixture')
        self.assertEqual(result['summary']['tags_assigned'],2048)
        self.assertGreater(result['events_lost'],4000)

    def test_pinned_JAR_classpath_and_fixed_JNI_rejections(self):
        jar=self.directory/'target.jar'
        with zipfile.ZipFile(jar,'w')as stream:
            for entry in self.classes.rglob('*.class'):stream.write(entry,entry.relative_to(self.classes))
        p={**self.profile,'class_path':str(jar),'class_path_sha256':classpath_sha256(jar),
           'main_class':'runtimeaccess.probe.WrongProbe'}
        result=self.client(p).run('fixture')
        self.assertEqual(result['status'],'completed');self.assertEqual(result['summary']['tags_assigned'],0)

    def test_profile_validation_rejects_model_code_paths_and_invalid_budgets(self):
        for change in ({'wall_ms':True},{'event_budget':0},{'event_budget':2049},{'main_class':'X -javaagent:x'},
                       {'class_prefix':'*'},{'allow_run':1},{'agent_sha256':'bad'},{'jvm_args':['-Xmx8g']},
                       {'allocation_sampling_interval_bytes':True},{'allocation_sampling_interval_bytes':-1},
                       {'allocation_sampling_interval_bytes':2**31}):
            with self.subTest(change=change):
                with self.assertRaises(ManagedProbeError)as caught:self.client({**self.profile,**change})
                self.assertFalse(caught.exception.effect_dispatched)

    def test_real_direct_new_and_reference_array_sampling_stable_tags_across_GC(self):
        p={**self.profile,'main_class':'runtimeaccess.probe.SampledProbe','allocation_sampling_interval_bytes':0}
        client=self.client(p);result=client.run('fixture')
        self.assertEqual(result['status'],'completed',result)
        self.assertTrue(result['allocation_sampling']['capability_supported'],result)
        self.assertTrue(result['allocation_sampling']['started'],result)
        self.assertEqual(result['allocation_sampling']['requested_interval_bytes'],0)
        self.assertGreater(result['allocation_sampling']['started_monotonic_ns'],0)
        allocs=[e for e in result['events']if e['kind']=='sampled_object_alloc']
        self.assertTrue(any(e['class_signature']=='Lruntimeaccess/probe/SampledProbe$Plain;'for e in allocs),result)
        self.assertTrue(any(e['class_signature']=='[Lruntimeaccess/probe/SampledProbe$Plain;'for e in allocs),result)
        semantic={e['event_code']:e for e in result['events']if e['kind']=='semantic'}
        self.assertEqual(semantic[101]['tag'],semantic[102]['tag'])
        self.assertNotEqual(semantic[101]['tag'],semantic[104]['tag'])
        self.assertTrue(any(e['kind']=='object_free'and e['tag']==semantic[103]['tag']for e in result['events']))
        self.assertFalse(result['all_JVM_allocations_proven']);self.assertFalse(result['allocation_history_before_sampling_observed'])
        print('SAMPLED_DIRECT_NEW',json.dumps({'sampling':result['allocation_sampling'],'observed_samples':len(allocs),'stable_tag':semantic[101]['tag'],'array_tag':semantic[104]['tag']}))

    def test_sampling_default_off_rejects_JNI_start_and_budget_remains_explicit(self):
        result=self.client({**self.profile,'main_class':'runtimeaccess.probe.DeniedSamplingProbe'}).run('fixture')
        self.assertEqual(result['status'],'completed',result);self.assertFalse(result['allocation_sampling']['started'])
        wrong=self.client({**self.profile,'main_class':'runtimeaccess.probe.WrongIntervalProbe',
            'allocation_sampling_interval_bytes':0}).run('fixture')
        self.assertEqual(wrong['status'],'completed',wrong);self.assertFalse(wrong['allocation_sampling']['started'])
        result=self.client({**self.profile,'main_class':'runtimeaccess.probe.SampledProbe',
            'allocation_sampling_interval_bytes':0,'event_budget':5}).run('fixture')
        self.assertEqual(result['status'],'completed',result)
        self.assertTrue(result['allocation_sampling']['started']);self.assertGreater(result['events_lost'],0)
        self.assertFalse(result['native_capture_complete'])

    def test_explicit_capability_unavailable_branch_is_reported_without_invented_samples(self):
        # Fault-inject an older negotiated JVMTI version in a separately built
        # pinned agent. The normal JDK21 positive test uses unmodified source.
        source=self.directory/'older-version-probe.c'
        raw=(ROOT/'native/managed-probe/managed_probe.c').read_text()
        declaration='int modern=sampling_configured && (*vm)->GetEnv(vm,(void **)&ti,JVMTI_VERSION_11)==JNI_OK;'
        self.assertIn(declaration,raw);source.write_text(raw.replace(declaration,'int modern=0;'))
        target=self.directory/'older-version-probe.so'
        subprocess.run([shutil.which('gcc'),'-std=c11','-O2','-fPIC','-shared','-pthread','-Wall','-Wextra','-Werror',
            '-I'+str(HEADERS/'include'),'-I'+str(HEADERS/'include/linux'),str(source),'-o',str(target)],check=True,timeout=20)
        p={**self.profile,'agent':str(target),'agent_sha256':digest(target),
           'main_class':'runtimeaccess.probe.SampledProbe','allocation_sampling_interval_bytes':0}
        result=self.client(p).run('fixture')
        self.assertEqual(result['status'],'completed',result)
        self.assertFalse(result['allocation_sampling']['capability_supported'])
        self.assertFalse(result['allocation_sampling']['started'])
        self.assertEqual(result['allocation_sampling']['support_status'],'unsupported_JVMTI_version')
        self.assertFalse(any(e['kind']=='sampled_object_alloc'for e in result['events']))

    def test_default_off_remains_compatible_with_the_old_three_method_JNI_bridge(self):
        classes=self.directory/'legacy-classes';shutil.copytree(self.classes,classes)
        source=self.directory/'RuntimeProbe.java'
        source.write_text('''package runtimeaccess.probe;
public final class RuntimeProbe {
 public static native long tag(Object object);
 public static native long identity(Object object);
 public static native void event(Object object,int code,int state);
}''')
        subprocess.run([str(JAVA),'com.sun.tools.javac.Main','-d',str(classes),str(source)],check=True,timeout=20)
        result=self.client({**self.profile,'class_path':str(classes),'class_path_sha256':classpath_sha256(classes)}).run('fixture')
        self.assertEqual(result['status'],'completed',result)
        kinds={e['kind']for e in result['events']}
        self.assertTrue({'explicit_tag','gc_start','gc_finish','object_free'}<=kinds)
        self.assertNotIn('allocation_sampling',result['summary'])

    def test_legal_2048_budget_transport_and_complete_capture_pagination_are_bounded(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.ManyEventsProbe','event_budget':2048})
        result=client.run('fixture');self.assertEqual(result['status'],'completed')
        self.assertGreater(result['transport_events_omitted'],1000)
        self.assertFalse(result['transport_complete']);self.assertFalse(result['capture_complete'])
        self.assertEqual(result['events_lost'],0);self.assertTrue(result['native_capture_complete'])
        self.assertLessEqual(_nodes(result),3400);self.assertLessEqual(len(json.dumps(result).encode()),48*1024)
        _json_copy(result)
        events=[];cursor=0
        with patch('observation_extension.managed_probe.subprocess.Popen')as launch:
            while True:
                page=client.poll(result['capture_handle'],cursor,32)
                self.assertLessEqual(_nodes(page),3400);self.assertLessEqual(len(json.dumps(page).encode()),48*1024)
                self.assertEqual(page['capture_sha256'],result['native_event_artifact']['sha256'])
                events.extend(page['events']);cursor=page['next_cursor'];_json_copy(page)
                if page['done']:break
            launch.assert_not_called()
        self.assertEqual([e['seq']for e in events],list(range(1,result['summary']['retained']+1)))
        self.assertEqual(events[-1]['state_code'],1499)
        self.assertTrue(client.release(result['capture_handle'])['released'])
        with self.assertRaisesRegex(ManagedProbeError,'capture_unavailable'):client.poll(result['capture_handle'])

    def test_capture_hash_integrity_page_validation_and_capacity_are_enforced(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.WrongProbe','event_budget':5})
        result=client.run('fixture');handle=result['capture_handle']
        for args in ((handle,-1,32),(handle,0,33),('/tmp/raw-events',0,32)):
            with self.assertRaises(ManagedProbeError)as failure:client.poll(*args)
            self.assertFalse(failure.exception.effect_dispatched)
        client.captures[handle]['path'].write_bytes(b'corrupt')
        with self.assertRaisesRegex(ManagedProbeError,'capture_integrity_failed'):client.poll(handle)
        client.release(handle)
        for _ in range(8):client.run('fixture')
        with patch('observation_extension.managed_probe.subprocess.Popen')as launch:
            with self.assertRaisesRegex(ManagedProbeError,'capture_capacity')as failure:client.run('fixture')
            self.assertFalse(failure.exception.effect_dispatched);launch.assert_not_called()
        self.assertEqual(client.inspect()['capture_count'],8)
        self.assertTrue(client.close()['cleanup_complete']);self.assertEqual(list(self.directory.iterdir()),[])

    def test_prelaunch_pin_permission_and_unknown_profile_fail_without_dispatch(self):
        for key in ('agent_sha256','java_sha256','class_path_sha256'):
            with self.subTest(key=key):
                client=self.client({**self.profile,key:'0'*64})
                with self.assertRaises(ManagedProbeError)as caught:client.run('fixture')
                self.assertFalse(caught.exception.effect_dispatched)
        client=self.client({**self.profile,'allow_run':False})
        for name in ('fixture','not_registered'):
            with self.assertRaises(ManagedProbeError)as caught:client.run(name)
            self.assertFalse(caught.exception.effect_dispatched)

    def test_event_schema_rejects_unbounded_or_invented_address_records(self):
        good=[{'seq':1,'kind':'agent_ready'},
              {'kind':'summary','generated':1,'retained':1,'lost':0,'tag_limit':2048,'tags_assigned':0}]
        events,summary=parse_events(b'\n'.join(json.dumps(e).encode()for e in good),5)
        self.assertEqual(len(events),1)
        bad=[]
        for change in ({'seq':True},{'kind':'memory','address':123},{'address':123},{'seq':2}):
            rows=copy.deepcopy(good);rows[0].update(change);bad.append(rows)
        rows=copy.deepcopy(good);rows[1]['lost']=1;bad.append(rows)
        rows=copy.deepcopy(good);rows.pop();bad.append(rows)
        rows=copy.deepcopy(good);rows[1]['tags_assigned']=2049;bad.append(rows)
        for rows in bad:
            with self.subTest(rows=rows):
                with self.assertRaises(ManagedProbeError):parse_events(b'\n'.join(json.dumps(e).encode()for e in rows),5)
        with self.assertRaises(ManagedProbeError):
            parse_events(b'{"seq":2,"seq":1,"kind":"agent_ready"}\n'+json.dumps(good[1]).encode(),5)

    def test_guardian_pin_failure_after_Popen_retains_and_cleans_owned_JVM(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe'})
        original=os.pidfd_open;pids=[]
        def fail_guardian_pin(pid,*args):
            if pid==os.getpid():return original(pid,*args)
            pids.append(pid);deadline=time.monotonic()+3
            while time.monotonic()<deadline:
                children=Path(f'/proc/{pid}/task/{pid}/children')
                if children.exists()and children.read_text().strip():
                    pids.extend(int(n)for n in children.read_text().split());break
                if not children.exists():
                    for entry in Path('/proc').iterdir():
                        if not entry.name.isdecimal():continue
                        try:status=(entry/'status').read_text()
                        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
                        if re.search(r'^PPid:\s+'+str(pid)+r'\s*$',status,re.M):pids.append(int(entry.name))
                    if len(pids)>1:break
                time.sleep(.01)
            raise OSError(errno.EMFILE,'injected guardian pin failure')
        with patch('observation_extension.managed_probe.os.pidfd_open',side_effect=fail_guardian_pin):
            with self.assertRaises(ManagedProbeError)as caught:client.run('fixture')
        self.assertTrue(caught.exception.effect_dispatched)
        self.assertEqual(len(pids),2)
        for pid in pids:self.gone(pid)
        self.assertEqual(list(self.directory.iterdir()),[])

    def test_wall_budget_cleans_owned_JVM_and_guardian(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe','wall_ms':250})
        with self.assertRaises(ManagedProbeError)as caught:client.run('fixture')
        self.assertTrue(caught.exception.effect_dispatched)
        self.assertIn(str(caught.exception),{'managed_probe_wall_budget','managed_probe_guardian_start_timeout','managed_probe_launch_or_capture_failed'})
        self.assertIsNone(client.inspect()['active_guardian_pid']);self.assertEqual(list(self.directory.iterdir()),[])

    def test_pre_entry_delay_waits_for_armed_guardian_and_preserves_wall_budget(self):
        read_gate,write_gate=os.pipe2(os.O_CLOEXEC)
        bootstrap=f'''import os,runpy,sys,time
time.sleep(0.45)
os.read({read_gate},1)
sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name="__main__")
'''
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe','wall_ms':250})
        original_stop=client._stop
        released=False
        def open_gate(record):
            nonlocal released
            if not released:os.write(write_gate,b'R');released=True
            return original_stop(record)
        try:
            with patch('observation_extension.managed_probe.subprocess.Popen',side_effect=self.guardian_launcher(bootstrap,(read_gate,))),patch.object(client,'_stop',side_effect=open_gate):
                with self.assertRaises(ManagedProbeError)as caught:client.run('fixture')
            self.assertEqual(str(caught.exception),'managed_probe_guardian_start_timeout')
            self.assertTrue(caught.exception.effect_dispatched)
            self.assertIsNone(client.inspect()['active_guardian_pid'])
            self.assertEqual(list(self.directory.iterdir()),[])
        finally:
            os.close(read_gate);os.close(write_gate)

    def test_unarmed_cleanup_timeout_retains_same_authority_for_later_close(self):
        read_gate,write_gate=os.pipe2(os.O_CLOEXEC)
        bootstrap=f'''import os,runpy,sys
os.read({read_gate},1)
sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name="__main__")
'''
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe','wall_ms':250})
        try:
            with patch('observation_extension.managed_probe.subprocess.Popen',side_effect=self.guardian_launcher(bootstrap,(read_gate,))):
                with self.assertRaisesRegex(ManagedProbeError,'managed_probe_cleanup_unresolved')as caught:client.run('fixture')
            self.assertTrue(caught.exception.effect_dispatched)
            retained=client.active
            self.assertIsNotNone(retained)
            self.assertIsNone(retained['child'].poll(),'unarmed guardian must not receive TERM')
            self.assertFalse(client.inspect()['active_guardian_armed'])
            with patch('observation_extension.managed_probe.subprocess.Popen')as launch:
                with self.assertRaisesRegex(ManagedProbeError,'cleanup_pending'):client.run('fixture')
                launch.assert_not_called()
            self.assertIs(client.active,retained)
            os.write(write_gate,b'R')
            self.assertEqual(client.close(),{'cleanup_complete':True,'guardian_retained':False})
            self.gone(retained['child'].pid)
            self.assertIsNone(client.active);self.assertEqual(list(self.directory.iterdir()),[])
        finally:
            os.close(read_gate);os.close(write_gate)

    def test_root_exit_without_complete_receipt_stays_unknown_until_same_run_retries(self):
        marker_read,marker_write=os.pipe2(os.O_CLOEXEC);held=[]
        bootstrap=f'''import os,runpy,sys
arguments=sys.argv[1:];cleanup=int(arguments[arguments.index('--cleanup-fd')+1]);write=os.write
def intercept(fd,data):
 if fd==cleanup and data==b'MP1 COMPLETE\\n':
  write({marker_write},b'C');os._exit(70)
 return write(fd,data)
os.write=intercept;sys.argv=arguments;runpy.run_path(arguments[0],run_name="__main__")
'''
        client=self.client()
        try:
            with patch('observation_extension.managed_probe.subprocess.Popen',side_effect=self.guardian_launcher(bootstrap,(marker_write,),held)):
                with self.assertRaisesRegex(ManagedProbeError,'managed_probe_cleanup_unresolved')as caught:client.run('fixture')
            self.assertTrue(caught.exception.effect_dispatched)
            self.assertTrue(select.select([marker_read],[],[],10)[0])
            self.assertEqual(os.read(marker_read,1),b'C','guardian reached genuine full cleanup before receipt loss')
            retained=client.active
            self.assertIsNotNone(retained);self.assertEqual(retained['child'].returncode,70)
            self.assertTrue(select.select([retained['pidfd']],[],[],0)[0])
            self.assertTrue(select.select([retained['target_fd']],[],[],0)[0])
            self.assertFalse(client.inspect()['active_cleanup_receipt'])
            self.assertEqual(client.close(),{'cleanup_complete':False,'guardian_retained':True})
            self.assertIs(client.active,retained)
            # Replay the genuine completed frame through the same private
            # transport after the induced lost-delivery/guardian70 outcome.
            os.write(held[0],b'MP1 COMPLETE\n');os.close(held.pop())
            self.assertEqual(client.close(),{'cleanup_complete':True,'guardian_retained':False})
            self.assertIsNone(client.active);self.assertEqual(list(self.directory.iterdir()),[])
        finally:
            os.close(marker_read);os.close(marker_write)
            for descriptor in held:os.close(descriptor)

    def test_missing_or_malformed_receipts_never_turn_root_exit_zero_into_tree_proof(self):
        client=self.client()
        for raw in (b'MP1 ARMED\n',b'MP1 COMPLETE\n',b'MP1 ARMED\nBAD\nMP1 COMPLETE\n',b'MP1 ARMED\nMP1 COMPLETE\nx'):
            with self.subTest(raw=raw),tempfile.TemporaryDirectory(dir=self.directory)as directory:
                child=subprocess.Popen([sys.executable,'-c','pass'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                descriptor=os.pidfd_open(child.pid);target=os.dup(descriptor)
                read,write=os.pipe2(os.O_CLOEXEC);os.set_blocking(read,False)
                try:
                    os.write(write,raw)
                    if not raw.endswith(b'x'):os.close(write);write=None
                    child.wait(timeout=10)
                    record={'child':child,'pidfd':descriptor,'target_fd':target,'cleanup_fd':read}
                    self.assertFalse(client._stop(record))
                    self.assertFalse(record.get('released',False))
                    self.assertEqual(child.returncode,0)
                finally:
                    if child.poll()is None:child.kill();child.wait(timeout=10)
                    for stream in (child.stdin,child.stdout,child.stderr):stream.close()
                    for fd in (descriptor,target,read,write):
                        if fd is not None:os.close(fd)

    def test_concurrent_close_before_ready_registration_cannot_acquire_new_authority(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe'})
        original_read=os.read;original_pin=os.pidfd_open;opened=[];observed=[]
        def pin(pid,*args,**kwargs):
            opened.append(pid);return original_pin(pid,*args,**kwargs)
        def read(descriptor,size):
            raw=original_read(descriptor,size)
            if size==128 and re.fullmatch(rb'[1-9][0-9]{0,9}\n',raw) and not observed:
                observed.append(int(raw))
                self.assertTrue(client.close()['cleanup_complete'])
            return raw
        with patch('observation_extension.managed_probe.os.read',side_effect=read),patch('observation_extension.managed_probe.os.pidfd_open',side_effect=pin):
            with self.assertRaisesRegex(ManagedProbeError,'closed_during_run')as caught:client.run('fixture')
        self.assertTrue(caught.exception.effect_dispatched)
        self.assertEqual(len(observed),1);self.assertNotIn(observed[0],opened)
        self.assertIsNone(client.active);self.assertEqual(list(self.directory.iterdir()),[])

    def test_rejected_ready_pid_never_becomes_foreign_target_authority(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe'})
        unrelated=subprocess.Popen(['/bin/sleep','30'])
        unrelated_fd=os.pidfd_open(unrelated.pid)
        original_read=os.read;original_stop=client._stop;replaced=[];target_authority=[]
        def read(descriptor,size):
            raw=original_read(descriptor,size)
            if size==128 and re.fullmatch(rb'[1-9][0-9]{0,9}\n',raw) and not replaced:
                replaced.append(int(raw));return (str(unrelated.pid)+'\n').encode()
            return raw
        def stop(record):
            target_authority.append(record.get('target_fd'))
            return original_stop(record)
        try:
            with patch('observation_extension.managed_probe.os.read',side_effect=read),patch.object(client,'_stop',side_effect=stop):
                with self.assertRaisesRegex(ManagedProbeError,'target_parent_mismatch')as caught:client.run('fixture')
            self.assertTrue(caught.exception.effect_dispatched)
            self.assertEqual(target_authority,[None])
            self.assertIsNone(unrelated.poll());self.assertFalse(select.select([unrelated_fd],[],[],0)[0])
            self.assertIsNone(client.active);self.assertEqual(list(self.directory.iterdir()),[])
        finally:
            if unrelated.poll()is None:unrelated.terminate();unrelated.wait(timeout=10)
            os.close(unrelated_fd)

    def test_close_from_another_thread_cleans_only_the_owned_JVM(self):
        client=self.client({**self.profile,'main_class':'runtimeaccess.probe.SlowProbe'})
        errors=[]
        def capture():
            try:client.run('fixture')
            except ManagedProbeError as error:errors.append(error)
        thread=threading.Thread(target=capture);thread.start()
        deadline=time.monotonic()+3
        while not (info:=client.inspect())['active_target_pid']:
            self.assertLess(time.monotonic(),deadline);time.sleep(.01)
        unrelated=subprocess.Popen(['/bin/sleep','10']);self.addCleanup(lambda:(unrelated.terminate(),unrelated.wait()))
        self.assertTrue(client.close()['cleanup_complete']);thread.join(timeout=5)
        self.assertFalse(thread.is_alive());self.assertTrue(errors and errors[0].effect_dispatched)
        self.gone(info['active_target_pid']);self.gone(info['active_guardian_pid'])
        self.assertIsNone(unrelated.poll())

    def test_host_SIGKILL_independent_guardian_cleans_actual_JVM(self):
        config=self.directory/'config.json';p={**self.profile,'main_class':'runtimeaccess.probe.SlowProbe','wall_ms':15000}
        config.write_text(json.dumps({'profiles':{'fixture':p}}))
        state=self.directory/'state';state.mkdir(mode=0o700)
        script=self.directory/'host.py'
        script.write_text('''import json,sys,threading,time
from pathlib import Path
entry=Path(sys.argv[1])/'runtime-access.pyz'
sys.path.insert(0,str(entry if entry.is_file() else Path(sys.argv[1])/'src'))
from observation_extension.managed_probe import ManagedProbe
client=ManagedProbe(json.load(open(sys.argv[2])),sys.argv[3],bundle_root=sys.argv[1])
threading.Thread(target=lambda:client.run("fixture"),daemon=True).start()
deadline=time.monotonic()+4
while time.monotonic()<deadline:
 value=client.inspect()
 if value['active_target_pid']:
  print(json.dumps(value),flush=True);break
 time.sleep(.01)
time.sleep(30)
''')
        host=subprocess.Popen([sys.executable,'-u',str(script),str(ROOT),str(config),str(state)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            self.assertTrue(select.select([host.stdout],[],[],5)[0])
            info=json.loads(host.stdout.readline())
            host.kill();host.wait(timeout=2)
            self.gone(info['active_target_pid']);self.gone(info['active_guardian_pid'])
        finally:
            if host.poll()is None:host.kill();host.wait(timeout=2)
            host.stdout.close();host.stderr.close()


if __name__=='__main__':unittest.main()
