import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.reverse_native import inspect_reverse
from observation_extension.reverse_mcp import analyze_artifact


class ReverseBackendTests(unittest.TestCase):
    @unittest.skipUnless(os.environ.get('RUNTIME_CROSS_BINARIES') and os.environ.get('RUNTIME_RADARE2'), 'set RUNTIME_CROSS_BINARIES to real cross-compiled PE/Mach-O fixture manifest')
    def test_real_pe_and_macho_instruction_references(self):
        fixtures=json.loads(Path(os.environ['RUNTIME_CROSS_BINARIES']).read_text())
        for entry in fixtures:
            with self.subTest(target=entry['target']):
                binary=Path(entry['path'])
                result=inspect_reverse(str(binary),radare2=os.environ['RUNTIME_RADARE2'],
                    expected_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
                self.assertEqual(result['binary']['abi']['format'],entry['format'])
                self.assertTrue(any(c['references'] for c in result['candidates']))
                self.assertTrue(result['callgraph'])
                self.assertNotIn('token=fixture',json.dumps(result))
                self.assertFalse(result['dynamic_verified'])

    @unittest.skipUnless(os.environ.get('RUNTIME_RADARE2') and shutil.which('gcc'), 'set RUNTIME_RADARE2 to the fixed installed backend')
    def test_real_radare_strings_references_and_callers(self):
        with tempfile.TemporaryDirectory() as directory:
            binary = Path(directory) / 'fixture'
            subprocess.run(['gcc', '-O0', '-fno-inline', '-fno-omit-frame-pointer',
                            str(ROOT / 'tests/fixtures/reverse_routes.c'), '-o', str(binary)], check=True, timeout=10)
            result = inspect_reverse(str(binary), radare2=os.environ['RUNTIME_RADARE2'],
                                     expected_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
            self.assertTrue(result['candidates'])
            self.assertTrue(result['functions'])
            self.assertTrue(result['callgraph'])
            self.assertFalse(result['dynamic_verified'])
            self.assertFalse(result['execution_authorized'])

    @unittest.skipUnless(os.environ.get('RUNTIME_JSHOOK_ENTRY') and shutil.which('node'), 'set RUNTIME_JSHOOK_ENTRY to the fixed installed provider')
    def test_real_jshook_mcp_ast_and_named_function_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'fixture.js'
            source = b"function settings(){return fetch('/interface/settings');}"
            path.write_bytes(source)
            result = analyze_artifact({'path': str(path), 'kind': 'javascript', 'sha256': hashlib.sha256(source).hexdigest()},
                {'argv': [shutil.which('node'), os.environ['RUNTIME_JSHOOK_ENTRY']], 'timeout_seconds': 30})
            self.assertTrue(any(item['name'] == 'settings' for item in result['function_declarations']))
            self.assertTrue(result['calls']['matches'])
            self.assertTrue(result['strings']['matches'])
            self.assertFalse(result['dynamic_verified'])


if __name__ == '__main__': unittest.main()
