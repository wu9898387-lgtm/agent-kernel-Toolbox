"""Real upstream SAILR recovery plus fixed-profile and resource boundaries."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.structured_recovery import StructuredRecovery, StructuredRecoveryError

ANGR_PYTHON = os.environ.get('RUNTIME_ANGR_PYTHON')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class StructuredRecoveryBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.binary = self.root / 'target'
        self.binary.write_bytes(b'not executed')
        self.config = {'python': sys.executable, 'python_sha256': digest(Path(sys.executable).resolve()),
            'profiles': {'owned': {'binary': 'owned', 'sha256': digest(self.binary), 'function': 'owned_function'}}}
        self.binaries = {'owned': str(self.binary)}

    def service(self, config=None, directory=None):
        return StructuredRecovery(config or self.config, directory or self.root / 'state', self.binaries)

    def test_profile_function_budget_and_interpreter_digest_validation(self):
        for patch in [{'function': 'main; system("id")'}, {'function': True}, {'max_blocks': True},
                      {'max_edges': 0}, {'structurers': ['sailr', 'other']}, {'structurer_sha256': None}]:
            config = {**self.config, 'profiles': {'owned': {**self.config['profiles']['owned'], **patch}}}
            with self.subTest(patch=patch), self.assertRaises(StructuredRecoveryError):
                self.service(config)
        with self.assertRaisesRegex(StructuredRecoveryError, 'python_unavailable_or_changed'):
            self.service({**self.config, 'python_sha256': '0' * 64}).inspect()

    def test_unregistered_profile_algorithm_and_target_digest_rejected_before_engine(self):
        service = self.service()
        with self.assertRaisesRegex(StructuredRecoveryError, 'unregistered_profile'):
            service.decompile('not-registered')
        with self.assertRaisesRegex(StructuredRecoveryError, 'structurer_not_allowed'):
            service.decompile('owned', structurer='phoenix')
        self.binary.write_bytes(b'changed')
        with self.assertRaisesRegex(RuntimeError, 'digest_mismatch'):
            service.decompile('owned')

    def test_private_state_directory_and_symlinked_target_are_rejected(self):
        public = self.root / 'public'
        public.mkdir(mode=0o755)
        public.chmod(0o755)
        with self.assertRaisesRegex(StructuredRecoveryError, 'state_must_be_private'):
            self.service(directory=public)
        link = self.root / 'target-link'
        link.symlink_to(self.binary)
        service = StructuredRecovery(self.config, self.root / 'state', {'owned': str(link)})
        with self.assertRaises(OSError):
            service.decompile('owned')


@unittest.skipUnless(ANGR_PYTHON and shutil.which('gcc'),
                     'set RUNTIME_ANGR_PYTHON to an installed angr interpreter for real SAILR checks')
class ActualSAILRTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name)
        cls.binary = cls.root / 'owned-structured-app'
        source = cls.root / 'owned.c'
        source.write_text(r'''
__attribute__((noinline)) int structured_score(int x) {
    int sum=0;
    for (int i=0;i<x;i++) {
        if ((i&1)==0) sum+=i; else sum-=i;
    }
    switch(x&3) { case 0:sum+=11;break; case 1:sum+=7;break;default:sum+=3; }
    return sum;
}
int main(void) { return structured_score(8)!=7; }
''')
        subprocess.run([shutil.which('gcc'), '-O1', '-g', '-fno-inline', '-fno-pie', '-no-pie',
                        str(source), '-o', str(cls.binary)], check=True, timeout=20)
        cls.interpreter = str(Path(ANGR_PYTHON).absolute())
        cls.config = {'python': cls.interpreter,
            'python_sha256': digest(Path(cls.interpreter).resolve()),
            'profiles': {'owned': {'binary': 'owned', 'sha256': digest(cls.binary),
                                   'function': 'structured_score', 'structurers': ['sailr', 'phoenix'],
                                   'timeout_seconds': 60}}}
        cls.service = StructuredRecovery(cls.config, cls.root / 'state', {'owned': str(cls.binary)})

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_real_upstream_sailr_selection_cfg_ail_and_structured_code(self):
        inspected = self.service.inspect()
        self.assertEqual(inspected['status'], 'available')
        self.assertIn('sailr', inspected['algorithms'])
        self.assertEqual(inspected['engine']['structurers']['sailr']['class'],
                         'angr.analyses.decompiler.structuring.sailr.SAILRStructurer')
        result = self.service.decompile('owned')
        self.assertEqual(result['status'], 'decompiled', result)
        self.assertEqual(result['algorithm']['requested'], 'sailr')
        self.assertEqual(result['algorithm']['actual_class'],
                         'angr.analyses.decompiler.structuring.sailr.SAILRStructurer')
        self.assertEqual(result['algorithm']['implementation_sha256'],
                         inspected['engine']['structurers']['sailr']['implementation_sha256'])
        self.assertIn('structured_score', result['pseudocode'])
        self.assertRegex(result['pseudocode'], r'\b(while|for)\b')
        self.assertIn('if (', result['pseudocode'])
        self.assertEqual(result['goto_count'], 0)
        self.assertGreater(result['cfg']['block_count'], 3)
        self.assertGreater(result['cfg']['edge_count'], 3)
        self.assertFalse(result['cfg']['truncated'])
        self.assertTrue(result['ail']['blocks'])
        self.assertEqual(hashlib.sha256(result['pseudocode'].encode()).hexdigest(), result['pseudocode_sha256'])
        self.assertFalse(result['target_executed'])
        self.assertFalse(result['source_equivalence_proven'])
        self.assertFalse(result['dynamic_object_correspondence_proven'])
        self.assertFalse(result['engine_packages_fully_pinned'])
        self.assertEqual(list((self.root / 'state').iterdir()), [])

    def test_phoenix_is_an_explicit_distinct_engine_selection(self):
        result = self.service.decompile('owned', structurer='phoenix')
        self.assertEqual(result['algorithm']['actual_class'],
                         'angr.analyses.decompiler.structuring.phoenix.PhoenixStructurer')
        self.assertFalse(result['target_executed'])

    def test_unknown_function_version_pin_and_structurer_pin_fail_closed(self):
        for config, code in [
                ({**self.config, 'angr_version': 'not-installed'}, 'version_mismatch'),
                ({**self.config, 'profiles': {'owned': {**self.config['profiles']['owned'],
                    'function': 'not_present'}}}, 'function_not_found'),
                ({**self.config, 'profiles': {'owned': {**self.config['profiles']['owned'],
                    'structurer_sha256': '0' * 64}}}, 'structurer_digest_mismatch')]:
            with self.subTest(code=code), self.assertRaisesRegex(StructuredRecoveryError, code):
                StructuredRecovery(config, self.root / 'state', {'owned': str(self.binary)}).decompile('owned')

    def test_cfg_work_and_code_budget_return_unknown_without_claiming_decompilation(self):
        for budget in [{'max_blocks': 1}, {'max_code_bytes': 128}]:
            config = {**self.config, 'profiles': {'owned': {**self.config['profiles']['owned'], **budget}}}
            result = StructuredRecovery(config, self.root / 'state', {'owned': str(self.binary)}).decompile('owned')
            self.assertEqual(result['status'], 'unknown')
            self.assertNotIn('pseudocode', result)
            self.assertFalse(result['target_executed'])

    def test_zipimported_module_extracts_its_worker_and_accepts_fixed_address(self):
        archive = self.root / 'structured-source.pyz'
        if RUNTIME.is_file():
            archive.write_bytes(RUNTIME.read_bytes())
        else:
            with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_STORED) as bundle:
                for source in RUNTIME.rglob('*.py'):
                    bundle.write(source, str(source.relative_to(RUNTIME)))
        # Resolve the fixed function address from compiler-produced symbol data;
        # the model does not supply a function expression or arbitrary address.
        symbol = next(line for line in subprocess.check_output(['nm', str(self.binary)], text=True).splitlines()
                      if line.endswith(' structured_score'))
        config = {**self.config, 'profiles': {'owned': {**self.config['profiles']['owned'],
                                                       'function': int(symbol.split()[0], 16)}}}
        script = '''import json,sys
sys.path.insert(0,sys.argv[1])
from observation_extension.structured_recovery import StructuredRecovery
service=StructuredRecovery(json.loads(sys.argv[2]),sys.argv[3],{'owned':sys.argv[4]})
result=service.decompile('owned')
print(json.dumps(result))
'''
        child = subprocess.run([sys.executable, '-I', '-c', script, str(archive), json.dumps(config),
                                str(self.root / 'zip-state'), str(self.binary)],
                               capture_output=True, text=True, timeout=75)
        self.assertEqual(child.returncode, 0, child.stderr[-8192:])
        result = json.loads(child.stdout)
        self.assertEqual(result['status'], 'decompiled')
        self.assertEqual(result['function']['address'], hex(config['profiles']['owned']['function']))
        self.assertTrue(result['algorithm']['actual_class'].endswith('.SAILRStructurer'))
        self.assertFalse(result['target_executed'])


if __name__ == '__main__':
    unittest.main()
