"""Bind real Kotlin DebugMetadata to live JDI continuation state and resume it.

These are owned JVM programs and compiler-produced state machines. No ART,
physical address, reconstructed Kotlin source or arbitrary debugger expression
is used. Optional tool paths follow the existing real managed-JVM test suite.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

SOURCE = ROOT / 'tests/fixtures/recovery/LiveCoroutineFixture.kt'
sys.path.insert(0, str(RUNTIME))
from observation_extension.managed_jvm import ManagedJvm, ManagedJvmError, classpath_sha256

JAVA = Path(os.environ.get('RUNTIME_JAVA', '/usr/lib/jvm/java-21-openjdk-amd64/bin/java'))
KOTLINC = os.environ.get('RUNTIME_KOTLINC')
TOP = 'runtimeaccess.livecoroutine.LiveCoroutineFixtureKt'
CONTINUATION = TOP + '$calculate$1'
try:
    MODULES = subprocess.check_output([str(JAVA), '--list-modules'], text=True, timeout=3)
    HAS_JDI = all(name + '@' in MODULES for name in ('jdk.compiler', 'jdk.jdi', 'jdk.jdeps'))
except (OSError, subprocess.SubprocessError):
    HAS_JDI = False


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def debug_metadata(javap):
    """Read the compiler's annotation arrays; field names are never guessed."""
    block = re.search(r'kotlin\.coroutines\.jvm\.internal\.DebugMetadata\(\s*(.*?)\n\s*\)',
                      javap, re.DOTALL)
    if block is None:
        raise AssertionError('compiler did not emit coroutine DebugMetadata')
    annotation = block.group(1)
    result = {}
    for name in ('i', 's', 'n', 'l'):
        match = re.search(r'^\s*' + name + r'=\[(.*?)\]\s*$', annotation, re.MULTILINE)
        if match is None:
            raise AssertionError('missing compiler DebugMetadata array ' + name)
        result[name] = json.loads('[' + match.group(1) + ']')
    for name in ('f', 'm', 'c'):
        match = re.search(r'^\s*' + name + r'=(".*")\s*$', annotation, re.MULTILINE)
        if match is None:
            raise AssertionError('missing compiler DebugMetadata scalar ' + name)
        result[name] = json.loads(match.group(1))
    if not len(result['i']) == len(result['s']) == len(result['n']):
        raise AssertionError('inconsistent compiler spill metadata')
    result['state_fields'] = {}
    for state, storage, variable in zip(result['i'], result['s'], result['n']):
        result['state_fields'].setdefault(state + 1, {})[variable] = storage
    return result


@unittest.skipUnless(sys.platform.startswith('linux') and HAS_JDI and KOTLINC
                     and hasattr(os, 'pidfd_open'),
                     'set RUNTIME_KOTLINC and provide a Linux JDK with JDI/compiler/jdeps/pidfd')
class LiveKotlinJvmTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.directory = Path(cls.temporary.name)
        try:
            specification = importlib.util.spec_from_file_location('live_kotlin_jdi_builder',
                ROOT / 'native/managed-jvm/build.py')
            builder = importlib.util.module_from_spec(specification)
            specification.loader.exec_module(builder)
            helper = builder.build(JAVA, cls.directory / 'helper')
            cls.jar = cls.directory / 'owned-coroutine.jar'
            subprocess.run([str(KOTLINC), str(SOURCE), '-jvm-target', '1.8',
                            '-include-runtime', '-d', str(cls.jar)],
                           check=True, capture_output=True, timeout=60)
            if cls.jar.stat().st_size > 16 * 1024 * 1024:
                raise AssertionError('owned fat JAR exceeds managed classpath budget')
            cls.javap = subprocess.check_output([str(JAVA), '--module',
                'jdk.jdeps/com.sun.tools.javap.Main', '-v', '-p', '-classpath',
                str(cls.jar), CONTINUATION], text=True, timeout=15)
            cls.metadata = debug_metadata(cls.javap)
            cls.states = cls.metadata['state_fields']
            if not {1, 2} <= cls.states.keys():
                raise AssertionError('fixture needs two compiler-described suspend states')
            fields = [cls.states[1]['local'], 'label', cls.states[1]['factor']]
            for state in cls.states.values():
                for field in state.values():
                    if field not in fields:
                        fields.append(field)
            cls.config = {'java': str(JAVA.resolve()), 'java_sha256': digest(JAVA.resolve()),
                **helper, 'class_path': str(cls.jar), 'class_path_sha256': classpath_sha256(cls.jar),
                'main_class': TOP, 'root_class': TOP, 'safe_point_method': 'ready',
                'root_field': 'ROOT', 'fields': fields, 'methods': [], 'patches': {}}
        except BaseException:
            cls.temporary.cleanup()
            raise

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def client(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        client = ManagedJvm(self.config, Path(temporary.name), bundle_root=ROOT)
        self.addCleanup(client.close)
        self.assertTrue(client.initial['ok'], client.initial)
        return client

    def assert_state(self, snapshot, state, expected_local):
        self.assertTrue(snapshot['ok'], snapshot)
        self.assertEqual(snapshot['type'], CONTINUATION)
        self.assertEqual(snapshot['values']['label'], state)
        field = self.states[state]['local']
        self.assertEqual(snapshot['values'][field], expected_local)
        self.assertFalse(snapshot['physical_address_known'])
        actual_layout = {item['name']: item for item in snapshot['layout']}
        self.assertEqual(actual_layout[field]['signature'], 'I')
        self.assertEqual(actual_layout['label']['signature'], 'I')
        self.assertTrue(all(item['declaring_type'] == CONTINUATION for item in actual_layout.values()))
        self.assertTrue(all(item['location_source'] == 'JVM_runtime_field_metadata'
                            for item in actual_layout.values()))
        self.assertFalse(any('offset' in item or 'address' in item for item in actual_layout.values()))
        factor = snapshot['values'][self.states[state]['factor']]
        self.assertEqual(factor['type'], 'runtimeaccess.livecoroutine.Factor')
        return factor['object_id']

    def wait_output(self, client, token):
        deadline = time.monotonic() + 2
        while True:
            snapshot = client.snapshot()
            self.assertTrue(snapshot['ok'], snapshot)
            if token in snapshot['stdout']['prefix']:
                return snapshot
            self.assertLess(time.monotonic(), deadline, snapshot['stdout'])
            time.sleep(.01)

    def assert_gc_observed(self, output):
        collections = re.findall(r'live-coroutine-gc:(first|second):(\d+):(\d+)', output)
        self.assertEqual([row[0] for row in collections], ['first', 'second'])
        for label, before, after in collections:
            self.assertGreater(int(after), int(before), 'owned JVM GC did not run at ' + label)

    def evidence(self, phase, first, second, final, factor_id, expected_result):
        print('KOTLIN_JDI_EVIDENCE ' + json.dumps({
            'phase': phase, 'jar_sha256': digest(self.jar),
            'continuation_type': CONTINUATION, 'object_id': first['object_id'],
            'second_object_id': second['object_id'], 'final_object_id': final['object_id'],
            'captured_factor_object_id': factor_id, 'compiler_state_fields': self.states,
            'first_local': first['values'][self.states[1]['local']],
            'second_local': second['values'][self.states[2]['local']],
            'business_result': expected_result,
            'gc_counters': re.findall(r'live-coroutine-gc:(first|second):(\d+):(\d+)',
                                      final['stdout']['prefix']),
            'runtime': final['runtime'], 'vm_version': final['vm_version'],
            'physical_address_known': False, 'source_equivalence_proven': False,
            'ART_execution_verified': False}, sort_keys=True))

    def test_compiler_metadata_binds_two_states_to_concrete_jvm_fields(self):
        self.assertEqual(self.metadata['f'], SOURCE.name)
        self.assertEqual(self.metadata['m'], 'calculate')
        self.assertEqual(self.metadata['c'], TOP)
        self.assertEqual(len(self.metadata['l']), 2)
        for line in self.metadata['l']:
            self.assertIn('suspendCoroutineUninterceptedOrReturn', SOURCE.read_text().splitlines()[line - 1])
        for state in (1, 2):
            self.assertIn('local', self.states[state])
            self.assertIn('factor', self.states[state])
            self.assertRegex(self.javap, r'\bint\s+' + re.escape(self.states[state]['local']) + ';')
            self.assertRegex(self.javap, r'\bjava\.lang\.Object\s+' + re.escape(self.states[state]['factor']) + ';')
        with zipfile.ZipFile(self.jar) as archive:
            self.assertIn(CONTINUATION.replace('.', '/') + '.class', archive.namelist())
            self.assertIn('kotlin/coroutines/jvm/internal/DebugMetadata.class', archive.namelist())

    def test_unmodified_real_continuation_resumes_twice_and_keeps_identity_through_gc(self):
        client = self.client()
        first = client.snapshot()
        factor_id = self.assert_state(first, 1, 3)
        second = client.advance()
        self.assertEqual(self.assert_state(second, 2, 13), factor_id)
        self.assertEqual(second['object_id'], first['object_id'])
        final = client.advance()
        self.assertTrue(final['ok'], final)
        final = self.wait_output(client, 'live-coroutine-result=37')
        self.assertEqual(final['object_id'], first['object_id'])
        self.assert_gc_observed(final['stdout']['prefix'])
        self.assertFalse(final['physical_address_known'])
        self.evidence('baseline', first, second, final, factor_id, 37)
        self.assertTrue(client.close()['target_exit_confirmed'])

    def test_metadata_located_spill_compare_write_changes_real_post_resume_result(self):
        client = self.client()
        first = client.snapshot()
        factor_id = self.assert_state(first, 1, 3)
        local = self.states[1]['local']
        refused = client.set_field(first['object_id'], local, 99, 9)
        self.assertFalse(refused['ok'], refused)
        self.assertEqual(refused['error'], 'managed_precondition_mismatch')
        self.assertFalse(refused['dispatched'])
        self.assertEqual(client.snapshot()['values'][local], 3)
        changed = client.set_field(first['object_id'], local, 3, 9)
        self.assertTrue(changed['ok'], changed)
        self.assertEqual(changed['status'], 'verified')
        self.assertEqual(changed['snapshot']['values'][local], 9)
        with self.assertRaisesRegex(ManagedJvmError, 'managed_method_not_allowed'):
            client.invoke(first['object_id'], 'invokeSuspend', 9, 10)
        second = client.advance()
        self.assertEqual(self.assert_state(second, 2, 19), factor_id)
        self.assertEqual(second['object_id'], first['object_id'])
        final = client.advance()
        self.assertTrue(final['ok'], final)
        final = self.wait_output(client, 'live-coroutine-result=43')
        self.assertNotIn('live-coroutine-result=37', final['stdout']['prefix'])
        self.assertEqual(final['object_id'], first['object_id'])
        self.assert_gc_observed(final['stdout']['prefix'])
        self.assertFalse(client.unresolved)
        self.evidence('spill_3_to_9', first, second, final, factor_id, 43)
        self.assertTrue(client.close()['target_exit_confirmed'])


if __name__ == '__main__':
    unittest.main()
