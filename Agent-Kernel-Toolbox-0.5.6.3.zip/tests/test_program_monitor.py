"""Reducer and backend-contract tests only; these do not emulate a real probe.

NativeProbe/GCC/ASLR/Frida acceptance lives in the real backend/host tests. Here
explicit source dictionaries exercise loss, identity and arithmetic invariants
inside TraceState. No MCP endpoint accepts these dictionaries from a model.
"""
import copy
import random
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.program_monitor import ProgramMonitor,ProgramMonitorError,TraceState,canonical

SHA='a'*64
SOURCE='owned-probe-session'


def event(seq,kind,**values):
    return {'source':'native_probe','session_id':SOURCE,'seq':seq,'kind':kind,**values}


def feed(state,kind,**values):
    row=event(state.source_cursor+1,kind,**values);state.feed(row);return row


def allocation(state,operation='malloc',address='0x1000',size=16,success=True,**values):
    return feed(state,'allocation',operation=operation,address=address,size=size,success=success,**values)


def publish(state,operation='define',object_id=71,generation=1,address='0x1000',size=16,**values):
    if operation=='define':values.setdefault('type_slot',3)
    return feed(state,'object',operation=operation,object_id=object_id,generation=generation,address=address,size=size,**values)


def memory(state,address='0x1000',size=4,**values):
    return feed(state,'memory',address=address,size=size,access='read',phase='before',committed=False,**values)


def accesses(state):return [x for x in state.records if x['kind']=='memory_access']


def record_type(identity='record',name='Local',field_name='value',offset=0,size=8):
    return {'id':identity,'name':name,'kind':'structure_type','byte_size':size,'layout_known':True,
            'members':[{'name':field_name,'byte_offset':offset,'byte_size':4,'known':True,'overlapping_storage':False}]}


def metadata(types=None,variables=None,first_vaddr=0,elf_type='ET_DYN'):
    return {'artifact':{'sha256':SHA},'types':types or [record_type()], 'variables':variables or [],
            'elf':{'type':elf_type,'class_bits':64,'machine':'EM_X86_64','endianness':'little',
                   'load_segments':[{'p_vaddr':hex(first_vaddr),'p_offset':hex(first_vaddr&0xffff),'p_memsz':'0x100000','p_filesz':'0x100000','p_align':'0x1000','flags':6}]}}


def variable(name='global',type_id='record',address=0x3100,die_offset='0x41',size=8):
    return {'name':name,'type_id':type_id,'die_offset':die_offset,'byte_size':size,
            'location':{'kind':'module_relative','elf_virtual_address':hex(address),'load_bias_required':True,'live_address':None}}


class StubNativeProbe:
    """A contract fixture, not evidence of live probing or event authenticity."""
    def __init__(self,events=(),*,state='running',dropped=0,sha=SHA,coverage=None):
        self.events=list(events);self.state=state;self.dropped=dropped;self.sha=sha
        self.coverage=coverage or {}
        self.opens=0;self.polls=[];self.closes=[];self.fail_close=False;self.close_result={'closed':True}
    def profile_identity(self,profile):return {'binary_sha256':self.sha}
    def open(self,profile):self.opens+=1;return {'probe_session':SOURCE}
    def poll(self,session,cursor=0,max_events=128):
        self.polls.append(cursor)
        rows=[copy.deepcopy(x) for x in self.events if x['seq']>cursor][:max_events]
        return {'probe_session':session,'events':rows,'next_cursor':rows[-1]['seq'] if rows else cursor,
                'state':self.state,'dropped':self.dropped,'coverage':{'dropped':self.dropped,**self.coverage},
                'cleanup':{'control':'closed'} if self.state=='closed' else None}
    def close(self,session=None):
        self.closes.append(session)
        if self.fail_close:raise RuntimeError('owned cleanup fixture failure')
        return self.close_result


class StubMetadata:
    def __init__(self,value):self.value=value
    def extract(self,profile):return copy.deepcopy(self.value)


class ProgramReducerTests(unittest.TestCase):
    def state(self,**kw):return TraceState(SOURCE,SHA,**kw)

    def test_real_free_null_size_contract_ends_block_and_backing_identity(self):
        state=self.state();allocation(state);publish(state)
        original=next(iter(state.allocations))
        allocation(state,'free',size=None)
        self.assertNotIn(original,state.allocations)
        self.assertFalse(state.objects['71']['certain']);self.assertNotEqual(state.objects['71']['state'],'live')
        self.assertEqual(state.violations,0)
        allocation(state,'free',address='0x0',size=None)
        self.assertEqual(state.violations,0)

    def test_failed_realloc_preserves_old_block_but_zero_unknown_invalidates_it(self):
        state=self.state();allocation(state);publish(state)
        before=next(iter(state.allocations))
        allocation(state,'realloc',address='0x0',size=8192,success=False,old_address='0x1000')
        self.assertIn(before,state.allocations);self.assertTrue(state.allocations[before]['certain']);self.assertTrue(state.objects['71']['certain'])
        allocation(state,'realloc',address='0x0',size=0,success=None,old_address='0x1000',zero_size_behavior='implementation_defined_old_allocation_may_be_freed')
        self.assertFalse(state.allocations[before]['certain']);self.assertFalse(state.objects['71']['certain'])
        self.assertFalse(state.lifetimes_complete)
        memory(state);self.assertIsNone(accesses(state)[-1]['object']);self.assertIsNone(accesses(state)[-1]['allocation'])

    def test_reuse_creates_new_allocation_incarnation_and_never_revives_old_object(self):
        state=self.state();allocation(state);publish(state)
        old=next(iter(state.allocations));publish(state,'retire');allocation(state,'free',size=None)
        allocation(state);new=next(iter(state.allocations));self.assertNotEqual(old,new)
        memory(state);self.assertIsNone(accesses(state)[-1]['object'])
        publish(state,object_id=72,generation=2);memory(state)
        last=accesses(state)[-1]
        self.assertEqual(last['object']['object_id'],'72');self.assertEqual(last['allocation']['allocation_id'],new)
        self.assertEqual(state.objects['71']['state'],'retired')

    def test_realloc_move_preserves_semantic_generation_and_increments_location_epoch(self):
        state=self.state();allocation(state);publish(state,generation=7)
        old_block=next(iter(state.allocations))
        allocation(state,'realloc',address='0x3000',size=64,old_address='0x1000')
        self.assertFalse(state.objects['71']['certain'])
        publish(state,'move',generation=7,address='0x3000',size=64)
        obj=state.objects['71']
        self.assertEqual(obj['generation'],7);self.assertEqual(obj['observed_location_epoch'],2)
        self.assertEqual(obj['history'][-1]['address'],'0x1000');self.assertTrue(obj['certain'])
        self.assertNotEqual(obj['allocation_id'],old_block)
        memory(state,address='0x1000');self.assertIsNone(accesses(state)[-1]['object'])
        memory(state,address='0x3000');self.assertEqual(accesses(state)[-1]['object']['generation'],'7')
        publish(state,'move',generation=8,address='0x4000',size=64)
        self.assertEqual(state.objects['71']['address'],0x3000);self.assertGreater(state.violations,0)

    def test_overlapping_observed_heap_allocation_invalidates_old_object_binding(self):
        state=self.state();allocation(state);publish(state);allocation(state)
        self.assertFalse(state.objects['71']['certain'])
        memory(state);self.assertIsNone(accesses(state)[-1]['object'])
        self.assertFalse(state.lifetimes_complete)

    def test_aslr_pie_exec_and_actual_page_size_resolve_only_after_matching_module(self):
        for kind,lowest,base,page,global_vaddr,expected in [
            ('ET_DYN',0,0x70000000,4096,0x3100,0x70003100),
            ('ET_EXEC',0x400000,0x400000,4096,0x404100,0x404100),
            ('ET_DYN',0x12345,0x60000000,16384,0x16000,0x60006000),
        ]:
            with self.subTest(kind=kind,page=page):
                state=self.state(metadata=metadata(variables=[variable(address=global_vaddr)],first_vaddr=lowest,elf_type=kind))
                self.assertEqual(len(state.objects),0)
                feed(state,'module',base=hex(base),page_size=page,build_sha='b'*64)
                self.assertEqual(len(state.objects),0)
                feed(state,'module',base=hex(base),page_size=page,build_sha=SHA)
                obj=next(iter(state.objects.values()))
                self.assertEqual(obj['address'],expected)
                self.assertEqual(int(state.module['load_bias']),base-(lowest//page*page))

    def test_exact_global_die_survives_typedef_qualifiers_and_duplicate_type_names(self):
        types=[record_type('first','Local','wrong_cu',0),record_type('second','Local','correct_cu',4),
               {'id':'alias','name':'Local','kind':'typedef','type_id':'second','byte_size':8,'members':[]},
               {'id':'qualified','name':None,'kind':'const_type','type_id':'alias','byte_size':8,'members':[]}]
        state=self.state(metadata=metadata(types, [variable(type_id='qualified')]))
        feed(state,'module',base='0x70000000',page_size=4096,build_sha=SHA)
        memory(state,address='0x70003104')
        self.assertEqual([x['name'] for x in accesses(state)[-1]['fields']],['correct_cu'])
        memory(state,address='0x70003100')
        self.assertEqual(accesses(state)[-1]['fields'],[])
        self.assertEqual(len(state.objects),1)

    def test_ambiguous_name_slot_has_no_guessed_layout_and_static_name_is_not_identity(self):
        types=[record_type('first','Local','one',0),record_type('second','Local','two',4)]
        state=self.state(metadata=metadata(types),type_slots={'3':'Local'})
        allocation(state);publish(state);memory(state)
        self.assertEqual(accesses(state)[-1]['fields'],[])
        variables=[variable('same_static','first',0x3100,'0x41'),variable('same_static','second',0x3200,'0x81')]
        state=self.state(metadata=metadata(types,variables))
        feed(state,'module',base='0x70000000',page_size=4096,build_sha=SHA)
        self.assertEqual(len(state.objects),2)
        self.assertEqual({x['address'] for x in state.objects.values()},{0x70003100,0x70003200})

    def test_effective_address_arithmetic_wrap_rip_and_invalid_evidence(self):
        cases=[('0x1014',{'base_register':'rax','base_value':'0x1000','index_register':'rcx','index_value':'0x3','scale':8,'disp':-4,'address_bits':64,'pc_next':'0x2000','rip_relative':False}),
               ('0x10',{'base_register':'eax','base_value':'0xfffffff0','index_register':'ecx','index_value':'0x8','scale':4,'disp':0,'address_bits':32,'pc_next':'0x2000','rip_relative':False}),
               ('0x5000',{'base_register':'rip','base_value':'0x5010','index_register':None,'index_value':'0x0','scale':1,'disp':-16,'address_bits':64,'pc_next':'0x5010','rip_relative':True})]
        state=self.state()
        for addr,evidence in cases:
            memory(state,address=addr,address_evidence=evidence)
            self.assertTrue(accesses(state)[-1]['effective_address_arithmetic_verified'])
            self.assertFalse(accesses(state)[-1]['committed']);self.assertFalse(accesses(state)[-1]['value_read_by_monitor'])
        count=len(accesses(state))
        memory(state,address='0x1015',address_evidence=cases[0][1]);self.assertEqual(len(accesses(state)),count)
        wrong_rip={**cases[-1][1],'base_value':'0x6000','pc_next':'0x5010','disp':0}
        memory(state,address='0x6000',address_evidence=wrong_rip);self.assertEqual(len(accesses(state)),count)
        missing_base={**cases[0][1],'base_register':None}
        memory(state,address='0x1014',address_evidence=missing_base);self.assertEqual(len(accesses(state)),count)
        memory(state,address='0x1234');self.assertFalse(accesses(state)[-1]['effective_address_arithmetic_verified'])

    def test_source_gap_and_source_mismatch_never_preserve_certain_old_identity(self):
        state=self.state();allocation(state);publish(state)
        state.feed(event(9,'memory',address='0x1000',size=4,access='read',phase='before',committed=False))
        self.assertFalse(state.objects['71']['certain']);self.assertIsNone(accesses(state)[-1]['object'])
        self.assertEqual(state.gaps,1);self.assertFalse(state.lifetimes_complete)
        with self.assertRaises(ProgramMonitorError):state.feed({**event(10,'instruction'),'session_id':'not-owned'})
        self.assertEqual(state.source_cursor,9)

    def test_bounded_report_cursor_retains_unreturned_records_and_marks_eviction(self):
        fields=[{'name':'field_'+str(i)+'x'*80,'byte_offset':0,'byte_size':4,'known':True,'overlapping_storage':True} for i in range(64)]
        t=record_type();t.update(kind='union_type',members=fields,overlapping_members=True)
        state=self.state(metadata=metadata([t]),type_slots={'3':'Local'},max_records=128)
        allocation(state);publish(state)
        for _ in range(24):memory(state)
        cursor=0;seen=[]
        for _ in range(40):
            report=state.report(cursor,32)
            self.assertLessEqual(len(canonical(report)),48*1024)
            self.assertFalse(report['cursor_gap'])
            rows=report['events'];seen.extend(x['cursor'] for x in rows)
            if not rows:break
            self.assertEqual(report['next_cursor'],rows[-1]['cursor']);cursor=report['next_cursor']
        self.assertEqual(seen,list(range(1,state.record_cursor+1)))
        small=self.state(max_records=8)
        for _ in range(20):feed(small,'instruction',pc='0x1234')
        report=small.report(0,32)
        self.assertTrue(report['cursor_gap']);self.assertEqual(report['records_evicted'],12)

    def test_seeded_allocation_reuse_never_reuses_an_incarnation_or_resurrects_object(self):
        rng=random.Random(5533);state=self.state(max_records=64);active={};seen=set();generations={}
        for _ in range(180):
            slot=rng.randrange(8);address=0x10000+slot*256
            if slot not in active:
                allocation(state,address=hex(address));block=next(x for x in state.allocations.values() if x['address']==address)
                self.assertNotIn(block['allocation_id'],seen);seen.add(block['allocation_id']);active[slot]=block['allocation_id']
                generations[slot]=generations.get(slot,0)+1
                publish(state,object_id=slot+1,generation=generations[slot],address=hex(address))
            elif rng.choice([True,False]):
                allocation(state,'free',address=hex(address),size=None);del active[slot]
                self.assertFalse(state.objects[str(slot+1)]['certain'])
            else:
                allocation(state,'realloc',address='0x0',size=4096,success=False,old_address=hex(address))
                self.assertTrue(state.objects[str(slot+1)]['certain'])
            self.assertEqual(set(state.allocations),set(active.values()))
            self.assertEqual(state.violations,0)
        self.assertGreater(len(seen),8)


class ProgramMonitorContractTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.count=0

    def monitor(self,probe,meta=None):
        self.count+=1
        profile={'probe_profile':'owned'}
        if meta is not None:profile['metadata_profile']='layout'
        monitor=ProgramMonitor({'profiles':{'joined':profile}},self.root/('state'+str(self.count)),native_probe=probe,compiler_metadata=StubMetadata(meta) if meta is not None else None)
        self.addCleanup(monitor.close);return monitor

    def test_metadata_artifact_pin_mismatch_is_preflight_and_close_failure_is_visible(self):
        probe=StubNativeProbe();wrong=metadata();wrong['artifact']['sha256']='b'*64
        monitor=self.monitor(probe,wrong)
        with self.assertRaises(ProgramMonitorError) as caught:monitor.open('joined')
        self.assertFalse(caught.exception.effect_dispatched);self.assertEqual(probe.opens,0)
        monitor=self.monitor(probe);session=monitor.open('joined')['monitor_session']
        probe.fail_close=True
        result=monitor.close(session)
        self.assertFalse(result['closed']);self.assertEqual(result['cleanup_errors'],[session])
        self.assertFalse(monitor.sessions[session]['closed'])
        probe.fail_close=False
        for bad in ({'closed':False},{'closed':True,'cleanup_complete':False},{'closed':True,'cleanup_errors':['owned-fixture']}):
            probe.close_result=bad
            self.assertFalse(monitor.close(session)['closed'])
            self.assertFalse(monitor.sessions[session]['closed'])
        probe.close_result={'closed':True};self.assertTrue(monitor.close(session)['closed'])

    def test_dropped_counter_increase_invalidates_identity_even_if_seq_is_contiguous(self):
        probe=StubNativeProbe([event(1,'allocation',operation='malloc',address='0x1000',size=16,success=True),event(2,'object',operation='define',object_id=71,generation=1,address='0x1000',size=16,type_slot=3)])
        monitor=self.monitor(probe);session=monitor.open('joined')['monitor_session']
        first=monitor.poll(session);state=monitor.sessions[session]['state'];self.assertTrue(state.objects['71']['certain'])
        probe.dropped=2
        result=monitor.poll(session,cursor=first['next_cursor'])
        self.assertFalse(state.objects['71']['certain']);self.assertFalse(result['coverage']['allocation_lifetimes_complete'])
        gaps=state.gaps;monitor.poll(session,cursor=result['next_cursor']);self.assertEqual(state.gaps,gaps)

    def test_closed_source_drains_backlog_before_marking_addresses_dead(self):
        rows=[event(1,'allocation',operation='malloc',address='0x1000',size=16,success=True),event(2,'object',operation='define',object_id=71,generation=1,address='0x1000',size=16,type_slot=3)]
        rows.extend(event(seq,'instruction',pc='0x1234') for seq in range(3,301))
        rows.append(event(301,'allocation',operation='free',address='0x1000',size=None,success=True))
        probe=StubNativeProbe(rows,state='closed');monitor=self.monitor(probe)
        session=monitor.open('joined')['monitor_session'];first=monitor.poll(session)
        state=monitor.sessions[session]['state']
        if state.source_cursor<len(rows):self.assertFalse(state.ended)
        cursor=first['next_cursor']
        for _ in range(16):
            result=monitor.poll(session,cursor=cursor)
            cursor=result['next_cursor']
            if state.ended:break
        self.assertEqual(state.source_cursor,301);self.assertTrue(state.ended)
        self.assertFalse(state.allocations);self.assertEqual(result['live_allocations'],0)
        self.assertFalse(state.objects['71']['certain'])
        self.assertEqual(probe.polls[0],0)
        self.assertTrue(any(cursor>=256 for cursor in probe.polls))

    def test_closed_source_without_free_never_exposes_former_address_as_live(self):
        rows=[event(1,'allocation',operation='malloc',address='0x1000',size=16,success=True),event(2,'object',operation='define',object_id=71,generation=1,address='0x1000',size=16,type_slot=3)]
        probe=StubNativeProbe(rows,state='closed');monitor=self.monitor(probe)
        session=monitor.open('joined')['monitor_session'];result=monitor.poll(session)
        self.assertEqual(result['live_allocations'],0)
        self.assertFalse(monitor.sessions[session]['state'].objects['71']['certain'])

    def test_budget_stopped_hooks_in_live_process_never_expose_current_objects(self):
        rows=[event(1,'allocation',operation='malloc',address='0x1000',size=16,success=True),event(2,'object',operation='define',object_id=71,generation=1,address='0x1000',size=16,type_slot=3)]
        rows.extend(event(seq,'instruction',pc='0x1234') for seq in range(3,301))
        rows.append(event(301,'memory',address='0x1000',size=4,access='read',phase='before',committed=False))
        probe=StubNativeProbe(rows,coverage={'stopped':True,'stop_reason':'instruction_budget'})
        monitor=self.monitor(probe);session=monitor.open('joined')['monitor_session']
        result=monitor.poll(session);state=monitor.sessions[session]['state'];seen=list(result['events'])
        self.assertEqual(result['source_status']['state'],'running');self.assertEqual(result['source_status']['dropped'],0)
        self.assertFalse(result['coverage']['source_observation_current'])
        self.assertEqual(result['live_allocations'],0);self.assertFalse(result['object_summary'][0]['certain'])
        for _ in range(20):
            result=monitor.poll(session,cursor=result['next_cursor']);seen.extend(result['events'])
            self.assertFalse(result['coverage']['source_observation_current'])
            if state.source_cursor==301 and result['next_cursor']==state.record_cursor:break
        historical=[row for row in seen if row['kind']=='memory_access']
        self.assertEqual(state.source_cursor,301);self.assertEqual(historical[-1]['object']['object_id'],'71')
        self.assertFalse(state.ended);self.assertFalse(result['closed'])
        self.assertEqual(result['live_allocations'],0);self.assertFalse(result['object_summary'][0]['certain'])

    def test_cached_pages_refresh_stop_exit_and_loss_without_consuming_source_events(self):
        for change in ('budget_stop','process_exit','event_loss'):
            with self.subTest(change=change):
                rows=[event(1,'allocation',operation='malloc',address='0x1000',size=16,success=True),
                      event(2,'object',operation='define',object_id=71,generation=1,address='0x1000',size=16,type_slot=3)]
                rows.extend(event(seq,'instruction',pc='0x1234') for seq in range(3,66))
                probe=StubNativeProbe(rows);monitor=self.monitor(probe)
                session=monitor.open('joined')['monitor_session']
                first=monitor.poll(session,max_events=1)
                state=monitor.sessions[session]['state']
                self.assertEqual((first['next_cursor'],state.source_cursor,state.record_cursor),(1,64,64))
                if change=='budget_stop':probe.coverage={'stopped':True,'stop_reason':'instruction_budget'}
                elif change=='process_exit':probe.state='closed'
                else:probe.dropped=1
                second=monitor.poll(session,cursor=first['next_cursor'],max_events=1)
                self.assertEqual(probe.polls,[0,64])
                self.assertEqual(state.source_cursor,64,'status refresh must preserve source-event backpressure')
                self.assertEqual(second['events'][0]['cursor'],2)
                self.assertFalse(second['object_summary'][0]['certain'])
                self.assertEqual(second['live_allocations'],0)
                if change=='event_loss':
                    self.assertEqual(second['source_status']['dropped'],1)
                    self.assertEqual(second['coverage']['source_gaps'],1)
                    repeated=monitor.poll(session,cursor=0,max_events=1)
                    self.assertEqual(repeated['coverage']['source_gaps'],1)
                else:
                    self.assertFalse(second['coverage']['source_observation_current'])
                    self.assertEqual(second['object_summary'][0]['state'],'source_ended')
                    self.assertFalse(state.ended,'a terminal source still has unread historical events')

if __name__=='__main__':unittest.main()
