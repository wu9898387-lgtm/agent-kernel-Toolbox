import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import tempfile
import time
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PackageTests(unittest.TestCase):
    def test_embedded_sources_extract_and_rebuild_without_overwriting(self):
        builder = load('source_extraction_builder', 'build-source.py')
        verifier = load('source_extraction_verifier', 'verify-runtime.py')
        raw = builder.build()
        with tempfile.TemporaryDirectory() as temporary:
            package = Path(temporary)
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                archive.extractall(package)
            source_root = package / 'src'
            command = [sys.executable, str(package / 'tools/extract_sources.py'),
                       '--output', str(source_root)]
            extracted = subprocess.run(command, capture_output=True, text=True, timeout=10)
            self.assertEqual(extracted.returncode, 0, extracted.stdout + extracted.stderr)
            self.assertEqual(json.loads(extracted.stdout)['python_members'], 49)
            source = source_root / 'observation_extension/version.py'
            original = source.read_bytes()
            repeated = subprocess.run(command, capture_output=True, text=True, timeout=10)
            self.assertEqual(repeated.returncode, 2)
            self.assertEqual(source.read_bytes(), original, 'existing sources were overwritten')
            self.assertEqual(builder.build(package), raw)
            changed = original + b'\n# local source customization\n'
            source.write_bytes(changed)
            rebuilt = builder.build(package)
            self.assertTrue(verifier.verify(rebuilt)['runtime_sources_verified'])
            with zipfile.ZipFile(io.BytesIO(rebuilt)) as outer:
                self.assertFalse(any(name.startswith('src/') for name in outer.namelist()))
                with zipfile.ZipFile(io.BytesIO(outer.read('runtime-access.pyz'))) as inner:
                    self.assertEqual(inner.read('observation_extension/version.py'), changed)

    def test_reproducible_source_bundle_and_pinned_verification(self):
        builder = load('builder', 'build-source.py')
        verifier = load('verifier', 'verify-runtime.py')
        raw = builder.build()
        self.assertEqual(raw, builder.build())
        result = verifier.verify(raw, hashlib.sha256(raw).hexdigest())
        self.assertEqual(result['package_version'], '0.5.6.2')
        with zipfile.ZipFile(io.BytesIO(raw)) as outer:
            inventory = json.loads(outer.read('CONTENTS.json'))
            with zipfile.ZipFile(io.BytesIO(outer.read('runtime-access.pyz'))) as inner:
                for name in inner.namelist():
                    self.assertEqual(hashlib.sha256(inner.read(name)).hexdigest(), inventory['python_files'][name])
                    self.assertNotIn('src/' + name, outer.namelist())
            # The shipped rebuild entrypoint must work with the single source
            # copy inside the zipapp, without a development checkout beside it.
            with tempfile.TemporaryDirectory() as temporary:
                package = Path(temporary)
                outer.extractall(package)
                rebuilt = package / 'rebuilt.zip'
                process = subprocess.run([sys.executable, str(package / 'build-source.py'),
                    '--output', str(rebuilt)], capture_output=True, text=True, timeout=20)
                self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
                self.assertEqual(rebuilt.read_bytes(), raw)
        with self.assertRaisesRegex(ValueError, 'archive_digest_mismatch'):
            verifier.verify(raw, '0' * 64)
        oversized = io.BytesIO()
        with zipfile.ZipFile(oversized, 'w', compression=zipfile.ZIP_STORED) as archive:
            for number in range(verifier.MAX_ENTRIES + 1):
                archive.writestr(str(number) + '.txt', b'')
        with self.assertRaisesRegex(ValueError, 'entry_limit'):
            verifier.verify(oversized.getvalue())

    def test_packaged_stdio_entrypoint(self):
        builder = load('entrypoint_builder', 'build-source.py')
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            with zipfile.ZipFile(io.BytesIO(builder.build())) as outer:
                (directory / 'runtime-access.pyz').write_bytes(outer.read('runtime-access.pyz'))
            config = {'schema_version': 1, 'state_directory': str(directory / 'state'),
                      'allowed_tools': ['runtime.status']}
            path = directory / 'config.json'
            path.write_text(json.dumps(config))
            messages = [
                {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
                    'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {}}},
                {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
                {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'runtime.status'}}]
            result = subprocess.run([sys.executable, str(directory / 'runtime-access.pyz'), 'serve',
                                     '--config', str(path)], input=''.join(json.dumps(m) + '\n' for m in messages),
                                    text=True, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            replies = [json.loads(line) for line in result.stdout.splitlines()]
            self.assertEqual(replies[0]['result']['serverInfo']['version'], '0.5.6.2')
            self.assertTrue(replies[1]['result']['structuredContent']['ok'])
            self.assertIn('receipt_sha256', replies[1]['result']['structuredContent']['evidence'])

    def test_packaged_process_exit_status_through_stdio_mcp(self):
        builder = load('lifecycle_builder', 'build-source.py')
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            with zipfile.ZipFile(io.BytesIO(builder.build())) as outer:
                (directory / 'runtime-access.pyz').write_bytes(outer.read('runtime-access.pyz'))
            config = {'schema_version': 1, 'state_directory': str(directory / 'state'),
                      'allowed_tools': ['process.launch', 'process.status', 'process.terminate'],
                      'profiles': {'short': {'argv': ['/bin/sh', '-c', 'exit 7']}}}
            path = directory / 'config.json'; path.write_text(json.dumps(config))
            child = subprocess.Popen([sys.executable, str(directory / 'runtime-access.pyz'),
                                      'serve', '--config', str(path)], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            sequence = 0
            def send(method, params, *, notify=False):
                nonlocal sequence
                sequence += 1
                message = {'jsonrpc': '2.0', 'method': method, 'params': params}
                if not notify: message['id'] = sequence
                child.stdin.write((json.dumps(message) + '\n').encode())
                if notify:return
                data = bytearray();deadline = time.monotonic() + 5
                while not data.endswith(b'\n'):
                    self.assertTrue(select.select([child.stdout], [], [], max(0, deadline-time.monotonic()))[0], 'MCP reply timed out')
                    byte = os.read(child.stdout.fileno(), 1);self.assertTrue(byte, 'MCP closed early');data.extend(byte)
                    self.assertLess(len(data), 65536)
                reply = json.loads(data);self.assertEqual(reply['id'], sequence)
                return reply['result']
            def call(name, arguments):
                result = send('tools/call', {'name': name, 'arguments': arguments})['structuredContent']
                self.assertTrue(result['ok'], result)
                return result['data']
            try:
                send('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {}})
                send('notifications/initialized', {}, notify=True)
                session = call('process.launch', {'profile': 'short', 'request_id': 'start'})['session_id']
                deadline = time.monotonic()+3
                while True:
                    status = call('process.status', {'session_id': session})
                    if status['returncode'] is not None:break
                    self.assertLess(time.monotonic(), deadline);time.sleep(.01)
                self.assertEqual(status['returncode'], 7);self.assertFalse(status['alive'])
                self.assertTrue(call('process.terminate', {'session_id': session, 'request_id': 'finish'})['already_exited'])
            finally:
                child.stdin.close()
                try:child.wait(timeout=3)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=3)
                child.stdout.close()


if __name__ == '__main__':
    unittest.main()
