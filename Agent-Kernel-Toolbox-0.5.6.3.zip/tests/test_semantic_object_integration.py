"""Actual C/Rust/procfs/object-view integration; all external reads are non-atomic.

The SDK view binds the shared semantic projection, not a copied heap allocation.
The C application alone mutates and migrates its live heap object through slots.
"""
import base64
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_runtime import ProcessSession
from observation_extension.object_runtime import ObjectRuntime, ObjectRuntimeError
from observation_extension.semantic_agent import SemanticAgent

CARGO = os.environ.get('RUNTIME_CARGO') or shutil.which('cargo')


@unittest.skipUnless(sys.platform == 'linux' and hasattr(os, 'pidfd_open')
                     and CARGO and shutil.which('gcc'),
                     'Linux procfs/pidfd, a C compiler and Rust >=1.89 are required')
class SemanticObjectIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build_directory = tempfile.TemporaryDirectory()
        cls.build_root = Path(cls.build_directory.name)
        try:
            spec = importlib.util.spec_from_file_location(
                'semantic_integration_build', ROOT / 'native/runtime-agent/build.py')
            build = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(build)
            cls.metadata = build.build(cls.build_root, cargo=CARGO, cc=shutil.which('gcc'))
            cls.controller = cls.build_root / 'runtime-control'
            cls.demo = cls.build_root / 'runtime-agent-demo'
        except BaseException:
            cls.build_directory.cleanup()
            raise

    @classmethod
    def tearDownClass(cls):
        cls.build_directory.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.environment = self.root / 'environment'
        session = os.urandom(16).hex()
        self.process = subprocess.Popen([self.demo, self.environment, session],
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.addCleanup(self._close_process)
        self.assertTrue(select.select([self.process.stdout], [], [], 3)[0], 'C agent readiness timeout')
        self.ready = json.loads(self.process.stdout.readline())
        self.assertTrue(self.ready['ready'])
        result = subprocess.run([self.controller, 'status', self.environment, session],
                                capture_output=True, check=True, timeout=3)
        initial = json.loads(result.stdout)
        self.assertTrue(initial['ok'], initial)
        config = {'path': str(self.controller),
                  'sha256': self.metadata['artifacts']['runtime-control'],
                  'environment': str(self.environment), 'session': session,
                  'epoch': initial['epoch'], 'pid': self.process.pid,
                  'build_id': self.metadata['build_id'], 'allowed_slots': [1, 2, 3, 4, 5]}
        self.agent = SemanticAgent(config, self.root)
        self.addCleanup(self.agent.close)
        self.external = ProcessSession.attach(self.process.pid, allow_memory=True)
        self.addCleanup(self.external.close)
        mappings = [row for row in self.external.maps() if row['path'] == str(self.environment)]
        self.assertEqual(len(mappings), 1)
        self.mapping = mappings[0]
        self.base = int(self.mapping['start'], 16)
        self.assertEqual(self.mapping['memory_kind'], 'shared_file')
        self.assertEqual(self.mapping['sharing'], 'shared')
        self.assertTrue(self.mapping['ordinary_memory'])
        self.assertTrue(self.mapping['other_writers_possible'])
        self.assertEqual(self.mapping['offset'], '0x0')
        self.assertEqual(int(self.mapping['inode']), self.environment.stat().st_ino)

        def generation(allocation_id):
            if allocation_id != 'environment-block':
                return None
            return self.external.memory_mapping(self.base, 4096)['mapping_fingerprint']

        def denied_write(address, raw):
            raise AssertionError('the external observer must never write process memory')

        self.sdk = ObjectRuntime(self._read, denied_write,
                                 build_id=self.metadata['build_id'], mapping_generation=generation)
        self.sdk.register_allocation('environment-block', self.base, 4096,
            generation=self.mapping['mapping_fingerprint'], kind='file_shared',
            writable=False, provenance={'source': 'linux_procfs_maps_and_smaps',
                'mapping': self.mapping, 'process_identity': self.external.validate_identity()})
        self.initial = self.agent.status()
        self.handle = self._bind_projection(self.initial)

    def _close_process(self):
        if self.process.poll() is None:
            self.process.send_signal(signal.SIGCONT)
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=2)
        self.process.stdout.close()
        self.process.stderr.close()

    def _read(self, address, size):
        result = self.external.read_memory(address, size)
        self.assertFalse(result['atomic_snapshot'])
        self.assertTrue(result['observation_only'])
        return base64.b64decode(result['data'], validate=True)

    def _bind_projection(self, status):
        # RA ABI v1 publishes these little-endian fields at env offsets 112..159.
        # This is a runtime projection; the actual DemoObject sizeof/offsetof
        # evidence comes from the C compiler and is carried separately.
        return self.sdk.bind_object(
            'app-object-' + str(status['object_id']) + '-generation-' + str(status['object_generation']),
            'environment-block', 112, 48, type_id='RAObjectProjectionV1',
            build_id=status['build_id'], byte_order='little',
            fields={'object_id': {'offset': 0, 'type': 'uint64'},
                    'object_generation': {'offset': 8, 'type': 'uint64'},
                    'value': {'offset': 16, 'type': 'int64'},
                    'location_epoch': {'offset': 24, 'type': 'uint64'},
                    'object_size': {'offset': 32, 'type': 'uint32'},
                    'field_offset': {'offset': 36, 'type': 'uint32'},
                    'object_address': {'offset': 40, 'type': 'uint64'}},
            evidence={'source': 'runtime', 'representation': 'shared_semantic_projection',
                'compiler_layout': {'source': 'C_compiler_sizeof_and_offsetof',
                    'object_size': status['object_size'], 'field_offset': status['field_offset']},
                'logical_object_id': status['object_id'],
                'logical_object_generation': status['object_generation']})

    def _call(self, slot, expected=0, value=0):
        status = self.agent.status()
        result = self.agent.call(slot, status['object_generation'], status['request_seq'] + 1,
                                 expected, value)
        self.assertTrue(result['ok'], result)
        return result

    def test_live_callback_external_memory_semantic_view_and_object_migration(self):
        initial = self.initial
        self.assertEqual(initial['object_size'], self.ready['object_size'])
        self.assertEqual(initial['field_offset'], self.ready['value_offset'])
        self.assertEqual(initial['build_id'], self.metadata['build_id'])
        self.assertEqual(initial['value'], 7)
        self.assertEqual(self._call(2, 7, 41)['value'], 41)
        status = self.agent.status()
        published = self.external.read_memory(self.base + 128, 8)
        self.assertEqual(int.from_bytes(base64.b64decode(published['data']), 'little', signed=True), 41)
        heap_value = int.from_bytes(self._read(status['address'] + status['field_offset'], 8),
                                    sys.byteorder, signed=True)
        self.assertEqual(heap_value, 41)
        origin = self.external.resolve_address(self.base + 128)
        self.assertEqual(origin['mapping']['path'], str(self.environment))
        self.assertEqual(origin['backing_file_offset'], '0x80')
        self.assertFalse(origin['object_identity_proven'])
        self.sdk.observe(self.handle, address=self.base + 128,
            generation=self.mapping['mapping_fingerprint'], build_id=status['build_id'],
            source='external_observation', observation={'memory': published, 'origin': origin})
        self.sdk.observe(self.handle, address=self.base + 128,
            generation=self.mapping['mapping_fingerprint'], build_id=status['build_id'],
            source='internal_agent', observation=status)
        observed = self.sdk.snapshot(self.handle)
        self.assertEqual(observed['consistency'], 'non_atomic')
        self.assertEqual(observed['fields']['value'], str(status['value']))
        self.assertEqual(observed['fields']['object_address'], str(status['address']))
        resolved = self.sdk.resolve(self.handle)
        self.assertEqual(resolved['allocation_id'], 'environment-block')
        self.assertEqual(resolved['kind'], 'file_shared')
        self.assertEqual(len(resolved['observations']), 2)
        self.assertTrue(all(not row['causal_identity_proven'] for row in resolved['observations']))
        self.assertEqual(resolved['evidence']['compiler_layout']['field_offset'], initial['field_offset'])
        # Matching observations do not create a checkpoint over unknown writers.
        with self.sdk.checkpoint():
            with self.assertRaisesRegex(ObjectRuntimeError, 'shared_mapping_writers_not_coordinated'):
                self.sdk.snapshot(self.handle)

        self._call(4, 41)
        moved = self.agent.status()
        self.assertEqual(moved['object_id'], status['object_id'])
        self.assertEqual(moved['object_generation'], status['object_generation'])
        self.assertEqual(moved['location_epoch'], status['location_epoch'] + 1)
        self.assertNotEqual(moved['address'], status['address'])
        after = self.sdk.snapshot(self.handle)
        self.assertEqual(after['handle'], self.handle)
        self.assertEqual(after['fields']['location_epoch'], str(moved['location_epoch']))
        self.assertEqual(after['fields']['object_address'], str(moved['address']))
        self.assertEqual(after['fields']['value'], '41')
        self.assertEqual(int.from_bytes(self._read(moved['address'] + moved['field_offset'], 8),
                                       sys.byteorder, signed=True), 41)
        self.assertEqual(self.sdk.audit()['bytes_written'], 0)

    def test_changed_runtime_generation_invalidates_old_lifetime_without_reusing_allocation(self):
        old = self.initial
        allocation_generation = self.mapping['mapping_fingerprint']
        self._call(5, 7, 23)
        current = self.agent.status()
        self.assertEqual(current['object_id'], old['object_id'])
        self.assertEqual(current['object_generation'], old['object_generation'] + 1)
        stale = self.agent.call(1, old['object_generation'], current['request_seq'] + 1)
        self.assertFalse(stale['ok'])
        self.assertEqual(stale['error'], 'semantic_stale_handle')
        self.assertFalse(stale['dispatched'])
        # Runtime lifecycle metadata explicitly retires the old logical view.
        # Allocation/VMA identity remains separate from object lifetime.
        self.sdk.retire_object(self.handle)
        with self.assertRaisesRegex(ObjectRuntimeError, 'object_handle_not_live'):
            self.sdk.snapshot(self.handle)
        replacement = self._bind_projection(current)
        self.assertNotEqual(replacement, self.handle)
        self.assertEqual(self.sdk.resolve(replacement)['allocation_id'], 'environment-block')
        self.assertEqual(self.sdk.resolve(replacement)['mapping_generation'], allocation_generation)
        self.assertEqual(self.sdk.snapshot(replacement)['fields']['value'], '23')
        self.assertEqual(self.sdk.audit()['bytes_written'], 0)


if __name__ == '__main__':
    unittest.main()
