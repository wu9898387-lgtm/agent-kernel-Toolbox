import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time
import unittest
import tempfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.native_runtime import ProcessSession
from observation_extension.native_accessibility import NativeAccessibility, AccessibilityError
from observation_extension.runtime_host import RuntimeHost,SPECS


@unittest.skipUnless(os.environ.get('RUNTIME_DESKTOP_INTEGRATION') == '1', 'run tools/run_desktop_checks.py for an isolated X/DBus session')
class DesktopAppTests(unittest.TestCase):
    def test_real_related_label_input_and_checkbox_state(self):
        process=ProcessSession.launch(['/usr/bin/python3',str(ROOT/'tests/fixtures/gtk_app.py')],stdout=subprocess.PIPE,
                                      enable_accessibility=True)
        native=None
        try:
            self.assertTrue(select.select([process.child.stdout],[],[],5)[0]);process.child.stdout.readline()
            native=NativeAccessibility(process.pid,allow_actions=True,include_editable_text=True,allow_text_input=True)
            deadline=time.monotonic()+5
            while True:
                snapshot=native.query('Search for:',roles=['text'],limit=1)
                if snapshot['nodes']:break
                if time.monotonic()>deadline:self.fail('related-label input was not exposed')
                time.sleep(.05)
            entry=snapshot['nodes'][0]
            self.assertTrue(entry['can_set_text']);self.assertEqual(entry['label_source'],'parent-labelled-by')
            self.assertEqual(native.set_text(snapshot['snapshot_id'],entry['node_id'],'label-bound input')['status'],'acknowledged')
            self.assertEqual(native.query('label-bound input',roles=['text'],limit=1)['nodes'][0]['text'],'label-bound input')
            snapshot=native.query('Enable option',roles=['check box'],limit=1);check=snapshot['nodes'][0]
            self.assertFalse(check['states']['checked'])
            native.invoke(snapshot['snapshot_id'],check['node_id'],check['actions'][0]['index'])
            self.assertTrue(native.query('Enable option',roles=['check box'],limit=1)['nodes'][0]['states']['checked'])
        finally:
            if native:native.close()
            if process.child.poll() is None:process.terminate_owned()
            process.close();process.child.stdout.close()

    def test_native_form_input_focus_wait_and_navigation_over_mcp_host(self):
        with tempfile.TemporaryDirectory() as directory:
            config={'schema_version':1,'state_directory':directory+'/state','allowed_tools':list(SPECS),
                'profiles':{'gtk':{'argv':['/usr/bin/python3',str(ROOT/'tests/fixtures/gtk_app.py')],
                    'include_editable_text':True,'allow_text_input':True}}}
            host=RuntimeHost(config,bundle_root=ROOT)
            session=None
            def call(name,args):
                result=host.call(name,args)
                self.assertTrue(result['ok'],result)
                return result['data']
            try:
                session=call('process.launch',{'profile':'gtk','request_id':'launch-gtk'})['session_id']
                call('native.open',{'session_id':session})
                deadline=time.monotonic()+5
                while True:
                    result=host.call('native.snapshot',{'session_id':session})
                    if result['ok'] and any(n.get('text')=='initial native text' and n['states']['editable'] for n in result['data']['nodes']):
                        snapshot=result['data'];break
                    if time.monotonic()>deadline:self.fail('native form readiness deadline')
                    time.sleep(0.05)
                self.assertNotIn('PASSWORD_SECRET',json.dumps(snapshot))
                password=next(n for n in snapshot['nodes'] if n['role_id']==40)
                denied=host.call('native.set_text',{'session_id':session,'snapshot_id':snapshot['snapshot_id'],
                    'node_id':password['node_id'],'text':'must-not-write','request_id':'refuse-password'})
                self.assertFalse(denied['ok']);self.assertFalse(denied['effect_unknown'])
                entry=next(n for n in snapshot['nodes'] if n['states']['editable'] and n['text']=='initial native text')
                call('native.focus',{'session_id':session,'snapshot_id':snapshot['snapshot_id'],'node_id':entry['node_id'],'request_id':'focus-gtk'})
                snapshot=call('native.snapshot',{'session_id':session})
                entry=next(n for n in snapshot['nodes'] if n['states']['editable'] and n['text']=='initial native text')
                edited=call('native.set_text',{'session_id':session,'snapshot_id':snapshot['snapshot_id'],
                    'node_id':entry['node_id'],'text':'AI 原生输入','request_id':'input-gtk'})
                self.assertFalse(edited['effect_confirmed'])
                waited=call('native.wait_for',{'session_id':session,'query':'输入结果：AI 原生输入','timeout_ms':3000})
                self.assertEqual(waited['status'],'matched')
                snapshot=call('native.snapshot',{'session_id':session})
                button=next(n for n in snapshot['nodes'] if n['name']=='打开设置' and n['actions'])
                call('native.invoke',{'session_id':session,'snapshot_id':snapshot['snapshot_id'],
                    'node_id':button['node_id'],'request_id':'navigate-gtk'})
                self.assertEqual(call('native.wait_for',{'session_id':session,'query':'设置页面已打开','timeout_ms':3000})['status'],'matched')
                self.assertNotIn('AI 原生输入'.encode(),(Path(directory)/'state/runtime.sqlite3').read_bytes())
            finally:
                if session:call('process.terminate',{'session_id':session,'request_id':'terminate-gtk'})
                host.close()

    def test_gtk_app_observed_navigation_and_postcondition(self):
        process = ProcessSession.launch(['/usr/bin/python3', str(ROOT / 'tests/fixtures/gtk_app.py')], stdout=subprocess.PIPE)
        native = None
        try:
            self.assertTrue(select.select([process.child.stdout], [], [], 5)[0], 'GTK fixture readiness deadline')
            self.assertEqual(process.child.stdout.readline(), b'gtk-ready\n')
            native = NativeAccessibility(process.pid, allow_actions=True, max_nodes=128, max_text_bytes=16384)
            deadline = time.monotonic() + 8
            while True:
                try:
                    before = native.snapshot()
                    if any(n.get('name') == '打开设置' and n.get('actions') for n in before['nodes']): break
                except AccessibilityError as error:
                    if str(error) != 'application_not_accessible': raise
                if time.monotonic() > deadline: self.fail('GTK accessibility export deadline')
                time.sleep(0.05)
            self.assertNotIn('PASSWORD_SECRET', json.dumps(before))
            button = next(n for n in before['nodes'] if n.get('name') == '打开设置' and n.get('actions'))
            result = native.invoke(before['snapshot_id'], button['node_id'], 0)
            self.assertEqual(result['status'], 'acknowledged')
            deadline = time.monotonic() + 5
            while True:
                after = native.snapshot()
                if any('设置页面已打开' in (n.get('name', '') + n.get('text', '')) and n['states']['showing'] for n in after['nodes']): break
                if time.monotonic() > deadline: self.fail('APP page transition postcondition deadline')
                time.sleep(0.05)
            self.assertNotIn('PASSWORD_SECRET', json.dumps(after))
            self.assertEqual(process.abi()['architecture'], 'x86_64')
        finally:
            if native: native.close()
            if process.child.poll() is None: process.terminate_owned()
            process.close();process.child.stdout.close()


if __name__ == '__main__': unittest.main()
