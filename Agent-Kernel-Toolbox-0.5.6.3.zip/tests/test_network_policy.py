"""Real owned loopback HTTP tests for fixed-profile request governance."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from email.utils import format_datetime
import copy
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.network_policy import NetworkPolicy, NetworkPolicyError


def reply(handler, status=200, body=b'ok', headers=None):
    handler.send_response(status)
    handler.send_header('Content-Length', str(len(body)))
    for name, value in (headers or {}).items():
        handler.send_header(name, value)
    handler.end_headers()
    if handler.command != 'HEAD':
        handler.wfile.write(body)
        handler.wfile.flush()


class OwnedServer:
    def __init__(self, callback=None):
        self.hits, self.active, self.peak = [], 0, 0
        self.lock, self.release, self.received = threading.Lock(), threading.Event(), threading.Event()
        self.callback = callback or (lambda _server, handler, _hit: reply(handler))
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def serve(self):
                body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
                with owner.lock:
                    hit = {'method': self.command, 'path': self.path, 'body': body,
                           'headers': dict(self.headers), 'at': time.monotonic(), 'number': len(owner.hits) + 1}
                    owner.hits.append(hit)
                    owner.active += 1
                    owner.peak = max(owner.peak, owner.active)
                owner.received.set()
                try:
                    owner.callback(owner, self, hit)
                except (OSError, BrokenPipeError):
                    pass  # Deadline/close tests intentionally end the owned connection.
                finally:
                    with owner.lock:
                        owner.active -= 1

            do_GET = do_HEAD = do_POST = do_PUT = do_PATCH = do_DELETE = serve

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.origin = 'http://127.0.0.1:' + str(self.server.server_port)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *_args):
        self.release.set()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)


def config(origin, **profile):
    return {'origins': {'service': {'origin': origin, 'min_interval_ms': 0}},
            'profiles': {'fixed': {'origin': 'service', 'method': 'GET', 'path': '/fixed',
                                   'timeout_ms': 2000, **profile}}}


class NetworkPolicyTests(unittest.TestCase):
    @contextmanager
    def policy(self, settings):
        with tempfile.TemporaryDirectory() as directory:
            instance = NetworkPolicy(settings, directory)
            try:
                yield instance
            finally:
                result = instance.close()
                self.assertEqual(result['cleanup_errors'], [])

    def test_fixed_template_response_digest_and_ignored_environment_proxy(self):
        secret = b'sensitive-response-do-not-return'
        with OwnedServer(lambda _s, h, _x: reply(h, body=secret)) as server:
            settings = config(server.origin, headers={'X-Fixed': 'operator-value'})
            with self.policy(settings) as policy, patch.dict(os.environ, {
                    'HTTP_PROXY': 'http://127.0.0.1:1', 'http_proxy': 'http://127.0.0.1:1', 'NO_PROXY': ''}):
                result = policy.request('fixed', 'digest-1')
                self.assertEqual(result['status_code'], 200)
                self.assertEqual(result['response_sha256'], hashlib.sha256(secret).hexdigest())
                self.assertEqual(result['response_bytes'], len(secret))
                self.assertNotIn(secret.decode(), json.dumps(result))
                self.assertFalse(result['business_effect_confirmed'])
                self.assertTrue(result['effect_dispatched'])
                snapshot = policy.inspect()
                self.assertEqual(snapshot['origins'][0]['attempts'], 1)
                self.assertFalse(snapshot['arbitrary_target_program_traffic_controlled'])
            self.assertEqual(server.hits[0]['headers']['X-Fixed'], 'operator-value')
            self.assertEqual((server.hits[0]['method'], server.hits[0]['path']), ('GET', '/fixed'))

    def test_request_protocol_validation_and_explicit_write_grant(self):
        cases = [({'path': '//elsewhere/a'}, 'network_invalid_request_profile'),
                 ({'path': 'http://elsewhere/a'}, 'network_invalid_request_profile'),
                 ({'path': '/x\r\nX: y'}, 'network_invalid_request_profile'),
                 ({'headers': {'X-Fixed': 'x\x00y'}}, 'network_invalid_header'),
                 ({'headers': {'Host': 'elsewhere'}}, 'network_invalid_header'),
                 ({'headers': {'Content-Length': '999'}}, 'network_invalid_header'),
                 ({'headers': {'Transfer-Encoding': 'chunked'}}, 'network_invalid_header'),
                 ({'headers': {'Connection': 'keep-alive'}}, 'network_invalid_header'),
                 ({'method': 'POST'}, 'network_write_grant_required'),
                 ({'method': 'POST', 'allow_write': True, 'max_attempts': 2}, 'network_write_retry_forbidden'),
                 ({'body_utf8': 'read-with-body'}, 'network_read_body_forbidden')]
        for overrides, expected in cases:
            with self.subTest(overrides=overrides), tempfile.TemporaryDirectory() as directory:
                with self.assertRaisesRegex(NetworkPolicyError, expected):
                    NetworkPolicy(config('http://127.0.0.1:1', **overrides), directory)
        with self.policy({'origins': {}, 'profiles': {}}) as empty:
            self.assertFalse(empty.inspect()['configured'])
            with self.assertRaisesRegex(NetworkPolicyError, 'network_unknown_profile'):
                empty.request('missing', 'empty')

    def test_aliases_share_pacing_concurrency_and_durable_total_budget(self):
        def hold(_server, handler, _hit):
            time.sleep(.085)
            reply(handler)
        with OwnedServer(hold) as server:
            settings = config(server.origin)
            settings['origins']['service'].update(min_interval_ms=40, max_concurrent=2, max_requests=4)
            settings['origins']['alias'] = copy.deepcopy(settings['origins']['service'])
            settings['origins']['alias']['origin'] += '/'
            settings['profiles']['alias'] = {**settings['profiles']['fixed'], 'origin': 'alias'}
            with self.policy(settings) as policy:
                self.assertEqual(policy.origin_scope('fixed'), policy.origin_scope('alias'))
                # Pacing constrains admission, recorded as next_at - interval.
                # Observe that state before the existing Condition releases;
                # sendall and server-handler timestamps can bunch after later
                # scheduling delays. This successful-response fixture has no
                # retry/backoff updates to next_at. No clock or HTTP is mocked.
                admission_deadlines = []
                actual_condition = policy.condition
                origin = policy.origins[policy.origin_scope('fixed')]
                interval = origin.limits['min_interval_ms'] / 1000
                class RecordingCondition:
                    previous = origin.next_at
                    def __enter__(self):
                        return actual_condition.__enter__()
                    def __exit__(self, *args):
                        try:
                            if origin.next_at != self.previous:
                                admission_deadlines.append(origin.next_at)
                                self.previous = origin.next_at
                        finally:
                            actual_condition.__exit__(*args)
                    def __getattr__(self, name):
                        return getattr(actual_condition, name)
                policy.condition = RecordingCondition()
                barrier = threading.Barrier(5)
                def run(index):
                    barrier.wait()
                    return policy.request('fixed' if index % 2 else 'alias', 'parallel-' + str(index))
                with ThreadPoolExecutor(max_workers=4) as executor:
                    pending = [executor.submit(run, index) for index in range(4)]
                    barrier.wait()
                    self.assertTrue(all(item.result(3)['status_code'] == 200 for item in pending))
                with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_request_budget') as error:
                    policy.request('alias', 'over-budget')
                self.assertFalse(error.exception.effect_dispatched)
                self.assertEqual(len(policy.inspect()['origins']), 1)
            self.assertEqual(len(server.hits), 4)
            self.assertLessEqual(server.peak, 2)
            self.assertEqual(len(admission_deadlines), 4)
            for earlier, later in zip(admission_deadlines, admission_deadlines[1:]):
                self.assertGreaterEqual(later, earlier + interval, admission_deadlines)

    def test_conflicting_alias_limits_are_rejected(self):
        settings = config('http://localhost:80')
        settings['origins']['other'] = {'origin': 'http://LOCALHOST./', 'min_interval_ms': 1}
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_alias_policy_conflict'):
                NetworkPolicy(settings, directory)

    def test_explicit_zero_port_is_rejected_without_changing_the_origin(self):
        for origin in ('http://127.0.0.1:0', 'https://example.com:0'):
            with self.subTest(origin=origin), tempfile.TemporaryDirectory() as directory:
                with self.assertRaisesRegex(NetworkPolicyError, 'network_invalid_origin'):
                    NetworkPolicy(config(origin), directory)

    def test_unknown_outcome_fences_a_request_already_waiting_for_admission(self):
        for method in ('POST', 'GET'):
            with self.subTest(method=method):
                def drop_first(server, handler, hit):
                    if hit['path'] == '/drop':
                        server.release.wait(3)
                        handler.connection.shutdown(socket.SHUT_RDWR)
                    else:
                        reply(handler)

                with OwnedServer(drop_first) as server:
                    settings = config(server.origin, method=method, path='/drop',
                                      allow_write=method == 'POST', timeout_ms=5000)
                    settings['origins']['service']['max_concurrent'] = 1
                    settings['profiles']['queued'] = {**settings['profiles']['fixed'], 'path': '/queued'}
                    with self.policy(settings) as policy, ThreadPoolExecutor(max_workers=2) as executor:
                        queued, settled = threading.Event(), threading.Event()
                        first_thread = []
                        actual_wait, actual_release = policy.condition.wait, policy._release

                        def observe_wait(timeout=None):
                            if threading.get_ident() != first_thread[0]:
                                queued.set()
                            return actual_wait(timeout)

                        def observe_release(*args, **kwargs):
                            result = actual_release(*args, **kwargs)
                            if threading.get_ident() == first_thread[0]:
                                # Choose the legal interleaving where the queued
                                # request runs immediately after slot release.
                                # The real Condition lock and HTTP I/O remain in use.
                                settled.wait(2)
                            return result

                        def request_first():
                            first_thread.append(threading.get_ident())
                            return policy.request('fixed', 'first-' + method)

                        with patch.object(policy.condition, 'wait', side_effect=observe_wait), \
                                patch.object(policy, '_release', side_effect=observe_release):
                            first = executor.submit(request_first)
                            try:
                                self.assertTrue(server.received.wait(2), 'first request did not reach server')
                                second = executor.submit(policy.request, 'queued', 'second-' + method)
                                second.add_done_callback(lambda _future: settled.set())
                                self.assertTrue(queued.wait(2), 'second request did not enter the real Condition queue')
                            finally:
                                server.release.set()
                            if method == 'POST':
                                self.assertEqual(first.result(3)['status'], 'unknown')
                            else:
                                with self.assertRaises(NetworkPolicyError) as error:
                                    first.result(3)
                                self.assertTrue(error.exception.effect_dispatched)
                            with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_outcome_unresolved') as error:
                                second.result(3)
                            self.assertFalse(error.exception.effect_dispatched)
                            self.assertTrue(policy.inspect()['origins'][0]['unresolved'])
                    self.assertEqual(len(server.hits), 1)

    def test_real_429_retry_after_and_bounded_exponential_503_retry(self):
        def busy(_server, handler, hit):
            if hit['number'] == 1:
                reply(handler, 429, headers={'Retry-After': '1'})
            elif hit['number'] == 2:
                reply(handler, 503)
            else:
                reply(handler)
        # This success case checks Retry-After/backoff, with scheduler slack
        # around its mandatory 1s wait. Short-deadline cancellation is tested separately.
        with OwnedServer(busy) as server, self.policy(config(server.origin, max_attempts=3,
                timeout_ms=10000, retry_base_ms=30, retry_max_ms=100)) as policy:
            started = time.monotonic()
            result = policy.request('fixed', 'retry-safe')
            self.assertEqual([x['status_code'] for x in result['attempts']], [429, 503, 200])
            self.assertGreaterEqual(time.monotonic()-started, 1)
            self.assertGreaterEqual(server.hits[1]['at']-server.hits[0]['at'], .95)
            self.assertGreaterEqual(server.hits[2]['at']-server.hits[1]['at'], .04)

    def test_retry_after_over_deadline_does_not_sleep_or_retry(self):
        with OwnedServer(lambda _s, h, _x: reply(h, 503, headers={'Retry-After': '60'})) as server:
            with self.policy(config(server.origin, max_attempts=3, timeout_ms=200)) as policy:
                started = time.monotonic()
                result = policy.request('fixed', 'bounded-retry')
                self.assertEqual(result['status_code'], 503)
                self.assertEqual(len(result['attempts']), 1)
                self.assertLess(time.monotonic()-started, .5)
                self.assertFalse(policy.inspect()['origins'][0]['unresolved'])
            self.assertEqual(len(server.hits), 1)
        date = format_datetime(datetime.now(timezone.utc) + timedelta(seconds=20), usegmt=True)
        self.assertGreater(NetworkPolicy._retry_after(date), 18)

    def test_write_drop_is_unknown_never_retried_and_fence_survives_restart(self):
        def drop(_server, handler, _hit):
            handler.connection.shutdown(socket.SHUT_RDWR)
        with OwnedServer(drop) as server, tempfile.TemporaryDirectory() as directory:
            settings = config(server.origin, method='POST', allow_write=True, body_utf8='fixed-write')
            settings['profiles']['alias'] = copy.deepcopy(settings['profiles']['fixed'])
            policy = NetworkPolicy(settings, directory)
            try:
                result = policy.request('fixed', 'write-1')
                self.assertEqual(result['status'], 'unknown')
                self.assertTrue(result['effect_dispatched'])
                self.assertFalse(result['automatic_retry_performed'])
                with self.assertRaisesRegex(NetworkPolicyError, 'network_request_replay'):
                    policy.request('alias', 'write-1')
                with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_outcome_unresolved'):
                    policy.request('alias', 'write-2')
                self.assertEqual(policy.close()['cleanup_errors'], [])
                policy = NetworkPolicy(settings, directory)
                self.assertTrue(policy.inspect()['origins'][0]['unresolved'])
                with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_outcome_unresolved'):
                    policy.request('alias', 'after-restart')
            finally:
                policy.close()
            self.assertEqual(len(server.hits), 1)
            self.assertEqual(server.hits[0]['body'], b'fixed-write')

    def test_get_drop_has_dispatched_unknown_and_fence(self):
        with OwnedServer(lambda _s, h, _x: h.connection.shutdown(socket.SHUT_RDWR)) as server:
            with self.policy(config(server.origin)) as policy:
                with self.assertRaises(NetworkPolicyError) as error:
                    policy.request('fixed', 'get-drop')
                self.assertTrue(error.exception.effect_dispatched)
                self.assertTrue(policy.inspect()['origins'][0]['unresolved'])
                with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_outcome_unresolved'):
                    policy.request('fixed', 'no-further-get')
            self.assertEqual(len(server.hits), 1)

    def test_get_transport_retry_is_explicitly_read_safe_and_finite(self):
        def drop_once(_server, handler, hit):
            if hit['number'] == 1:
                handler.connection.shutdown(socket.SHUT_RDWR)
            else:
                reply(handler)
        with OwnedServer(drop_once) as server, self.policy(config(server.origin, max_attempts=2,
                retry_base_ms=10)) as policy:
            result = policy.request('fixed', 'get-drop-retry')
            self.assertEqual(result['status_code'], 200)
            self.assertEqual(len(result['attempts']), 2)
            self.assertFalse(policy.inspect()['origins'][0]['unresolved'])
            self.assertEqual(len(server.hits), 2)

    def test_redirect_never_contacts_location_or_returns_sensitive_headers(self):
        with OwnedServer() as elsewhere:
            with OwnedServer(lambda _s, h, _x: reply(h, 302, body=b'redirect-secret',
                    headers={'Location': elsewhere.origin + '/secret', 'Set-Cookie': 'private'})) as server:
                with self.policy(config(server.origin)) as policy:
                    result = policy.request('fixed', 'redirect')
                    self.assertEqual(result['status'], 'redirect_refused')
                    self.assertFalse(result['body_complete'])
                    self.assertNotIn('private', json.dumps(result))
                    self.assertNotIn(elsewhere.origin, json.dumps(result))
                self.assertEqual(elsewhere.hits, [])

    def test_response_body_budget_and_truncated_write_are_unknown(self):
        with OwnedServer(lambda _s, h, _x: reply(h, body=b'x' * 100)) as server:
            with self.policy(config(server.origin, max_response_bytes=10)) as policy:
                with self.assertRaisesRegex(NetworkPolicyError, 'network_response_body_budget') as error:
                    policy.request('fixed', 'response-budget')
                self.assertTrue(error.exception.effect_dispatched)
        def truncate(_server, handler, _hit):
            handler.send_response(200)
            handler.send_header('Content-Length', '5')
            handler.end_headers()
            handler.wfile.write(b'x')
            handler.wfile.flush()
        with OwnedServer(truncate) as server:
            with self.policy(config(server.origin, method='POST', allow_write=True)) as policy:
                result = policy.request('fixed', 'truncated-write')
                self.assertEqual(result['status'], 'unknown')

    def test_absolute_deadline_interrupts_http10_response_file_reference(self):
        def slow(server, handler, _hit):
            handler.send_response(200)
            handler.send_header('Content-Length', '2')
            handler.end_headers()
            handler.wfile.write(b'x')
            handler.wfile.flush()
            server.release.wait(2)
        with OwnedServer(slow) as server, self.policy(config(server.origin, timeout_ms=150)) as policy:
            started = time.monotonic()
            with self.assertRaises(NetworkPolicyError) as error:
                policy.request('fixed', 'slow-body')
            self.assertTrue(error.exception.effect_dispatched)
            self.assertLess(time.monotonic()-started, .7)

    def test_queued_deadline_does_not_claim_dispatch_and_close_releases_io(self):
        def wait(server, handler, _hit):
            server.release.wait(2)
            reply(handler)
        with OwnedServer(wait) as server:
            settings = config(server.origin)
            settings['origins']['service']['max_concurrent'] = 1
            settings['profiles']['short'] = {**settings['profiles']['fixed'], 'timeout_ms': 100}
            with self.policy(settings) as policy, ThreadPoolExecutor(max_workers=1) as executor:
                first = executor.submit(policy.request, 'fixed', 'hold')
                self.assertTrue(server.received.wait(1))
                with self.assertRaisesRegex(NetworkPolicyError, 'network_request_deadline') as error:
                    policy.request('short', 'queue-expired')
                self.assertFalse(error.exception.effect_dispatched)
                self.assertFalse(policy.inspect()['origins'][0]['unresolved'])
                self.assertEqual(policy.close()['cleanup_errors'], [])
                with self.assertRaises(NetworkPolicyError) as error:
                    first.result(1)
                self.assertTrue(error.exception.effect_dispatched)
                self.assertTrue(policy.inspect()['closed'])
            self.assertEqual(len(server.hits), 1)

    def test_circuit_and_successful_request_id_persist_without_redispatch(self):
        with OwnedServer(lambda _s, h, _x: reply(h, 503)) as server:
            settings = config(server.origin)
            settings['origins']['service'].update(failure_threshold=1, circuit_ms=500)
            with self.policy(settings) as policy:
                self.assertEqual(policy.request('fixed', 'server-busy')['status_code'], 503)
                with self.assertRaisesRegex(NetworkPolicyError, 'network_origin_circuit_open') as error:
                    policy.request('fixed', 'circuit-reject')
                self.assertFalse(error.exception.effect_dispatched)
            self.assertEqual(len(server.hits), 1)
        with OwnedServer() as server, tempfile.TemporaryDirectory() as directory:
            settings = config(server.origin, method='POST', allow_write=True)
            for iteration in range(2):
                policy = NetworkPolicy(settings, directory)
                try:
                    if iteration == 0:
                        self.assertEqual(policy.request('fixed', 'once')['status_code'], 200)
                    else:
                        with self.assertRaisesRegex(NetworkPolicyError, 'network_request_replay'):
                            policy.request('fixed', 'once')
                finally:
                    policy.close()
            self.assertEqual(len(server.hits), 1)

    def test_real_localhost_dns_is_resolved_before_direct_connection(self):
        with OwnedServer() as server:
            with self.policy(config(server.origin.replace('127.0.0.1', 'localhost'))) as policy:
                self.assertEqual(policy.request('fixed', 'dns-localhost')['status_code'], 200)
            self.assertEqual(len(server.hits), 1)

    @unittest.skipUnless(shutil.which('openssl'), 'openssl needed to generate owned self-signed TLS fixture')
    def test_real_tls_untrusted_certificate_fails_before_http_dispatch(self):
        with tempfile.TemporaryDirectory() as directory:
            key, certificate = Path(directory) / 'key.pem', Path(directory) / 'certificate.pem'
            subprocess.run([shutil.which('openssl'), 'req', '-x509', '-newkey', 'rsa:2048', '-nodes',
                '-keyout', str(key), '-out', str(certificate), '-subj', '/CN=localhost', '-days', '1'],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                check=True, timeout=10)
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(certificate, key)
            with OwnedServer() as server:
                server.server.socket = context.wrap_socket(server.server.socket, server_side=True)
                settings = config(server.origin.replace('http:', 'https:'))
                with self.policy(settings) as policy:
                    with self.assertRaisesRegex(NetworkPolicyError, 'network_connection_failed') as error:
                        policy.request('fixed', 'untrusted-tls')
                    self.assertFalse(error.exception.effect_dispatched)
                    self.assertFalse(policy.inspect()['origins'][0]['unresolved'])
                self.assertEqual(server.hits, [])


if __name__ == '__main__':
    unittest.main()
