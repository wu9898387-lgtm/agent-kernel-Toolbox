"""Real neutral environment-call observation; no hostile-program verdicts."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.environment_probe import EnvironmentProbe,EnvironmentProbeError,CATEGORIES


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def worker():
    spec=importlib.util.spec_from_file_location('env_probe_worker',ROOT/'tools/environment_probe_agent.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


class EnvironmentParserTests(unittest.TestCase):
    def test_unknown_records_stay_unknown_and_do_not_become_verdicts(self):
        module=worker();shared=module.shared_module()
        raw=(b'100 100.000001 execve(0x1, 0x2, 0x3) = 0\n'
             b'100 not a syscall; __import__("os")\n'
             b'100 100.000002 uname(0x123) = 0 <0.000001>\n')
        result=module.parse_environment(raw,{'categories':['system'],'cwd':'/tmp','roots':['/tmp']},1000000,shared,shared.parse_trace)
        self.assertEqual(result['parse_issues']['unparsed_lines'],1)
        self.assertEqual(result['events'][0]['operation'],'uname')
        self.assertEqual(result['events'][0]['source_kind'],'environment_syscall')
        self.assertNotIn('observed_scan_pattern',result)
        self.assertFalse(result['payloads_captured'])

    def test_clone3_output_annotation_preserves_thread_tgid_and_no_buffers(self):
        module=worker();shared=module.shared_module()
        raw=(b'100 100.000001 execve(0x1, 0x2, 0x3) = 0\n'
             b'100 100.000002 clone3({flags=CLONE_THREAD|CLONE_FILES|CLONE_FS|CLONE_VM} => {parent_tid=[101]}, 88) = 101\n'
             b'101 100.000003 clock_gettime(0x1, 0x123456) = 0 <0.000001>\n')
        result=module.parse_environment(raw,{'categories':['process','time'],'cwd':'/tmp','roots':['/tmp']},1000000,shared,shared.parse_trace)
        child=next(row for row in result['actors'] if row['tid']==101)
        self.assertEqual(child['pid'],100)
        self.assertEqual(result['events'][-1]['pid'],100)
        self.assertEqual(result['parse_issues']['unparsed_lines'],0)
        self.assertFalse(result['events'][-1]['evidence']['buffers_decoded'])


@unittest.skipUnless(sys.platform=='linux' and shutil.which('gcc') and shutil.which('strace'),'Linux, gcc and strace required')
class EnvironmentProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build=tempfile.TemporaryDirectory();cls.binary=Path(cls.build.name)/'owned-environment-fixture'
        subprocess.run([shutil.which('gcc'),'-O0','-g','-Wall','-Wextra','-Werror','-pthread',
            str(ROOT/'tests/fixtures/environment_probe.c'),'-o',str(cls.binary)],check=True,timeout=20)
        cls.strace=Path(shutil.which('strace')).resolve()

    @classmethod
    def tearDownClass(cls):cls.build.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.input=self.root/'private-data-name'
        self.secret='FILE_PAYLOAD_NEVER_RETURNED_aa89'
        self.input.write_text(self.secret)
        self.clients=[];self.addCleanup(lambda:[client.close() for client in self.clients])

    def config(self,categories=None,mode='normal',**options):
        return {'strace':{'path':str(self.strace),'sha256':digest(self.strace)},'profiles':{'owned':{
            'argv':[str(self.binary),mode,str(self.input)],'sha256':digest(self.binary),
            'categories':list(CATEGORIES) if categories is None else categories,'allow_capture':True,**options}}}

    def client(self,categories=None,mode='normal',**options):
        result=EnvironmentProbe(self.config(categories,mode,**options),self.root/('state'+str(len(self.clients))),ROOT)
        self.clients.append(result);return result

    def test_real_all_category_calls_have_source_and_thread_attribution(self):
        result=self.client().capture('owned')
        self.assertEqual(result['binary_sha256'],digest(self.binary))
        self.assertEqual(result['status'],'observed',result['parse_issues'])
        self.assertEqual(result['source_kind'],'environment_syscall')
        for category in CATEGORIES:
            with self.subTest(category=category):self.assertGreater(result['summary']['category_counts'][category],0)
        self.assertTrue(all(row['source_kind']=='environment_syscall' for row in result['events']))
        self.assertTrue(all({'seq','tid','category','operation','result','evidence'}<=row.keys() for row in result['events']))
        thread=next(actor for actor in result['actors'] if actor['relation']=='thread')
        self.assertEqual(thread['pid'],result['root_pid'])
        self.assertTrue(any(row['tid']==thread['tid'] and row['pid']==result['root_pid'] for row in result['events']))
        self.assertTrue(result['capture_cleanup_confirmed'])
        self.assertNotIn('observed_scan_pattern',result)

    def test_default_paths_endpoints_and_payloads_are_not_exposed(self):
        result=self.client().capture('owned');text=json.dumps(result)
        for secret in (self.secret,'NETWORK_PAYLOAD_MUST_NOT_APPEAR_12b7','private-data-name','127.0.0.1'):
            self.assertNotIn(secret,text)
        self.assertFalse(result['file_contents_captured'])
        self.assertFalse(result['network_payloads_captured'])
        self.assertFalse(result['device_output_buffers_captured'])
        self.assertTrue(all(not row['evidence']['buffers_decoded'] for row in result['events']))
        self.assertTrue(any('endpoint' in row['evidence'] for row in result['events']))
        self.assertTrue(all(row['evidence']['endpoint']['redacted'] for row in result['events'] if 'endpoint' in row['evidence']))

    def test_operator_can_show_endpoint_metadata_without_network_payload(self):
        result=self.client(['network'],show_endpoints=True).capture('owned')
        endpoints=[row['evidence']['endpoint'] for row in result['events'] if 'endpoint' in row['evidence']]
        self.assertTrue(any(not endpoint['redacted'] and '127.0.0.1' in endpoint['value'] for endpoint in endpoints))
        self.assertNotIn('NETWORK_PAYLOAD_MUST_NOT_APPEAR_12b7',json.dumps(result))
        self.assertFalse(result['endpoint_data_is_authority'])

    def test_independent_category_selection_and_budget_coverage(self):
        result=self.client(['memory']).capture('owned')
        self.assertEqual(set(row['category'] for row in result['events']),{'memory'})
        self.assertEqual(list(result['summary']['category_counts']),['memory'])
        partial=self.client(['time','system'],mode='slow',duration_ms=60).capture('owned')
        self.assertEqual(partial['stop_reason'],'duration_budget')
        self.assertFalse(partial['coverage_complete'])
        self.assertTrue(partial['capture_cleanup_confirmed'])
        limited=self.client(['time'],mode='repeat',max_events=16).capture('owned')
        self.assertEqual(limited['stop_reason'],'event_budget')
        self.assertFalse(limited['coverage_complete'])
        self.assertIsNone(limited['lost_event_count'])
        self.assertLessEqual(len(result['events']),64)
        self.assertLess(len(json.dumps(result,ensure_ascii=True).encode()),65536)

    def test_invalid_categories_and_missing_permissions_are_preflight(self):
        for categories in ([],['unknown'],['time','time'],['network; system("bad")']):
            with self.subTest(categories=categories),self.assertRaises(EnvironmentProbeError):
                EnvironmentProbe(self.config(categories),self.root/'bad',ROOT)
        with self.assertRaisesRegex(EnvironmentProbeError,'path_roots_required'):
            EnvironmentProbe(self.config(['file'],show_paths=True),self.root/'display',ROOT)
        client=self.client(['system'],allow_capture=False)
        with self.assertRaises(EnvironmentProbeError) as error:client.capture('owned')
        self.assertFalse(error.exception.effect_dispatched)
        with self.assertRaises(EnvironmentProbeError):client.capture('/bin/sh')

    def test_host_sigkill_leaves_no_running_or_unreaped_owned_tracee(self):
        config=self.config(['system','time'],mode='slow',duration_ms=5000)
        host=self.root/'host.py';state=self.root/'host-state'
        host.write_text('''import json,sys
sys.path.insert(0,sys.argv[1])
from observation_extension.environment_probe import EnvironmentProbe
c=EnvironmentProbe(json.loads(sys.argv[3]),sys.argv[2],sys.argv[4])
c.capture('owned')
''')
        process=subprocess.Popen([sys.executable,str(host),str(RUNTIME),str(state),json.dumps(config),str(ROOT)],
                                 stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        target=None;descriptor=None
        try:
            deadline=time.monotonic()+3
            while target is None:
                for log in state.glob('environment-*/trace.log'):
                    lines=log.read_text().splitlines()
                    if lines:target=int(lines[0].split()[0]);break
                self.assertLess(time.monotonic(),deadline);time.sleep(.01)
            descriptor=os.pidfd_open(target);process.kill();process.wait(timeout=2)
            self.assertTrue(select.select([descriptor],[],[],3)[0])
            deadline=time.monotonic()+3
            while Path(f'/proc/{target}').exists():
                self.assertLess(time.monotonic(),deadline);time.sleep(.01)
        finally:
            if process.poll() is None:process.kill();process.wait(timeout=2)
            if descriptor is not None:
                if not select.select([descriptor],[],[],0)[0]:signal.pidfd_send_signal(descriptor,signal.SIGKILL)
                os.close(descriptor)


if __name__=='__main__':unittest.main()
