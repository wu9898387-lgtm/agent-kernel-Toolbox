"""Actual fork/setsid/short-child accounting and independent tree cleanup."""
import copy
import errno
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0,str(RUNTIME))
from observation_extension.process_tree import ProcessTree,TreeError


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(sys.platform.startswith('linux') and hasattr(os,'pidfd_open') and shutil.which('gcc'),
                     'Linux pidfd and C compiler required for actual process-tree tests')
class ProcessTreeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory();cls.binary=Path(cls.temporary.name)/'tree-app'
        subprocess.run([shutil.which('gcc'),'-std=c11','-O2','-Wall','-Wextra','-Werror','-pthread',
                        str(ROOT/'tests/fixtures/recovery/tree_app.c'),'-o',str(cls.binary)],
                       check=True,timeout=15)

    @classmethod
    def tearDownClass(cls):cls.temporary.cleanup()

    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.directory=Path(self.temporary.name);self.pidfile=self.directory/'pids'

    def profile(self,mode,**updates):
        result={'argv':[str(self.binary),mode,str(self.pidfile)],'binary_sha256':digest(self.binary),
            'allow_run':True,'cpu_milliseconds':2000,'rss_bytes':128*1024*1024,'wall_ms':4000,
            'max_processes':16,'address_space_bytes':64*1024*1024,'open_files':32,
            'max_pause_ms':1000,'sample_ms':100,'capture_output':True}
        result.update(updates);return result

    def backend(self,profile):
        backend=ProcessTree({'profiles':{'owned':profile}},self.directory/'state',bundle_root=ROOT)
        self.addCleanup(backend.close);return backend

    def run_mode(self,mode,**updates):return self.backend(self.profile(mode,**updates)).run('owned')

    def assert_clean(self,result):
        self.assertTrue(result['cleanup']['complete'],result)
        self.assertTrue(result['cleanup']['all_owned_exited_and_reaped'])
        self.assertTrue(result['cleanup']['guardian_reaped'])
        self.assertLess(len(json.dumps(result,ensure_ascii=True)),65536)
        if self.pidfile.exists():
            for value in self.pidfile.read_text().splitlines():
                self.assertFalse(Path('/proc',value).exists(),'owned process was not reaped: '+value)

    def test_short_waited_children_CPU_rollup_is_counted_once(self):
        result=self.run_mode('short')
        self.assertEqual(result['status'],'completed',result)
        fixture=json.loads(result['output']['stdout']['prefix'])
        self.assertEqual(fixture['children'],4)
        observed=result['aggregate_usage']['cpu_milliseconds']
        # Linux retains CPU usage across exec. Include the owned launcher's
        # startup CPU, which the work-only fixture clock deliberately excludes.
        expected=fixture['fixture_self_cpu_milliseconds']+fixture['fixture_children_cpu_milliseconds']
        self.assertGreaterEqual(observed,expected-2)
        self.assertLess(observed,expected+20,'wait4 and descendant rollup CPU was double-counted')
        self.assertTrue(result['aggregate_usage']['cpu_complete'])
        self.assertFalse(result['aggregate_usage']['cgroup_hard_quota'])
        self.assert_clean(result)
        print('TREE_CPU_ACCOUNTING',{'fixture_cpu_ms':expected,'aggregate_cpu_ms':observed,
                                     'fixture_work_cpu_ms':fixture['fixture_cpu_milliseconds'],
                                     'fixture_self_cpu_ms':fixture['fixture_self_cpu_milliseconds'],
                                     'fixture_children_cpu_ms':fixture['fixture_children_cpu_milliseconds'],
                                     'wait4_receipts':result['cleanup']['wait4_receipts']})

    def test_CPU_budget_cleans_setsid_descendants_but_not_an_unrelated_process(self):
        outsider=subprocess.Popen(['/bin/sleep','30'])
        try:
            result=self.run_mode('cpu',cpu_milliseconds=150)
            self.assertEqual((result['status'],result['reason']),('budget_exceeded','cpu'),result)
            self.assertGreaterEqual(result['aggregate_usage']['cpu_milliseconds'],150)
            self.assertLess(result['aggregate_usage']['cpu_milliseconds'],1500)
            self.assertIsNone(outsider.poll(),'tree cleanup signalled an unrelated PID')
            self.assert_clean(result)
        finally:
            outsider.terminate();outsider.wait(timeout=3)

    def test_all_threads_are_quiesced_before_CPU_partition_is_read(self):
        result=self.run_mode('threads')
        self.assertEqual(result['status'],'completed',result)
        fixture=json.loads(result['output']['stdout']['prefix'])
        expected=fixture['fixture_self_cpu_milliseconds']+fixture['fixture_children_cpu_milliseconds']
        self.assertGreaterEqual(result['sampling']['max_threads_observed_in_process'],3)
        self.assertGreaterEqual(result['aggregate_usage']['cpu_milliseconds'],expected-2)
        self.assertLess(result['aggregate_usage']['cpu_milliseconds'],expected+20)
        self.assert_clean(result)

    def test_aggregate_RSS_and_process_count_budgets(self):
        for mode,updates,reason in [('rss',{'rss_bytes':24*1024*1024},'rss'),
                                    ('count',{'max_processes':3},'process_count')]:
            self.pidfile.unlink(missing_ok=True)
            with self.subTest(mode=mode):
                result=self.run_mode(mode,**updates)
                self.assertEqual((result['status'],result['reason']),('budget_exceeded',reason),result)
                self.assertTrue(result['aggregate_usage']['rss_shared_pages_may_be_double_counted'])
                self.assert_clean(result)

    def test_root_exit_and_setsid_adoption_are_tracked_until_tree_completion(self):
        result=self.run_mode('orphan')
        self.assertEqual(result['status'],'completed',result)
        self.assertEqual(result['root_exit_code'],0)
        self.assertEqual(result['cleanup']['wait4_receipts'],3)
        self.assert_clean(result)
        self.pidfile.unlink()
        result=self.run_mode('escape',wall_ms=500,max_pause_ms=300)
        self.assertEqual((result['status'],result['reason']),('budget_exceeded','wall_clock'),result)
        self.assertEqual(result['cleanup']['wait4_receipts'],3)
        self.assert_clean(result)

    def test_per_process_address_and_descriptor_limits_are_real(self):
        result=self.run_mode('limits',address_space_bytes=32*1024*1024,open_files=16)
        self.assertEqual(result['status'],'completed',result)
        observed=json.loads(result['output']['stdout']['prefix'])
        self.assertEqual(observed['address_space_bytes'],32*1024*1024)
        self.assertEqual(observed['open_files'],16)
        self.assertTrue(observed['allocation_denied'])
        self.assertLess(observed['opened'],16)
        self.assert_clean(result)

    def test_perturbation_budget_terminates_instead_of_silently_pausing_more(self):
        result=self.run_mode('cpu',max_pause_ms=1)
        self.assertEqual((result['status'],result['reason']),('budget_exceeded','perturbation'),result)
        self.assertLessEqual(result['sampling']['quiesce_count'],1)
        self.assertGreaterEqual(result['sampling']['quiesce_upper_bound_milliseconds'],1)
        self.assert_clean(result)

    def test_invalid_permissions_parameters_and_binary_digest_do_not_launch(self):
        for updates,code in [({'cpu_milliseconds':True},'tree_invalid_cpu_milliseconds'),
                              ({'cpu_seconds':1},'tree_invalid_profile'),
                              ({'max_pause_ms':4001},'tree_invalid_max_pause_ms')]:
            with self.subTest(updates=updates),self.assertRaisesRegex(TreeError,code):
                self.backend(self.profile('short',**updates))
        for updates,code in [({'allow_run':False},'tree_run_not_authorized'),
                              ({'binary_sha256':'0'*64},'tree_binary_digest_mismatch')]:
            with self.subTest(updates=updates),patch('observation_extension.process_tree.subprocess.Popen')as launch:
                with self.assertRaisesRegex(TreeError,code):
                    self.backend(self.profile('short',**updates)).run('owned')
                launch.assert_not_called()

    def test_host_SIGKILL_causes_independent_subreaper_to_clean_all_descendants(self):
        profile=self.profile('escape',wall_ms=10000,max_pause_ms=1500)
        config=self.directory/'config.json';config.write_text(json.dumps({'profiles':{'owned':profile}}))
        state=self.directory/'host-state'
        source='''import json,sys\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nfrom observation_extension.process_tree import ProcessTree\nProcessTree(json.loads(Path(sys.argv[2]).read_text()),Path(sys.argv[3]),bundle_root=Path(sys.argv[4])).run('owned')\n'''
        errors=tempfile.TemporaryFile(dir=self.directory)
        host=subprocess.Popen([sys.executable,'-c',source,str(RUNTIME),str(config),str(state),str(ROOT)],
                              stdout=subprocess.DEVNULL,stderr=errors)
        descriptors=[]
        try:
            deadline=time.monotonic()+8;owned=[];guardian=None
            while time.monotonic()<deadline:
                if self.pidfile.exists():owned=[int(x)for x in self.pidfile.read_text().splitlines()]
                if len(owned)>=3:
                    try:
                        status=Path(f'/proc/{owned[1]}/status').read_text()
                        guardian=int(re.search(r'^PPid:\s+(\d+)',status,re.MULTILINE)[1])
                        parent_status=Path(f'/proc/{guardian}/status').read_text()
                        if re.search(r'^PPid:\s+'+str(host.pid)+r'\s*$',parent_status,re.MULTILINE):break
                    except (FileNotFoundError,TypeError):pass
                if host.poll()is not None:
                    errors.seek(0);self.fail(errors.read(4096).decode('utf-8','replace'))
                time.sleep(.01)
            self.assertGreaterEqual(len(owned),3)
            self.assertIsNotNone(guardian)
            for pid in owned[1:]+[guardian]:descriptors.append(os.pidfd_open(pid))
            host.kill();host.wait(timeout=3)
            deadline=time.monotonic()+5
            for fd in descriptors:self.assertTrue(select.select([fd],[],[],max(0,deadline-time.monotonic()))[0])
            for pid in owned:self.assertFalse(Path(f'/proc/{pid}').exists(),'guardian failed to reap owned descendant')
        finally:
            if host.poll()is None:host.kill();host.wait(timeout=3)
            for fd in descriptors:
                if not select.select([fd],[],[],0)[0]:
                    try:signal.pidfd_send_signal(fd,signal.SIGKILL)
                    except ProcessLookupError:pass
                os.close(fd)
            errors.close()

    def test_BrokenPipe_does_not_abandon_unfinished_subreaper_cleanup(self):
        spec=importlib.util.spec_from_file_location('tree_guardian_test',ROOT/'tools/tree_guardian.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        supervisor=module.Supervisor.__new__(module.Supervisor)
        with (patch.object(supervisor,'cleanup',create=True,side_effect=[False,True])as cleanup,
              patch.object(module,'emit',side_effect=BrokenPipeError)):
            with self.assertRaises(BrokenPipeError):supervisor.report_and_retain({},False)
            self.assertEqual(cleanup.call_count,2)
        supervisor.root=SimpleNamespace(stdout=io.BytesIO(),stderr=io.BytesIO())
        supervisor.tracked={};supervisor.selector=SimpleNamespace(close=lambda:None)
        with patch.object(supervisor,'cleanup',side_effect=[False,True])as cleanup:
            supervisor.close()
            self.assertEqual(cleanup.call_count,2)

    def test_initial_discovery_occurs_before_any_pause_budget_is_started(self):
        spec=importlib.util.spec_from_file_location('tree_guardian_discover_test',ROOT/'tools/tree_guardian.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        supervisor=module.Supervisor({'max_pause_ms':1000},-1,-1,Path('/unused'))
        supervisor.started_ns=0;order=[]
        def discovered():
            order.append('discover');return {}
        def clock():
            order.append('clock');return 1
        try:
            with (patch.object(supervisor,'discover',side_effect=discovered),
                  patch.object(supervisor,'reap'),patch.object(module.time,'monotonic_ns',side_effect=clock)):
                self.assertEqual(supervisor.sample()['observed_processes'],0)
            self.assertEqual(order[0],'discover')
            self.assertEqual(order.count('discover'),2)
        finally:
            supervisor.selector.close()

    def test_waiting_for_stop_does_not_repeat_global_discovery(self):
        spec=importlib.util.spec_from_file_location('tree_guardian_wait_test',ROOT/'tools/tree_guardian.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        supervisor=module.Supervisor({'max_pause_ms':1000},-1,-1,Path('/unused'))
        supervisor.started_ns=0
        supervisor.tracked={201:{'pid':201,'start_ticks':1,'fd':1201}}
        stopped={'pid':201,'start_ticks':1,'state':'T','ticks':0,'waited_ticks':0,'rss_pages':0}
        try:
            with (patch.object(supervisor,'discover',return_value={201:stopped})as discover,
                  patch.object(supervisor,'reap'),patch.object(supervisor,'threads_stopped',return_value=True),
                  patch.object(supervisor,'signal')as stop,patch.object(module.os,'dup',return_value=2201),
                  patch.object(module.os,'close'),patch.object(module.signal,'pidfd_send_signal')as resume,
                  patch.object(module,'read_stat',side_effect=[{**stopped,'state':'R'},stopped]),
                  patch.object(module.time,'monotonic_ns',return_value=1),patch.object(module.time,'sleep')):
                self.assertEqual(supervisor.sample()['observed_processes'],1)
            self.assertEqual(discover.call_count,2)
            stop.assert_called_once_with(supervisor.tracked[201],signal.SIGSTOP)
            resume.assert_called_once_with(2201,signal.SIGCONT)
        finally:
            supervisor.selector.close()

    def test_quiescence_deadline_still_refuses_a_partition_after_100_milliseconds(self):
        spec=importlib.util.spec_from_file_location('tree_guardian_deadline_test',ROOT/'tools/tree_guardian.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        supervisor=module.Supervisor({'max_pause_ms':1000},-1,-1,Path('/unused'))
        supervisor.tracked={201:{'pid':201,'start_ticks':1,'fd':1201}}
        try:
            with (patch.object(supervisor,'discover',return_value={}),
                  patch.object(supervisor,'threads_stopped',return_value=True),
                  patch.object(supervisor,'reap')as reaped,
                  patch.object(module,'read_stat',return_value={'state':'T','start_ticks':1}),
                  patch.object(module.time,'monotonic_ns',side_effect=[0,101_000_000,101_000_000,101_000_000])):
                with self.assertRaisesRegex(module.TreeFailure,'tree_quiescence_not_closed'):
                    supervisor.sample()
                reaped.assert_not_called()
            self.assertEqual(supervisor.samples,[])
            self.assertEqual(supervisor.pause_ns,101_000_000)
        finally:
            supervisor.selector.close()

    def test_close_from_another_thread_cleans_an_active_owned_tree(self):
        backend=self.backend(self.profile('escape',wall_ms=5000,max_pause_ms=1000))
        results=[];errors=[]
        def run():
            try:results.append(backend.run('owned'))
            except BaseException as error:errors.append(error)
        worker=threading.Thread(target=run);worker.start()
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            if self.pidfile.exists() and len(self.pidfile.read_text().splitlines())>=3:break
            time.sleep(.01)
        self.assertTrue(self.pidfile.exists())
        closed=backend.close();worker.join(5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(closed['cleanup_errors'],[])
        self.assertFalse(errors,errors)
        self.assertEqual(results[0]['status'],'cancelled')
        self.assert_clean(results[0])

    def test_guardian_pidfd_failure_reaps_the_already_running_owned_tree(self):
        backend=self.backend(self.profile('escape',wall_ms=5000,max_pause_ms=1000))
        original=os.pidfd_open;guardian=[];descriptors=[]
        before=len(os.listdir('/proc/self/fd'))
        def fail_guardian_pin(pid,flags=0):
            if pid==os.getpid():return original(pid,flags)
            guardian.append(pid);descriptors.append(original(pid,flags))
            deadline=time.monotonic()+3
            while time.monotonic()<deadline:
                if self.pidfile.exists() and len(self.pidfile.read_text().splitlines())>=3:break
                time.sleep(.005)
            raise OSError(errno.EMFILE,'injected guardian pidfd limit')
        try:
            with patch('observation_extension.process_tree.os.pidfd_open',side_effect=fail_guardian_pin):
                with self.assertRaisesRegex(TreeError,'tree_launch_or_transport_failed')as failure:
                    backend.run('owned')
            self.assertTrue(failure.exception.effect_dispatched)
            self.assertEqual(len(guardian),1)
            self.assertGreaterEqual(len(self.pidfile.read_text().splitlines()),3)
            self.assertTrue(select.select(descriptors,[],[],0)[0])
            self.assertFalse(Path(f'/proc/{guardian[0]}').exists(),'guardian was not reaped')
            for pid in self.pidfile.read_text().splitlines():
                self.assertFalse(Path('/proc',pid).exists(),'pin failure left an owned descendant')
            self.assertIsNone(backend.active)
            self.assertEqual(list((self.directory/'state').iterdir()),[])
            print('TREE_LAUNCH_PIN_FAILURE',{'guardian_reaped':True,'owned_tree_reaped':True,
                                            'effect_dispatched':failure.exception.effect_dispatched})
        finally:
            for descriptor in descriptors:os.close(descriptor)
        self.assertEqual(len(os.listdir('/proc/self/fd')),before)
