# 编译型原生 worker

此 worker 使用 Go 标准库，实现 Linux pidfd/procfs 连接观察和独立恢复看门狗。包内保留源码、测试与构建说明；在目标环境构建一次后，生产运行不需要 Go 编译器。

```sh
cd native/worker
CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags='-s -w' -o /absolute/runtime-native-worker .
sha256sum /absolute/runtime-native-worker
```

源码 `go.mod` 要求 Go 1.23+，没有第三方 Go 模块依赖。产物摘要可能随编译器版本改变，应审阅自己的产物并填入实际 SHA-256。

复制 `compiled-native-config.example.json`，填入准确的 helper 路径、APP argv、实际 helper SHA-256 和私有状态目录。配置占位值不能作为有效身份 pin。

宿主在启动时核对 helper 整个文件 SHA-256，复制至私有临时文件，重新以只读 fd 打开后删除名字，并通过该 fd 执行。原路径后续被替换不会改变已固定的执行内容。helper 路径、命令模式、目标 procfd 和 pidfd 均来自宿主；模型工具参数只能选择已经固定的会话。

## 进程连接

同时启用工具 `process.connections`、helper 配置和 profile/target 的独立 `allow_connections: true`。不需要内存读取/写入授权。

```json
{"session_id":"process.launch 或 attach 返回的会话"}
```

worker 从继承的目标 procfd 枚举 fd/socket inode，再过滤该目标网络命名空间内的 tcp/tcp6/udp/udp6/unix 表，只返回匹配 inode。宿主在操作前后复核原进程身份，避免 PID 重用错连。

结果含实际 fd、socket inode、命名空间、端点/内核状态、未解析 inode、不可用表和截断信息。Unix 路径只返回空白规范化后字符串的摘要；该摘要可用于关联，但不是对可猜测路径的匿名化。AF_UNIX peer、继承自其他网络命名空间的 socket、并发关闭的 fd 等可能无法解析，必须保留 unknown 数量。

每次最多 4096 fd、128 条连接、每表 2 MiB、响应 128 KiB、2 秒；每个宿主进程最多 4 个此类 worker，满额立即返回 `native_worker_capacity`。不读取连接载荷、不连接端点、不做 DNS；连接只证明观察到的 socket/端点，不证明 URL、API、路由或调用函数。

## 独立恢复看门狗

配置 helper 后，`process.suspend_for` 与受约束内存写入自动使用编译型看门狗，无需为模型新增权限；仍需原有 `allow_control` 以及独立写入范围。

握手为 ready → 宿主要求 stop → 看门狗自己按 pidfd 发送 SIGSTOP → 回执 → 宿主确认线程停止。3 秒租约从实际 stop 开始；宿主死亡、控制管道 EOF 或租约到期尝试 SIGCONT。宿主完成恢复并确认后发送 done。

Python fallback 也使用两阶段 stop 协议，确保停止动作由已就绪的看门狗执行。验证用例覆盖控制宿主 SIGKILL、正常恢复与延迟 arming；看门狗自身被杀、内核故障或高权限干预仍可能阻止恢复。

Go 运行时使用一个执行 CPU 与 32 MiB 软 GC 目标；显式长度和数量上限控制实际工作，软 GC 目标不是硬 RSS 上限。没有无限队列、自动重试或自动扩大预算。主 MCP 宿主仍按原模型串行化调用/副作用，helper 吞吐数字不能冒充完整 MCP 并发吞吐。

## 验证

```sh
cd native/worker
CGO_ENABLED=0 go test ./...
CGO_ENABLED=0 go test -fuzz=FuzzTableParsers -fuzztime=10s -parallel=2 .
cd ../..
RUNTIME_NATIVE_HELPER=/absolute/runtime-native-worker python3 -m unittest discover -s tests -p test_native_helper.py -v
python3 tools/benchmark_native_worker.py --helper /absolute/runtime-native-worker --output /absolute/benchmark.json
```

测试和基准脚本可使用 Python；它们不在生产逐次暂停/连接解析执行路径中。helper 的进程操作依赖 Linux pidfd/procfs；其他系统需要对应实现和实际运行验证。
