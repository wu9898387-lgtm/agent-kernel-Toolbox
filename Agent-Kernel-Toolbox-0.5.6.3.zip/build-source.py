#!/usr/bin/env python3
"""Compatible toolbox build entry; source is read from src/ or the zipapp."""
from pathlib import Path
import runpy

# Keep the original command/API while maintaining one packaging implementation.
_builder = runpy.run_path(str(Path(__file__).resolve().with_name('build-runtime.py')))
globals().update({key: value for key, value in _builder.items() if not key.startswith('__')})

if __name__ == '__main__':
    raise SystemExit(main())
