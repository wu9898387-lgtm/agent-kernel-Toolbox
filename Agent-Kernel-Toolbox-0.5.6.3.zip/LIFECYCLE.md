# 进程生命周期与 CPU 限额

`process.launch`、`process.status`、`process.terminate` 使用固定进程身份；读取、调试和控制权限分别登记。

## 配置和含义

```json
{
  "profiles": {
    "diagnostic-app": {
      "argv": ["/absolute/app"],
      "allow_memory": true,
      "startup_timeout_ms": 5000,
      "limits": {
        "cpu_seconds": 30,
        "cpu_grace_seconds": 1,
        "cpu_scope": "process",
        "address_space_bytes": 536870912,
        "open_files": 256
      }
    }
  }
}
```

`cpu_seconds` 是 Linux `RLIMIT_CPU` 的 soft 值，按同一进程全部线程的用户态和内核态 CPU 时间累计。默认 hard 为 soft 加 1 秒；`cpu_grace_seconds: 0` 明确表示 soft/hard 相同。父环境已有更低值时进一步收紧。达到 soft 时内核发 SIGXCPU，程序可能处理或忽略；达到 hard 时内核强制结束。进程不会因为单纯 sleep 超过这个墙钟时长而被 CPU 限额结束。

启动器自身的设置/exec 开销也计入同一个进程的 CPU 用量；CPU 亲和性不是百分比节流。地址空间限制不是 RSS；整个进程树没有聚合 CPU 或内存上限。子进程继承 rlimit 值，但每个进程分别记账，不能阻止通过 fork 分摊总 CPU。

`cpu_scope: "process_tree"` 等非 process 值明确拒绝，错误为 `process_tree_cpu_budget_requires_delegated_cgroup`。该接口没有聚合 cgroup 执行后端。需要受控程序树的采样预算时，参见 [DEFENSIVE-OBSERVATION.md](DEFENSIVE-OBSERVATION.md) 中的 `tree.*`；其预算仍不等于 cgroup 硬限额。`runtime.capabilities` 如实报告 `aggregate_cpu_budget_implemented: false`。`cgroup_procs_writable` 只是该路径写权限探测，不等于完整的 cgroup 可用性证明。

## 启动、退出和身份

启动过程始终先用 gate 暂停交接，在目标 exec 前固定 pidfd、procfs 目录和进程出生身份，再允许目标执行。`startup_timeout_ms` 约束交接握手（100–30000ms），不是目标程序的运行超时，也不承诺对内核不可中断任务实现硬墙钟终止。

在 `allowed_tools` 加入 `process.status` 后，可以使用 `{"session_id":"实际会话 ID"}` 查询仍存活或已经退出的会话。结果包含拥有关系、出生身份、当前执行文件、退出码、信号、内存描述符状态及配置限额。正常退出码和实时信号均可表示；附加的非子进程没有可回收的退出码。查询是分步观察，不是原子快照。仅看到 SIGKILL 不推断一定由 CPU 限额导致。

交接管道保留目标 exec 的数值 errno，并区分不支持的可执行格式、缺少解释器和执行权限拒绝。内核拒绝 IA32 ELF 时，将 ENOEXEC 记录为不支持该执行格式；其他启动错误保留其实际原因。

进程实例由 pidfd 加 PID、启动 tick、boot ID、UID 和 PID namespace 交叉校验；不匹配时拒绝发信号。终止使用 pidfd，不用可重用的裸 PID。已退出的自有会话可以正常查询/完成终止请求，不再因为 `/proc/PID/exe` 消失而丢失退出状态。短命令交接与退出测试不等同于强制制造 PID 重用。

内存、寄存器和既有 UI 句柄仍受执行文件校验约束；exec 为其他文件不会把旧地址或句柄自动转移过去。可执行文件 inode 本身不能辨认同一文件的再次 exec。内存读取因此另外固定一个只读 `/proc/PID/mem` 描述符，不在每次读取时重新打开；同文件 re-exec 后也不能悄悄改读新地址空间，短读会使该内存绑定失效。该保证不等于通用 exec 事件监控，不保证辨认所有相同文件的 UI/调试状态变化。需要新映像时显式重新建立会话。

## 验证

`tests/test_lifecycle.py` 覆盖 exec、可执行文件改名/删除、CPU 软硬限额、多线程忽略 SIGXCPU、继承限制、短命令退出、同文件 re-exec 的内存拒绝、出生身份不符拒绝发信号、实时信号状态、TERM/KILL 退出竞态、进程树预算拒绝、exec 失败和句柄/启动超时清理。

```sh
python3 -m unittest discover -s tests -p test_lifecycle.py -v
```

测试需要 Linux procfs/pidfd 和对应信号、资源限制权限。结果只适用于实际运行的内核与架构；环境拒绝的操作按其真实状态报告。
