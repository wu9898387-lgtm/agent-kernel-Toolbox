# Agent-Kernel-Toolbox 0.5.6.2

Agent-Kernel-Toolbox 为 AI 客户端提供可配置的运行时工具：操作浏览器和应用、观察进程与内存、调用固定分析后端，以及编译纯整数 IR。通过本地 MCP stdio 接入；工具只能使用安装者配置的目标、来源、文件、编译器和权限。

主入口为 `runtime-access.pyz`，Python 实现已包含在其中。解压后保持目录结构，通过配置启用所需组件。

包内同时提供原生 SDK 和可运行示例、13 个跨平台对象示例、测试与测试夹具、MCP/桌面/后端诊断、基准工具和重建入口。Python 源码完整保存在 pyz 内，可按需提取；日常使用和随包检查无需额外源码目录。

## 快速开始

### 1. 检查安装

在解压目录中运行：

```sh
python3 tools/check_installation.py --mcp
```

该命令检查运行文件、pyz 和元数据，并使用临时最小配置建立只读 MCP 连接；不启动目标应用、浏览器或编译器。省略 `--mcp` 可只做离线安装检查。

需要校验下载的 ZIP 时运行：

```sh
python3 verify-runtime.py /absolute/Agent-Kernel-Toolbox-0.5.6.2.zip
```

如已从可信渠道取得整包摘要，追加 `--expected-sha256 EXPECTED_SHA256`。`CONTENTS.json` 用于检查包内内容一致性；包内摘要本身不认证发布者。

### 2. 创建配置

从 [runtime-minimal-config.example.json](runtime-minimal-config.example.json) 复制一份配置到自己的私有目录，填写实际绝对路径：

```json
{
  "schema_version": 1,
  "state_directory": "/absolute/private/toolbox-state",
  "allowed_tools": [
    "runtime.status",
    "runtime.capabilities",
    "runtime.audit",
    "build.inspect"
  ],
  "portable_build": {
    "profiles": {}
  }
}
```

配置必须是当前用户拥有的普通文件，不能是符号链接，也不能允许组或其他用户写入。建议文件权限 `0600`；状态目录权限 `0700`，仅供这一组固定配置使用。

```sh
chmod 600 /absolute/private/toolbox-config.json
```

示例中的 `/absolute/...` 和全零 SHA-256 都是占位值，必须替换。JSON 路径不展开 `~` 或环境变量。

### 3. 连接 MCP 客户端

按 [mcp-client.example.json](mcp-client.example.json) 填入 Python、pyz 和配置文件的绝对路径：

```json
{
  "mcpServers": {
    "Agent-Kernel-Toolbox": {
      "command": "/absolute/python3",
      "args": [
        "/absolute/Agent-Kernel-Toolbox/runtime-access.pyz",
        "serve",
        "--config",
        "/absolute/private/toolbox-config.json"
      ]
    }
  }
}
```

不同客户端的配置入口可能不同，核心是以 stdio 启动上述命令。服务也可直接运行：

```sh
python3 runtime-access.pyz serve --config /absolute/private/toolbox-config.json
```

启动后服务等待 stdin 上的 MCP 消息，不提供网页界面。正常情况下 stdout 仅输出 JSON-RPC，诊断写入 stderr。客户端按 `initialize → notifications/initialized → tools/list → tools/call` 建立连接，结束时关闭 stdin 并等待宿主清理。

首先调用 `runtime.status`、`runtime.capabilities`、`build.inspect`，确认配置和宿主信息。例如以下内容作为 `tools/call` 的参数：

```json
{"name": "runtime.status", "arguments": {}}
```

协议细节见 [MCP.md](MCP.md)。

## 能做什么

工具目录包含 **162 项工具、36 个工具族**。`tools/list` 只返回当前 `allowed_tools` 中的项目及其实际参数 schema；按任务开放所需工具。

| 能力 | 工具族 | 使用条件 |
| --- | --- | --- |
| 运行状态、审计和工具禁用 | `runtime.*`、`policy.*` | 固定宿主配置和私有状态目录 |
| 浏览器观察、查询、导航、表单及网络控制 | `browser.*` | Node、Playwright、可启动的浏览器、准确的 origins；输入需要独立授权 |
| 进程、内存、CPU、连接和原生控件 | `process.*`、`native.*` | Linux 进程身份与相应读取、调试、控制、写入或无障碍权限 |
| 远程应用及调试 | `appium.*`、`debugger.*` | 固定设备、应用、Appium 或 LLDB 配置 |
| 文件格式、应用声明路由和静态脚本分析 | `binary.*`、`app.*`、`reverse.*` | 已登记文件和所选分析器 |
| 对象编译、整数 IR 和受限原生函数转换 | `build.*`、`ir.*`、`translate_native.*` | 固定输入、编译器、摘要、目标和支持的函数语义 |
| 程序分析、符号执行和仿真 | `analysis.*`、`symbolic.*`、`structure.*`、`portable.*` | 对应外部引擎、明确输入域和资源预算 |
| 指令、程序、对象和环境观察 | `probe.*`、`program.*`、`metadata.*`、`environment.*` | 已登记目标、分析器及观察范围 |
| 协作式状态、对象和 JVM 操作 | `coordinated.*`、`semantic.*`、`managed.*`、`managed_probe.*` | 已知写者、安全点或固定 JVM/agent；相关程序需支持接入 |
| 进程树、文件活动、指标检测及 HTTP 请求 | `tree.*`、`files.*`、`malware.*`、`network.*` | 固定目标/请求配置、所需跟踪权限和规则 |
| 跟踪、原生回放和固定探针替换 | `trace.*`、`debug_native.*`、`compatibility.*` | 内核权限、硬件能力及固定 GDB/Frida 等后端 |
| QEMU 整机状态与回放 | `machine.*` | 固定机器模型、内存、内核、固件及 QEMU |
| CPU 环境、探针预算和 OpenGL 过滤 | `cpu.*`、`probes.*`、`render.*` | 所选宿主能力；OpenGL 需显式预加载组件 |

`runtime.capabilities` 包含静态支持范围及基础宿主探测。某个工具出现在目录中，并不代表它所需的引擎、设备和权限已经就绪；实际可用性由对应调用及后置状态确认。

## 运行环境与组件

| 用途 | 条件 |
| --- | --- |
| 基础 MCP 宿主 | Linux / POSIX 环境、Python 3.10+；核心宿主使用 Python 标准库 |
| 浏览器 | Node.js 24+、随包锁定的 Playwright 依赖、可运行的 Chromium/Firefox/WebKit |
| 纯 IR 对象编译 | POSIX 宿主；固定摘要的 GCC、Clang 或 Zig；编译器需支持所选目标 |
| Linux 原生 UI | 桌面会话、D-Bus、AT-SPI 和应用导出的无障碍树 |
| 原生辅助进程 | 按需构建 Linux Go worker，或 C / Rust 协作式代理；构建要求见组件说明 |
| JVM | 相应 JDK、已登记 JVM/classpath；对象探针还需 JVMTI 构建环境 |
| 额外分析后端 | 按启用的配置准备 pyelftools、Z3、angr、Frida、YARA、Ghidra、JADX、GDB、QEMU、strace、perf 等 |

只准备任务所需的后端。编译工具、浏览器、分析引擎和设备服务由部署环境提供；配置中要求摘要的文件必须固定到实际使用的版本。

原生组件的源码与构建入口用于生成与宿主 ABI 匹配的可执行文件或库。参见 [native/README.md](native/README.md)、[协作式代理](native/runtime-agent/README.md) 和 [JVM 组件](native/managed-jvm/README.md)。操作系统权限、外部服务和设备能力不会由安装检查自动赋予。

## 配置选择与操作流程

先从适合任务的模板复制配置，再逐项填写真实路径、摘要、设备/应用标识和权限。不要把多个模板的 `allowed_tools` 无条件合并。

| 任务 | 配置模板 |
| --- | --- |
| 最小状态与能力检查 | [runtime-minimal-config.example.json](runtime-minimal-config.example.json) |
| 浏览器 | [runtime-config.example.json](runtime-config.example.json)、[browser-forms-config.example.json](browser-forms-config.example.json) |
| Linux 原生进程和控件 | [native-config.example.json](native-config.example.json)、[native-browser-config.example.json](native-browser-config.example.json) |
| 编译型原生辅助进程 | [compiled-native-config.example.json](compiled-native-config.example.json) |
| 固定远程设备/应用与调试器 | [cross-platform-config.example.json](cross-platform-config.example.json)、[debugger-profile.example.json](debugger-profile.example.json) |
| 程序、对象和环境观察 | [monitoring-config.example.json](monitoring-config.example.json) |
| 文件活动、指标规则、HTTP 和进程树 | [defensive-config.example.json](defensive-config.example.json) |
| 路由和逆向后端 | [reverse-config.example.json](reverse-config.example.json) |
| IR、分析引擎、语义代理、JVM 和整机功能 | [runtime-advanced-config.example.json](runtime-advanced-config.example.json) |
| 独立编译 CLI | [portable-build-config.example.json](portable-build-config.example.json) |

[v055-config.example.json](v055-config.example.json) 保留为高级配置的兼容文件名，内容与 `runtime-advanced-config.example.json` 相同。所有示例均需填写当前部署路径和摘要；编译型 worker 模板中的全零摘要应替换为本机产物的 SHA-256。

推荐在每个任务中遵循以下顺序：

1. **确认范围**：读取 `runtime.status`，核对工具授权、目标和后端配置。
2. **获取当前观察**：读取进程身份、DOM/ARIA、原生控件、输入文件或编译计划，使用返回的当前句柄。
3. **执行所需动作**：修改型工具使用一个新的 `request_id`；工具参数以当前 `tools/list` 为准。
4. **确认结果**：独立读取字段值、URL、应用状态、内存、对象头或文件摘要；接口成功响应不能替代业务完成。
5. **释放资源**：完成任务后关闭自己创建的会话/目标，结束 MCP 输入并等待清理。

`request_id` 标识一次具体操作。连接中断、超时或返回 Unknown 时，先处理原操作状态，不能用新 ID 自动重试。

### 浏览器

安装锁定的浏览器依赖：

```sh
cd browser
npm ci --ignore-scripts --omit=dev --no-audit --no-fund
```

配置 `browser.executablePath` 可使用已有浏览器；需要 Playwright 管理的 Chromium 时运行：

```sh
npx playwright install chromium
```

随后返回包根目录启动 MCP。在配置中填写精确的 `allowedOrigins`；读取可编辑内容和输入分别由 `includeEditableText`、`allowTextInput` 控制。

典型流程为 `browser.open → browser.snapshot/query/fields → browser.set_text/invoke → 重新观察`。写入使用刚观察到的 `snapshot_id` 和 `node_id`；导航或文档替换后重新获取句柄。独立扩展的安装与使用见 [browser/README.md](browser/README.md)。

DOM/ARIA、原生无障碍和截图是不同数据来源。未挂载的控件、关闭的 Shadow DOM 和自绘内容可能不出现在 DOM/无障碍观察中。

### 原生进程和应用

在 `profiles` 中登记要启动的完整 `argv`，通过 `process.launch` 选择 profile；工具调用不能临时提供任意命令。对已有进程，先取得身份信息：

```sh
python3 runtime-access.pyz identify --pid 12345
```

将返回的实际身份登记到 `targets`，再调用 `process.attach`。PID 复用不代表同一个进程实例。内存读取、调试、控制、写入和文本输入分别配置授权；可写区还需通过 `write_regions` 登记。

原生控件流程为 `native.open → native.snapshot/query → native.focus/set_text/invoke → native.wait_for 或重新观察`。应用必须导出相应的无障碍接口。远程 Windows/macOS/Android/iOS 操作使用固定的 Appium/LLDB profile，结果取决于所配置的驱动、设备、应用与平台能力。

## 平台检测与纯 IR 编译

`build.*` 接受已登记、摘要固定的纯整数 word-IR，产出可重定位对象文件。输入示例见 [portable-word-ir.example.json](portable-word-ir.example.json)。

先检测宿主：

```sh
python3 tools/runtime-platform.py detect
```

创建独立编译配置，填写编译器、输入文件的真实绝对路径及 SHA-256：

```json
{
  "compiler": "/absolute/registered/clang",
  "compiler_sha256": "REPLACE_WITH_64_LOWERCASE_HEX_DIGITS",
  "compiler_driver": "auto",
  "timeout_seconds": 10,
  "profiles": {
    "local": {
      "module_path": "/absolute/Agent-Kernel-Toolbox/portable-word-ir.example.json",
      "module_sha256": "REPLACE_WITH_64_LOWERCASE_HEX_DIGITS",
      "target": "host",
      "allow_compile": false
    }
  }
}
```

使用 Zig 时将 `compiler_driver` 设为 `zig-cc`，`compiler` 指向 Zig 可执行文件。使用 `target: "host"` 时，宿主 ABI 必须能明确匹配；否则填写 `build.inspect` 返回的显式目标。

查看可用 profile 和目标，并校验计划：

```sh
python3 tools/runtime-platform.py inspect --config /absolute/private/build.json --state-directory /absolute/private/build-state
python3 tools/runtime-platform.py plan --config /absolute/private/build.json --state-directory /absolute/private/build-state --profile local
```

确认计划后，将 `allow_compile` 设为 `true`，再执行：

```sh
python3 tools/runtime-platform.py compile --config /absolute/private/build.json --state-directory /absolute/private/build-state --profile local --request-id build-local-001
```

CLI 的构建配置是独立的 `portable_build` 对象，状态目录绑定固定最小 Host 配置；不要与采用另一份配置的 MCP Host 混用。通过 MCP 编译时，将同一对象放入宿主配置的 `portable_build`，授权 `build.inspect`、`build.plan`、`build.compile`，并为每次编译提供新的请求 ID。

返回结果包含目标信息、`artifact_path`、内容摘要及缓存信息。程序检查对象格式、机器类型、位宽、端序和 ABI；后续链接、SDK/系统库、签名及目标设备运行由部署流程完成。`target_execution_verified` 为 `false` 时，不表示目标程序已经运行。

内置目标覆盖 Linux 的 x86/x86_64、ARM/AArch64、RISC-V、MIPS、PPC，以及 macOS 和 Windows 的 x86_64/AArch64；具体 triple 和 libc 变体以 `build.inspect` 为准。该路径处理受限纯整数 IR，不提供任意操作系统 API 或整个应用的自动转换。

随包的 [examples/portable-objects/](examples/portable-objects/README.md) 提供 13 个对象及当前文件摘要、目标和 ABI 清单，可用于识别格式、检查链接输入和学习目标配置。它们需要适用的链接器和目标运行环境；详细构建流程见 [PORTABLE-BUILD.md](PORTABLE-BUILD.md)。

## 原生 SDK 示例与构建

协作式语义代理提供 `demo.c` 和可运行的五槽示例：字段快照、比较设置、带溢出检查的加法、对象迁移、对象重新实例化。具备 C11 与 Rust 工具链时运行：

```sh
python3 native/runtime-agent/build.py --output-directory /absolute/native-agent-build
```

输出为 `runtime-agent-demo`、`runtime-control`、`compiler-object-layout.json`，以及可供应用链接的 `runtime-agent.o`、`agent.h` 和同内容元数据入口 `build.json`。输出目录可预先存在；已有同名产物不会被覆盖。`build_id` 使用 `agent.h + agent.c + demo.c` 的内容摘要。示例启动、控制器调用、并发验证和应用接入方式见 [native/runtime-agent/README.md](native/runtime-agent/README.md)。

## 检查、诊断与基准

测试源码、夹具与检查脚本均随包提供。检查会按实际条件创建临时目标、编译夹具或启动所选后端；先阅读对应指南和命令的 `--help`。需要第三方验证依赖时，在自己的 Python 环境中安装 [requirements-validation.txt](requirements-validation.txt)，不影响只使用标准库的基础宿主。

离线契约检查与 Python 测试入口：

```sh
python3 tools/check_package_contract.py
python3 -m unittest discover -s tests -v
```

测试自动优先加载随包 `runtime-access.pyz`，直接运行单个测试文件也可使用。缺少特定工具链、设备或引擎时，相应检查可能跳过或报告不可用；需要内核权限的操作也可能失败。完整测试通过与否由本次执行输出判断。

浏览器依赖准备完成后运行：

```sh
cd browser
npm run test:unit
npm run test:browser
```

`npm test` 运行全部浏览器测试。`test:unit` 覆盖扩展和路由证据逻辑；`test:browser` 需要实际可启动的浏览器。

| 设施 | 入口 / 指南 |
| --- | --- |
| stdio MCP 工具目录、路由和原生操作检查 | `tools/check_runtime_mcp.py`，见 [MCP.md](MCP.md) |
| 官方 MCP Python SDK 客户端检查 | `tools/check_official_mcp.py`，见 [MCP.md](MCP.md) |
| 浏览器 MCP 联调 | `tools/check_browser_mcp.py`，见 [browser/README.md](browser/README.md) |
| 原生/浏览器无障碍与桌面检查 | `tools/check_live_accessibility.py`、`tools/check_advanced_accessibility.py`、`tools/run_desktop_checks.py`；见 [LIVE_CHECKS.md](LIVE_CHECKS.md) 和 [ADVANCED_CHECKS.md](ADVANCED_CHECKS.md) |
| ABI、跨架构读取与逆向检查 | `tools/check_cross_architecture.py`；见 [COMPATIBILITY.md](COMPATIBILITY.md) |
| 原生 worker 性能测量 | `tools/benchmark_native_worker.py`；见 [NATIVE_WORKER.md](NATIVE_WORKER.md) |
| 恢复/整机夹具构建 | `tools/build_recovery_fixture.py`、`tools/build_machine_fixture.py`，配合 `tests/fixtures/` |
| C、Rust、Go 组件自测 | `native/runtime-agent/concurrent_test.c`、Rust 单元测试、`native/worker/worker_test.go`；见对应组件说明 |

## 源码提取与重建

在未修改的解压目录中，可直接重新生成同一工具包；旧入口名继续可用：

```sh
python3 build-source.py --output /absolute/new/Agent-Kernel-Toolbox-0.5.6.2.zip
```

`build-runtime.py` 提供相同构建入口。需要查看或修改独立 Python 源文件时，提取到尚不存在的目录：

```sh
python3 tools/extract_sources.py --output src
```

提取前会核验 pyz 中每个源文件的摘要。之后构建器优先使用 `src/` 重新生成 pyz，未提取时从现有 pyz 重建。发布 ZIP 仍只保存一份 Python 实现；提取的 `src/` 不重复打包。修改源码后应先重建并解压新包，再对新包运行检查。具体目录、体积上限与构建约定见 [PACKAGING.md](PACKAGING.md)。

## 状态与异常恢复

同时检查 MCP `isError`、`structuredContent.ok`，以及存在时的 `unknown_effect`、`effect_unknown`、`effect_dispatched`。未知效果需要确认实际状态后处理，即使传输层返回成功也不能忽略。

宿主在私有状态目录保存有副作用请求及有界调用摘要，以防止重复派发并支持恢复。同一状态目录只允许一个活动 Host，且绑定配置摘要。进程写操作按稳定的真实进程实例共享未决阻断；重新附加、更换别名或重启不会完成对账。

出现 Unknown 时：

1. 停止继续修改同一目标，保留状态目录；可使用只读观察和允许的独立清理入口确认实际情况。
2. 停止使用该状态目录的 Host。
3. 查看审计并核对目标状态：

   ```sh
   python3 runtime-access.pyz audit --state-directory /absolute/private/toolbox-state
   ```

4. 由操作者确认处置结果，再记录离线对账：

   ```sh
   python3 runtime-access.pyz reconcile --state-directory /absolute/private/toolbox-state --request-id operation-001 --disposition effect_observed
   ```

可选处置值为 `effect_observed`、`no_effect_observed`、`abandoned`。对账记录处置结论，不执行、撤销或重试原动作；该请求 ID 继续保持不可重放。

配置摘要改变时，先完成现有状态中的未决处理，再为独立配置使用专用目录。不要通过删除数据库或更换目录来绕过同一目标的未决效果。

## 内置 Skill

`skills/agent-kernel-toolbox/` 包含执行工作流、操作参考和只读连接检查器。将该目录交给支持本地 skills 的客户端按其方式加载；MCP 服务配置仍使用客户端自己的接入入口。

可单独检查默认只读连接，或指定已经登记的配置：

```sh
python3 skills/agent-kernel-toolbox/scripts/inspect_mcp.py --entry /absolute/Agent-Kernel-Toolbox/runtime-access.pyz
python3 skills/agent-kernel-toolbox/scripts/inspect_mcp.py --entry /absolute/Agent-Kernel-Toolbox/runtime-access.pyz --config /absolute/private/toolbox-config.json
```

配置已被活动 Host 占用时，先停止该 Host 或使用默认临时检查，避免竞争同一个状态目录。脚本会初始化、列举获准工具并调用可用的状态/能力/构建检查入口，不执行目标修改。使用 `--protocol 2025-06-18` 可指定另一种支持的协议。

## 常见问题

| 现象 | 处理方式 |
| --- | --- |
| 启动后没有界面或输出 | stdio 服务正在等待客户端消息；使用 MCP 客户端或 `check_installation.py --mcp` 检查连接 |
| 工具没有出现在列表中 | 检查 `allowed_tools`，并重新启动配置对应的 Host |
| `config_must_be_owned_regular_file` | 检查文件属主、普通文件类型、权限和路径；不使用符号链接 |
| `state_directory_must_be_private` | 使用当前用户拥有、权限 `0700` 的私有目录 |
| `state_config_changed_...` 或 Host 锁冲突 | 检查是否已有 Host，核对配置和原状态；先处理未决请求 |
| origin 或页面句柄被拒绝 | 核对精确来源，重新观察当前文档；不复用导航前的句柄 |
| 编译器/输入摘要不匹配 | 核对登记路径与实际文件来源，确认后更新配置中的摘要；不跳过校验 |
| ptrace、perf、AT-SPI 或浏览器启动失败 | 检查宿主权限、桌面服务、可执行路径和运行环境；安装检查通过不代表这些后端均可用 |
| 收到 Unknown 或清理未完成 | 保留状态，先观察/清理并离线对账，不自动重放 |

## 文件入口

| 路径 | 用途 |
| --- | --- |
| `runtime-access.pyz` | MCP 宿主与 Python 实现 |
| `runtime-manifest.json`、`CONTENTS.json`、`verify-runtime.py` | 当前安装信息与内容一致性检查 |
| `MCP.md`、`mcp-client.example.json` | MCP 协议与接入配置 |
| `tools/` | 平台命令、安装诊断和各后端所需的运行 helper |
| `browser/` | Node 浏览器适配器及独立扩展 |
| `native/` | 可选原生组件、接入头文件、示范应用、构建与组件自测 |
| `tests/` | 可运行回归检查及 C、Java、Kotlin、汇编等测试夹具 |
| `examples/portable-objects/` | 13 个跨平台对象示例及格式、摘要清单 |
| `build-source.py`、`build-runtime.py` | 兼容构建入口与固定清单打包器 |
| `skills/agent-kernel-toolbox/` | 客户端工作流与只读检查器 |
| 根目录 `*.example.json` | 可编辑的配置与 IR 模板 |

专题指南包括 [运行状态](RUNTIME.md)、[生命周期](LIFECYCLE.md)、[原生操作](NATIVE.md)、[平台配置](CROSS_PLATFORM.md)、[逆向分析](REVERSE.md)、[程序观察](PROGRAM-MONITORING.md) 和 [进程树、文件与网络观察](DEFENSIVE-OBSERVATION.md)。它们说明当前操作条件和用法。

## 许可证

本包附带 [GNU Affero General Public License v3](LICENSE)，组件元数据声明 `AGPL-3.0-only`。Go 辅助组件同时保留其 `GO-LICENSE` 和 `GO-PATENTS`；所选第三方引擎按各自许可证使用。
