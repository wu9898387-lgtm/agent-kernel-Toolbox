# 原生桌面与公开网站检查

`tools/check_live_accessibility.py` 通过 Toolbox 的 MCP stdio 调用 `process.*` / `native.*`，在 Linux 上检查真实 AT-SPI 控件。运行器只使用自己创建的浏览器 profile 和 Mousepad 草稿，保留每步回执及业务结果；不依赖截图、OCR 或全局键鼠注入。

## 接入已有能力

以 `native-browser-config.example.json` 为配置起点。对明确启动的应用设置 `enable_accessibility: true`，Host 为该应用准备辅助功能环境，不修改全局桌面服务。应用需要同时具备可用的 AT-SPI 实现和当前 D-Bus 会话；仅有浏览器命令行开关无法保证它注册原生无障碍树。

调用 `process.launch → native.open` 后，用 `native.query` 查找真实控件：

```json
{"session_id":"RETURNED_SESSION_ID","query":"Whetting Your Appetite","roles":["link"],"limit":1}
```

结果提供 `snapshot_id`、实际 `node_id`、角色、文字、状态与动作。根据当前返回值调用 `native.invoke`，随后重新 query 检查文档或正文。快照和查询句柄只使用一次、15 秒有效；新查询使上一轮句柄失效。平台不提供文档 URI 时保持缺失，不能从标题推导 URL。

`native.query` 按字面量、角色和数量上限匹配可见非敏感节点，最多扫描 4096 节点、返回 64 项，并受 worker 截止和宿主输出预算约束。快照遍历省略未显示的菜单子树；隐藏的菜单项不能当作当前可操作控件。密码与敏感子树始终不读取或编辑，普通编辑器内容由 `include_editable_text` 独立授权。

## 可运行流程

| 检查对象 | 操作 | 结果判断 |
| --- | --- | --- |
| Chromium：Example.com → IANA | 观察真实链接并调用其 AT-SPI 动作 | 重新读取目标文档标题、正文和平台实际提供的 URI |
| Chromium：Python 教程 | 观察章节链接，点击后再查询 | 核对章节标题、正文及文档 URI |
| 可选 Firefox：Example.com → IANA | 在新 profile 中启用原生无障碍并操作链接 | 使用实际导出的标题和正文；没有 URI 时不补造 |
| Mousepad | 在专用草稿输入中文，通过可见 File/Save 菜单保存 | 独立读取磁盘文件并对照输入内容与摘要 |

这些是运行器的验证目标，执行后以生成结果为准。公共页面、菜单文字或无障碍接口改变可能使某个检查失败，应检查实际界面和回执。

## 运行

需要 Linux、AT-SPI、D-Bus、Xvfb、Chromium 和 Mousepad。由根目录执行：

```sh
python3 tools/check_live_accessibility.py \
  --xvfb /absolute/Xvfb \
  --chromium /absolute/chromium \
  --mousepad /absolute/mousepad \
  --output /absolute/new-test-run
```

`--output` 必须是尚不存在的目录。运行器建立独立 X/D-Bus、临时 XDG 设置和新的 profile，在此目录保存证据与草稿，不安装系统组件。当前桌面环境已准备好时可不传 `--xvfb`。

有 Firefox 时增加 `--firefox /absolute/firefox`。环境代理 CA 如需显式登记，可增加 `--ca-certificate /absolute/operator-trusted-proxy-ca.crt`；这需要 `certutil`，证书只导入新建 Firefox profile，TLS 验证保持开启。代理 URL 不支持内嵌用户名/密码。

运行器为独立 Chromium 配置 `--no-sandbox`，隔离 Firefox 检查使用 `MOZ_DISABLE_CONTENT_SANDBOX=1`；这些测试启动条件不写入常规应用配置。完整测试条件应与输出一起保留。

检查字段标签、替换对话框、复选框和网页表单时，使用 [ADVANCED_CHECKS.md](ADVANCED_CHECKS.md) 的运行器。原生控件、Playwright DOM 和其他平台 Appium 各自使用不同接口，需要分别确认结果。
