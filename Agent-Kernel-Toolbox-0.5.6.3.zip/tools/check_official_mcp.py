#!/usr/bin/env python3
"""Optional interoperability check using the installed official MCP Python SDK.

Connects to the packaged stdio server, evaluates fixed owned integer IR and
compiles a digest-pinned owned file with real GCC. No SDK is installed by this
script. Successful schema/allowlist denials are separate from actual tool runs.
"""
from __future__ import annotations

import argparse
from datetime import timedelta
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import tempfile
import traceback

ROOT = Path(__file__).resolve().parents[1]
MODULE = {'schema_version': 1, 'width': 64, 'inputs': ['x', 'y'],
          'instructions': [{'id': 'sum', 'op': 'add', 'args': ['x', 'y']},
                           {'id': 'answer', 'op': 'xor', 'args': ['sum', 'y']}], 'result': 'answer'}
ALLOWED = ['runtime.status', 'ir.evaluate', 'build.inspect', 'build.plan', 'build.compile']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


async def check(args, report):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    compiler = shutil.which('gcc')
    if compiler is None:
        raise RuntimeError('real_gcc_not_available')
    compiler = str(Path(compiler).resolve())
    report.update(sdk={'distribution': 'mcp', 'version': version('mcp')},
                  server_entry=str(args.entry), server_entry_sha256=sha(args.entry),
                  compiler_sha256=sha(compiler))
    expected_version = json.loads((args.bundle_root / 'runtime-manifest.json').read_text())['version']
    with tempfile.TemporaryDirectory(prefix='official-mcp-', dir=args.bundle_root) as temporary:
        directory = Path(temporary)
        source = directory / 'owned-word-ir.json'
        source.write_text(json.dumps(MODULE))
        config = directory / 'config.json'
        config.write_text(json.dumps({'schema_version': 1, 'state_directory': str(directory / 'state'),
            'allowed_tools': ALLOWED, 'ir_modules': {'owned': MODULE}, 'portable_build': {
                'compiler': compiler, 'compiler_sha256': sha(compiler), 'profiles': {'owned': {
                    'module_path': str(source), 'module_sha256': sha(source),
                    'target': 'host', 'allow_compile': True}}}}))
        config.chmod(0o600)
        parameters = StdioServerParameters(command=sys.executable,
            args=['-I', str(args.entry), 'serve', '--config', str(config), '--bundle-root', str(args.bundle_root)])
        with tempfile.TemporaryFile(mode='w+') as errors:
            try:
                async with stdio_client(parameters, errlog=errors) as (reader, writer):
                    async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=30)) as session:
                        initialized = await session.initialize()
                        report['initialize'] = initialized.model_dump(mode='json')
                        assert initialized.serverInfo.version == expected_version
                        catalog = await session.list_tools()
                        report['tools_list'] = [tool.name for tool in catalog.tools]
                        assert set(report['tools_list']) == set(ALLOWED)

                        async def call(tool, arguments=None, *, refusal=None):
                            response = await session.call_tool(tool, arguments or {})
                            value = response.structuredContent
                            assert isinstance(value, dict), 'structured_content_required'
                            text = next(item.text for item in response.content if item.type == 'text')
                            assert json.loads(text) == value, 'text_and_structured_content_disagree'
                            if refusal is None:
                                assert response.isError is False and value.get('ok') is True, value
                                assert not value.get('unknown_effect'), value
                                status = 'actual_success'
                            else:
                                assert response.isError is True and value.get('ok') is False, value
                                assert value.get('error') == refusal, value
                                assert not value.get('effect_unknown') and not value.get('effect_dispatched'), value
                                status = 'expected_denied'
                            report['invocations'].append({'tool': tool, 'status': status, 'response': value})
                            return value.get('data')

                        state = await call('runtime.status')
                        assert state['version'] == expected_version
                        evaluated = await call('ir.evaluate', {'module': 'owned', 'inputs': [7, 9]})
                        assert evaluated['value'] == ((7 + 9) ^ 9), evaluated
                        inspected = await call('build.inspect')
                        assert inspected['compiler_invoked'] is False
                        planned = await call('build.plan', {'profile': 'owned'})
                        assert planned['source_digest_verified'] is True and planned['compiler_invoked'] is False
                        await call('build.compile', {'profile': 'owned', 'request_id': 'compile-first',
                                                    'compiler': '/bin/sh'}, refusal='invalid_tool_arguments')
                        first = await call('build.compile', {'profile': 'owned', 'request_id': 'compile-first'})
                        second = await call('build.compile', {'profile': 'owned', 'request_id': 'compile-cached'})
                        assert first['cache_hit'] is False and second['cache_hit'] is True
                        assert first['artifact_sha256'] == second['artifact_sha256']
                        artifact = Path(first['artifact_path'])
                        assert artifact.is_relative_to(directory / 'state')
                        raw = artifact.read_bytes()
                        assert raw[:4] == b'\x7fELF'
                        byte_order = 'little' if raw[5] == 1 else 'big'
                        assert int.from_bytes(raw[16:18], byte_order) == 1, 'ELF_ET_REL_required'
                        assert hashlib.sha256(raw).hexdigest() == first['artifact_sha256']
                        assert first['target_execution_verified'] is False and first['linking_required'] is True
                        report['compiled_object'] = {'format': 'ELF', 'bytes': len(raw),
                            'sha256': first['artifact_sha256'], 'cache_verified': True,
                            'target_execution_verified': False}
                        await call('process.launch', {'profile': 'unregistered', 'request_id': 'unlisted'},
                                   refusal='endpoint_not_allowlisted')
            finally:
                errors.seek(0)
                report['server_stderr'] = errors.read(8192)
    report['passed'] = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-root', type=Path, default=ROOT)
    parser.add_argument('--entry', type=Path, help='Default: runtime-access.pyz in bundle root; no source fallback.')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    args.bundle_root = args.bundle_root.resolve()
    args.entry = (args.entry or args.bundle_root / 'runtime-access.pyz').resolve()
    report = {'kind': 'official_python_sdk_stdio_interoperability', 'passed': False, 'invocations': [],
              'scope': 'packaged server, fixed owned IR, real GCC object; no foreign target execution'}
    try:
        import anyio
        anyio.run(check, args, report)
    except Exception as error:
        report.update(error=type(error).__name__ + ':' + str(error), traceback=traceback.format_exc(limit=8)[-12000:])
    report['actual_success_tools'] = sorted({item['tool'] for item in report['invocations'] if item['status'] == 'actual_success'})
    report['expected_denials'] = sum(item['status'] == 'expected_denied' for item in report['invocations'])
    if args.report:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'invocations'}, ensure_ascii=False, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
