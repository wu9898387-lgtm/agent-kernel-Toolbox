#!/usr/bin/env python3
"""Check installed toolbox files; optionally negotiate read-only stdio MCP."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def check(with_mcp=False):
    spec = importlib.util.spec_from_file_location('toolbox_integrity', ROOT / 'verify-runtime.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    integrity = verifier.verify_directory(ROOT)
    sys.path.insert(0, str(ROOT / 'runtime-access.pyz'))
    from observation_extension.runtime_host import SPECS
    from observation_extension.runtime_mcp import VERSIONS
    from observation_extension.version import PACKAGE_ID, PACKAGE_NAME, VERSION
    manifest = json.loads((ROOT / 'runtime-manifest.json').read_text())
    if (manifest['id'], manifest['name'], manifest['version']) != (PACKAGE_ID, PACKAGE_NAME, VERSION):
        raise ValueError('runtime_identity_mismatch')
    if (manifest['tool_count'] != len(SPECS)
            or manifest['tool_families'] != len({name.split('.')[0] for name in SPECS})
            or manifest['mcp_protocol_versions'] != list(VERSIONS)):
        raise ValueError('runtime_catalog_mismatch')
    for config_path in sorted(ROOT.glob('*config.example.json')):
        config = json.loads(config_path.read_text())
        if 'allowed_tools' in config and not set(config['allowed_tools']).issubset(SPECS):
            raise ValueError('unknown_tool_in_example:' + config_path.name)
    result = {'passed': True, 'name': PACKAGE_NAME, 'version': VERSION,
              'integrity': integrity, 'tools': len(SPECS),
              'tool_families': manifest['tool_families'],
              'python': sys.version.split()[0],
              'optional_commands_found': {name: shutil.which(name) is not None
                  for name in ('node', 'gcc', 'clang', 'cargo', 'java', 'strace')},
              'mcp_checked': with_mcp, 'all_backends_verified': False}
    if with_mcp:
        inspector = ROOT / 'skills/agent-kernel-toolbox/scripts/inspect_mcp.py'
        protocols = []
        for protocol in VERSIONS:
            completed = subprocess.run([sys.executable, '-I', str(inspector), '--entry',
                str(ROOT / 'runtime-access.pyz'), '--protocol', protocol],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=100)
            try:
                report = json.loads(completed.stdout)
            except ValueError:
                raise RuntimeError('invalid_mcp_inspection_output') from None
            passed = completed.returncode == 0 and report.get('passed') is True
            protocols.append({'protocol': protocol, 'passed': passed,
                              'scope': report.get('scope')})
            if not passed:
                result.update(passed=False, mcp_failure=report)
        result['mcp_protocols'] = protocols
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mcp', action='store_true', help='Use a temporary read-only config to check both supported MCP protocols')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    try:
        result = check(args.mcp)
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, AttributeError,
            ImportError, subprocess.SubprocessError) as error:
        result = {'passed': False, 'error': str(error), 'all_backends_verified': False}
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.report:
        args.report.write_text(encoded)
    print(encoded, end='')
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
