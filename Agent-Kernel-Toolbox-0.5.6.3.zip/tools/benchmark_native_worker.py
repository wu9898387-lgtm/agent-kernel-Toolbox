#!/usr/bin/env python3
"""Bounded local APP benchmark; reports evidence, never an all-load guarantee."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import hashlib
import json
import os
import resource
import select
import statistics
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'
sys.path.insert(0,str(RUNTIME))
from observation_extension.native_runtime import ProcessSession,NativeRuntimeError
from observation_extension.native_helper import NativeHelper
from observation_extension.native_control import suspend_for


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--helper',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    config={'path':str(args.helper.resolve()),'sha256':hashlib.sha256(args.helper.read_bytes()).hexdigest()}
    with tempfile.TemporaryDirectory() as directory:
        directory=Path(directory);binary=directory/'app'
        subprocess.run(['gcc',str(ROOT/'tests/fixtures/native_connections.c'),'-o',str(binary)],check=True,timeout=10)
        helper=NativeHelper(config,directory)
        process=ProcessSession.launch([str(binary)],allow_control=True,stdout=subprocess.PIPE)
        try:
            if not select.select([process.child.stdout],[],[],2)[0]:raise RuntimeError('APP readiness timeout')
            ready=json.loads(process.child.stdout.readline())
            timing={}
            for backend in ('python_fallback','compiled_go'):
                process.native_helper=helper if backend=='compiled_go' else None
                samples=[];before=resource.getrusage(resource.RUSAGE_CHILDREN)
                for _ in range(40):
                    start=time.perf_counter();result=suspend_for(process,1);samples.append((time.perf_counter()-start)*1000)
                    assert result['resumed'] and result['watchdog_backend']==backend
                after=resource.getrusage(resource.RUSAGE_CHILDREN)
                timing[backend]={'samples':len(samples),'requested_pause_ms':1,'median_ms':round(statistics.median(samples),3),
                    'p95_ms':round(sorted(samples)[37],3),'child_user_cpu_seconds':round(after.ru_utime-before.ru_utime,4),
                    'child_system_cpu_seconds':round(after.ru_stime-before.ru_stime,4)}
            initial=len(os.listdir('/proc/self/fd'));start=time.monotonic()
            for _ in range(128):
                observed=helper.connections(process,permitted=True)
                assert any(row.get('local',{}).get('port')==ready['tcp_port'] for row in observed['connections'])
            sequential_seconds=time.monotonic()-start;final=len(os.listdir('/proc/self/fd'))
            assert initial==final, ('descriptor leak',initial,final)
            def probe(_):
                try:
                    helper.connections(process,permitted=True);return 'completed'
                except NativeRuntimeError as error:
                    if str(error)!='native_worker_capacity':raise
                    return 'backpressure'
            start=time.monotonic()
            with ThreadPoolExecutor(max_workers=16) as executor:outcomes=list(executor.map(probe,range(256)))
            burst_seconds=time.monotonic()-start
            assert len(os.listdir('/proc/self/fd'))==initial
            receipt={'helper':config,'host':{'system':os.uname().sysname,'release':os.uname().release,'machine':os.uname().machine},
                'watchdog':timing,'connection_probe':{'sequential_calls':128,'sequential_seconds':round(sequential_seconds,3),
                    'sequential_calls_per_second':round(128/sequential_seconds,2),'burst_requests':256,'client_threads':16,
                    'burst_seconds':round(burst_seconds,3),'completed':outcomes.count('completed'),
                    'capacity_refused':outcomes.count('backpressure'),'unexpected_errors':0,
                    'fd_count_before':initial,'fd_count_after':final,'worker_concurrency_cap':4},
                'scope':'one local Linux C APP, 40 pauses per backend, bounded loopback socket tables; no production SLA or full MCP throughput claim',
                'memory_limit':'Go 32 MiB soft GC target plus bounded buffers; no hard RSS cap claimed'}
            args.output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
        finally:
            process.terminate_owned();process.close();process.child.stdout.close();helper.close()


if __name__=='__main__':main()
