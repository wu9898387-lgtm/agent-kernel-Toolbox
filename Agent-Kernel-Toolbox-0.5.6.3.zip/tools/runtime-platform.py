#!/usr/bin/env python3
"""Detect/plan a pinned word-IR profile; compile through the durable MCP host."""
import argparse
import json
import os
from pathlib import Path
import re
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
MODULES = ROOT / 'runtime-access.pyz'
sys.path.insert(0, str(MODULES if MODULES.is_file() else ROOT / 'src'))
from observation_extension.portable_build import PortableBuild, PortableBuildError, detect_host


def error_result(error, *, unknown=False):
    code = str(error)
    result = {'ok': False, 'error': code if re.fullmatch(r'[a-z][a-z0-9_]{1,100}', code)
              else 'build_cli_failed', 'effect_unknown': unknown}
    dispatched = getattr(error, 'effect_dispatched', None)
    if type(dispatched) is bool:
        result['effect_dispatched'] = dispatched
    return result


def compile_profile(config, state_directory, profile, request_id):
    # Import lazily: detection and planning remain usable without a POSIX host.
    from observation_extension.runtime_host import RuntimeHost
    host = RuntimeHost({'schema_version': 1, 'state_directory': str(state_directory),
                        'allowed_tools': ['build.compile'], 'portable_build': config},
                       bundle_root=ROOT)
    try:
        try:
            result = host.call('build.compile', {'profile': profile, 'request_id': request_id})
        except (OSError, ValueError, RuntimeError, sqlite3.Error) as error:
            # A journal/transport error after entering call cannot establish
            # whether compilation ran. Leave Pending/Unknown for reconciliation.
            result = error_result(error, unknown=True)
    finally:
        try:
            cleanup = host.close()
        except (OSError, ValueError, RuntimeError, sqlite3.Error) as error:
            cleanup = {'cleanup_errors': [error_result(error)['error']]}
    if cleanup['cleanup_errors']:
        result = {**result, **({'error': 'build_cli_cleanup_unresolved'} if result['ok'] else {}),
                  'ok': False, 'cleanup_errors': cleanup['cleanup_errors']}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('detect', 'inspect', 'plan', 'compile'))
    parser.add_argument('--config', type=Path)
    parser.add_argument('--state-directory', type=Path)
    parser.add_argument('--profile')
    parser.add_argument('--request-id', help='Required for compile; never reuse a completed or uncertain request ID')
    args = parser.parse_args()
    if args.action == 'compile' and args.request_id is None:
        parser.error('compile requires --request-id; inspect the previous outcome before retrying')
    if args.action != 'compile' and args.request_id is not None:
        parser.error('--request-id is only valid for compile')
    try:
        if args.action == 'detect':
            if args.config or args.state_directory or args.profile:
                parser.error('detect accepts no configuration or profile')
            result = {'ok': True, 'data': detect_host()}
        else:
            if args.config is None or args.state_directory is None:
                parser.error('inspect/plan/compile require --config and --state-directory')
            if args.action in ('plan', 'compile') and args.profile is None:
                parser.error('plan/compile require --profile')
            if args.action == 'compile':
                if os.name != 'posix':
                    raise PortableBuildError('build_cli_host_unavailable')
                from observation_extension.runtime_host import load_config
                config = load_config(args.config)
                result = compile_profile(config, args.state_directory, args.profile, args.request_id)
            else:
                with args.config.open('rb') as stream:
                    raw = stream.read(65537)
                if len(raw) > 65536:
                    raise PortableBuildError('build_config_budget')
                def pairs(items):
                    result = {}
                    for key, value in items:
                        if key in result: raise PortableBuildError('build_duplicate_config_key')
                        result[key] = value
                    return result
                config = json.loads(raw, object_pairs_hook=pairs)
                service = PortableBuild(config, args.state_directory)
                try:
                    if args.action == 'inspect':
                        if args.profile: parser.error('inspect accepts no profile')
                        value = service.inspect()
                    else:
                        value = service.plan(args.profile)
                    result = {'ok': True, 'data': value}
                finally:
                    service.close()
        print(json.dumps(result, sort_keys=True, allow_nan=False))
        return 0 if result['ok'] and not result.get('effect_unknown') and not result.get('unknown_effect') else 2
    except (OSError, ValueError, RuntimeError, sqlite3.Error) as error:
        print(json.dumps(error_result(error), sort_keys=True))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
