#!/usr/bin/env python3
"""Build our two-DEX recovery fixture using local ECJ 3.41.0 and R8 8.3.37.

No Android runtime or emulator is needed. Supply trusted local tool JARs;
upstream binaries are not included in this Toolbox.
"""
import argparse
import hashlib
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def build(ecj, r8, output):
    with tempfile.TemporaryDirectory() as temporary:
        work = Path(temporary)
        classes = work / 'classes'
        classes.mkdir()
        subprocess.run(['java', '-jar', str(ecj), '-11', '-g', '-d', str(classes),
                        str(ROOT / 'tests/fixtures/recovery/Recovery.java'),
                        str(ROOT / 'tests/fixtures/recovery/Extra.java')], check=True, timeout=30)
        package = classes / 'runtimeaccess/fixture'
        members = {}
        for index, files in enumerate((sorted(package.glob('Recovery*.class')), [package / 'Extra.class']), 1):
            target = work / ('dex' + str(index))
            target.mkdir()
            subprocess.run(['java', '-cp', str(r8), 'com.android.tools.r8.D8', '--min-api', '26',
                            '--output', str(target), *map(str, files)], check=True, timeout=30)
            members['classes.dex' if index == 1 else 'classes2.dex'] = (target / 'classes.dex').read_bytes()
        with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as archive:
            for name, data in members.items():
                info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
    return hashlib.sha256(output.read_bytes()).hexdigest()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ecj', type=Path, required=True)
    parser.add_argument('--r8', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(build(args.ecj.resolve(), args.r8.resolve(), args.output))
