#!/usr/bin/env python3
"""Extract the complete embedded Python sources into a new directory."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]


def extract(output):
    spec = importlib.util.spec_from_file_location('toolbox_source_verifier', ROOT / 'verify-runtime.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    inventory = verifier.json_object(verifier.read_regular(ROOT, 'CONTENTS.json'))
    sources = verifier.read_archive(verifier.read_regular(ROOT, 'runtime-access.pyz'))
    verifier.hash_inventory(sources, inventory['python_files'])
    if '__main__.py' not in sources or any(not name.endswith('.py') for name in sources):
        raise ValueError('invalid_python_sources')
    output = Path(output).absolute()
    output.mkdir(mode=0o700, exist_ok=False)
    for name, raw in sorted(sources.items()):
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    return {'output': str(output), 'python_members': len(sources), 'source_hashes_verified': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path,
                        help='New directory; use src to enable source-based rebuilds')
    args = parser.parse_args()
    try:
        result = extract(args.output)
    except (OSError, ValueError, KeyError) as error:
        print('source_extraction_failed: ' + str(error), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
