#!/usr/bin/env python3
"""Compile our memory-layout fixture and check native/QEMU byte interoperability.

This is guest program execution, not foreign-kernel ptrace validation.
Zig/QEMU are optional test tools and are never bundled or installed by this script.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.abi import binary_abi, decode_memory

TARGETS = [('x86-linux-musl', 'qemu-i386'), ('aarch64-linux-musl', 'qemu-aarch64'),
           ('arm-linux-musleabihf', 'qemu-arm'), ('riscv64-linux-musl', 'qemu-riscv64'),
           ('mips-linux-musleabi', 'qemu-mips'), ('powerpc64-linux-musl', 'qemu-ppc64'),
           ('loongarch64-linux-musl', 'qemu-loongarch64')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig', type=Path, required=True)
    parser.add_argument('--qemu-directory', type=Path, required=True)
    parser.add_argument('--library-directory', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    environment = os.environ.copy()
    if args.library_directory:
        environment['LD_LIBRARY_PATH'] = str(args.library_directory)
    results = []
    with tempfile.TemporaryDirectory(prefix='runtime-cross-arch-') as temporary:
        for target, emulator in TARGETS:
            binary = Path(temporary) / target
            command = [str(args.zig), 'cc', '-target', target, '-static', '-O1',
                       str(ROOT / 'tests/fixtures/memory_layout.c'), '-o', str(binary)]
            try:
                build = subprocess.run(command, capture_output=True, timeout=180)
                if build.returncode:
                    results.append({'target': target, 'status': 'build_failed', 'diagnostic': build.stderr.decode(errors='replace')[-2000:]})
                    continue
                abi = binary_abi(binary.read_bytes()[:4096])
                run = subprocess.run([str(args.qemu_directory / emulator), str(binary)],
                                     env=environment, capture_output=True, timeout=10)
                raw = run.stdout
                assert run.returncode == 0 and len(raw) == 64 and raw[:4] == b'AKT1'
                assert raw[4] == abi['pointer_bits']
                assert ('little' if raw[5] == 1 else 'big') == abi['byte_order']
                assert decode_memory(raw[8:12], 'uint32', abi['byte_order'], abi['pointer_bits']) == ['305419896']
                assert decode_memory(raw[12:20], 'int64', abi['byte_order'], abi['pointer_bits']) == ['-9223372036854775807']
                pointer = decode_memory(raw[20:20 + abi['pointer_bits'] // 8], 'pointer', abi['byte_order'], abi['pointer_bits'])
                assert int(pointer[0], 16) > 0
                assert decode_memory(raw[28:32], 'utf16', abi['byte_order'], abi['pointer_bits']) == '状态'
                results.append({'target': target, 'status': 'passed', 'abi': abi,
                                'execution': 'qemu_user_guest_fixture', 'native_guest_ptrace_proven': False})
            except (OSError, AssertionError, subprocess.TimeoutExpired) as error:
                results.append({'target': target, 'status': 'failed', 'error_type': type(error).__name__})
            finally:
                print(json.dumps(results[-1]), flush=True)
    args.output.write_text(json.dumps({'scope': 'compiled_guest_memory_format_interoperability',
                                      'results': results}, indent=2) + '\n')
    return 0 if all(r['status'] == 'passed' for r in results) else 1


if __name__ == '__main__': raise SystemExit(main())
