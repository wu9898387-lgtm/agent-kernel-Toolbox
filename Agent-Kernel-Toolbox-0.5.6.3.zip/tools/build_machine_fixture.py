#!/usr/bin/env python3
"""Build the owned bare-metal i386 multiboot fixture without a guest OS."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def build(output, *, cc=None, linker=None):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('machine_fixture_output_exists')
    cc = cc or shutil.which('gcc')
    linker = linker or shutil.which('ld')
    if not cc or not linker:
        raise ValueError('machine_fixture_compiler_required')
    source = ROOT / 'tests/fixtures/recovery/machine_kernel.S'
    script = ROOT / 'tests/fixtures/recovery/machine_kernel.ld'
    with tempfile.TemporaryDirectory() as directory:
        obj = Path(directory) / 'kernel.o'
        subprocess.run([cc, '-m32', '-c', str(source), '-o', str(obj)], check=True, timeout=15)
        subprocess.run([linker, '-m', 'elf_i386', '-T', str(script), '-o', str(output), str(obj)],
                       check=True, timeout=15)
    return {'kernel': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
            'ram_address': 0x200000, 'ram_bytes': 8, 'initial_counter': 7,
            'architecture': 'i386', 'format': 'multiboot1 ELF32', 'guest_os': None,
            'serial_commands': {'increment': '69'}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.output), sort_keys=True))
