#!/usr/bin/env python3
"""Run the owned GTK APP test in a private Xvfb and D-Bus session."""
import argparse
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--xvfb', default=shutil.which('Xvfb'))
    args = parser.parse_args()
    if not args.xvfb or not shutil.which('dbus-run-session'):
        parser.error('Xvfb and dbus-run-session are required')
    root = Path(__file__).resolve().parents[1]
    server = subprocess.Popen([args.xvfb, '-displayfd', '1', '-screen', '0', '1024x768x24',
                               '-nolisten', 'tcp', '-ac'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        if not select.select([server.stdout], [], [], 5)[0]: raise RuntimeError('xvfb_start_timeout')
        display = server.stdout.readline().decode().strip()
        if not display.isdigit(): raise RuntimeError('xvfb_start_failed')
        environment = {**os.environ, 'DISPLAY': ':' + display, 'RUNTIME_DESKTOP_INTEGRATION': '1',
                       'NO_AT_BRIDGE': '0', 'GTK_MODULES': 'atk-bridge', 'GSETTINGS_BACKEND': 'memory'}
        return subprocess.run(['dbus-run-session', '--', sys.executable, '-m', 'unittest',
                               'discover', '-s', 'tests', '-p', 'test_native_app.py', '-v'],
                              cwd=root, env=environment, timeout=40).returncode
    finally:
        if server.poll() is None:
            server.terminate()
            try: server.wait(timeout=3)
            except subprocess.TimeoutExpired: server.kill();server.wait(timeout=3)
        server.stdout.close();server.stderr.close()


if __name__ == '__main__': raise SystemExit(main())
