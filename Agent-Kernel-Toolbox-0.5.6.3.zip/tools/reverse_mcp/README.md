# Optional local JavaScript analysis provider

This directory pins `@jshookmcp/jshook` **0.4.2** and its full npm dependency graph. The lock file fixes the dependency versions used by this integration. No provider is automatically installed or launched by unpacking the runtime ZIP.

Install in this directory using Node 24.15+ within the Node 24 line:

```sh
npm ci --ignore-scripts --omit=optional --no-audit --no-fund
```

The provider entry point is `node_modules/@jshookmcp/jshook/dist/index.mjs`; put its absolute path and the absolute Node executable in `reverse_mcp.argv`. The package is not launched through `npx @latest`.

Upstream sources:

- https://github.com/vmoranv/jshookmcp
- https://registry.npmjs.org/@jshookmcp/jshook/0.4.2
- https://registry.npmjs.org/@jshookmcp/jshook/-/jshook-0.4.2.tgz

The pinned tarball is 1,348,060 bytes, SHA-256 `009e8f216546ea0d02c1e128d91e1e58e7bde41b5ef4ef608ad8234ca49c7fd8`. Its npm integrity is `sha512-tAk7c1M5T/0e3FYkpPUI7EhoszfnyDu4J5CXf+FcFIg5RdoTkcnR7mS3xtEBm2WvfLhWTUMxcrwGBPw986ZfiQ==`. These identify the bytes; no claim is made that every transitive dependency has undergone a source security audit. The upstream package declares AGPL-3.0-only.

The runtime bridge forces `MCP_TOOL_PROFILE=search`, disables vector search and automatic search-domain activation, and sets a nonempty provider whitelist containing only `describe_tool`, `call_tool`, and `analysis_ast_match`. The bridge itself exposes only the fixed AST operation, not arbitrary names or arguments. It passes no API keys, opens no target browser, installs no interception CA, and has no arbitrary-command tool. The provider still runs as a locally installed executable; these controls are not a substitute for operating-system isolation.

The bridge uses MCP initialization and fixed AST matches for function declarations, call expressions and string literals. Returned matches include source locations; the host checks shape and UTF-16 bounds before associating calls with named enclosing functions. Static source fragments are observation data and can include literal values from the explicitly registered artifact. Do not register artifacts whose contents should not be returned to the model.

Other upstream tools are outside this integration; the AST bridge does not forward arbitrary provider names or parameters. Optional WABT, Frida, Ghidra and IDA engines are not included in this npm package.

Register reviewed JavaScript files under `artifacts` with a real SHA-256, and configure `reverse_mcp.argv` with the absolute Node executable and provider entry point. Use [reverse-config.example.json](../../reverse-config.example.json) as the starting configuration and enable `reverse.artifacts` / `reverse.analyze` in `allowed_tools`. The fixed request is:

```json
{"artifact":"app-bundle","analysis":"javascript_routes"}
```

The host accepts at most 256 KiB per source and bounds response reading to 1 MiB per request. After changing a registered file, review its new bytes and digest; unresolved effects must be reconciled before changing the target's configuration.

Run the integration test from the Toolbox root after installing the provider:

```sh
RUNTIME_JSHOOK_ENTRY=/absolute/Agent-Kernel-Toolbox/tools/reverse_mcp/node_modules/@jshookmcp/jshook/dist/index.mjs \
python3 -m unittest discover -s tests -p test_reverse_backends.py -v
```

Other optional backend cases in that module may skip if their own environment variables are absent.
