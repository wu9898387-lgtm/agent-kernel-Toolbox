#!/usr/bin/env python3
"""Exercise real stdio MCP -> Python host -> Node -> owned Chromium on loopback.

The fixture contains synthetic data only. --serve-only exposes the same page
for a separate manual/UI check; that check is not evidence that MCP passed.
No external URL, existing browser session, or login is used. A failed browser
launch remains a failure and is never counted as a successful or skipped test.
"""
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ['browser.' + name for name in (
    'open', 'targets', 'capabilities', 'snapshot', 'query', 'navigate', 'fields',
    'controls', 'set_text', 'activate', 'invoke', 'routes', 'analyze_script',
    'navigate_route', 'block_request', 'network', 'metrics', 'hide', 'restore', 'close_target')]
WRITES = {'open', 'navigate', 'set_text', 'activate', 'invoke', 'navigate_route',
          'block_request', 'hide', 'restore', 'close_target'}
HTML = '''<!doctype html><meta charset="utf-8"><title>Runtime Access owned fixture</title>
<style>body{font:18px sans-serif;max-width:760px;margin:48px auto;line-height:1.6}
input,button,a{font:inherit;margin:8px;padding:8px}#card{border:1px solid #aaa;padding:16px}</style>
<h1>Runtime Access owned fixture</h1><p>Loopback only. Synthetic test data.</p>
<label for="query">Query</label><input id="query" autocomplete="off"><button id="apply">Apply</button>
<p id="status" role="status">Ready</p><a id="settings" href="/settings">Settings</a>
<a href="/next">Next page</a><section id="card"><p>Restorable card</p></section>
<div data-private>SYNTHETIC_PRIVATE_TEXT</div><script src="/app.js"></script>'''
SCRIPT = '''const status=document.querySelector('#status');
document.querySelector('#apply').onclick=()=>{status.textContent='applied:'+document.querySelector('#query').value;};
document.querySelector('#settings').onclick=event=>{event.preventDefault();history.pushState({},'','/settings');status.textContent='settings:ready';};
addEventListener('popstate',()=>{status.textContent=location.pathname==='/settings'?'settings:ready':'Ready';});
if(location.pathname==='/settings')status.textContent='settings:ready';
if(location.pathname==='/network-check')fetch('/blocked',{credentials:'omit'}).then(()=>{status.textContent='blocked:no';}).catch(()=>{status.textContent='blocked:yes';});
fetch('/api/result',{credentials:'omit'}).catch(()=>{});
'''


class Fixture:
    def __init__(self, port=0):
        self.hits = []
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def do_GET(self):
                path = self.path.split('?', 1)[0]
                owner.hits.append(path)
                if path == '/app.js':
                    body, kind = SCRIPT.encode(), 'text/javascript'
                elif path.startswith('/api/') or path == '/blocked':
                    body, kind = b'{"owned_fixture":true}', 'application/json'
                else:
                    body, kind = HTML.encode(), 'text/html; charset=utf-8'
                self.send_response(200)
                self.send_header('Content-Type', kind)
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
        self.server.daemon_threads = True
        self.origin = 'http://127.0.0.1:' + str(self.server.server_port)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .05}, daemon=True)

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)


class Client:
    def __init__(self, entry, root, config, stderr):
        self.child = subprocess.Popen([sys.executable, '-I', str(entry), 'serve', '--config', str(config),
                                       '--bundle-root', str(root)], stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE, stderr=stderr, bufsize=0)
        self.sequence, self.buffer, self.steps = 0, b'', []
        self.current = 'initialize'

    def exchange(self, method, params, *, notify=False):
        self.sequence += 1
        request = {'jsonrpc': '2.0', 'method': method, 'params': params}
        if not notify:
            request['id'] = self.sequence
        self.child.stdin.write(json.dumps(request).encode() + b'\n')
        if notify:
            return None
        deadline = time.monotonic() + 45
        while b'\n' not in self.buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.child.stdout], [], [], remaining)[0]:
                raise RuntimeError('mcp_response_timeout')
            chunk = os.read(self.child.stdout.fileno(), 65536)
            if not chunk:
                raise RuntimeError('mcp_transport_closed')
            self.buffer += chunk
            if len(self.buffer) > 1048576:
                raise RuntimeError('mcp_response_budget')
        line, self.buffer = self.buffer.split(b'\n', 1)
        value = json.loads(line)
        if value.get('id') != request['id'] or 'error' in value:
            raise RuntimeError('mcp_protocol_error:' + json.dumps(value))
        return value['result']

    def call(self, name, arguments=None):
        self.current = name
        arguments = dict(arguments or {})
        if name.split('.', 1)[1] in WRITES:
            arguments['request_id'] = 'smoke-' + str(self.sequence + 1)
        result = self.exchange('tools/call', {'name': name, 'arguments': arguments})
        value = result.get('structuredContent', {})
        self.steps.append({'tool': name, 'ok': value.get('ok') is True,
                           'error': value.get('error') or value.get('code')})
        if result.get('isError') or value.get('ok') is not True:
            raise RuntimeError('mcp_tool_failed:' + json.dumps(value, ensure_ascii=True))
        return value['data']

    def close(self):
        self.child.stdin.close()
        try:
            self.child.wait(timeout=8)
        except subprocess.TimeoutExpired:
            self.child.terminate()
            try:
                self.child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.child.kill()
                self.child.wait(timeout=3)
        self.child.stdout.close()


def smoke(args, fixture):
    report = {'kind': 'real_stdio_mcp_browser_smoke', 'engine': 'chromium',
              'origin': fixture.origin, 'entry': str(args.entry), 'passed': False,
              'tools_list_verified': False, 'steps': [], 'not_executed': list(TOOLS)}
    with tempfile.TemporaryDirectory(prefix='runtime-browser-mcp-') as directory:
        directory = Path(directory)
        configuration = {'schema_version': 1, 'state_directory': str(directory / 'state'),
                         'allowed_tools': TOOLS, 'browser': {
            'engine': 'chromium', 'headless': True, 'allowedOrigins': [fixture.origin],
            'includeEditableText': True, 'allowTextInput': True, 'timeoutMs': 10000,
            'trafficPolicy': {'maxRequests': 100, 'origins': [{'origin': fixture.origin,
                'minIntervalMs': 0, 'maxConcurrent': 4, 'maxRequests': 100}]}}}
        executable = os.environ.get('RUNTIME_CHROMIUM') or shutil.which('chromium')
        if executable:
            configuration['browser']['executablePath'] = executable
        config = directory / 'config.json'
        config.write_text(json.dumps(configuration))
        config.chmod(0o600)
        with tempfile.TemporaryFile() as stderr:
            client = Client(args.entry, args.bundle_root, config, stderr)
            try:
                client.exchange('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                                                'clientInfo': {'name': 'owned-browser-smoke', 'version': '1'}})
                client.exchange('notifications/initialized', {}, notify=True)
                catalog = client.exchange('tools/list', {})
                assert {item['name'] for item in catalog['tools']} == set(TOOLS), 'browser_tool_catalog_mismatch'
                report['tools_list_verified'] = True
                report['capabilities'] = client.call('browser.capabilities')
                page = client.call('browser.open', {'url': fixture.origin + '/'})['pageId']
                assert len(client.call('browser.targets')['pages']) == 1

                def query(text):
                    return client.call('browser.query', {'page_id': page, 'options': {'query': text}})

                assert 'Ready' in json.dumps(query('Ready'))
                fields = client.call('browser.fields', {'page_id': page, 'query': 'Query'})
                field = fields['fields'][0]
                filled = client.call('browser.set_text', {'page_id': page, 'snapshot_id': fields['snapshotId'],
                    'node_id': field['nodeId'], 'text': 'owned-input'})
                assert filled['textVerified'] is True
                controls = client.call('browser.controls', {'page_id': page, 'query': 'Apply', 'role': 'button'})
                button = next(node for frame in controls['frames'] for node in frame.get('nodes', []))
                client.call('browser.invoke', {'page_id': page, 'snapshot_id': controls['snapshotId'], 'node_id': button['nodeId']})
                assert 'applied:owned-input' in json.dumps(query('applied:owned-input'))
                snapshot = client.call('browser.snapshot', {'page_id': page})
                assert 'SYNTHETIC_PRIVATE_TEXT' not in json.dumps(snapshot)
                link = next(node for frame in snapshot['frames'] for node in frame.get('nodes', []) if node['name'] == 'Settings')
                client.call('browser.activate', {'page_id': page, 'snapshot_id': snapshot['snapshotId'], 'node_id': link['nodeId']})
                assert 'settings:ready' in json.dumps(query('settings:ready'))
                evidence = client.call('browser.routes', {'page_id': page})
                script = next(item for item in evidence['scripts'] if item.get('sourceReadable') and item.get('url') == fixture.origin + '/app.js')
                analysis = client.call('browser.analyze_script', {'page_id': page, 'script_handle': script['scriptHandle']})
                assert '/api/result' in json.dumps(analysis)
                client.call('browser.navigate', {'page_id': page, 'url': fixture.origin + '/next'})
                routes = client.call('browser.routes', {'page_id': page})
                prior = next(item for item in routes['routes'] if item['url'] == fixture.origin + '/settings' and item.get('routeHandle'))
                client.call('browser.navigate_route', {'page_id': page, 'route_handle': prior['routeHandle']})
                assert 'settings:ready' in json.dumps(query('settings:ready'))
                client.call('browser.block_request', {'rule': {'origin': fixture.origin, 'pathPrefix': '/blocked'}})
                client.call('browser.navigate', {'page_id': page, 'url': fixture.origin + '/network-check'})
                deadline = time.monotonic() + 3
                while 'blocked:yes' not in json.dumps(query('blocked:yes')):
                    if time.monotonic() >= deadline:
                        raise AssertionError('blocked_request_postcondition_missing')
                    time.sleep(.02)
                events = client.call('browser.network')
                assert 'request_blocked' in json.dumps(events) and '/blocked' not in fixture.hits
                client.call('browser.metrics', {'page_id': page})
                assert 'Restorable card' in json.dumps(query('Restorable card'))
                hidden = client.call('browser.hide', {'page_id': page, 'selector': '#card'})
                assert not any(frame.get('nodes') for frame in query('Restorable card')['frames'])
                assert client.call('browser.restore', {'hide_id': hidden['hideId']})['restored'] is True
                assert 'Restorable card' in json.dumps(query('Restorable card'))
                client.call('browser.close_target', {'target_id': page})
                assert client.call('browser.targets')['pages'] == []
                report['passed'] = True
            except Exception as error:
                report.update(failed_at=client.current, error=type(error).__name__ + ':' + str(error))
            finally:
                client.close()
                report['steps'] = client.steps
                report['not_executed'] = sorted(set(TOOLS) - {step['tool'] for step in client.steps})
                report['runtime_exit_code'] = client.child.returncode
                report['passed'] = report['passed'] and client.child.returncode == 0
                stderr.seek(0)
                report['runtime_stderr'] = stderr.read(8192).decode('utf-8', errors='replace')
        report['fixture_requests'] = fixture.hits
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-root', type=Path, default=ROOT)
    parser.add_argument('--entry', type=Path, help='Default: runtime-access.pyz, or the development src directory if no zipapp exists.')
    parser.add_argument('--serve-only', action='store_true')
    parser.add_argument('--port', type=int, default=0)
    args = parser.parse_args()
    args.bundle_root = args.bundle_root.resolve()
    default_entry = args.bundle_root / 'runtime-access.pyz'
    if not default_entry.is_file():
        default_entry = args.bundle_root / 'src'
    args.entry = (args.entry or default_entry).resolve()
    fixture = Fixture(args.port)
    fixture.thread.start()
    try:
        if args.serve_only:
            print(json.dumps({'origin': fixture.origin, 'mode': 'independent_fixture_only',
                              'mcp_browser_validation': False}), flush=True)
            fixture.thread.join()
            return 0
        result = smoke(args, fixture)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result['passed'] else 1
    except KeyboardInterrupt:
        return 130
    finally:
        fixture.close()


if __name__ == '__main__':
    raise SystemExit(main())
