#!/usr/bin/env python3
"""Install hash-pinned official radare2/r2mcp archives into one private directory.

No root privileges, package scripts, global configuration, or system install.
Python 3.12+ and Linux x86_64 with a compatible glibc loader are required.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import tarfile
import tempfile
import urllib.request


ASSETS = (
    {"name": "radare2_6.2.4_amd64.deb", "bytes": 8648924,
     "url": "https://github.com/radareorg/radare2/releases/download/6.2.4/radare2_6.2.4_amd64.deb",
     "sha256": "7019eedc0e0e87d1f53d6b8f5fc62b898567679c5efdce7fbfc557c9e7655e90"},
    {"name": "r2mcp_1.9.0_amd64.deb", "bytes": 208448,
     "url": "https://github.com/radareorg/radare2-mcp/releases/download/1.9.0/r2mcp_1.9.0_amd64.deb",
     "sha256": "d426861a726f7e9bc13a44cc3bbfd8553c51b33fc05f1ff0eda75b433222d9e3"},
)


def acquire(asset, cache):
    cached = cache / asset["name"] if cache else None
    if cached is not None and cached.is_file():
        if cached.stat().st_size != asset["bytes"]:
            raise ValueError("Cached archive size mismatch: " + asset["name"])
        with cached.open("rb") as source:
            data = source.read(asset["bytes"] + 1)
    else:
        request = urllib.request.Request(asset["url"], headers={"User-Agent": "agent-kernel-reverse-installer/1"})
        with urllib.request.urlopen(request, timeout=45) as response:
            if not response.url.startswith("https://"):
                raise ValueError("Release download redirected outside HTTPS")
            data = response.read(asset["bytes"] + 1)
    if len(data) != asset["bytes"] or hashlib.sha256(data).hexdigest() != asset["sha256"]:
        raise ValueError("Official release archive digest mismatch: " + asset["name"])
    return data


def deb_payload(data):
    if data[:8] != b"!<arch>\n":
        raise ValueError("Invalid Debian ar container")
    offset = 8
    while offset + 60 <= len(data):
        header = data[offset:offset + 60]
        if header[58:] != b"`\n":
            raise ValueError("Invalid ar entry")
        name = header[:16].decode("ascii").strip().rstrip("/")
        length = int(header[48:58].decode("ascii").strip())
        start = offset + 60
        if not 0 <= length <= len(data) - start:
            raise ValueError("Invalid ar entry size")
        if name == "data.tar.xz":
            return data[start:start + length]
        offset = start + length + (length & 1)
    raise ValueError("Pinned Debian archive has no data.tar.xz")


def unpack(data, destination):
    with tarfile.open(fileobj=io.BytesIO(deb_payload(data)), mode="r:xz") as archive:
        members = archive.getmembers()
        if len(members) > 20000 or sum(item.size for item in members) > 512 * 1024 * 1024:
            raise ValueError("Archive extraction budget exceeded")
        for item in members:
            path = PurePosixPath(item.name)
            if path.is_absolute() or ".." in path.parts or item.isdev() or item.isfifo():
                raise ValueError("Unsafe archive member")
        # data_filter also confines link destinations and strips unsafe modes.
        archive.extractall(destination, members=members, filter="data")


def install(destination, archive_dir=None):
    if sys.version_info < (3, 12) or sys.platform != "linux" or platform.machine() != "x86_64":
        raise ValueError("This pinned installer requires Python 3.12+ on Linux x86_64")
    destination = Path(destination)
    if not destination.is_absolute() or destination.exists() or destination.is_symlink():
        raise ValueError("Destination must be an absolute path that does not yet exist")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".reverse-install-", dir=destination.parent) as temporary:
        stage = Path(temporary) / "payload"
        stage.mkdir(mode=0o700)
        for asset in ASSETS:
            data = acquire(asset, Path(archive_dir) if archive_dir else None)
            unpack(data, stage)
        environment = {"PATH": "/usr/bin:/bin", "LC_ALL": "C", "LD_LIBRARY_PATH": str(stage / "usr/lib")}
        versions = {}
        for name, relative in (("radare2", "usr/bin/radare2"), ("r2mcp", "usr/local/bin/r2mcp")):
            try:
                result = subprocess.run([str(stage / relative), "-v"], stdin=subprocess.DEVNULL,
                                        capture_output=True, text=True, timeout=5, env=environment)
            except OSError as error:
                raise ValueError("Compatible glibc loader unavailable; use an operator-installed radare2 package instead") from error
            if result.returncode != 0:
                raise ValueError("Downloaded " + name + " could not start on this host")
            versions[name] = result.stdout.strip()
        manifest = {"assets": list(ASSETS), "versions": versions,
                    "radare2": str(destination / "usr/bin/radare2"),
                    "r2mcp": str(destination / "usr/local/bin/r2mcp"),
                    "library_path": str(destination / "usr/lib"),
                    "system_install": False, "package_scripts_executed": False}
        (stage / "provenance.json").write_text(json.dumps(manifest, indent=2) + "\n")
        # No existing destination is replaced, even if one appeared mid-download.
        os.mkdir(destination, 0o700)
        try:
            for child in stage.iterdir():
                child.rename(destination / child.name)
        except BaseException:
            # Leave the incomplete private directory for explicit diagnosis.
            raise
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", required=True, help="New absolute private install directory")
    parser.add_argument("--archive-dir", help="Optional directory with already downloaded archives; hashes are still required")
    args = parser.parse_args()
    try:
        result = install(args.destination, args.archive_dir)
    except (ValueError, OSError, subprocess.SubprocessError, tarfile.TarError) as error:
        parser.exit(1, "Install failed: " + str(error) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
