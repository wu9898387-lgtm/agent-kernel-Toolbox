#!/usr/bin/env python3
"""Search, related-label replacement and native input capability checks via MCP."""
from pathlib import Path
import argparse,hashlib,json,os,sys,time,urllib.parse
from check_live_accessibility import MCP,private_desktop


def run(args):
    out=args.output.resolve();out.mkdir(exist_ok=False)
    proxy=os.environ.get('HTTPS_PROXY',os.environ.get('HTTP_PROXY',''));url=urllib.parse.urlsplit(proxy)
    if url.username or url.password:raise RuntimeError('noncredential proxy configuration required')
    scratch=out/'replacement.txt';original='alpha beta alpha\n中文测试 alpha\n';scratch.write_text(original)
    flags=['--no-sandbox','--disable-dev-shm-usage','--no-first-run','--disable-background-networking','--disable-sync','--force-renderer-accessibility']
    if url.hostname:flags+=['--proxy-server='+url.geturl()]
    browser={'mode':'launch','engine':'chromium','executablePath':str(args.chromium),'headless':True,
        'allowedOrigins':['https://docs.python.org'],'includeEditableText':True,'allowTextInput':True,'timeoutMs':10000}
    if url.hostname:browser['proxy']={'server':url.geturl()}
    profiles={'native-chrome':{'argv':[str(args.chromium),*flags,'--user-data-dir='+str(out/'native-profile'),'https://docs.python.org/3/'],
        'enable_accessibility':True,'include_editable_text':True,'allow_text_input':True},
        'mousepad':{'argv':[str(args.mousepad),'--disable-server',str(scratch)],'enable_accessibility':True,'include_editable_text':True,'allow_text_input':True}}
    allowed=['process.launch','process.terminate','native.open','native.query','native.focus','native.set_text','native.invoke',
             'browser.open','browser.fields','browser.set_text','browser.controls','browser.snapshot','browser.invoke','browser.activate','browser.query']
    host=MCP({'schema_version':1,'state_directory':str(out/'state'),'allowed_tools':allowed,'profiles':profiles,'browser':browser},out)
    calls=[];results=[];sessions=[]
    def call(name,values,required=True):
        result=host.call(name,values);path=out/(f'{len(calls)+1:03d}-'+name+'.json');path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        calls.append({'tool':name,'ok':result['ok'],'file':path.name,'receipt':result.get('evidence',{}).get('receipt_sha256')})
        if required and not result['ok']:raise RuntimeError(name+': '+result.get('error','unknown'))
        return result
    def query(sid,text='',roles=None,limit=1):
        deadline=time.monotonic()+20
        while True:
            r=call('native.query',{'session_id':sid,'query':text,'roles':roles or [],'limit':limit},False)
            if r['ok'] and r['data']['nodes']:return r['data']
            if not r['ok'] and r.get('error') not in ('application_not_accessible','accessibility_tree_changed'):raise RuntimeError(r['error'])
            if time.monotonic()>deadline:raise RuntimeError('native postcondition absent: '+text)
            time.sleep(.1)
    def launch(profile):
        sid=call('process.launch',{'profile':profile,'request_id':'launch-'+profile})['data']['session_id'];sessions.append(sid)
        call('native.open',{'session_id':sid});return sid
    def invoke(sid,snapshot,node,label):
        result=call('native.invoke',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],
            'action_index':node['actions'][0]['index'],'request_id':sid+':'+label})['data']
        if result['status']!='acknowledged':raise RuntimeError('native effect unknown; no replay')
    def fill(sid,label,value):
        snapshot=query(sid,label,['text']);node=snapshot['nodes'][0]
        assert node['can_set_text'] and label in node['labels']
        result=call('native.set_text',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],'text':value,'request_id':sid+':'+label.replace(' ','-')})['data']
        if result['status']!='acknowledged' or not result.get('text_verified'):raise RuntimeError('native text readback not verified')
    try:
        sid=None
        try:
            sid=launch('native-chrome');snapshot=query(sid,'Quick search',['entry']);node=snapshot['nodes'][0]
            assert node['can_set_text'] is False
            refused=call('native.set_text',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],'text':'sqlite3','request_id':sid+':unsupported-input'},False)
            assert not refused['ok'] and refused['error']=='native_text_interface_unsupported' and not refused['effect_unknown']
            snapshot=query(sid,'Quick search',['entry']);node=snapshot['nodes'][0]
            focused=call('native.focus',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],'request_id':sid+':still-admitted'})
            assert focused['data']['status']=='acknowledged'
            results.append({'scenario':'Chromium AT-SPI missing text interface','status':'passed','scope':'capability refusal and no false fence; no native form completion claimed'})
        except Exception as e:results.append({'scenario':'native capability boundary','status':'failed','error':str(e)})
        finally:
            if sid:call('process.terminate',{'session_id':sid,'request_id':sid+':terminate'},False);sessions.remove(sid)
        sid=None
        try:
            sid=launch('mousepad');query(sid,'alpha',['text'])
            snapshot=query(sid,'Search',['menu']);invoke(sid,snapshot,snapshot['nodes'][0],'open-search')
            snapshot=query(sid,'Find and Replace',['menu item']);invoke(sid,snapshot,snapshot['nodes'][0],'open-replace')
            fill(sid,'Search for:','alpha');fill(sid,'Replace with:','omega')
            stale=query(sid,'Replace',['button'],16);stale_node=next(n for n in stale['nodes'] if n['name']=='Replace')
            snapshot=query(sid,'Replace all in:',['check box']);check=snapshot['nodes'][0]
            refused=call('native.invoke',{'session_id':sid,'snapshot_id':stale['snapshot_id'],'node_id':stale_node['node_id'],
                'action_index':stale_node['actions'][0]['index'],'request_id':sid+':stale-handle-probe'},False)
            assert not refused['ok'] and refused['error']=='accessibility_snapshot_stale' and not refused['effect_unknown']
            if not check['states']['checked']:invoke(sid,snapshot,check,'replace-all-mode')
            assert query(sid,'Replace all in:',['check box'])['nodes'][0]['states']['checked']
            snapshot=query(sid,'Replace All',['button'],16);node=next(n for n in snapshot['nodes'] if n['name']=='Replace All');invoke(sid,snapshot,node,'replace-all')
            query(sid,'omega beta omega',['text'])
            snapshot=query(sid,'Close',['button'],16);node=next(n for n in snapshot['nodes'] if n['name']=='Close');invoke(sid,snapshot,node,'close-dialog')
            snapshot=query(sid,'File',['menu']);invoke(sid,snapshot,snapshot['nodes'][0],'file-menu')
            snapshot=query(sid,'Save',['menu item'],16);node=next(n for n in snapshot['nodes'] if n['name'].strip()=='Save');invoke(sid,snapshot,node,'save')
            expected=original.replace('alpha','omega');deadline=time.monotonic()+5
            while scratch.read_text()!=expected:
                if time.monotonic()>deadline:raise RuntimeError('saved replacement content absent')
                time.sleep(.05)
            results.append({'scenario':'Mousepad labelled fields → checked Replace all → stale refusal → saved replacements','status':'passed',
                'source':'linux-at-spi','bytes':scratch.stat().st_size,'sha256':hashlib.sha256(scratch.read_bytes()).hexdigest()})
        except Exception as e:results.append({'scenario':'native replacement','status':'failed','error':str(e)})
        finally:
            if sid:call('process.terminate',{'session_id':sid,'request_id':sid+':terminate'},False);sessions.remove(sid)
        try:
            page=call('browser.open',{'url':'https://docs.python.org/3/','request_id':'open-search-page'})['data']['pageId']
            fields=call('browser.fields',{'page_id':page,'query':'Quick search','limit':1})['data'];field=fields['fields'][0]
            filled=call('browser.set_text',{'page_id':page,'snapshot_id':fields['snapshotId'],'node_id':field['nodeId'],'text':'sqlite3','request_id':'fill-search'})['data']
            assert filled['textVerified']
            controls=call('browser.controls',{'page_id':page,'query':'Go','role':'button','limit':16})['data'];button=next(n for f in controls['frames'] for n in f.get('nodes',[]) if n['name']=='Go')
            call('browser.invoke',{'page_id':page,'snapshot_id':controls['snapshotId'],'node_id':button['nodeId'],'request_id':'submit-search'})
            deadline=time.monotonic()+25
            while True:
                q=call('browser.query',{'page_id':page,'options':{'query':'sqlite3','selector':'a[href]','maxNodes':16,'maxTextBytes':4096}},False)
                if q['ok'] and any('/library/sqlite3.html' in (n.get('href') or '') for f in q['data']['frames'] for n in f.get('nodes',[])):break
                if time.monotonic()>deadline:raise RuntimeError('real search result did not appear')
                time.sleep(.15)
            controls=call('browser.controls',{'page_id':page,'query':'sqlite3','role':'link','limit':32})['data']
            selected=next(n for f in controls['frames'] for n in f.get('nodes',[]) if '/library/sqlite3.html' in (n.get('href') or ''))
            call('browser.activate',{'page_id':page,'snapshot_id':controls['snapshotId'],'node_id':selected['nodeId'],'request_id':'open-sqlite-result'})
            deadline=time.monotonic()+15
            while True:
                q=call('browser.query',{'page_id':page,'options':{'query':'sqlite3','selector':'h1','maxNodes':1,'maxTextBytes':1024}},False)
                if q['ok'] and any('/library/sqlite3.html' in f.get('url','') and f.get('nodes') for f in q['data']['frames']):break
                if time.monotonic()>deadline:raise RuntimeError('SQLite chapter postcondition absent')
                time.sleep(.15)
            results.append({'scenario':'Python public site: observed field → sqlite3 search → observed result → chapter','status':'passed',
                'source':'explicit Playwright DOM adapter; separate fresh browser from native refusal',
                'observed_result':selected['href'],'heading':[n['name'] for f in q['data']['frames'] for n in f.get('nodes',[])]})
        except Exception as e:results.append({'scenario':'public browser form','status':'failed','error':str(e)})
    finally:
        for sid in sessions:call('process.terminate',{'session_id':sid,'request_id':sid+':cleanup'},False)
        host.close();(out/'results.json').write_text(json.dumps({'scenarios':results,'calls':calls,'transport':'MCP stdio','screenshots_used':False,
            'native_and_dom_evidence_separate':True,'global_keyboard_or_mouse_injection':False},ensure_ascii=False,indent=2)+'\n')
        for result in results:print(json.dumps(result,ensure_ascii=False),flush=True)
    return int(any(r['status']!='passed' for r in results))


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--xvfb',type=Path);parser.add_argument('--chromium',type=Path,default=Path('/usr/lib/chromium/chromium'))
    parser.add_argument('--mousepad',type=Path,default=Path('/usr/bin/mousepad'));args=parser.parse_args()
    if args.xvfb:
        if args.output.exists():parser.error('--output must be new')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        return private_desktop([sys.executable,str(Path(__file__).resolve()),'--output',str(args.output.resolve()),
            '--chromium',str(args.chromium.resolve()),'--mousepad',str(args.mousepad.resolve())],args.xvfb,args.output.parent)
    return run(args)

if __name__=='__main__':raise SystemExit(main())
