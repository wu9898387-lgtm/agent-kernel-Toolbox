#!/usr/bin/env python3
"""Offline distribution/skill/MCP contract checks; no optional backend launch."""
import argparse
import ast
import importlib.util
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'runtime-access.pyz' if (ROOT / 'runtime-access.pyz').is_file() else ROOT / 'src'

sys.path.insert(0, str(RUNTIME))
from observation_extension.runtime_host import SPECS, tool_catalog
from observation_extension.runtime_mcp import VERSIONS
from observation_extension.version import PACKAGE_ID, PACKAGE_NAME, VERSION


def check(root=ROOT):
    root = Path(root)
    manifest = json.loads((root / 'runtime-manifest.json').read_text())
    assert (manifest['id'], manifest['name'], manifest['version']) == (PACKAGE_ID, PACKAGE_NAME, VERSION)
    assert manifest['tool_count'] == len(SPECS) == 162
    assert manifest['tool_families'] == len({name.split('.')[0] for name in SPECS}) == 36
    assert manifest['mcp_protocol_versions'] == list(VERSIONS)
    assert len(tool_catalog(SPECS)) == len(SPECS)
    skill = root / manifest['bundled_skill']
    text = skill.read_text()
    assert text.startswith('---\nname: agent-kernel-toolbox\ndescription: ')
    assert '\n---\n' in text[4:] and len(text.splitlines()) < 200
    assert not re.search(r'\bTODO\b|\[INSERT', text)
    for link in re.findall(r'\]\(([^)]+)\)', text):
        assert (skill.parent / link).is_file(), link
    for path in ('agents/openai.yaml', 'scripts/inspect_mcp.py'):
        assert (skill.parent / path).is_file(), path
    metadata = (skill.parent / 'agents/openai.yaml').read_text()
    assert PACKAGE_NAME in metadata and '$agent-kernel-toolbox' in metadata
    ast.parse((skill.parent / 'scripts/inspect_mcp.py').read_text())
    client = json.loads((root / manifest['mcp_client_example']).read_text())
    assert client['mcpServers'][PACKAGE_NAME]['args'][1:3] == ['serve', '--config']
    minimum = json.loads((root / 'runtime-minimal-config.example.json').read_text())
    assert minimum['portable_build'] == {'profiles': {}}
    assert set(minimum['allowed_tools']) <= SPECS.keys()
    browser = json.loads((root / 'browser/package.json').read_text())
    lock = json.loads((root / 'browser/package-lock.json').read_text())
    assert browser['version'] == lock['version'] == lock['packages']['']['version'] == '0.5.6+toolbox.2'
    assert browser['toolbox_release'] == VERSION
    assert browser['name'] == lock['name'] == lock['packages']['']['name'] == 'agent-kernel-toolbox-browser'
    extension = json.loads((root / 'browser/extension/manifest.json').read_text())
    assert (extension['name'], extension['version']) == (PACKAGE_NAME, VERSION)
    spec = importlib.util.spec_from_file_location('toolbox_package_builder', root / 'build-source.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    for filename in builder.EXTERNAL:
        assert (root / filename).is_file(), filename
    assert len(builder.EXTERNAL) == len(set(builder.EXTERNAL))
    for filename in ('browser/extension.test.mjs', 'browser/route-evidence.test.mjs', manifest['bundled_skill']):
        assert filename in builder.EXTERNAL
    with zipfile.ZipFile(root / manifest['entrypoint']) as archive:
        packed = {name: archive.read(name) for name in archive.namelist()}
    if (root / 'src').is_dir():
        source = {str(path.relative_to(root / 'src')): path.read_bytes()
                  for path in (root / 'src').rglob('*.py')}
        assert packed == source, 'runtime-access.pyz is stale; rebuild before release'
    else:
        spec = importlib.util.spec_from_file_location('toolbox_contract_verifier', root / 'verify-runtime.py')
        verifier = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(verifier)
        assert verifier.verify_directory(root)['runtime_sources_verified'] is True
    return {'passed': True, 'scope': 'offline_distribution_skill_and_mcp_contract_only',
            'name': PACKAGE_NAME, 'version': VERSION, 'tools': len(SPECS),
            'tool_families': manifest['tool_families'], 'python_members': len(packed),
            'bundled_skill': manifest['bundled_skill'], 'all_backends_verified': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    try:
        report = check()
    except (AssertionError, OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
        report = {'passed': False, 'error': str(error) or 'contract_mismatch'}
    encoded = json.dumps(report, indent=2) + '\n'
    if args.report:
        args.report.write_text(encoded)
    print(encoded, end='')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
