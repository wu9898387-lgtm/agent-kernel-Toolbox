#!/usr/bin/env python3
"""Real public-site and Mousepad smoke checks through MCP/AT-SPI; no screenshots.

Run with --xvfb for a private display/session bus. All files and browser state
are created below a new --output directory; no existing APP profile is reused.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import select
import subprocess
import sys
import tempfile
import time
import urllib.parse

ROOT=Path(__file__).resolve().parents[1]


class MCP:
    def __init__(self,config,out):
        path=out/'config.json';path.write_text(json.dumps(config));path.chmod(0o600)
        self.log=(out/'mcp-stderr.log').open('wb')
        self.child=subprocess.Popen([sys.executable,str(ROOT/'runtime-access.pyz'),'serve','--config',str(path)],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,bufsize=0)
        self.buffer=b'';self.counter=0
        try:
            self.rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'live-atspi-check','version':'1'}})
            self.child.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
        except BaseException:
            self.close();raise
    def rpc(self,method,params):
        self.counter+=1
        raw=json.dumps({'jsonrpc':'2.0','id':self.counter,'method':method,'params':params}).encode()+b'\n'
        self.child.stdin.write(raw)
        deadline=time.monotonic()+35
        while b'\n' not in self.buffer:
            if not select.select([self.child.stdout],[],[],max(0,deadline-time.monotonic()))[0]:raise RuntimeError('MCP response deadline')
            chunk=os.read(self.child.stdout.fileno(),16384)
            if not chunk:raise RuntimeError('MCP closed')
            self.buffer+=chunk
            if len(self.buffer)>2*1024*1024:raise RuntimeError('MCP response budget')
        line,self.buffer=self.buffer.split(b'\n',1);result=json.loads(line)
        if result.get('id')!=self.counter or 'error' in result:raise RuntimeError('MCP protocol failure')
        return result['result']
    def call(self,name,args):return self.rpc('tools/call',{'name':name,'arguments':args})['structuredContent']
    def close(self):
        self.child.stdin.close()
        try:self.child.wait(timeout=5)
        except subprocess.TimeoutExpired:self.child.kill();self.child.wait(timeout=2)
        self.child.stdout.close();self.log.close()


def run_checks(args):
    out=args.output.resolve();out.mkdir(exist_ok=False)
    proxy=urllib.parse.urlsplit(os.environ.get('HTTPS_PROXY',os.environ.get('HTTP_PROXY','')))
    if proxy.username or proxy.password:raise RuntimeError('this smoke check needs a noncredential proxy URL')
    flags=['--no-sandbox','--disable-dev-shm-usage','--no-first-run','--no-default-browser-check',
        '--disable-background-networking','--disable-sync','--password-store=basic','--force-renderer-accessibility']
    if proxy.hostname:flags+=['--proxy-server='+proxy.geturl()]
    scratch=out/'scratch.txt';scratch.write_text('Original scratch document.\n')
    profiles={name:{'argv':[str(args.chromium),*flags,'--user-data-dir='+str(out/(name+'-profile')),url],
                    'enable_accessibility':True} for name,url in
              [('example','https://example.com/'),('python','https://docs.python.org/3/tutorial/')]}
    profiles['mousepad']={'argv':[str(args.mousepad),'--disable-server',str(scratch)],
        'enable_accessibility':True,'include_editable_text':True,'allow_text_input':True}
    if args.firefox:
        profile=out/'firefox-profile';profile.mkdir()
        if args.ca_certificate:
            subprocess.run(['certutil','-N','--empty-password','-d','sql:'+str(profile)],check=True,timeout=5)
            subprocess.run(['certutil','-A','-d','sql:'+str(profile),'-n','operator-configured-test-ca','-t','C,,',
                '-i',str(args.ca_certificate)],check=True,timeout=5)
        prefs={'network.proxy.type':1 if proxy.hostname else 0,'accessibility.force_disabled':0,
               'security.enterprise_roots.enabled':True,'browser.shell.checkDefaultBrowser':False,
               'browser.startup.homepage_override.mstone':'ignore','browser.aboutwelcome.enabled':False,
               'datareporting.policy.dataSubmissionEnabled':False}
        if proxy.hostname:
            prefs.update({'network.proxy.http':proxy.hostname,'network.proxy.http_port':proxy.port,
                'network.proxy.ssl':proxy.hostname,'network.proxy.ssl_port':proxy.port})
        (profile/'user.js').write_text('\n'.join('user_pref('+json.dumps(k)+', '+json.dumps(v)+');' for k,v in prefs.items())+'\n')
        profiles['firefox']={'argv':[str(args.firefox),'--no-remote','--profile',str(profile),'https://example.com/'],
            'enable_accessibility':True}
    allowed=['process.launch','process.terminate','process.inspect','process.cpu_sample',
             'native.open','native.snapshot','native.query','native.invoke','native.focus','native.set_text']
    host=MCP({'schema_version':1,'state_directory':str(out/'state'),'allowed_tools':allowed,'profiles':profiles},out)
    calls=[];results=[];sessions=[]
    def call(name,arguments,required=True):
        result=host.call(name,arguments);path=out/(f'{len(calls)+1:03d}-'+name+'.json')
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        calls.append({'tool':name,'ok':result['ok'],'file':path.name,'receipt':result.get('evidence',{}).get('receipt_sha256')})
        if required and not result['ok']:raise RuntimeError(name+': '+result.get('error','unknown'))
        return result
    def query(sid,text='',roles=None,limit=1):
        deadline=time.monotonic()+20
        while True:
            result=call('native.query',{'session_id':sid,'query':text,'roles':roles or [],'limit':limit},False)
            if result['ok'] and result['data']['nodes']:return result['data']
            if time.monotonic()>deadline:raise RuntimeError('query postcondition absent: '+text+' ('+result.get('error','no match')+')')
            time.sleep(.15)
    def invoke(sid,snapshot,node,request):
        result=call('native.invoke',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],
            'action_index':node['actions'][0]['index'],'request_id':sid+':'+request})['data']
        if result['status']!='acknowledged':raise RuntimeError('native effect unknown; no replay')
    try:
        for profile in profiles:
            sid=None;started=time.monotonic()
            try:
                sid=call('process.launch',{'profile':profile,'request_id':'launch-'+profile})['data']['session_id'];sessions.append(sid)
                call('native.open',{'session_id':sid})
                if profile in ('example','firefox'):
                    query(sid,'Example Domain',roles=['document web'])
                    snapshot=query(sid,roles=['link'],limit=16)
                    selected=next(n for n in snapshot['nodes'] if n['actions'] and any(
                        urllib.parse.urlsplit(u).hostname in ('iana.org','www.iana.org') for u in n['links']))
                    invoke(sid,snapshot,selected,'navigate-iana')
                    after=query(sid,'Example Domains',roles=['document web'])
                    uri_exposed=any(urllib.parse.urlsplit(u).hostname in ('iana.org','www.iana.org') for n in after['nodes'] for u in n['links'])
                    if profile=='example':assert uri_exposed
                    body=query(sid,'documentation purposes')
                    result={'scenario':('Firefox: ' if profile=='firefox' else 'Chromium: ')+'Example.com → IANA',
                        'observed_link':selected['links'],'postcondition':after['nodes'][0]['name'],
                        'document_uri_exposed':uri_exposed,'visible_body_postcondition':body['nodes'][0]['text'][:512]}
                elif profile=='python':
                    query(sid,'Python Tutorial',roles=['document web'])
                    snapshot=query(sid,'Whetting Your Appetite',roles=['link']);selected=snapshot['nodes'][0]
                    assert any(urllib.parse.urlsplit(u).hostname=='docs.python.org' for u in selected['links'])
                    invoke(sid,snapshot,selected,'navigate-python-chapter')
                    after=query(sid,'Whetting Your Appetite',roles=['document web'])
                    assert any(urllib.parse.urlsplit(u).path=='/3/tutorial/appetite.html' for n in after['nodes'] for u in n['links'])
                    result={'scenario':'Python tutorial → chapter','observed_link':selected['links'],'postcondition':after['nodes'][0]['name']}
                else:
                    snapshot=query(sid,'Original scratch document.',roles=['text']);node=snapshot['nodes'][0]
                    call('native.focus',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],'request_id':'focus-editor'})
                    snapshot=query(sid,'Original scratch document.',roles=['text']);node=snapshot['nodes'][0]
                    payload='原生无障碍服务实测：中文输入与保存。\nRuntime accessibility live check.\n'
                    result=call('native.set_text',{'session_id':sid,'snapshot_id':snapshot['snapshot_id'],'node_id':node['node_id'],
                        'text':payload,'request_id':'edit-editor'})['data']
                    if result['status']!='acknowledged':raise RuntimeError('input effect unknown; no replay')
                    query(sid,'原生无障碍服务实测',roles=['text'])
                    snapshot=query(sid,'File',roles=['menu']);invoke(sid,snapshot,snapshot['nodes'][0],'open-file-menu')
                    snapshot=query(sid,'Save',roles=['menu item'],limit=16)
                    selected=next(n for n in snapshot['nodes'] if n['name'].strip()=='Save');invoke(sid,snapshot,selected,'save-editor')
                    deadline=time.monotonic()+5
                    while scratch.read_text()!=payload:
                        if time.monotonic()>deadline:raise RuntimeError('saved file content absent')
                        time.sleep(.05)
                    result={'scenario':'Mousepad → Chinese input → File/Save → disk bytes','saved_bytes':scratch.stat().st_size,
                        'saved_sha256':hashlib.sha256(scratch.read_bytes()).hexdigest()}
                call('process.inspect',{'session_id':sid});call('process.cpu_sample',{'session_id':sid,'interval_ms':100})
                result.update(status='passed',seconds=round(time.monotonic()-started,3));results.append(result)
            except Exception as error:
                results.append({'scenario':profile,'status':'failed','error':str(error)})
                if sid:call('native.snapshot',{'session_id':sid},False)
            finally:
                if sid:
                    call('process.terminate',{'session_id':sid,'request_id':'terminate-'+profile},False);sessions.remove(sid)
                print(json.dumps(results[-1],ensure_ascii=False),flush=True)
    finally:
        for sid in sessions:call('process.terminate',{'session_id':sid,'request_id':'cleanup-'+sid},False)
        host.close()
        (out/'results.json').write_text(json.dumps({'scenarios':results,'calls':calls,'transport':'MCP stdio',
            'source':'linux-at-spi','screenshots_used':False,'dom_or_cdp_control_used':False,
            'browser_certificate_checks_disabled':False,'existing_profiles_reused':False},ensure_ascii=False,indent=2)+'\n')
    return int(any(r['status']!='passed' for r in results))


def private_desktop(command,xvfb,parent,timeout=180):
    server=subprocess.Popen([str(xvfb),'-displayfd','1','-screen','0','1440x1000x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    try:
        if not select.select([server.stdout],[],[],5)[0]:raise RuntimeError('Xvfb readiness deadline')
        display=server.stdout.readline().decode().strip()
        if not display.isdigit():raise RuntimeError('invalid Xvfb display')
        with tempfile.TemporaryDirectory(prefix='runtime-a11y-settings-',dir=parent) as settings:
            env={**os.environ,'DISPLAY':':'+display,'NO_AT_BRIDGE':'0','GTK_MODULES':'atk-bridge','GSETTINGS_BACKEND':'memory',
                'XDG_CONFIG_HOME':settings+'/config','XDG_CACHE_HOME':settings+'/cache','XDG_DATA_HOME':settings+'/data'}
            return subprocess.run(['dbus-run-session','--',*command],env=env,timeout=timeout).returncode
    finally:
        if server.poll() is None:server.terminate()
        try:server.wait(timeout=3)
        except subprocess.TimeoutExpired:server.kill();server.wait(timeout=2)
        server.stdout.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--chromium',type=Path,default=Path('/usr/lib/chromium/chromium'))
    parser.add_argument('--mousepad',type=Path,default=Path('/usr/bin/mousepad'))
    parser.add_argument('--firefox',type=Path,help='optional exact Firefox executable')
    parser.add_argument('--ca-certificate',type=Path,help='optional operator-trusted proxy CA, imported only into the new Firefox profile')
    parser.add_argument('--xvfb',type=Path)
    args=parser.parse_args()
    if args.xvfb:
        if args.output.exists():parser.error('--output must be a new directory')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        command=[sys.executable,str(Path(__file__).resolve()),'--output',str(args.output.resolve()),
            '--chromium',str(args.chromium.resolve()),'--mousepad',str(args.mousepad.resolve())]
        if args.firefox:command+=['--firefox',str(args.firefox.resolve())]
        if args.ca_certificate:command+=['--ca-certificate',str(args.ca_certificate.resolve())]
        return private_desktop(command,args.xvfb,args.output.parent)
    return run_checks(args)


if __name__=='__main__':raise SystemExit(main())
