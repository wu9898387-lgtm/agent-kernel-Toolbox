#!/usr/bin/env python3
"""Real stdio MCP checks on owned C fixtures, plus explicit catalog/denial coverage.

No ptrace, sandbox, or host policy is changed. Successful authorization denials
are recorded separately from actual backend execution. Native and DWARF phases
have independent hosts and state directories so a blocked backend cannot taint
the other phase. The owned native fixture also exits after 30 seconds.
"""
from __future__ import annotations

import argparse
import ast
import base64
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

from check_browser_mcp import Client

ROOT = Path(__file__).resolve().parents[1]
NATIVE_TOOLS = ['runtime.status', 'runtime.capabilities', 'runtime.audit',
    'process.launch', 'process.status', 'process.resources', 'process.inspect', 'process.maps',
    'process.abi', 'process.read_memory', 'process.read_value', 'process.resolve_address',
    'process.capture_memory', 'process.diff_memory', 'process.release_capture',
    'process.write_memory', 'process.cpu_sample', 'process.cpu_snapshot', 'process.terminate']
NATIVE_SOURCE = r'''
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
volatile uint64_t owned_value = 7;
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    alarm(30);
    uint64_t last = 0;
    for (;;) {
        uint64_t value = owned_value;
        if (value != last) {
            FILE *out = fopen(argv[1], "w");
            if (!out) return 3;
            fprintf(out, "{\"value\":%llu}\n", (unsigned long long)value);
            fclose(out);
            last = value;
        }
        usleep(10000);
    }
}
'''


class Blocked(RuntimeError):
    pass


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def static_inventory(root, specs, catalog, entry=None):
    root = Path(root)
    entry = Path(entry) if entry is not None else root / 'runtime-access.pyz'
    if entry.is_file():
        with zipfile.ZipFile(entry) as archive:
            source = archive.read('observation_extension/runtime_host.py').decode('utf-8')
    else:
        source_root = entry if entry.is_dir() else root / 'src'
        source = (source_root / 'observation_extension/runtime_host.py').read_text()
    tree = ast.parse(source)
    host = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'RuntimeHost')
    routers = [node for node in host.body if isinstance(node, ast.FunctionDef)
               and node.name in ('_dispatch', '_extended_dispatch')]

    def evidence(name):
        found = []
        values = {'name': name, 'prefix': name.split('.', 1)[0], 'operation': name.split('.', 1)[1]}

        def visit(nodes, router, selected=False):
            for node in nodes:
                if isinstance(node, ast.If):
                    names = {part.id for part in ast.walk(node.test) if isinstance(part, ast.Name)}
                    if names and names <= values.keys():
                        try:
                            matched = eval(compile(ast.Expression(node.test), '<dispatch-guard>', 'eval'),
                                           {'__builtins__': {}}, values)
                        except (TypeError, ValueError, AttributeError):
                            matched = None
                        if matched is True:
                            found.append({'router': router, 'line': node.lineno,
                                          'guard': ast.get_source_segment(source, node.test)})
                            visit(node.body, router, True)
                        elif matched is False:
                            visit(node.orelse, router, selected)
                        else:
                            visit(node.body, router, selected)
                            visit(node.orelse, router, selected)
                    else:
                        visit(node.body, router, selected)
                        visit(node.orelse, router, selected)
                elif isinstance(node, ast.Return) and selected:
                    found.append({'router': router, 'line': node.lineno,
                                  'return': ast.get_source_segment(source, node.value)[:300]})

        for router in routers:
            visit(router.body, router.name)
        return found

    rows = []
    for tool in catalog:
        name = tool['name']
        description, properties, required, mutating = specs[name]
        schema = tool['inputSchema']
        expected_properties = set(properties) | ({'request_id'} if mutating else set())
        expected_required = set(required) | ({'request_id'} if mutating else set())
        valid = (tool['description'] == description and schema['type'] == 'object'
                 and schema['additionalProperties'] is False
                 and set(schema['properties']) == expected_properties
                 and set(schema['required']) == expected_required
                 and tool['annotations']['readOnlyHint'] is not mutating)
        rows.append({'tool': name, 'schema_consistent_with_specs': valid,
                     'input_schema': schema, 'mutating': mutating,
                     'static_dispatch_evidence': evidence(name),
                     'execution_status': 'not_run', 'authorization_preflight': 'not_run'})
    return {'scope': 'catalog/schema/dispatch-source inspection; no backend execution proof',
            'tools': len(rows), 'rows': rows}


class Session(Client):
    def __init__(self, args, config, stderr, report, phase, specs):
        super().__init__(args.entry, args.bundle_root, config, stderr)
        self.report, self.phase, self.specs = report, phase, specs
        self.exchange('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                      'clientInfo': {'name': 'owned-runtime-smoke', 'version': '1'}})
        self.exchange('notifications/initialized', {}, notify=True)

    def invoke(self, tool, arguments=None, *, denied=False, required=True):
        arguments = dict(arguments or {})
        if self.specs[tool][3] and not denied:
            arguments['request_id'] = self.phase + '-' + str(self.sequence + 1)
        result = self.exchange('tools/call', {'name': tool, 'arguments': arguments})
        value = result.get('structuredContent', {})
        data = value.get('data')
        if denied:
            status = ('expected_denied' if value.get('ok') is False
                      and value.get('error') == 'endpoint_not_allowlisted'
                      and value.get('effect_dispatched') is False else 'blocked')
        else:
            status = ('actual_success' if value.get('ok') is True and not value.get('unknown_effect')
                      and (not isinstance(data, dict) or data.get('status') not in ('unknown', 'error'))
                      else 'blocked')
        self.report['invocations'].append({'phase': self.phase, 'tool': tool,
                                           'status': status, 'response': value})
        if required and status == 'blocked':
            raise Blocked(tool + ':' + str(value.get('error') or (data or {}).get('reason', 'unknown_result')))
        return data if status == 'actual_success' else None


@contextmanager
def session(args, directory, config, report, phase, specs):
    directory.mkdir()
    config = {'schema_version': 1, 'state_directory': str(directory / 'state'), **config}
    path = directory / 'config.json'
    path.write_text(json.dumps(config))
    path.chmod(0o600)
    with tempfile.TemporaryFile() as stderr:
        client = Session(args, path, stderr, report, phase, specs)
        try:
            yield client
        finally:
            client.close()
            stderr.seek(0)
            report['transports'].append({'phase': phase, 'exit_code': client.child.returncode,
                'stderr': stderr.read(8192).decode('utf-8', errors='replace')})


def wait_value(path, expected):
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        try:
            if json.loads(path.read_text())['value'] == expected:
                return
        except (OSError, ValueError, KeyError):
            pass
        time.sleep(.01)
    raise AssertionError('owned_program_did_not_observe_value_' + str(expected))


def native(args, directory, report, specs):
    source, binary, business = directory / 'owned.c', directory / 'owned', directory / 'business.json'
    source.write_text(NATIVE_SOURCE)
    subprocess.run(['gcc', '-g', '-O0', '-no-pie', str(source), '-o', str(binary)],
                   check=True, capture_output=True, timeout=15)
    symbols = {line.split()[2]: int(line.split()[0], 16)
               for line in subprocess.check_output(['nm', str(binary)], text=True, timeout=5).splitlines()
               if len(line.split()) == 3}
    address = hex(symbols['owned_value'])
    config = {'allowed_tools': NATIVE_TOOLS, 'binaries': {'owned': str(binary)},
              'profiles': {'owned': {'argv': [str(binary), str(business)], 'allow_memory': True,
                  'allow_control': True, 'allow_memory_write': True, 'allow_debug': True,
                  'write_regions': {'value': {'address': address, 'size': 8}},
                  'limits': {'cpu_seconds': 20, 'address_space_bytes': 268435456, 'open_files': 128}}}}
    with session(args, directory / 'native-host', config, report, 'native', specs) as client:
        listed = client.exchange('tools/list', {})
        assert {tool['name'] for tool in listed['tools']} == set(NATIVE_TOOLS)
        client.invoke('runtime.status')
        client.invoke('runtime.capabilities')
        launched = client.invoke('process.launch', {'profile': 'owned'})
        key = launched['session_id']
        selected = {'session_id': key}
        memory = {**selected, 'address': address, 'size': 8}
        try:
            wait_value(business, 7)
            assert client.invoke('process.status', selected)['alive'] is True
            client.invoke('process.resources', selected)
            client.invoke('process.inspect', selected)
            client.invoke('process.maps', selected)
            abi = client.invoke('process.abi', selected)
            order = abi['byte_order']
            before = (7).to_bytes(8, order)
            after = (9).to_bytes(8, order)
            read = client.invoke('process.read_memory', memory)
            assert base64.b64decode(read['data']) == before
            client.invoke('process.read_value', {**memory, 'type': 'uint64'})
            resolved = client.invoke('process.resolve_address', {**selected, 'address': address})
            assert 'owned' in resolved['registered_binary_ids']
            captured = client.invoke('process.capture_memory', memory)
            patch_args = {**selected, 'region': 'value', 'offset': 0,
                          'data_hex': after.hex(), 'expected_sha256': captured['sha256']}
            written = client.invoke('process.write_memory', patch_args)
            assert written['status'] == 'verified'
            assert base64.b64decode(client.invoke('process.read_memory', memory)['data']) == after
            wait_value(business, 9)
            capture_args = {**selected, 'capture_id': captured['capture_id']}
            assert client.invoke('process.diff_memory', capture_args)['changed_bytes'] == 1
            restored = client.invoke('process.write_memory', {**patch_args, 'data_hex': before.hex(),
                'expected_sha256': hashlib.sha256(after).hexdigest()})
            assert restored['status'] == 'verified'
            wait_value(business, 7)
            assert client.invoke('process.diff_memory', capture_args)['changed_bytes'] == 0
            assert client.invoke('process.release_capture', capture_args)['released'] is True
            client.invoke('process.cpu_sample', {**selected, 'interval_ms': 50})
            report['native_business_roundtrip'] = [7, 9, 7]
            # Actual ptrace attempt: failure is reported, with no fallback.
            client.invoke('process.cpu_snapshot', selected, required=False)
        finally:
            terminated = client.invoke('process.terminate', selected)
            assert terminated['exited'] is True
            assert client.invoke('process.status', selected)['alive'] is False
            client.invoke('runtime.audit')


def metadata(args, directory, report, specs):
    engine_python = os.environ.get('RUNTIME_PYELFTOOLS_PYTHON')
    if not engine_python:
        raise Blocked('RUNTIME_PYELFTOOLS_PYTHON_not_configured')
    engine = json.loads(subprocess.check_output([engine_python, '-I', '-c',
        'import elftools,hashlib,pathlib,json,sys;print(json.dumps({"python":sys.executable,'
        '"python_sha256":hashlib.sha256(pathlib.Path(sys.executable).read_bytes()).hexdigest(),'
        '"pyelftools_version":elftools.__version__,"pyelftools_module_sha256":'
        'hashlib.sha256(pathlib.Path(elftools.__file__).read_bytes()).hexdigest()}))'], text=True, timeout=15))
    binary = directory / 'layout'
    subprocess.run(['gcc', '-g', '-O0', '-fPIE', '-pie', '-Wl,--build-id=sha1',
                    str(args.bundle_root / 'tests/fixtures/compiler_metadata/layout.c'), '-o', str(binary)],
                   check=True, capture_output=True, timeout=15)
    oracle = json.loads(subprocess.check_output([str(binary)], text=True, timeout=5))
    config = {'allowed_tools': ['metadata.inspect', 'metadata.extract'],
              'compiler_metadata': {**engine, 'profiles': {'owned': {'path': str(binary),
                'sha256': sha(binary), 'types': ['Packet'], 'variables': ['GLOBAL_PACKET'], 'timeout_seconds': 30}}}}
    with session(args, directory / 'metadata-host', config, report, 'metadata', specs) as client:
        assert len(client.exchange('tools/list', {})['tools']) == 2
        inspected = client.invoke('metadata.inspect')
        assert inspected['engine']['available'] is True
        result = client.invoke('metadata.extract', {'profile': 'owned'})
        packet = next(item for item in result['types'] if item['name'] == 'Packet')
        assert packet['byte_size'] == oracle['packet_size']
        members = {item['name']: item for item in packet['members'] if item['name']}
        for name in ('sequence', 'nested', 'payload', 'values'):
            assert members[name]['known'] and members[name]['byte_offset'] == oracle[name]
        assert result['target_executed'] is False and result['live_addresses_returned'] is False
        report['metadata_compiler_oracle'] = oracle
        report['metadata_engine'] = engine


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-root', type=Path, default=ROOT)
    parser.add_argument('--entry', type=Path, help='Default: runtime-access.pyz, or the development src directory if no zipapp exists.')
    parser.add_argument('--report', type=Path)
    parser.add_argument('--inventory', type=Path)
    args = parser.parse_args()
    args.bundle_root = args.bundle_root.resolve()
    default_entry = args.bundle_root / 'runtime-access.pyz'
    if not default_entry.is_file():
        default_entry = args.bundle_root / 'src'
    args.entry = (args.entry or default_entry).resolve()
    sys.path.insert(0, str(args.entry))
    from observation_extension.runtime_host import SPECS, tool_catalog
    catalog = tool_catalog(SPECS)
    inventory = static_inventory(args.bundle_root, SPECS, catalog, args.entry)
    report = {'kind': 'real_stdio_owned_native_and_dwarf', 'entry': str(args.entry),
              'invocations': [], 'transports': [], 'phase_errors': [],
              'scope': 'owned Linux C fixture and offline DWARF only; denials are not backend successes'}
    with tempfile.TemporaryDirectory(prefix='runtime-mcp-') as temporary:
        directory = Path(temporary)
        try:
            with session(args, directory / 'catalog-host', {'allowed_tools': list(SPECS)},
                         report, 'catalog', SPECS) as client:
                observed = client.exchange('tools/list', {})['tools']
                report['catalog_matches_source'] = observed == catalog
                assert report['catalog_matches_source']
            with session(args, directory / 'deny-host', {'allowed_tools': []}, report, 'deny_all', SPECS) as client:
                assert client.exchange('tools/list', {})['tools'] == []
                for tool in sorted(SPECS):
                    client.invoke(tool, denied=True)
        except Exception as error:
            report['phase_errors'].append({'phase': 'catalog_or_denials', 'error': type(error).__name__ + ':' + str(error)})
        for phase, check in [('native', native), ('metadata', metadata)]:
            try:
                check(args, directory, report, SPECS)
            except Exception as error:
                report['phase_errors'].append({'phase': phase, 'error': type(error).__name__ + ':' + str(error)})
    for row in inventory['rows']:
        records = [item for item in report['invocations'] if item['tool'] == row['tool']]
        actual = [item['status'] for item in records if item['phase'] != 'deny_all']
        row['execution_status'] = ('blocked' if 'blocked' in actual else 'actual_success' if actual else 'not_run')
        row['authorization_preflight'] = next((item['status'] for item in records if item['phase'] == 'deny_all'), 'not_run')
    report['tool_counts'] = {status: sum(row['execution_status'] == status for row in inventory['rows'])
                             for status in ('actual_success', 'blocked', 'not_run')}
    report['expected_denied_tools'] = sum(row['authorization_preflight'] == 'expected_denied' for row in inventory['rows'])
    report['schema_consistent_tools'] = sum(row['schema_consistent_with_specs'] for row in inventory['rows'])
    report['static_routing_evidence_tools'] = sum(bool(row['static_dispatch_evidence']) for row in inventory['rows'])
    report['all_requested_checks_passed'] = not report['phase_errors'] and report['tool_counts']['blocked'] == 0
    if args.inventory:
        args.inventory.write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
    if args.report:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'invocations'}, ensure_ascii=False, indent=2))
    return 0 if report['all_requested_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
