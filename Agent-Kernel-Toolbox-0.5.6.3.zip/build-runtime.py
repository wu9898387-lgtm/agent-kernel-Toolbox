#!/usr/bin/env python3
"""Build the complete toolbox from an explicit functional resource allowlist."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
MAX_ARCHIVE_BYTES = 1536 * 1024
MAX_EXPANDED_BYTES = 4 * 1024 * 1024
MAX_MEMBERS = 320
EXTERNAL = (
    'ADVANCED_CHECKS.md',
    'COMPATIBILITY.md',
    'CROSS_PLATFORM.md',
    'DEFENSIVE-OBSERVATION.md',
    'LICENSE',
    'LIFECYCLE.md',
    'LIVE_CHECKS.md',
    'MCP.md',
    'NATIVE.md',
    'NATIVE_WORKER.md',
    'PACKAGING.md',
    'PORTABLE-BUILD.md',
    'PROGRAM-MONITORING.md',
    'README.md',
    'REVERSE.md',
    'RUNTIME.md',
    'browser-forms-config.example.json',
    'browser/README.md',
    'browser/cli.mjs',
    'browser/compatibility.test.mjs',
    'browser/extension.test.mjs',
    'browser/extension/background.mjs',
    'browser/extension/content.js',
    'browser/extension/control.css',
    'browser/extension/control.html',
    'browser/extension/control.mjs',
    'browser/extension/manifest.json',
    'browser/extension/rules.mjs',
    'browser/form-input.test.mjs',
    'browser/package-lock.json',
    'browser/package.json',
    'browser/portable-evidence.mjs',
    'browser/route-analysis.mjs',
    'browser/route-evidence.mjs',
    'browser/route-evidence.test.mjs',
    'browser/runtime.mjs',
    'browser/runtime.test.mjs',
    'browser/semantic-query.mjs',
    'browser/text-input.mjs',
    'browser/traffic-policy.mjs',
    'browser/traffic-policy.test.mjs',
    'build-runtime.py',
    'build-source.py',
    'compiled-native-config.example.json',
    'cross-platform-config.example.json',
    'debugger-profile.example.json',
    'defensive-config.example.json',
    'examples/portable-objects/MANIFEST.json',
    'examples/portable-objects/README.md',
    'examples/portable-objects/aarch64-apple-darwin.o',
    'examples/portable-objects/aarch64-linux-gnu.o',
    'examples/portable-objects/aarch64-linux-musl.o',
    'examples/portable-objects/aarch64-pc-windows-msvc.o',
    'examples/portable-objects/armv7-linux-gnueabihf.o',
    'examples/portable-objects/i686-linux-gnu.o',
    'examples/portable-objects/mips-linux-gnu.o',
    'examples/portable-objects/powerpc64-linux-gnu.o',
    'examples/portable-objects/riscv64-linux-gnu.o',
    'examples/portable-objects/x86_64-apple-darwin.o',
    'examples/portable-objects/x86_64-linux-gnu.o',
    'examples/portable-objects/x86_64-linux-musl.o',
    'examples/portable-objects/x86_64-pc-windows-msvc.o',
    'mcp-client.example.json',
    'monitoring-config.example.json',
    'native-browser-config.example.json',
    'native-config.example.json',
    'native/README.md',
    'native/REVERSE.md',
    'native/build.py',
    'native/managed-jvm/README.md',
    'native/managed-jvm/RuntimeManagedAgent.java',
    'native/managed-jvm/build.py',
    'native/managed-probe/RuntimeProbe.java',
    'native/managed-probe/build.py',
    'native/managed-probe/managed_probe.c',
    'native/probe-sdk/probe.c',
    'native/probe-sdk/probe.h',
    'native/render_filter.cpp',
    'native/runtime-agent/Cargo.lock',
    'native/runtime-agent/Cargo.toml',
    'native/runtime-agent/README.md',
    'native/runtime-agent/agent.c',
    'native/runtime-agent/agent.h',
    'native/runtime-agent/build.py',
    'native/runtime-agent/concurrent_test.c',
    'native/runtime-agent/demo.c',
    'native/runtime-agent/src/main.rs',
    'native/runtime-agent/test_build.py',
    'native/worker/GO-LICENSE',
    'native/worker/GO-PATENTS',
    'native/worker/go.mod',
    'native/worker/main.go',
    'native/worker/platform_linux.go',
    'native/worker/platform_other.go',
    'native/worker/worker_test.go',
    'portable-build-config.example.json',
    'portable-word-ir.example.json',
    'requirements-validation.txt',
    'reverse-config.example.json',
    'runtime-advanced-config.example.json',
    'runtime-config.example.json',
    'runtime-manifest.json',
    'runtime-minimal-config.example.json',
    'skills/agent-kernel-toolbox/SKILL.md',
    'skills/agent-kernel-toolbox/agents/openai.yaml',
    'skills/agent-kernel-toolbox/references/operations.md',
    'skills/agent-kernel-toolbox/scripts/inspect_mcp.py',
    'tests/fixtures/compiler_metadata/layout.c',
    'tests/fixtures/environment_probe.c',
    'tests/fixtures/file_activity_scanner.c',
    'tests/fixtures/gtk_app.py',
    'tests/fixtures/lifecycle.c',
    'tests/fixtures/memory_layout.c',
    'tests/fixtures/native32.S',
    'tests/fixtures/native_connections.c',
    'tests/fixtures/native_control_app.c',
    'tests/fixtures/recovery/CoroutineFixture.kt',
    'tests/fixtures/recovery/Extra.java',
    'tests/fixtures/recovery/LiveCoroutineFixture.kt',
    'tests/fixtures/recovery/ManagedFixture.java',
    'tests/fixtures/recovery/ManagedProbeFixture.java',
    'tests/fixtures/recovery/Recovery.java',
    'tests/fixtures/recovery/build_kotlin_fixture.py',
    'tests/fixtures/recovery/compatibility_target.c',
    'tests/fixtures/recovery/frida_agent.js',
    'tests/fixtures/recovery/frida_target.c',
    'tests/fixtures/recovery/ghidra_owned.c',
    'tests/fixtures/recovery/ghidra_owned_aarch64.S',
    'tests/fixtures/recovery/ghidra_owned_aarch64.build.json',
    'tests/fixtures/recovery/ghidra_owned_aarch64.o',
    'tests/fixtures/recovery/kotlin-fixture-build.json',
    'tests/fixtures/recovery/kotlin-fixture.apk',
    'tests/fixtures/recovery/kotlin-fixture.dex',
    'tests/fixtures/recovery/machine_kernel.S',
    'tests/fixtures/recovery/machine_kernel.ld',
    'tests/fixtures/recovery/multidex.apk',
    'tests/fixtures/recovery/native_probe_access.S',
    'tests/fixtures/recovery/native_probe_target.c',
    'tests/fixtures/recovery/native_probe_threads.c',
    'tests/fixtures/recovery/native_symbolic.c',
    'tests/fixtures/recovery/portable_memory.c',
    'tests/fixtures/recovery/portable_memory_aarch64.S',
    'tests/fixtures/recovery/record_reverse.S',
    'tests/fixtures/recovery/shared_writer.c',
    'tests/fixtures/recovery/stalker_target.c',
    'tests/fixtures/recovery/tree_app.c',
    'tests/fixtures/reverse_cross_format.c',
    'tests/fixtures/reverse_routes.c',
    'tests/native_probe_budget.test.mjs',
    'tests/test_abi.py',
    'tests/test_analysis_tools.py',
    'tests/test_app_routes.py',
    'tests/test_appium_native.py',
    'tests/test_build_cli.py',
    'tests/test_build_host.py',
    'tests/test_compatibility_control.py',
    'tests/test_compiler_metadata.py',
    'tests/test_coordinated_state.py',
    'tests/test_distribution.py',
    'tests/test_environment_probe.py',
    'tests/test_extended_host.py',
    'tests/test_file_activity.py',
    'tests/test_frida_integration.py',
    'tests/test_ghidra_die_integration.py',
    'tests/test_ir_analysis.py',
    'tests/test_kotlin_recovery.py',
    'tests/test_lifecycle.py',
    'tests/test_linux_tracing.py',
    'tests/test_live_kotlin_jvm.py',
    'tests/test_lldb_agent.py',
    'tests/test_malware_triage.py',
    'tests/test_managed_guardian.py',
    'tests/test_managed_jvm.py',
    'tests/test_managed_probe.py',
    'tests/test_mapping_safety.py',
    'tests/test_memory_compatibility.py',
    'tests/test_native_app.py',
    'tests/test_native_control.py',
    'tests/test_native_debug.py',
    'tests/test_native_fence.py',
    'tests/test_native_helper.py',
    'tests/test_native_probe.py',
    'tests/test_native_query.py',
    'tests/test_native_symbolic.py',
    'tests/test_native_translation.py',
    'tests/test_network_policy.py',
    'tests/test_object_runtime.py',
    'tests/test_package.py',
    'tests/test_portable_build.py',
    'tests/test_portable_emulation.py',
    'tests/test_probe_budget.py',
    'tests/test_probe_sdk.py',
    'tests/test_process_tree.py',
    'tests/test_program_monitor.py',
    'tests/test_reconciliation.py',
    'tests/test_register_control.py',
    'tests/test_reverse_backends.py',
    'tests/test_revision2_host.py',
    'tests/test_revision_host.py',
    'tests/test_runtime.py',
    'tests/test_runtime_distribution.py',
    'tests/test_semantic_agent.py',
    'tests/test_semantic_object_integration.py',
    'tests/test_structured_recovery.py',
    'tests/test_translation.py',
    'tests/test_v055_host.py',
    'tests/test_whole_system.py',
    'tools/RuntimeAccessEmulate.java',
    'tools/RuntimeAccessEmulateMemory.java',
    'tools/RuntimeAccessExport.java',
    'tools/benchmark_native_worker.py',
    'tools/build_machine_fixture.py',
    'tools/build_recovery_fixture.py',
    'tools/check_advanced_accessibility.py',
    'tools/check_browser_mcp.py',
    'tools/check_cross_architecture.py',
    'tools/check_installation.py',
    'tools/check_live_accessibility.py',
    'tools/check_official_mcp.py',
    'tools/check_package_contract.py',
    'tools/check_runtime_mcp.py',
    'tools/coordinated_watchdog.py',
    'tools/environment_probe_agent.py',
    'tools/extract_sources.py',
    'tools/file_activity_agent.py',
    'tools/install_reverse_native.py',
    'tools/lldb_agent.py',
    'tools/managed_jvm_guardian.py',
    'tools/native_probe.js',
    'tools/native_probe_agent.py',
    'tools/native_symbolic_agent.py',
    'tools/reverse_mcp/README.md',
    'tools/reverse_mcp/package-lock.json',
    'tools/reverse_mcp/package.json',
    'tools/run_desktop_checks.py',
    'tools/runtime-platform.py',
    'tools/tree_guardian.py',
    'v055-config.example.json',
    'verify-runtime.py',
)


def read_source(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > 2 * 1024 * 1024:
            raise ValueError('invalid_source')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(2 * 1024 * 1024 + 1)
        after = os.fstat(fd)
        if len(raw) != before.st_size or any(getattr(before, k) != getattr(after, k)
                for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')):
            raise ValueError('source_changed_or_oversized')
        return raw
    finally:
        os.close(fd)


def archive(files):
    result = io.BytesIO()
    with zipfile.ZipFile(result, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for name, raw in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 14, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            package.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return result.getvalue()


def python_sources(root=ROOT):
    """Read one source tree or the delivered zipapp without executing its code."""
    root = Path(root)
    if (root / 'src').is_dir():
        inner = {str(path.relative_to(root / 'src')): read_source(path)
                 for path in sorted((root / 'src').rglob('*.py'))}
    else:
        spec = importlib.util.spec_from_file_location('toolbox_build_verifier', root / 'verify-runtime.py')
        verifier = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(verifier)
        inner = verifier.read_archive(read_source(root / 'runtime-access.pyz'))
        inventory = verifier.json_object(read_source(root / 'CONTENTS.json'))
        verifier.hash_inventory(inner, inventory['python_files'])
    if '__main__.py' not in inner or any(not name.endswith('.py') for name in inner):
        raise ValueError('missing_or_invalid_python_sources')
    return inner


def build(root=ROOT):
    root = Path(root)
    if len(set(EXTERNAL)) != len(EXTERNAL):
        raise ValueError('duplicate_resource')
    inner = python_sources(root)
    outer = {name: read_source(root / name) for name in EXTERNAL}
    outer['runtime-access.pyz'] = archive(inner)
    manifest = json.loads(outer['runtime-manifest.json'])
    inventory = {
        'schema_version': 1, 'package_id': manifest['id'],
        'package_name': manifest['name'], 'package_version': manifest['version'],
        'files': {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(outer.items())},
        'python_files': {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(inner.items())},
    }
    outer['CONTENTS.json'] = (json.dumps(inventory, sort_keys=True, indent=2) + '\n').encode()
    if len(outer) > MAX_MEMBERS or sum(map(len, outer.values())) > MAX_EXPANDED_BYTES:
        raise ValueError('runtime_expanded_size_or_member_budget')
    raw = archive(outer)
    if len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('runtime_archive_size_budget')
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    raw = build()
    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
    print(json.dumps({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
