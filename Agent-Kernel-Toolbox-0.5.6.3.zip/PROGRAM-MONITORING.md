# 程序监测、对象关联与状态控制

探针用于监测程序本身。其事件可用于对象生命周期关联、环境行为分析、文件活动分析和受控状态检查。

## 接入链路

1. 安装者登记目标ELF、执行/观察范围、工具摘要和预算；模型只选择档案ID。
2. `metadata.extract`读取真实DWARF和ELF，给出类型、字段、符号、装载段及可解释的全局变量定位。复杂或优化消失的位置返回unknown。
3. `probe.open/poll/close`在独立监督下启动目标，输出指定范围的指令、有效地址、分配/释放、函数和可选环境API事件。
4. `program.open/poll/close`直接消费该NativeProbe会话，并把执行位置/地址与分配代次、显式对象声明和编译器字段关联。不接受模型提交的伪造事件。
5. `coordinated.capture/patch/release`在另行登记的多写者屏障下完成一致状态捕获和固定模板修改；监测证据本身不授予写权限。

NativeProbe是有界采集会话：默认租约5秒，可登记200毫秒至30秒，同时最多2个活动会话、保留最多8份事件流。指令、回调时间、事件数和字节预算独立生效；达到预算会卸除探针。该接口不提供无限期、全程序零遗漏的后台跟踪，长期低密度采样应使用独立的trace/probes预算接口。

CPU地址计算证据包括参与的base/index寄存器值、比例、位移、下一指令地址和地址位宽。追踪不为读取事件而读取目标地址的值；每个内存事件明确为指令执行前的尝试，不冒充成功完成或硬件retired轨迹。段寻址、隐式访问或无法支持的语义必须保留unknown/覆盖缺口。

## 身份与生命周期

malloc/calloc/realloc/free和mmap/munmap形成分配块代次。失败realloc保留旧块；零长度realloc语义不明确时使相关身份不确定；同一地址再次分配产生新代次。分配块不会自动被认作高层对象。

`native/probe-sdk/probe.h/c`提供显式发布点：`ra_probe_object`、`ra_probe_move`、`ra_probe_retire`。对象ID与生命周期generation独立于分配地址；迁移保持generation，观察到的位置epoch另行递增。type_slot登记到DWARF类型或精确DIE身份。应用负责引用修复、写者同步及声明真实性，发布点本身不迁移或修改对象。

PIE/ASLR全局定位使用经过摘要核对的实际模块base、实际页大小和ELF PT_LOAD，不能直接把静态DWARF地址当活地址。同名类型优先按精确DIE身份；多个同名record不能唯一解析时保留歧义。联合体重叠字段不推断唯一成员。

游标读取可重复，关联层有有界回压与记录保留。事件丢失、序列断开、未知生命周期、输出裁剪或监测结束分别报告；不能把事件缺失解释为没有发生访问。closed会话不会继续把对象报告为确定存活。即使进程仍在运行且没有丢失计数，预算停止并卸除探针后，`source_observation_current`也立即变为false；历史事件仍可排空和关联，但不能冒充当前内存状态。

## 状态检查与恢复

多写者档案登记PID、启动ticks、执行文件摘要、允许的共享普通RAM区域及映射指纹，并明确声明写者集完整。所有登记线程组暂停后才捕获/比较；只恢复本工具原先暂停的进程，已暂停者保持原状态。独立watchdog在宿主死亡或租约超时后恢复。

固定patch模板先比较全部前像与映射，再写入并读回。失败只有在身份、映射及屏障仍有效时才允许回滚，否则返回unknown并持久围栏；不向变化后的地址盲写。IO/PFNMAP/MIXEDMAP和特殊设备映射不参与普通RAM捕获/回写。声明完整并不证明不存在未知进程、DMA或其他外部写者，VMA同属性ABA也不能由指纹排除。

## 环境与托管运行时

`environment.capture`用固定strace观察程序的文件、内存映射、进程/线程、时间、随机、系统信息、调度、网络、调试和设备控制系统调用。只输出元数据和来源，默认路径/端点摘要化，不返回缓冲区。直接硬件指令、vDSO或未通过相应系统调用的库行为不在其覆盖内。

NativeProbe可选固定`environment_functions`捕获同一次执行中的库API返回事件；不读取字符串/输出缓冲区、不替换行为。它和EnvironmentProbe是互补观察面，不能把不同运行实例的数据当同一次执行的因果链。

`managed_probe.run`通过真实JVMTI原生agent记录对象tag、VMObjectAlloc、ObjectFree和GC事件，固定JNI发布点可标记现有对象并验证GC后身份。VMObjectAlloc不覆盖全部Java new；tag不是物理地址。JVMTI 后端面向支持该接口的 JVM，ART 与 CLR 需要独立适配。

`portable.run`在Ghidra统一p-code引擎里运行固定函数与私有RAM，记录虚拟执行及内存变化；它不会读写宿主活进程的这些虚拟地址。系统调用、用户操作或设备语义未建模时返回unknown。此能力不等于把任意OS程序直接AOT为所有ISA；已有原生AOT/JIT继续遵守其独立的等价验证范围。

## 配置与审计

从`monitoring-config.example.json`登记所需模块。依赖安装、构建JVMTI agent、注册目标和填写真实摘要由安装者完成；全零摘要不是有效配置。相关 MCP 工具默认关闭，跟随原有持久调用日志、权限和Unknown围栏。关闭、释放快照拥有独立清理范围。升级保留或核对旧Pending/Unknown，不通过换state目录绕过。

运行回执报告实际覆盖、丢失和截断。有限采样无法保证所有程序、所有读写零遗漏或无扰动。


补充接入细节：NativeProbe固定函数可通过唯一导出符号或ELF函数符号表定位；同名静态函数歧义拒绝，不开放模型任意RVA。发布 SDK 以保留参数的编译器屏障和可 patch 函数入口提供观察点；目标优化配置应通过 `tests/test_probe_sdk.py` 验证，同步仍由应用承担。

JVM可选`allocation_sampling_interval_bytes`启用JVMTI分配采样，固定JNI `RuntimeProbe.startAllocationSampling(long)`只接受档案同一间隔。普通 new、引用数组、GC 后 tag 和 ObjectFree 由集成测试检查。采样启动时已有线程的内部状态可能延迟生效，采样不能立即穷尽既有 JVM 的全部分配。

JVM运行回执分开报告原生捕获完整性和传输省略。`managed_probe.poll(capture_handle,cursor,max_events)`可按原始seq分页取回私有捕获，`managed_probe.release`只释放本地数据。完整原生流有独立hash校验；保留数量、压缩/解压字节和页面节点均有界，原生丢失不能靠分页恢复。

`managed_probe.close`只接受新的`request_id`，关闭本宿主缓存的整个JVMTI backend：停止其owned JVM/guardian并释放保留捕获，不接受任意PID。未确认回收时返回unknown并保留清理authority；可用新的request_id重试同一backend的关闭。该工具默认禁用，需单独加入allowed_tools；关闭后此backend不再启动新运行。

关闭未知时可以用新的request_id重试已明确只清理owned句柄的close；旧Unknown和目标写入围栏保留，旧request_id仍拒重放。释放捕获或成功清理均不清除任何目标Unknown。

## 构建与检查入口

JVMTI 组件按 [native/README.md](native/README.md) 构建，JDI 协作接口见 [native/managed-jvm/README.md](native/managed-jvm/README.md)。测试 fixture 和检查源码随包保留：

```sh
python3 -m unittest discover -s tests -p test_native_probe.py -v
python3 -m unittest discover -s tests -p test_probe_sdk.py -v
python3 -m unittest discover -s tests -p test_program_monitor.py -v
python3 -m unittest discover -s tests -p test_compiler_metadata.py -v
python3 -m unittest discover -s tests -p test_coordinated_state.py -v
python3 -m unittest discover -s tests -p test_managed_probe.py -v
```

Frida、pyelftools、JDK/JVMTI、Ghidra 和内核跟踪权限按所选路径准备；测试中的跳过不能代替对应后端的实际运行检查。
