# 纯整数 IR 的 13 个真实目标对象

此目录保存本包 `../../portable-word-ir.example.json` 的真实编译产物，
便于直接检查二进制头、机器类型、位宽、字节序和 SHA-256。
示例计算 64 位无符号整数 `((x + y) mod 2^64) xor y`，导出函数为
`int runtime_ir_eval(const unsigned long long *inputs, unsigned long long *output)`。
`inputs` 顺序为 `x`、`y`，调用方提供有效数组和输出指针。

## 使用和核对

`MANIFEST.json` 记录输入摘要、编译器 pin、每个对象的目标 triple、大小、ABI 和 SHA-256。输入路径相对于本目录，重新生成所需配置见 [PORTABLE-BUILD.md](../../PORTABLE-BUILD.md)。先核对 manifest 与当前文件，再交给匹配目标的链接器；对象本身不自动授予执行权限。

运行下列命令可检查文件摘要和示例输入：

```sh
python3 - <<'PY'
import hashlib, json
from pathlib import Path
root = Path('examples/portable-objects')
manifest = json.loads((root / 'MANIFEST.json').read_text())
items = [manifest['input'], *manifest['artifacts']]
for item in items:
    path = root / item['file']
    data = path.read_bytes()
    if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        raise SystemExit('digest or size mismatch: ' + str(path))
print('Verified', len(manifest['artifacts']), 'objects and the input IR')
PY
```

以上命令在 Toolbox 根目录运行。对象是纯整数函数示例，`target_execution_verified` 为 `false`；最终链接、执行和应用 ABI 仍需在实际目标环境验证。MCP 宿主、Linux 进程控制及 UI 后端不会随对象格式自动移植。

## 对象范围

| 格式 | 目标 |
|---|---|
| ELF / GNU 环境 | x86_64、i686、AArch64、ARMv7 hard-float、RISC-V64、MIPS32 big-endian、PowerPC64 big-endian |
| ELF / musl 环境 | x86_64、AArch64 |
| Mach-O / macOS | x86_64、AArch64 |
| COFF / Windows MSVC 环境 | x86_64、AArch64 |

`.o` 是可重定位对象，不能直接当应用程序启动。最终使用还需目标链接器、
SDK、运行时库、应用调用约定和目标设备验收。macOS 的两份对象尚未组成
Universal App；Windows 对象尚未链接为 PE 可执行文件。

对象头检查范围为格式、架构、指针宽度和字节序。清单保留对象头可见的
ABI 变体：例如 ARM hard-float、RISC-V double-float，以及这些对象的
PowerPC64 ELFv2；目标环境必须与实际 ABI 匹配。MIPS 和 PowerPC 对象为大端。
只依据 CPU 的 CISC/RISC 分类不足以确定这些兼容条件。

SHA-256 标识当前交付文件。编译器可能写入时间戳等元数据，清单没有
承诺另一时刻重编译将得到逐字节相同的对象；源、编译器与产物摘要分别记录。
编译器单个可执行文件的摘要也不覆盖整个工具链安装目录或目标 SDK。
