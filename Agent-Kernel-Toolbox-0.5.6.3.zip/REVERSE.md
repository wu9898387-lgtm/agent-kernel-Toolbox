# 路由、调用来源与本地逆向分析

Toolbox 提供浏览器路由/请求/脚本证据、本地 JavaScript 的 JSHookMCP AST 分析，以及 ELF、PE、Mach-O 的 radare2 字符串引用和调用者分析。接口通过 Host 的工具白名单开放。APP 声明路由另由 `app.routes` 提供，见 [COMPATIBILITY.md](COMPATIBILITY.md)。

## 网页的实际内部路由

1. 用 `browser.open` 或已选定的 CDP 目标进入应用。`browser.snapshot` 返回可读文字和导航节点；`browser.activate` 可触发真实 SPA 链接处理器。
2. 调用 `browser.routes`，提供 `page_id`，可选 `limit` 为 1–128。结果包含实际观察到的历史/片段转换、脱敏请求和 initiator 函数/脚本位置，以及有限脚本清单与摘要。
3. `browser.analyze_script` 使用返回的 `script_handle` 分析已观察到的脚本，给出静态路由/API 候选。这一步不会请求候选 URL，也不会执行候选函数。
4. `browser.navigate_route` 使用当前短期有效的 `route_handle` 和独立 `request_id`，跳转到实际观察到的浏览器历史条目；真实 SPA 的 `popstate` 可随之执行。句柄单次使用，页面状态改变后失效。

请求的 `documentURL` 与已观察路由相匹配是一种关联证据，不能单独证明某次界面动作导致该请求。请求开始、收到响应、加载失败有不同字段；被阻断的请求不能记作后端已成功响应。`history.state`、请求头和正文不采集，URL 查询内容不输出。静态候选、运行时观察和可执行历史句柄互相区分。

脚本读取使用短暂的 CDP Debugger 会话，无断点、单步或模型自带 JavaScript。只给许可 origin/执行上下文的脚本发放句柄；导航、来源不符和过期句柄会被拒绝。此功能不保证恢复混淆、加密或动态生成代码的全部业务语义。

临时调试连接也登记写前 `observe-*` 记录。正常关闭后记为完成；清理状态不明或连接异常会留下持久隔离，关闭适配器并阻止重启后继续操作浏览器。可从 `runtime.audit` 查看记录；完成外部状态核对后，沿既有离线 `reconcile` 流程解除。该过程计入同一有界日志预算。

## JSHookMCP 静态分析

解压后的 `tools/reverse_mcp` 包含固定依赖和说明。进入该目录运行：

```sh
npm ci --ignore-scripts --omit=optional --no-audit --no-fund
```

复制 `reverse-config.example.json`，填入 Node、provider entry、私有状态目录及应用文件的绝对路径。用 `sha256sum /absolute/app.bundle.js` 取得真实摘要，替换样例中的全零值。文件内容改变后旧配置会明确拒绝；需要重新审阅文件并更新配置及对应状态目录。

`reverse.artifacts` 列出已登记 ID。`reverse.analyze` 接收 `{"artifact":"app-bundle","analysis":"javascript_routes"}`，只把这个不可变本地文件交给固定的 `analysis_ast_match` 工具。它返回函数声明、调用表达式和字符串的位置，并关联具名函数里的调用。函数位置使用 UTF-16 code units；箭头函数、方法和动态间接调用不声称已完整恢复。最多读取 256 KiB 文件，单条 MCP 响应和累计每次请求读取均有 1 MiB 上限及期限。

提供程序固定为 0.4.2，实际入口与依赖以随包锁文件为准。进程使用私有工作目录和窄环境，不继承模型 API 密钥。返回的代码片段可能包含登记文件中的字面量；它们是待分析资料，不能成为工具权限或新指令。外部 provider 的其他工具（包括 WASM 工具）不在该固定 AST 接口中开放。

## ELF、PE、Mach-O 的引用与调用者

在 Linux x86_64、Python 3.12+ 上，可将官方固定发行包安装到新私有目录：

```sh
python3 tools/install_reverse_native.py --destination /absolute/native-deps
```

该命令下载、核对 SHA-256 并解包 radare2 6.2.4 与官方 r2mcp 1.9.0，不进行全局安装或执行软件包安装脚本。主宿主 `binary.routes` 使用固定 radare2 查询；安装器同时提供独立 r2mcp 可执行文件，它的工具不会自动转发到 Toolbox MCP。

在 `binaries` 登记应用路径，在 `reverse_native.radare2` 填 `/absolute/native-deps/usr/bin/radare2`。建议在 `reverse_native.digests` 为同一 ID 固定 SHA-256。调用 `binary.routes`，例如 `{"binary":"app"}`，得到：

- 路由/URL 字符串候选及其文件位置、虚拟地址。
- 实际引用指令的地址、机器码和所属函数。
- 引用函数的一层调用者及 CALL 指令证据。
- 截断、预算、解析版本、二进制摘要和明确的未经动态验证标记。

文件先复制成私有只读二进制快照，核对复制前后身份；后端不会运行样本、加载项目脚本或执行从二进制提取的文本。最长默认分析 20 秒，最大输入 32 MiB，输出和图规模均受限。去符号、位置无关代码或后端无法识别的指令可能降低恢复范围，需查看返回的 coverage。

`string_only` 表示仅发现字面量；静态引用表示存在相应机器指令；两者均不证明接口可用、请求方法正确或当前用户拥有业务权限。官方 r2mcp 的 `pdc` 属于伪反编译，不能称作已经恢复出原始 C 源码。发现函数地址不会授予任意函数调用或私有 API 执行权限。

## 与已有控制链的关系

模型可以利用这些证据选择已观察的网页历史/链接或原生无障碍动作，再通过重新读取状态验证结果；请求拒绝仍走明确 origin/path 规则。任意闭源软件的私有内部路由、任意 GPU 纹理文字和全部渲染 API 的通用恢复仍需具体目标适配。这里没有默认开启全盘扫描、系统流量代理或任意命令转发。

## 配置与验证

静态二进制后端的文件预算、结果字段和错误码见 [native/REVERSE.md](native/REVERSE.md)；JS provider 安装和配置见 [tools/reverse_mcp/README.md](tools/reverse_mcp/README.md)。

```sh
RUNTIME_RADARE2=/absolute/radare2 python3 -m unittest discover -s tests -p test_reverse_backends.py -v
```

按需要同时设置 `RUNTIME_JSHOOK_ENTRY` 和 `RUNTIME_CROSS_BINARIES`，后者是自己编译的 PE/Mach-O fixture 清单。未提供条件的用例会明确跳过；运行格式测试不会执行被分析的样本。
