# 跨系统原生控件与调试接口

当前提供四套按人工登记 profile 选择的 Appium 原生控件接口：Windows WinCore / 旧 Windows、macOS Mac2、Android UiAutomator2、iOS XCUITest。它们由本包现有 **Linux/POSIX MCP 宿主**协调，可连到 HTTPS Appium 服务或显式回环 HTTP；插件没有绕过目标平台辅助功能、代码签名或设备权限。`appium.*` 的协议测试不等于 Windows/macOS/Android/iOS 实机验收。

## iOS 登记示例

在 `appium_targets` 中登记 iOS 项，需在可信的独立 Mac/Appium 服务端预先安装 XCUITest 驱动，并准备可调试的指定设备或模拟器。示例不使用 `appium:app` 触发安装和重置：

```json
{
  "ios-app": {
    "platform": "ios",
    "endpoint": "https://ios-operator.example.invalid:4723",
    "capabilities": {
      "platformName": "iOS",
      "appium:automationName": "XCUITest",
      "appium:udid": "EXACT-DEVICE-UDID",
      "appium:bundleId": "org.example.ownedapp",
      "appium:noReset": true,
      "appium:newCommandTimeout": 30
    },
    "allow_actions": true,
    "allow_text_input": false,
    "include_editable_text": false,
    "routes": {"home": "myownedapp://home"}
  }
}
```

`appium.open` 只接受固定 profile；拒绝自动设备选择 `udid=auto`、`browserName=Safari`、`appium:app`（安装）、`appium:fullReset`、`appium:autoAcceptAlerts` 与 `appium:autoDismissAlerts`，并拒绝非同一 Bundle 的 `appium:defaultActiveApplication`。单次工具成功 ACK 不代表实际应用状态已改变。

iOS 每次 `appium.snapshot` 或 `appium.invoke/set_text` 派发前，先请求 `GET /session/:id/context`，确认 `NATIVE_APP`；随后请求 `POST /session/:id/execute/sync`，执行官方 `mobile: activeAppInfo` 并检查 `bundleId` 与登记项一致。未知/不支持身份返回直接拒绝，禁止静默回退到猜测身份。密码字段、后代节点、输入值仍受脱敏策略约束；`XCUIElementTypeSearchField` 可作为编辑控件识别。每份快照有 15 秒有效期和单次动作句柄。

iOS `appium.route` 只执行 `mobile: deepLink`，并在参数中显式指定已登记 `bundleId`，避免系统默认处理器改变目标；受 iOS/Xcode/驱动版本制约，失败或超时视为 Unknown 并保留目标隔离。Android 则继续使用 `mobile: deepLink` 的 `package` 参数。Windows/macOS 维持控件导航，不对未实现深链能力作兼容声称。

`include_editable_text=false` 对输入值与其子树继续脱敏，`allow_text_input=true` 独立授予修改普通编辑控件的权限；敏感/密码输入始终拒绝。没有读取许可时不能借输入操作读出旧值；如需业务结果证明，应使用独立、获授权的状态观察。

## 目标身份与平台边界

- Apple XCUITest 的 `mobile: activeAppInfo` 与 `NATIVE_APP` 是**顺序检查**，紧邻调用之间仍可能切换界面；不提供强事务化应用焦点锁。对系统权限弹窗失焦采取拒绝策略。
- Windows WinCore 和 macOS Mac2 目前用固定驱动会话限定作用域，还不能独立证明操作时目标仍是指定窗口/Bundle。该限制保留，跨应用焦点劫持场景不能宣称完成隔离。
- Android 允许的辅助包仅限人工固定 `allowed_packages`，可能跨包 UI 动作；不要在包含系统设置或其他未授权 APP 的 profile 中扩大列表。
- MCP 宿主仍使用 POSIX `fcntl`/权限检查与 Linux 特有进程工具。不得将 Appium 的跨设备访问推断为 Windows/macOS 原生安装版已经可运行。
- HTTP 不允许连接非回环地址；跨机器要求 HTTPS、证书可信和独立授权。仅协议模拟得到的新能力需要真实设备验证。

官方接口参考：
- https://appium.github.io/appium-xcuitest-driver/latest/capabilities/
- https://appium.github.io/appium-xcuitest-driver/latest/reference/execute-methods/
- https://github.com/appium/appium/blob/master/packages/appium/docs/en/guides/context.md

## 原生控件后端

`cross-platform-config.example.json` 提供 Windows、macOS、Android 和 iOS 四个固定目标示例。MCP 宿主可以在当前 Linux 上协调远程 Windows/macOS 的 Appium 服务和指定 Android 设备；其他机器必须先准备实际驱动、系统权限和 APP。Python MCP 宿主自身仍采用 POSIX 文件锁/私有目录，并未声称已经原生移植到 Windows。

- Windows：配置支持 `appium:automationName=Wincore`，并保留固定旧部署使用的 `Windows`。固定 exe 或顶层窗口句柄，拒绝 `app=Root`。实际原生驱动在 Windows 上运行；已观察且唯一的 AutomationId 优先使用 accessibility id，其余使用快照派生的 XPath。
- macOS：`appium:automationName=Mac2`，固定 `appium:bundleId`，由真实 macOS/XCTest 辅助功能权限约束。不会自动绕过辅助功能授权。
- Android：`appium:automationName=UiAutomator2`，固定设备 `udid`、包名与 Activity；观察/动作前检查当前包及 `NATIVE_APP` 上下文，拒绝静默转入 WebView 或未授权 APP。系统权限对话框等另一个包，必须由人工显式加入 `allowed_packages`，不能由页面文字扩大许可。受保护/不可调试目标不被自动提权。

远程服务只允许 HTTPS，或显式 loopback HTTP。可通过配置中的固定 `Authorization` header 连接受保护服务；值不返回给模型或写进审计 payload。能力、设备、APP、路线和地址均由人工配置，模型不能自行修改。

工具链：`appium.open → appium.snapshot → appium.invoke / appium.set_text → appium.wait_for`。控件句柄来自有界原生 XML，XPath 由适配器生成，不接受模型提供的新选择器。快照单次使用、15 秒有效；派发前重新核对原生 source 摘要。密码及敏感输入不读取/编辑；普通输入读取/编辑需要独立配置许可。

`appium.route` 用于 Android 和 iOS：根据人工登记的 route ID 调用固定的 `mobile: deepLink`，Android 显式传入登记包名，iOS 显式传入登记 Bundle ID。不接受模型脚本或新 URI；Windows/macOS 通过已观察的原生控件导航。

新建和结束驱动会话、点击、输入、深链都写前登记 Pending。点击/清空后输入出现超时，可能已有部分效果，返回 Unknown 并隔离该目标，不自动重放。`appium.close` 明确结束会话，APP 是否退出取决于驱动，不假称已确认。清理采用独立作用域，允许结束已处于 Unknown 隔离的会话，但不会解除原操作隔离或允许新建会话绕过对账。宿主正常关闭不会偷偷发起远程退出；服务端应配置有限的 command timeout。

## 原生内存和 CPU 后端：LLDB

`tools/lldb_agent.py` 是独立原生代理，使用真实 LLDB Python SDK，不开放命令解释器、表达式求值、任意 attach 或模型命令。可以在安装了兼容 LLDB/Python 绑定的 Linux、Windows、macOS 上部署；Android 通过人工建立的 loopback LLDB/debugserver 转发接入授权的可调试进程。能否工作仍取决于实际平台 LLDB、代码签名/调试权限与设备条件。

代理仅导入通用 ABI 模块，不依赖 Linux procfs、pidfd 或 fcntl。协调宿主使用固定 `argv` 启动本地代理或人工配置的 SSH stdio 命令。代理配置摘要及目标可执行文件 SHA-256 都必须匹配，改变权限/目标需要重新审阅配置；模型不能提交新启动命令。

配置步骤：

1. 在实际目标平台安装官方 LLDB 与匹配 Python 绑定；填 `debugger-profile.example.json` 的固定 argv、二进制摘要和各项权限。
2. 如需写入，按目标模块的真实数据符号登记 `write_regions`；仅允许可写、不可执行的实际区域。默认关闭写入和单步。
3. 将规范配置 JSON 的 SHA-256 写入宿主 `debuggers.<id>.profile_sha256`。规范编码为键排序、`ensure_ascii=True`、紧凑分隔符、禁止 NaN，与本包 `canonical` 一致。
4. 宿主 `argv` 指向实际平台解释器、`tools/lldb_agent.py --config <固定配置>`。如需匹配 Python 绑定和动态库，可以在固定 `env` 中设置 `PYTHONPATH`、`LD_LIBRARY_PATH`、`LLDB_DEBUGSERVER_PATH` 或 macOS 对应路径；不继承模型 API 密钥。

MCP 工具：

- `debugger.open / debugger.status`：登记配置启动或连接，报告 LLDB/系统、目标 triple、指针宽度、字节序、PID 和 SDK 进程唯一 ID。
- `debugger.inspect`：实际线程、栈帧和通用寄存器，不按宿主架构猜布局。
- `debugger.read_memory / debugger.read_value`：有界原生内存与类型化值。
- `debugger.write_memory`：固定数据符号区域、旧摘要校验、写后验证与回滚。
- `debugger.step`：额外 `allow_step` 许可下，在已观察线程执行 1–8 条指令；不推断业务效果。
- `debugger.terminate`：只终止由该固定代理启动的进程，拒绝终止远程附加目标。
- `debugger.detach`：释放调试绑定；清理使用独立作用域，即使上次效果不明也可以结束调试。

读寄存器和 LLDB 内存读取可能临时停止目标，因此这些操作也需要 `request_id` 并写前登记。SDK 异步事件必须消费后才能确认“停止→读取/写入/单步→恢复”的状态交接。4 MiB 读取、每次 4096 字节写入、每会话 64 KiB 写入等预算继续有效。

可用自有 C fixture 检查 MCP→stdio 代理→目标程序→寄存器/类型化内存读取→数据符号写入→程序输出→单步→终止/释放的完整路径。Linux 的独立 pidfd 崩溃恢复看门狗属于 `process.*` 后端，不能冒充 Windows/macOS 调试器的同等故障保证。

## 检查与部署

协议、原生 XML 和身份约束测试：

```sh
python3 -m unittest discover -s tests -p test_appium_native.py -v
python3 -m unittest discover -s tests -p test_lldb_agent.py -v
```

Appium 的回环模拟验证请求和拒绝规则，实际设备仍需运行完整登录、文件选择、弹窗、权限和多应用流程。LLDB 测试是否能够执行取决于 SDK、平台及调试权限；缺少条件时保留跳过或阻碍状态。

接入具体程序时，以该平台原生输出/控件、进程身份、工具收据和实际后置状态共同验收。完整操作系统权限代理、任意自绘控件、任意私有对象和全平台资源配额不由这些接口自动提供。
