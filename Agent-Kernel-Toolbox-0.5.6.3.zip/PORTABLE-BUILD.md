# 安装时平台检测与统一 IR 对象编译

此路径处理已下载、由安装者登记并固定摘要的 `word-ssa-1` JSON。沿用现有
8/16/32/64 位无符号整数语义，将同一模块降级为生成的 C，再交给固定的
GCC、Clang 或 Zig/Clang 生成可重定位对象。它不运行下载的程序、不解析
任意 C/汇编、不接受模型提供的编译参数，也不翻译系统调用或 UI 框架。

## 使用

先观察本机 OS、当前进程的 CPU 架构/位宽/字节序和 libc。此命令不调用编译器：

```sh
python3 tools/runtime-platform.py detect
```

从 `portable-build-config.example.json` 建立私有配置，将 `compiler`、
`module_path` 改为实际绝对路径，并填入两个文件的真实 SHA-256。
`compiler_driver=auto` 使用独立 GCC/Clang；`zig-cc` 只允许固定的
`[registered_zig, "cc", ...]` 驱动，不提供任意 argv 前缀。
示例全零摘要不是可用 pin。示例默认关闭编译。

```sh
python3 tools/runtime-platform.py plan --config /absolute/build.json --state-directory /absolute/private/build-cache --profile local
```

`plan` 核验来源摘要和 IR 结构，选择登记的目标，不创建编译缓存、不运行
编译器、不执行来源。`host` 只在 OS、架构、位宽、字节序和 libc 能明确
匹配时选择目标；未知组合不会回退成另一种 OS/ISA。ARM32 浮点 ABI 无法
仅凭机器名确定时，需要安装者显式登记目标。

安装者确认配置后，将所需 profile 的 `allow_compile` 设为 `true`。
CLI 编译复用 `RuntimeHost` 的持久日志、请求去重和 Unknown 隔离，每次调用必须显式提供 `--request-id`。配置需由当前用户拥有，为
非符号链接的普通文件，且不可由组或其他用户写入；建议权限 `0600`。

```sh
python3 tools/runtime-platform.py compile --config /absolute/build.json --state-directory /absolute/private/build-state --profile local --request-id build-local-001
```

`detect`、`inspect`、`plan` 的原有参数保持可用，并且不启动编译器、不绑定
宿主状态。`compile` 的状态目录必须是绝对路径和私有目录，生成对象缓存
位于它的 `portable_build` 子目录；旧的直接编译缓存不会自动迁移到该位置。

输入文件每次都会重新核验，包括缓存命中。编译器使用有界流式 SHA-256
核验；生成源码仅来自经过验证的 IR，禁止原始源码/链接选项。Zig 缓存
限制在本次私有工作目录，使用显式目标与基线 CPU（ARMv7 使用显式 v7a），
不启用宿主 `native` CPU 优化。生成对象关闭调试信息。

MCP 宿主配置可把同一对象放在 `portable_build` 下，通过 `build.inspect`、
`build.plan`、`build.compile` 使用；模型只选择 profile ID。编译权限还
受宿主工具 allowlist 和独立请求日志控制。编译后错误携带实际编译子进程
是否已派发；版本查询同样运行登记编译器，只要其子进程已启动，随后失败
也保留 Unknown。源摘要、目标与编译器身份相同的 profile 别名共用围栏。

### CLI 的审计与恢复

CLI 以固定的最小 Host 配置包装 build 配置：`schema_version=1`、给定
`state_directory`、`allowed_tools=["build.compile"]` 和 `portable_build`。
该配置摘要在第一次编译时绑定状态目录。相同配置的新 CLI 进程复用原日志；
等价 profile 别名不能绕过同一来源/目标/编译器的未决结果，旧请求 ID 在
完成后也不可重放。不同工具 allowlist 的完整 MCP 配置不能混用这个目录。

CLI 保留 Host 的 JSON 结果和 `unknown_effect` / `effect_unknown`，编译
适配器明确知道是否已启动子进程时还返回 `effect_dispatched`。缺少这个
字段不证明未派发。仅 `ok=true` 且没有 Unknown 标志时退出码为 0；错误或
Unknown 返回 2。关闭 Host 不会清除未决状态，也不会自动重复编译。

查看当前日志使用同一运行入口：

```sh
python3 runtime-access.pyz audit --state-directory /absolute/private/build-state
```

遇到 Unknown，先核对实际编译进程、输出与收据。停止相关宿主后，由操作员
根据观察选择离线处置；下面只是确认效果已观察到的示例：

```sh
python3 runtime-access.pyz reconcile --state-directory /absolute/private/build-state --request-id build-local-001 --disposition effect_observed
```

也可使用 `no_effect_observed` 或 `abandoned`。对账只记录处置，不执行或
撤销编译；旧请求 ID 继续拒绝。确需继续时使用新的 ID。配置发生变化会
拒绝复用原目录；先解决旧的未决结果，再为独立任务建立新配置/状态，不能
通过更换目录或配置绕过同一目标的 Unknown。

验证 CLI 的真实失败、跨进程重放、别名隔离和人工对账：

```sh
python3 -m unittest discover -s tests -p test_build_cli.py -v
```

## 目标范围

| 系统对象格式 | 登记目标 |
|---|---|
| Linux ELF | x86_64、i686、AArch64、ARMv7 hard-float、RISC-V64、MIPS32 big-endian、PowerPC64 big-endian |
| Linux ELF / musl 环境 | x86_64、AArch64 |
| macOS Mach-O | x86_64、AArch64（Apple Silicon） |
| Windows COFF 对象 | x86_64、AArch64，MSVC 环境 |

包内 [examples/portable-objects/](examples/portable-objects/README.md) 提供当前示例 IR 的 13 份对象与 `MANIFEST.json`，可逐个核对摘要、格式与 ABI。`tests/test_portable_build.py` 提供重新编译及本机固定 launcher 检查；示例对象的存在不代表目标系统已执行验证。完整运行控制宿主的移植需要平台适配。

```sh
RUNTIME_ZIG=/absolute/zig python3 -m unittest discover -s tests -p test_portable_build.py -v
```

这是对象文件验收。其它系统/ISA 的对象未在相应设备运行，仍需要目标
SDK、链接器、运行时库、应用 ABI 和真机验证。对象头中的 ARM 浮点 ABI、
RISC-V 浮点 ABI、PowerPC64 ELF ABI 变体会如实返回；它们不能由“64 位”
或“RISC”代替。检查范围明确为对象格式、架构、指针宽度与字节序；跨
工具链调用约定与最终链接仍需要安装者验证。

macOS 的两个 `.o` 不是 Universal App，不能取代 Xcode/SDK 的链接、
签名、权限和双架构运行检查。Windows COFF 也不是可直接启动的 PE 程序。
Linux native 可执行运行与解释器 oracle 可用于本机结果对照；Linux
procfs/pidfd/ptrace 控制器仍依赖对应内核接口。

## 官方依据

- [Clang target triple 与交叉编译](https://clang.llvm.org/docs/CrossCompilation.html)
- [LLVM 模块、目标和数据布局](https://llvm.org/docs/LangRef.html)
- [Apple Universal macOS 构建](https://developer.apple.com/documentation/apple-silicon/building-a-universal-macos-binary)
- [Microsoft PE/COFF 格式](https://learn.microsoft.com/en-us/windows/win32/debug/pe-format)
- [Zig C 编译与交叉编译](https://ziglang.org/learn/overview/)

工具链二进制摘要不等于它的整个安装目录、系统头文件和链接 SDK 都已
被认证。这里的无头文件、无链接对象路径减少这些依赖；完整应用构建
应由安装者另外固定工具链与 SDK 的来源和版本。
