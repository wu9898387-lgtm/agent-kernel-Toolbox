# Toolbox 运行与授权

Agent-Kernel-Toolbox 通过固定配置手动启用，浏览器后端支持 Chromium / Firefox / WebKit。它从真实网页 DOM、原生 AT-SPI、选定进程内存和 CPU 状态读取信息，并提供请求拦截、界面元素隐藏、原生动作与 OpenGL 绘制过滤。它提供本地 MCP stdio 入口供模型调用；用户配置决定允许的工具、站点、进程和启动命令。

## 安装与启用

解压 `Agent-Kernel-Toolbox-0.5.6.2.zip`。基础宿主需要 Python 3.10+ 和 POSIX 环境；浏览器路径另需 Node.js 24+、Playwright 及所选浏览器。Linux 原生路径需要 procfs/pidfd，原生控件需要桌面会话的 AT-SPI 服务；二进制检查使用 binutils；OpenGL 层由本机 C++ 编译器构建。逆向分析的依赖和接口见 [REVERSE.md](REVERSE.md)，平台范围见 [COMPATIBILITY.md](COMPATIBILITY.md)。

```sh
cd browser
npm ci --ignore-scripts --omit=dev
npx playwright install chromium
cd ..
python3 native/build.py
cp runtime-config.example.json runtime-config.json
chmod 600 runtime-config.json
```

编辑配置中的绝对私有状态目录和 `allowedOrigins`。已有 Chromium 可在 `browser.executablePath` 填写其绝对路径。`browser.engine` 可选择 Chromium、Firefox 或 WebKit；安装器或浏览器启动失败时按实际错误排查。OpenGL 构建仅在需要绘制过滤时执行。

MCP 客户端配置示例（替换两个绝对路径）：

```json
{
  "mcpServers": {
    "Agent-Kernel-Toolbox": {
      "command": "python3",
      "args": ["/absolute/package/runtime-access.pyz", "serve", "--config", "/absolute/package/runtime-config.json"]
    }
  }
}
```

协议提供 2025-11-25 / 2025-06-18 的 tools 子集，详细连接和检查命令见 [MCP.md](MCP.md)。MCP 客户端负责连接模型；工具执行使用固定本地配置，页面文字不能扩大权限。工具包不自带大模型或 API 密钥。

## 直接安装浏览器扩展

在 Chromium 扩展管理页启用开发者模式，选择“加载已解压的扩展程序”，指向包内 `browser/extension`。打开目标 HTTP/HTTPS 标签页，再从扩展面板激活该标签页。

面板连接真实的文字读取、同源链接跳转、遮挡元素隐藏/恢复、请求规则保存与启用。网络拒绝规则安装后显式重新加载页面才覆盖该次加载。规则按标签页会话生效；保存的站点策略在需要时重新激活。浏览器重启后不能声称已经自动覆盖首次绘制。没有激活的标签页不受其规则影响。

## 网页运行时

`browser.snapshot` 直接读取页面和许可范围内子框架的 DOM 文字、帧列表和导航节点，不使用截图或 OCR。密码、私有标记、输入内容默认脱敏。链接快照包含短期节点句柄；页面变化、对象变化或快照过期时拒绝旧句柄。`browser.activate` 使用链接真实点击，能触发单页应用的内部路由处理；`browser.navigate` 用于明确 URL 跳转。

`browser.block_request` 接收 `{ "origin": "https://example.com", "pathPrefix": "/ads/" }`，可加 `resourceTypes`。规则是完整 origin 加路径前缀匹配，没有基于模糊关键词自动扩大封禁。它阻止匹配的未来请求；已经完成的请求不能撤销。需要移除现有遮挡时调用 `browser.hide`，保存返回的 `hideId` 后可调用 `browser.restore`。预置 `cosmeticRules` 在文档开始阶段安装隐藏规则。

`browser.metrics` 返回渲染器累计任务/脚本时长及 JavaScript 堆计数；它不等同于原生进程 CPU 计时。`browser.network` 返回经过 URL 查询参数清理的有界事件。`browser.close_target` 只关闭已观测且由当前运行时拥有的页面或专属 worker。连接已有浏览器时必须给出 loopback CDP endpoint 和精确 targetIds；关闭适配器会断开连接并保留借用页面。

## 原生进程、内存和 CPU

在 `profiles` 登记准确的绝对 argv，然后将相应工具名加入 `allowed_tools`。模型只能选择 profile 名，不能提交任意 shell 命令：

```json
{
  "my-app": {
    "argv": ["/absolute/application", "--argument"],
    "allow_memory": true,
    "allow_debug": true,
    "include_editable_text": false,
    "render_library": "/absolute/package/native/libagent_kernel_render.so"
  }
}
```

不需要 OpenGL 过滤时删除 `render_library`。`process.launch` 返回 session_id，后续 `process.inspect` / `process.maps` 读取统计与映射；`process.read_memory` 读取明确十六进制地址及长度，MCP 单次最多 32768 字节，适配器累计内存读取最多 4 MiB。数据返回 base64 与 SHA-256，不自动扫描整进程或推断结构。

`process.cpu_snapshot` 对有调试许可的自有子进程短暂调试停止，读取寄存器及有界帧指针栈，再释放跟踪。帧指针栈不是完整 DWARF 展开；内核拒绝 ptrace 时会明确失败，不改变系统调试权限。

已在运行的应用通过人类配置的 `targets` 接入。先在同一 PID 命名空间运行：

```sh
python3 runtime-access.pyz identify --pid 12345
```

将返回对象放入 `targets` 下的具名条目，再按需要设置内存权限。进程实例绑定启动时间、boot ID、UID、PID 命名空间与 pidfd；内存等操作另校验执行文件。exec 后的状态、限额与终止仍绑定原实例，详见 `LIFECYCLE.md`。结束已附加进程还需要独立 `allow_terminate`，不会仅凭进程名称包含 GPU 就结束它。共享浏览器 GPU 进程可能服务多个页面，不能按单一广告对象等同处理。

`binary.inspect` 对 `binaries` 登记的 ELF 文件读取头、动态符号、指定函数反汇编和经过清理的 URL 字符串候选。字符串候选不证明应用实际调用了该 API；运行时网页请求事件提供另一项独立证据。缺少符号、代码混淆或应用自绘文字都可能需要对应软件的专项解析。

## 原生无障碍

先取得 process session_id，再调用 `native.open`、`native.snapshot`。AT-SPI 返回真实应用控件角色、名称、文字、关系、支持的动作及可用链接。`native.invoke` 使用同一快照里的节点与动作下标，重新检查进程、节点状态和短期有效性，且句柄单次使用。

密码和敏感子树始终脱敏。编辑器/输入区文本可通过该 profile/target 的 `include_editable_text: true` 由宿主单独启用；网页有独立的 `browser.includeEditableText` 许可。原生适配器在最大 256 MiB 地址空间的隔离工作进程中运行，并使用调用及操作期限。动作 ACK 不代表业务结果已完成；重新读取界面确认实际后置状态。桌面没有启用 AT-SPI、会话总线不可用或软件没有导出控件时会明确报错。

## OpenGL 绘制拦截

通过已配置的 profile 启动应用时，加载器只为该启动设置 `LD_PRELOAD`。拦截层覆盖实现中列明的核心 draw/clear/blit 调用及常见 EGL/GLX 查询路径，记录有界绘制事件。`render.events` 返回程序号、绘制序号、上下文及阻断标志；`render.block` 追加明确的程序号或绘制序号，控制文件原子替换后绘制路径重新加载规则。

程序号属于具体 OpenGL 上下文，同一个数字在多个上下文里可能代表不同对象；本版程序过滤会匹配该进程各上下文的同号程序。绘制序号按进程调用顺序计数。规则不自动判断哪个着色器是广告，也不保证跨帧稳定语义。恢复/退出宿主时解除该会话过滤；不要将数字程序号无条件复用于下一次进程启动。

Vulkan、Direct3D、Metal、受保护进程与未覆盖扩展别名不属于此拦截器。物理 GPU、专有驱动和具体应用须分别验证。

## 白名单、持久拒绝与恢复

`allowed_tools`、origins、targets、profiles 是用户控制的固定授权。模型可增加网络拒绝、绘制拒绝、工具拒绝，不能扩大安装配置。SQLite 在私有目录保存拒绝规则和副作用意图，不保存原始内存、页面文字、请求 payload 或错误堆栈。

每个有副作用的调用需要独立 `request_id`。派发前同步写入 Pending；结果不明或进程中断会保留隔离，重启后禁止同一 scope 继续产生效果，也拒绝 request_id 重放。一个状态目录只允许一个活动宿主，避免内存规则落后于持久拒绝。

先停止宿主并核对真实应用状态，再由人类 CLI 对账：

```sh
python3 runtime-access.pyz audit --state-directory /absolute/private/runtime-state
python3 runtime-access.pyz reconcile --state-directory /absolute/private/runtime-state --request-id example-1 --disposition effect_observed
```

对账只记录确认，不重复操作。状态目录绑定配置摘要；改变许可配置需要明确的新状态目录，旧目录保留供审计。日志恢复保留持久拒绝和未决结果；系统断电、磁盘故障以及外部效果与日志的跨进程原子提交不在其保证范围。

## 检查与故障定位

```sh
python3 tools/check_installation.py --mcp
python3 -m unittest discover -s tests -v
```

安装检查只验证目录、内置 Python 和 MCP 握手；组件测试与实机动作需要各自依赖和权限。程序、设备或浏览器接口不提供所需信息时，保留明确的缺失或 Unknown 状态。更多接入说明见 [NATIVE.md](NATIVE.md)、[browser/README.md](browser/README.md)、[CROSS_PLATFORM.md](CROSS_PLATFORM.md) 与 [PROGRAM-MONITORING.md](PROGRAM-MONITORING.md)。
