# Toolbox operations

## Connect

Use the selected installation's `runtime-access.pyz` with a private fixed configuration. Read the root `MCP.md` for wire details. Perform `initialize`, send `notifications/initialized`, then use `tools/list` and `tools/call`; close stdin and wait for cleanup.

JSON-RPC `id` identifies one response. Tool `request_id` identifies one durable modifying operation. Keep these roles separate. Use the advertised schema without adding arbitrary shell commands, code, flags, paths or targets.

## Choose a route

| Task | Configuration | Check after the action |
| --- | --- | --- |
| Status and diagnosis | Minimal runtime config | Product/version, allowed tools, configured resources |
| Process or native UI | Exact process identity or owned launch; separate read/write/debug/control grants | Same process instance, fresh value or application state |
| Browser | Fixed origins and owned browser or explicit Chromium target | Current document, field value, URL and business result |
| Remote app or debugger | Fixed device/application/debugger profile | Application context, device identity and actual platform outcome |
| Program, metadata or probes | Pinned readers and registered observations | Source identity, freshness, loss and budget indicators |
| Coordinated state | Registered writers and fixed patch templates | Expected epoch/value, bounded readback and rollback result |
| HTTP | Fixed request profile and origin budgets | Actual response/server state; unresolved writes are not replayed |
| Word-IR build | Fixed input/compiler digests and target | Artifact identity, object ABI and cache; target execution is separate |
| Optional analysis or machine backend | Matching configured engine and budget | Actual engine result with its declared unsupported or unknown cases |

Configuration examples are listed in the installation's README. Do not grant execution authority to an address, route, process or file merely because it appeared in an observation.

## Recover an uncertain operation

Keep the affected target's state directory. Host request records prevent repetition and fence unresolved effects; process UI and write calls share the stable process-instance scope. Read-only observation and permitted independent cleanup can establish the current state.

After the operator confirms the disposition, stop the active Host and run:

```sh
python /absolute/package/runtime-access.pyz audit --state-directory /absolute/private/toolbox-state
python /absolute/package/runtime-access.pyz reconcile --state-directory /absolute/private/toolbox-state --request-id operation-001 --disposition effect_observed
```

Allowed dispositions are `effect_observed`, `no_effect_observed` and `abandoned`. Reconciliation records that conclusion; it does not retry or undo an effect, and the request ID stays consumed. A configuration change requires its own properly managed state after pending operations have been resolved.

## Diagnose availability

Run `tools/check_installation.py --mcp` for file/metadata checks and a temporary read-only connection. Use the skill's `scripts/inspect_mcp.py` to inspect an explicit entry/configuration, select a supported protocol or save a bounded diagnostic report.

Choose the wider facility that matches the failure. Use `tools/check_runtime_mcp.py` for the runtime protocol, route and owned-process checks, `tools/check_official_mcp.py` for the official SDK client, and `tools/check_browser_mcp.py` for the configured browser integration. Read `LIVE_CHECKS.md`, `ADVANCED_CHECKS.md`, `COMPATIBILITY.md` or `NATIVE_WORKER.md` for desktop, ABI or performance checks. These scripts are executable facilities; their outputs describe the current run and should be kept outside the distributed toolbox.

Use the native SDK demonstration in `native/runtime-agent/README.md` for first integration. Preserve `runtime-agent-demo`, `runtime-control`, `compiler-object-layout.json` and their compatible build invocation. The SDK also provides `runtime-agent.o`, `agent.h` and `build.json`. Check current environment identity and postconditions before using the demo's five callback slots. For fixed word-IR objects, use `PORTABLE-BUILD.md` and the 13 examples under `examples/portable-objects/`; an object file still needs target linking and execution.

Run tests against the selected installation's pyz. When source edits are authorized, read `PACKAGING.md`, extract the complete Python sources with `tools/extract_sources.py`, rebuild, and test the new unpacked toolbox. Keep tests, fixtures, examples, diagnostic tools and current guides in the package while excluding historical reports and generated caches.

A listed tool or successful handshake does not establish target access. Missing SDKs, denied ptrace/perf, unavailable AT-SPI, absent headers, a browser startup failure and disconnected devices are concrete blockers. Report the relevant one, without changing permissions or claiming a different execution route proved this backend.

For a successful operation, return the useful result and independent postcondition. For an incomplete operation, retain the exact error/Unknown state and describe the next dependency or observation needed.
