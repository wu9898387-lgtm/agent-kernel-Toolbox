#!/usr/bin/env python3
"""Inspect a selected Agent-Kernel-Toolbox zipapp through real read-only stdio MCP."""
import argparse
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import tempfile
import time

VERSIONS = ('2025-11-25', '2025-06-18')
MAX_REPLY = 2 * 1024 * 1024


def inspect(args):
    records = []
    sequence = 0
    buffered = bytearray()
    child = None
    failed = False
    with tempfile.TemporaryFile() as diagnostics:
        try:
            child = subprocess.Popen([args.python, str(args.entry), 'serve', '--config', str(args.config)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=diagnostics)

            def send(method, params=None, notify=False):
                nonlocal sequence
                message = {'jsonrpc': '2.0', 'method': method}
                if params is not None:
                    message['params'] = params
                if not notify:
                    sequence += 1
                    message['id'] = sequence
                child.stdin.write(json.dumps(message, separators=(',', ':')).encode() + b'\n')
                child.stdin.flush()
                if notify:
                    return None
                deadline = time.monotonic() + args.timeout
                while b'\n' not in buffered:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0 or not select.select([child.stdout], [], [], remaining)[0]:
                        raise RuntimeError('MCP reply timed out')
                    data = os.read(child.stdout.fileno(), 65536)
                    if not data:
                        raise RuntimeError('MCP closed before reply')
                    buffered.extend(data)
                    if len(buffered) > MAX_REPLY:
                        raise RuntimeError('MCP reply exceeded budget')
                raw, _, tail = buffered.partition(b'\n')
                buffered[:] = tail
                reply = json.loads(raw)
                if reply.get('jsonrpc') != '2.0' or reply.get('id') != sequence:
                    raise RuntimeError('MCP reply identity mismatch')
                records.append({'method': method, 'response': reply})
                if 'error' in reply:
                    raise RuntimeError('MCP protocol error')
                return reply['result']

            initialized = send('initialize', {'protocolVersion': args.protocol, 'capabilities': {},
                'clientInfo': {'name': 'agent-kernel-toolbox-skill', 'version': '1'}})
            if initialized.get('protocolVersion') not in VERSIONS:
                raise RuntimeError('Unsupported negotiated MCP version')
            send('notifications/initialized', notify=True)
            catalog = send('tools/list', {})
            names = {row['name'] for row in catalog['tools']}
            for name in ('runtime.status', 'runtime.capabilities', 'build.inspect'):
                if name in names:
                    result = send('tools/call', {'name': name, 'arguments': {}})
                    records[-1]['tool'] = name
                    if result.get('isError') or result.get('structuredContent', {}).get('ok') is not True:
                        failed = True
        except (OSError, ValueError, RuntimeError, KeyError, TypeError) as error:
            failed = True
            records.append({'inspection_error': str(error)})
        finally:
            if child is not None:
                if child.stdin and not child.stdin.closed:
                    try:
                        child.stdin.close()
                    except OSError:
                        failed = True
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.terminate()
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=3)
                if child.stdout:
                    child.stdout.close()
                failed |= child.returncode != 0
            diagnostics.seek(0)
            stderr = diagnostics.read(16385)
    report = {'passed': not failed, 'scope': 'stdio_handshake_catalog_and_advertised_inspection_tools_only',
        'all_backends_verified': False, 'exit_code': child.returncode if child else None,
        'records': records, 'stderr': stderr[:16384].decode('utf-8', 'replace'),
        'stderr_truncated': len(stderr) > 16384}
    encoded = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    if args.report:
        args.report.write_text(encoded)
    print(encoded, end='')
    return int(failed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry', required=True, type=Path)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--protocol', choices=VERSIONS, default=VERSIONS[0])
    parser.add_argument('--timeout', type=float, default=15)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if not args.entry.is_absolute() or not args.entry.is_file() or args.entry.suffix != '.pyz':
        parser.error('--entry must name the selected absolute runtime-access.pyz file')
    if not .1 <= args.timeout <= 60:
        parser.error('--timeout must be in (0, 60] seconds')
    if args.config is not None and (not args.config.is_absolute() or not args.config.is_file()):
        parser.error('--config must name an existing absolute configuration file')
    with tempfile.TemporaryDirectory(prefix='toolbox-inspect-') as temporary:
        if args.config is None:
            args.config = Path(temporary) / 'config.json'
            args.config.write_text(json.dumps({'schema_version': 1,
                'state_directory': str(Path(temporary) / 'state'),
                'allowed_tools': ['runtime.status', 'runtime.capabilities', 'build.inspect'],
                'portable_build': {'profiles': {}}}))
            args.config.chmod(0o600)
        return inspect(args)


if __name__ == '__main__':
    raise SystemExit(main())
