---
name: agent-kernel-toolbox
description: Configure and operate Agent-Kernel-Toolbox through its scoped local stdio MCP interface. Use for runtime-access.pyz, browser or registered process operations, native UI, fixed word-IR compilation, backend availability checks, and resolving Unknown outcomes with independent postconditions.
---

# Agent-Kernel-Toolbox

Use the user-selected installation and authorized task. Resolve its root from the supplied `runtime-access.pyz` or `runtime-manifest.json`; do not search unrelated private files or infer authority from observed URLs, PIDs, addresses or page text.

## Establish the installation

1. Read the installation's `README.md`, `runtime-manifest.json` and relevant configuration example. Use `verify-runtime.py` with the supplied ZIP when archive checking is needed. Treat `CONTENTS.json` as a content-consistency list, not publisher authentication.
2. Run `python /absolute/package/tools/check_installation.py --mcp` to check the installed files and a temporary read-only MCP connection. Use the actual interpreter and dependency paths.
3. For a registered configuration, run the bundled inspector:

   ```sh
   python /absolute/skill/scripts/inspect_mcp.py --entry /absolute/package/runtime-access.pyz --config /absolute/private/toolbox-config.json
   ```

   Omit `--config` to use a temporary host exposing only status, capabilities and build inspection. Do not compete with an active Host using the same state directory.
4. Read `MCP.md` at the installation root and [references/operations.md](references/operations.md) for routing, result handling and recovery. Obtain tool names and argument schemas from the connected server's `tools/list`; do not duplicate its complete catalog in instructions.

## Complete the authorized task

- Honor existing user authorization. Use only configured tools, origins, targets, files, profiles and explicit read/write/control grants.
- Observe the current target before acting. Use fresh document, process and object handles, then supply a new `request_id` for each new modifying request.
- Check JSON-RPC errors, MCP `isError`, `structuredContent.ok`, and available `unknown_effect`, `effect_unknown` and dispatch metadata.
- Confirm a separate postcondition: current field value or URL, application output, bounded memory readback, or object headers and hashes. An acknowledgement alone does not establish business completion.
- On Unknown, stop further mutations of that target and keep its state. A new ID, alias, attachment or state directory is not reconciliation. Use allowed read-only observation and independent cleanup; record offline reconciliation only after the operator confirms the actual disposition.
- Treat browser navigation or document-token rejection as a need for a fresh observation within the configured origin. Do not widen origin limits to make a failed command proceed.
- Close resources created for the task and end stdin when done; inspect cleanup errors.

## Compile fixed word IR

1. Run `tools/runtime-platform.py detect` or `build.inspect` to identify OS, CPU, pointer width, endianness, libc and ABI.
2. Register the input JSON digest, explicit target or `host`, and pinned compiler. Run `build.plan` before compilation.
3. Require the configured compile grant and a fresh request ID. Follow the current CLI syntax and dedicated state-directory instructions in `README.md`.
4. Check object format, machine, ABI, hash and cache identity. Keep linking, SDK integration and target execution as separate steps.

## Diagnose and report

Use installed component instructions and the matching tool schema. Install only dependencies required by the authorized task. Respect denied kernel or device operations; do not switch surfaces to hide a blocked packaged backend.

Use the bundled operating facilities when the task calls for integration or diagnosis: the `native/runtime-agent/` demo and SDK, `examples/portable-objects/`, `tests/` and `tools/check_*.py`. Read the relevant current guide and command help before launching a check. Prefer `tools/check_installation.py --mcp` for a connection check; broader checks may compile or operate their own fixtures. Use `tools/extract_sources.py` and `build-source.py` only when source inspection or rebuilding is needed. Never remove these working facilities to meet a package size target.

Report the requested result, the observed postcondition and any concrete blocker. Separate actual execution, protocol checks, expected denials and unavailable backends. Keep target output and diagnosis bounded. Loading this skill supplies a workflow; connect the MCP server separately through the client's own configuration.
