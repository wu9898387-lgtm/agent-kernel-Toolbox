# 字段标签、控件状态与表单验证

原生 AT-SPI 与浏览器 DOM 分别提供字段观察和输入接口。此指南列出当前参数、读回约束和可运行检查；应用导出的接口决定实际支持范围。

## 原生字段信息

- 返回 checked、expanded、focusable、focused、modal、selected、indeterminate 等 AT-SPI 状态。
- 对没有名称的编辑字段，读取 `LABELLED_BY` 关系；GTK 组合框内的编辑器可继承最多三层内的标准父控件标签关系。返回 `labels` 与 `label_source`，文字 query 可以匹配这些实际标签。
- 标签来源必须在同一个 APP 进程，且经过密码/敏感祖先、可见性和读取权限检查；不根据相邻位置猜测标签。处理最多 32 个关系、每个最多 8 个目标、最多 4 个标签，每个最多 512 UTF-8 字节；祖先检查最多 32 层。
- `can_set_text` 区分“状态可编辑”与“提供实际文本写接口”。缺少接口是已知未派发拒绝；已派发但读回未确认保持 Unknown。
- 超链接元数据缺失时返回 `links_unavailable`，超过 16 个 anchor 时返回有界结果和 `links_truncated`，不因此抛弃整棵控件树；核心身份、隐私、角色和状态错误仍拒绝。

AT-SPI 枚举和内存所有权依据 [GNOME constants](https://github.com/GNOME/at-spi2-core/blob/main/atspi/atspi-constants.h)、[accessible](https://github.com/GNOME/at-spi2-core/blob/main/atspi/atspi-accessible.c)、[relation](https://github.com/GNOME/at-spi2-core/blob/main/atspi/atspi-relation.c)。本包释放 GArray、relation 与 target 的拥有引用；原生 worker 的内存/时间限制仍有效。

## 浏览器表单接口

`browser.fields → browser.set_text → browser.controls → browser.invoke/activate → browser.query`。使用 `browser-forms-config.example.json`；写入需要独立 `allowTextInput:true`，字段观察需要 `includeEditableText:true`，默认均未打开。

`browser.fields` 按字面名称查询当前普通 input/textarea，返回实际字段句柄和值。`browser.set_text` 只接收这个新鲜句柄，核对来源、frame、元素身份和当前值，然后消费句柄并用 Playwright fill 触发正常输入事件，读回值单独验证。它不自动提交表单、不接受模型脚本或新选择器。实际业务状态仍需重新查询。

密码、支付/一次性验证码 autocomplete、私有祖先、隐藏字段和超过 2048 UTF-8 字节的字段排除。写入也最多 2048 字节。字段观察每 frame 最多检查 256 项、最多 16 frames、最多返回 32 项。Firefox 可能把不识别的 autocomplete DOM 属性归一为空，过滤同时读取原始 HTML attribute，以免敏感字段因属性归一化而漏过过滤。

`browser.controls` 按名称和角色返回可操作的一次性句柄，最多扫描 5000 个候选、返回 64 项并受超时限制。它包括 Sphinx 等网站实际使用的 `input type=submit/button/reset`，返回动作目标而不附带整页正文。

字段过期、只读或权限拒绝采用可信的未派发回执，不错误隔离后续操作。派发后异常或读回不符仍为 Unknown。所有输入动作继续经过配置绑定、Pending/Unknown、请求 ID 和摘要收据。

## 复测

```sh
python3 tools/check_advanced_accessibility.py --xvfb /absolute/Xvfb --output /absolute/new-advanced-run
```

需要 Linux、AT-SPI、D-Bus、Chromium、Mousepad 和已安装的 Playwright；可用 `--chromium` / `--mousepad` 指定实际路径。运行器通过 zipapp 的 MCP stdio 创建隔离 X/D-Bus、临时 XDG 设置、新浏览器 profile 和新草稿。

若环境需要 HTTP(S) 代理，浏览器配置可显式加入 `"proxy":{"server":"http://operator-proxy:port"}`；不关闭 TLS 校验。运行器为其新建的测试 Chromium 配置 `--no-sandbox`；这个测试条件不写入正常 Host 配置。

检查器创建专用 Mousepad 草稿，按 `Search for:` / `Replace with:` 关联标签输入，观察 Replace all 状态，并在保存后独立读取文件核对替换结果。浏览器部分在 Python 文档站读取 Quick search、提交 sqlite3 搜索并观察结果页面。它同时检查 Chromium 原生字段缺少 EditableText 时的派发前拒绝；目标浏览器导出能力改变时，该情景需要按实际回执判断。

公开网站、菜单文字和平台控件实现可能变化。运行器逐项记录结果和 MCP 回执，不把 ACK、输入法事件或窗口启动当作业务完成。原生输入已派发但没有读回确认时保留 Unknown，不自动换成 DOM 后端重放。

本地字段与状态回归也可从根目录运行：

```sh
python3 tools/run_desktop_checks.py --xvfb /absolute/Xvfb
cd browser
RUNTIME_TEST_ENGINES=chromium,firefox,webkit npm run test:browser
```

真实桌面检查、浏览器引擎检查及 W3C 协议模拟分别报告，某一层通过不代表其他平台已验证。
