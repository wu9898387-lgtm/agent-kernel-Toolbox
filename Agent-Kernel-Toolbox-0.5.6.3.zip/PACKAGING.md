# 包体与可复现构建

Agent-Kernel-Toolbox 0.5.6.2 包含运行实现、原生 SDK 与示例、浏览器适配器、完整测试与夹具、检查和基准工具、配置、内置 skill 及当前功能指南。发布文件由 `build-runtime.py` 的固定 `EXTERNAL` 清单决定；`build-source.py` 保留相同命令入口。

## 从解压包重建

在 Toolbox 根目录中运行：

```sh
python3 build-source.py --output /absolute/new/Agent-Kernel-Toolbox-0.5.6.2.zip
python3 verify-runtime.py /absolute/new/Agent-Kernel-Toolbox-0.5.6.2.zip
```

输出 ZIP 必须尚不存在。`build-runtime.py --output ...` 使用同一实现。构建会重新生成 pyz 与 `CONTENTS.json`，不会执行内嵌运行代码、下载依赖或启动后端。

## Python 源码

`runtime-access.pyz` 包含全部 49 个 Python 源文件。常规运行、随包测试和检查工具直接加载 pyz，无需重复展开源码。需要单独编辑时：

```sh
python3 tools/extract_sources.py --output src
```

提取器先核对每个内嵌源文件与 `CONTENTS.json` 的摘要，然后写入尚不存在的目录。不会覆盖现有 `src/`。构建器在有 `src/` 时使用该源码树；没有时读取并核验现有 pyz。修改源码后应重新打包，并在新解压包中验证，避免对旧 pyz 执行测试。

源码、测试、示例和检查工具的能力保留；外层不再重复存储与 pyz 相同的 Python 实现。C、Rust、Go、Java 等需要本机构建的源码直接随包分发。

## 完整性与体积约束

- 外层 ZIP 与内层 pyz 使用 DEFLATE level 9，固定排序、文件权限和时间戳。同一 Python/zlib 环境内重复构建应逐字节一致；不同 zlib 实现不作压缩字节一致承诺。
- 当前文件与内嵌 Python 源码分别在 `CONTENTS.json` 中记录 SHA-256。`verify-runtime.py` 同时检查两层清单、入口、名称、版本和模块数；目录检查只读取清单中的文件。
- 构建上限为压缩包 **1.5 MiB**、外层声明展开量 **4 MiB**、**320 个成员**。超限会报错并停止，不会静默删掉功能文件。单个输入文件上限 **2 MiB**。
- ZIP 检查限制文件数、逐层展开总量与单文件大小，拒绝不合法路径、重复成员、加密成员和非普通文件；只接受 STORED/DEFLATED。
- 安装依赖、编译中间目录、运行状态、缓存、历史发行说明和过往测试日志不进入发行包。测试程序、测试夹具、示例对象的摘要/ABI，以及当前构建说明属于可用设施，保留在包中。
- 浏览器、编译器和大型可选分析引擎由运行环境提供，不在每次发布中复制；按配置固定实际二进制摘要。

包内摘要用于核对内容一致性，不认证发布者。需要独立摘要时使用 `verify-runtime.py --expected-sha256 ...`。

## 修改资源清单

添加功能资源时，显式更新 `build-runtime.py` 的 `EXTERNAL`，并检查相关相对路径。新增 Python 运行模块需同步 `runtime-manifest.json` 的 `python_members` 和相应检查。先构建，再对新解压包运行：

```sh
python3 tools/check_installation.py --mcp
python3 tools/check_package_contract.py
python3 -m unittest discover -s tests -p 'test_*distribution.py' -v
python3 -m unittest discover -s tests -p test_package.py -v
```

原生代理构建输出同时保留 `runtime-agent-demo`、`runtime-control`、`compiler-object-layout.json` 和 SDK 对象/头文件，见 [原生代理说明](native/runtime-agent/README.md)。高级配置兼容名 `v055-config.example.json` 与 `runtime-advanced-config.example.json` 内容一致。

产品发布版本为 `0.5.6.2`。MCP、扩展与当前清单使用此值；要求 SemVer 的 npm/Cargo 使用 `0.5.6+toolbox.2`，并保留精确产品版本 metadata。协议 magic 与 ABI 独立于产品名称和发布版本。
