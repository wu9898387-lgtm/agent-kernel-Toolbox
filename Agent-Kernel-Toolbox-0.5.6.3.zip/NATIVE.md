# 原生 APP、内存与 CPU 执行能力

这些功能作用于 Linux 原生进程和 AT-SPI 控件。应用需要导出可用的无障碍接口；进程读取、调试和控制需要相应操作系统权限。Windows UIA/WinCore、macOS Mac2、Android UiAutomator2、iOS XCUITest 和 LLDB 平台代理入口见 [CROSS_PLATFORM.md](CROSS_PLATFORM.md)。

原生字段标签、控件状态和写入确认见 [ADVANCED_CHECKS.md](ADVANCED_CHECKS.md)，桌面运行器见 [LIVE_CHECKS.md](LIVE_CHECKS.md)，socket 连接观察和编译型恢复看门狗见 [NATIVE_WORKER.md](NATIVE_WORKER.md)。

## 连接原生程序

从 `native-config.example.json` 开始。人工填入准确的绝对 `argv` 和私有状态目录，工具调用只选择 profile 名。`process.launch` 返回固定身份的会话；既有进程可按原 `identify → targets → process.attach` 流程接入读取与无障碍。强制暂停、亲和性及内存写入目前只允许本宿主启动且单独授权的 APP。

```json
{
  "profiles": {
    "my-app": {
      "argv": ["/absolute/my-app"],
      "allow_memory": true,
      "allow_debug": true,
      "allow_control": true,
      "allow_memory_write": false,
      "include_editable_text": true,
      "allow_text_input": true,
      "limits": {"cpu_seconds": 120,"address_space_bytes": 536870912,"open_files": 256}
    }
  }
}
```

配置中的各项授权彼此独立：能读取不等于能写，能读取寄存器不等于能暂停整个程序。`process.inspect` 列出实际权限、登记写入区域名和 CPU 控制范围；`runtime.capabilities` 列出宿主可用 CPU 集合。内存写入另需明确登记数据区，不能从搜索结果自行获得写权限。

## 原生控件、输入与业务状态

调用顺序可以是：

1. `process.launch` / `process.attach`。
2. `native.open → native.snapshot`，取得实际控件的名称、角色、状态、动作和短期句柄。
3. `native.focus` 或 `native.invoke`，传入当前 `snapshot_id/node_id` 与唯一 `request_id`。
4. 若需要输入，重新取快照，再用 `native.set_text` 设置已观察到的可编辑控件；必须有独立 `allow_text_input`。一次最多 2048 UTF-8 字节，拒绝 NUL。
5. 用 `native.wait_for` 等待可见文本出现，或重新 `native.snapshot` 核对控件状态；动作 ACK 不等于业务完成。

密码控件及其子树始终不读取或编辑。默认不读取普通输入/编辑器内容；需要人工开启 `include_editable_text` 才能观察其内容并使用相应句柄。文字内容不被解释成新权限或工具指令。

`native.wait_for` 使用字面量匹配，最长 10 秒，最多返回 16 个匹配控件；最后一轮保留新快照，旧句柄自然失效。已知在派发动作前被拒绝的请求会给出明确未派发收据；真实派发后超时或结果不明仍走持久 Unknown 隔离。

可用 `tests/fixtures/gtk_app.py` 配合 `tools/run_desktop_checks.py` 验证焦点、中文输入、APP 回显、页面按钮及密码字段拒绝。应用必须实际导出 AT-SPI 控件；未导出的自绘控件需要专项适配。

## 内存快照、差异和类型化读取

- `process.abi`：从固定目标的可执行文件识别位数、字节序、架构和 ABI 标志。
- `process.read_memory / process.read_value`：显式范围原始字节或整数、指针、浮点与 UTF-8/16/32。
- `process.search_memory`：限定范围的字面量检索，支持不同文字编码。
- `process.resolve_address`：把寄存器/搜索地址连接到映射、文件偏移和已登记二进制身份。
- `process.capture_memory`：为一段明确范围生成只在内存中存活的 capture ID 和摘要。
- `process.diff_memory`：重新读取同一范围，返回变化字节数、有界变化区间和前后摘要。
- `process.release_capture`：释放不再需要的快照。

原始内存不写入审计数据库。capture 缓存最多 8 项、总共 256 KiB，宿主重启失效；不会绕过每会话 4 MiB 累计读取预算。普通快照/差异不是整进程原子快照，也不会自动还原 JVM/.NET/私有对象结构或跟随任意指针。

## 有边界的内存修改

需要同时开启 `allow_memory`、`allow_control`、`allow_memory_write`，并登记 `write_regions`。只允许唯一匹配、私有、可写且不可执行的映射，不能写代码页或共享映射。区域可以固定地址，也可绑定模块设备/inode 与文件偏移，以适配 ASLR：

```json
{
  "write_regions": {
    "app-state": {"module":"/absolute/my-app","file_offset":"0x3000","size":64}
  }
}
```

这里的地址/偏移和大小必须由人工依据目标程序确认，示例值不能直接复用。另一种区域格式为 `{"address":"0x明确地址","size":64}`。工具只接收区域名和区域内偏移：

```json
{
  "session_id":"已授权会话",
  "region":"app-state",
  "offset":0,
  "data_hex":"0900000000000000",
  "expected_sha256":"此前读取取得的64位小写摘要",
  "request_id":"change-app-state-1"
}
```

执行前暂停该 APP 的线程组，核对旧内容摘要；不匹配则拒绝写入。写后读回验证；部分写入会尝试恢复原内容并验证。无法确定结果时保留隔离，不自动重试。每次最多 4096 字节、每会话累计写入最多 64 KiB，且预留验证/回滚读取预算。只证明字节与恢复结果，业务语义仍要通过 APP 的输出或状态验证。

暂停前先启动独立的 pidfd 恢复看门狗：正常流程立即恢复，宿主死亡/通信断开或达到约 3 秒期限时也尝试恢复原目标。它只持有该进程的内核身份，不按可重用的 PID 随意发信号。对应测试覆盖控制宿主 SIGKILL 和部分写入后的恢复路径。外部高权限干预、看门狗本身被强制结束和系统故障不构成可保证范围。

## CPU 与线程

`process.cpu_sample` 在 50–1000ms 窗口内比较真实 CPU tick，返回进程与线程使用量，不暂停 APP。百分比以一个核为 100%，多线程进程可以超过 100%。

`process.cpu_snapshot` 对有调试授权的自有 APP 短暂读取寄存器；目标架构布局与帧展开限制见兼容矩阵。`process.suspend_for` 可暂停线程组 1–1000ms 后恢复，同样使用独立看门狗。

`process.set_cpu_affinity` 只接受人工预先配置的 `control_cpu_set` 的子集；当前作用于进程主线程，不冒充所有既存线程的聚合 CPU 配额。启动时的 rlimit 继续约束 CPU 秒、地址空间、文件句柄等；它不是 cgroup 进程树配额，也不是精确 RSS 上限。

这些能力可以服务 GUI APP、命令行程序和后台服务；是否有浏览器内核不是进程级能力的条件。它们不开放任意内核内存、任意寄存器改写、全进程注入或系统权限绕过。

## 运行验证

原生 C fixture 的检查链：启动→固定会话→读取/捕获数据→带旧摘要的数据区写入→程序自行产生新业务状态文件→内存差异→CPU 采样/亲和性→短暂停止与恢复→结束。另有部分写入回滚、代码页拒绝、权限拒绝和宿主 SIGKILL 后看门狗恢复测试。

GTK fixture 的检查链：启动→观察控件→密码编辑拒绝→聚焦普通输入→输入中文→读取回显→操作页面按钮→验证新页面。所有写操作经过同一 MCP 白名单、配置摘要、Pending/Unknown 日志及收据机制；原始输入文本和内存 payload 不进持久日志。


在 Toolbox 根目录运行：

```sh
python3 -m unittest discover -s tests -p test_native_control.py -v
python3 -m unittest discover -s tests -p test_mapping_safety.py -v
python3 tools/run_desktop_checks.py --xvfb /absolute/Xvfb
```

桌面检查需要 Xvfb、D-Bus、AT-SPI 与 GTK。内核拒绝 ptrace、桌面组件缺失和目标未导出控件时，保留对应失败、跳过或阻碍状态。
