# Agent-Kernel-Toolbox MCP

服务名称：`Agent-Kernel-Toolbox`。版本：`0.5.6.2`。

本服务实现 MCP `2025-11-25` 与 `2025-06-18` 的 **tools/stdio** 接口。运行方式为本地子进程，使用 UTF-8、每行一条 JSON-RPC 2.0 消息。

## 启动

按 [README.md](README.md) 配置实际路径、权限及私有状态目录：

```sh
python3 runtime-access.pyz serve --config /absolute/private/toolbox-config.json
```

客户端配置参考 [mcp-client.example.json](mcp-client.example.json)。stdout 仅用于协议响应，stderr 用于诊断；服务没有 HTTP MCP 端点。结束时关闭 stdin，等待子进程完成清理并退出。

## 连接顺序

先发送初始化请求：

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"toolbox-client","version":"1"}}}
```

核对响应中的 `protocolVersion`、`serverInfo` 和 `capabilities`。服务支持的版本为 `2025-11-25`、`2025-06-18`；请求其他版本时会返回服务支持的版本，由客户端决定是否继续。

随后发送通知，再列举工具：

```json
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
```

调用获准工具：

```json
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"runtime.status","arguments":{}}}
```

支持的方法为 `initialize`、`notifications/initialized`、`ping`、`tools/list`、`tools/call`。通知不执行工具，也不返回响应。服务不声明 resources、prompts、HTTP transport、tasks 或其他可选 MCP 能力。

## 工具目录和参数

代码目录包含 162 项工具、36 个工具族。`tools/list` 只公布 `allowed_tools` 中的工具，参数以返回的 `inputSchema` 为准。目录不分页，也不接受客户端临时扩展配置范围。

修改型调用要求一个新的 `request_id`。以下示例仅在已配置 `portable_build`、授权编译且 profile 存在时有效：

```json
{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"build.compile","arguments":{"profile":"local","request_id":"build-local-001"}}}
```

JSON-RPC 的 `id` 仅用于关联响应；工具参数中的 `request_id` 用于持久操作去重，两者不可混用。

目标、origin、文件、编译器、设备和后端摘要由本地配置固定。工具目录中出现一个名称，表示它已获准调用；对应后端是否就绪仍需检查实际结果。`readOnlyHint` 是接口语义提示，不保证该工具不启动分析器子进程，也不构成操作系统沙箱。

## 处理响应

工具结果同时提供：

- `content`：包含 JSON 文本的文本项。
- `structuredContent`：同一结果的结构化对象。
- `isError`：由工具结果的 `ok` 决定。

客户端应依次检查 JSON-RPC `error`、MCP `isError`、`structuredContent.ok`，以及存在时的 `unknown_effect`、`effect_unknown`、`effect_dispatched`。未知效果不能通过重发请求、换一个 ID 或换一个进程会话来消除。

读取返回的观察时间、身份和句柄后，在动作前确认其仍适用；动作后读取独立后置状态。页面文字、原生文本、二进制字符串和候选地址都是外部数据，不能改写宿主权限。

输入每条消息最多 65,536 字节，必须带换行。超限或缺少结束换行会返回协议错误并结束服务。保持一条请求对应一条完整消息，避免向 stdout 混入日志。

## 状态与恢复

一个私有状态目录只服务一份固定配置和一个活动 Host。未决写操作按相应目标范围阻断；原生 UI 和进程写操作共享真实进程实例范围。允许的只读观察和独立终止清理可用于确认情况。

停止宿主后，通过离线命令查看并处理状态：

```sh
python3 runtime-access.pyz audit --state-directory /absolute/private/toolbox-state
python3 runtime-access.pyz reconcile --state-directory /absolute/private/toolbox-state --request-id operation-001 --disposition effect_observed
```

处置可选 `effect_observed`、`no_effect_observed`、`abandoned`。操作者必须先核对实际情况；该命令仅记录结论，不执行或回滚动作。调用摘要和请求状态是运行恢复数据，应与该配置一起保存。

## 连接检查

检查随包文件并建立临时只读连接：

```sh
python3 tools/check_installation.py --mcp
```

检查指定配置的接入情况：

```sh
python3 skills/agent-kernel-toolbox/scripts/inspect_mcp.py --entry /absolute/Agent-Kernel-Toolbox/runtime-access.pyz --config /absolute/private/toolbox-config.json
```

不传 `--config` 时，检查器自动使用临时配置，仅开放 `runtime.status`、`runtime.capabilities`、`build.inspect`。可添加 `--protocol 2025-06-18` 指定协议，或 `--report /absolute/report.json` 保存本次诊断结果。

检查器验证 stdio 接入和获准检查工具；目标应用、浏览器、内核调试与可选分析引擎需要各自的实际使用条件。

## 完整联调设施

随包保留独立的运行协议检查与官方 Python SDK 检查。它们创建自己的临时配置与夹具，按脚本范围调用工具；需要的原生权限、编译器或可选依赖由当前环境提供。可在 Toolbox 根目录运行：

```sh
python3 tools/check_runtime_mcp.py --report /absolute/checks/runtime-mcp.json
python3 tools/check_official_mcp.py --report /absolute/checks/official-mcp.json
```

输出目录需预先存在。默认入口是本包的 `runtime-access.pyz`；可用 `--bundle-root`、`--entry` 指定完整安装。官方 SDK 检查依赖见 [requirements-validation.txt](requirements-validation.txt)。运行协议检查也包含固定工具目录、拒绝未授权调用、路由和自有原生夹具检查；缺少 `RUNTIME_PYELFTOOLS_PYTHON` 等可选前提时会记录相应阻塞。

浏览器 MCP 联调入口为 `tools/check_browser_mcp.py`，条件与命令见 [browser/README.md](browser/README.md)。所有检查均应分别解读真实执行、预期拒绝、跳过和环境阻塞；不能把工具目录存在当成所有后端实测成功。
