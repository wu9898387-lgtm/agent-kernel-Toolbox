// Offline source analysis and synthetic CDP boundary regression tests.
// Live SPA/history/CDP compatibility remains in the browser integration suite.
import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createHash} from 'node:crypto';
import {existsSync} from 'node:fs';
import {mkdtemp,writeFile,symlink,rm} from 'node:fs/promises';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {analyzeJavaScript,analyzeFile,safeURL,SOURCE_BYTE_LIMIT} from './route-analysis.mjs';
import {RouteEvidence,RouteNavigationRefusal} from './route-evidence.mjs';

const origin='https://owned.example';
const sha=value=>createHash('sha256').update(value).digest('hex');
const script=(id,overrides={})=>({scriptId:id,url:origin+'/app.js',hash:'a'.repeat(64),length:48,
  executionContextAuxData:{frameId:'main',isDefault:true},...overrides});

async function fixture(){
  const f={url:origin+'/next',history:{currentIndex:1,entries:[{id:1,url:origin+'/'},{id:2,url:origin+'/next'}]},
    navigated:[],scripts:[],source:'fetch("/api?secret=value");',historyHook:null,sourceHook:null,failDetach:false,failNavigation:false};
  f.session=new EventEmitter();
  f.session.send=async(method,args)=>{
    if(method==='Page.getFrameTree')return {frameTree:{frame:{id:'main',url:f.url}}};
    if(method==='Page.getNavigationHistory'){await f.historyHook?.();return structuredClone(f.history);}
    if(method==='Page.navigateToHistoryEntry'){
      f.navigated.push(args.entryId);if(f.failNavigation)throw Error('receipt_lost');return {};
    }
    throw Error('unexpected_cdp_method');
  };
  const page={url:()=>f.url,context:()=>({newCDPSession:async()=>{
    const debug=new EventEmitter();
    debug.send=async method=>{
      if(method==='Debugger.enable'){f.scripts.forEach(s=>debug.emit('Debugger.scriptParsed',s));return {};}
      if(method==='Debugger.disable')return {};
      if(method==='Debugger.getScriptSource'){await f.sourceHook?.();return {scriptSource:f.source};}
      throw Error('unexpected_debugger_method');
    };
    debug.detach=async()=>{if(f.failDetach)throw Error('detach_lost');};return debug;
  }})};
  f.collector=new RouteEvidence({session:f.session,page,allowedOrigins:[origin]});
  await f.collector.start();f.collector.addRoute(origin+'/','historyApi');
  f.navigateDocument=url=>{f.url=url;f.session.emit('Page.frameNavigated',{frame:{id:'main',url}});};
  return f;
}

test('static source analysis redacts secrets, skips comments/templates and grants no runtime authority',()=>{
  const source='// fetch("/comment");\nfetch("/api?secret=value");\nconst r={path:"/orders"};\nfetch(`/dynamic/${id}`);';
  const result=analyzeJavaScript(source,{baseURL:origin+'/',allowedOrigins:[origin],sourceStartLine:10});
  assert.equal(result.sourceUtf8SHA256,sha(source));
  assert.deepEqual(result.candidates.map(c=>c.url),[origin+'/api',origin+'/orders']);
  assert.equal(result.candidates[0].queryRedacted,true);assert.equal(result.candidates[0].resourcePosition.lineNumber,11);
  assert.ok(result.candidates.every(c=>c.runtimeVerified===false&&c.executionAuthorized===false));
  assert.equal(JSON.stringify(result).includes('secret=value'),false);
  assert.equal(result.skippedDynamicOrMalformedLiterals,1);
  assert.throws(()=>analyzeJavaScript('x'.repeat(SOURCE_BYTE_LIMIT+1),{baseURL:origin}),/script_source_budget/);
});

test('URL evidence rejects credentials/non-web schemes and does not replay sanitized state',()=>{
  for(const value of ['https://user:secret@owned.example/','javascript:run()','file:///tmp/a','/has space'])
    assert.equal(safeURL(value,origin),null);
  assert.deepEqual(safeURL(origin+'/app?secret=x#/route?token=y'),{
    url:origin+'/app#/route',origin,queryRedacted:true,fragmentRedacted:false,replayable:false});
  assert.equal(safeURL(origin+'/app#opaque').fragmentRedacted,true);
  assert.equal(safeURL(origin+'/app#opaque').replayable,false);
});

test('local source input enforces regular-file, byte and UTF-8 boundaries',async t=>{
  const tempParent=process.env.TMPDIR&&existsSync(process.env.TMPDIR)?process.env.TMPDIR:dirname(fileURLToPath(import.meta.url));
  const directory=await mkdtemp(join(tempParent,'.route-test-'));
  t.after(()=>rm(directory,{recursive:true,force:true}));
  const file=join(directory,'source.js');await writeFile(file,'fetch("/api");');
  assert.equal((await analyzeFile(file,{baseURL:origin})).candidates[0].url,origin+'/api');
  if(process.platform!=='win32'){
    const link=join(directory,'link.js');await symlink(file,link);
    await assert.rejects(analyzeFile(link,{baseURL:origin}),{code:'ELOOP'});
  }
  await assert.rejects(analyzeFile(directory,{baseURL:origin}),/script_source_budget/);
  await writeFile(file,Buffer.from([0xff]));await assert.rejects(analyzeFile(file,{baseURL:origin}),TypeError);
  await writeFile(file,'x'.repeat(SOURCE_BYTE_LIMIT+1));await assert.rejects(analyzeFile(file,{baseURL:origin}),/script_source_budget/);
});

test('only unique observed history entries gain navigation handles',async()=>{
  const f=await fixture();
  f.history.entries.push({id:3,url:origin+'/'},{id:4,url:origin+'/secret?token=value'});
  f.collector.addRoute(origin+'/secret?token=value','historyApi');
  const result=await f.collector.evidence();
  assert.equal(result.routes.find(r=>r.url===origin+'/').navigationUnavailableReason,'ambiguous_history_entry');
  assert.equal(result.routes.find(r=>r.url===origin+'/secret').routeHandle,null);
  assert.ok(result.routes.find(r=>r.url===origin+'/next').routeHandle);
  await assert.rejects(f.collector.navigate('candidate-1'),RouteNavigationRefusal);
  assert.deepEqual(f.navigated,[]);f.collector.close();
});

test('a navigation attempt consumes sibling handles even if its acknowledgment is lost',async()=>{
  const f=await fixture(),result=await f.collector.evidence();f.failNavigation=true;
  const first=result.routes.find(r=>r.url===origin+'/').routeHandle;
  const sibling=result.routes.find(r=>r.url===origin+'/next').routeHandle;
  await assert.rejects(f.collector.navigate(first),/receipt_lost/);
  await assert.rejects(f.collector.navigate(first),/stale_route_handle/);
  await assert.rejects(f.collector.navigate(sibling),/stale_route_handle/);
  assert.deepEqual(f.navigated,[1]);f.collector.close();
});

test('document navigation during the awaited history read prevents dispatch',async()=>{
  const f=await fixture(),result=await f.collector.evidence();
  const handle=result.routes.find(r=>r.url===origin+'/').routeHandle;
  f.historyHook=()=>{f.navigateDocument(origin+'/replacement');};
  await assert.rejects(f.collector.navigate(handle),/stale_route_handle/);
  assert.deepEqual(f.navigated,[]);f.collector.close();
});

test('script evidence excludes untrusted realms and sourceURL labels from readable handles',async()=>{
  const f=await fixture();
  f.scripts=[script('normal'),script('label',{hasSourceURL:true}),script('foreign',{url:'https://other.example/code.js'}),
    script('isolated',{executionContextAuxData:{frameId:'main',isDefault:false}}),script('wasm',{scriptLanguage:'WebAssembly'})];
  const result=await f.collector.evidence();assert.equal(result.scripts.length,2);
  assert.equal(result.scripts.filter(s=>s.scriptHandle).length,1);
  const label=result.scripts.find(s=>s.sourceURLLabel);assert.equal(label.sourceReadable,false);assert.equal(label.scriptHandle,null);
  const analyzed=await f.collector.analyze(result.scripts.find(s=>s.scriptHandle).scriptHandle);
  assert.equal(analyzed.sourceUtf8SHA256,sha(f.source));assert.equal(analyzed.candidates[0].url,origin+'/api');
  assert.equal(analyzed.implicitNetworkFetch,false);assert.equal(analyzed.candidates[0].correspondenceProvesImplementation,false);
  assert.equal(JSON.stringify(analyzed).includes('secret=value'),false);f.collector.close();
});

test('live edit invalidates the script handle before newly read source is returned',async()=>{
  const f=await fixture();f.scripts=[script('normal')];
  const result=await f.collector.evidence(),handle=result.scripts[0].scriptHandle;
  f.sourceHook=()=>{f.collector.parsedScript(script('normal',{hash:'b'.repeat(64)}));};
  await assert.rejects(f.collector.analyze(handle),/stale_script_handle/);f.collector.close();
});

test('unknown debugger cleanup fences later evidence and navigation',async()=>{
  const f=await fixture(),result=await f.collector.evidence();f.failDetach=true;
  await assert.rejects(f.collector.evidence(),/debugger_cleanup_unknown/);
  await assert.rejects(f.collector.navigate(result.routes[0].routeHandle),/debugger_cleanup_unknown/);
  assert.deepEqual(f.navigated,[]);f.collector.close();
});
