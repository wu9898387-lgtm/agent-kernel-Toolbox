# 网页运行时访问与独立浏览器扩展

本目录直接读取真实网页的 DOM、可见文字、链接和浏览器运行时计数，不需要网页主动接入 SDK，也不使用截图/OCR。提供 Node 适配器、JSON-lines 子进程接口和可单独加载的 Manifest V3 扩展。

## 可单独安装的扩展

1. 在 Chrome / Chromium 的扩展管理页启用开发者模式，选择“加载已解压的扩展程序”，指向本目录的 `extension/`。
2. 打开要操作的普通 HTTP/HTTPS 网页，点击扩展按钮。
3. 填写请求规则和隐藏选择器，点击“启用规则”。默认先安装本标签页的请求规则，再重新加载网页。
4. 点击“读取文字与链接”，直接查看文本。链接按钮使用网页现有点击处理器，可触发单页应用内部路由。独立“隐藏/恢复”用于一个明确选择器匹配的元素。

升级扩展后重新加载已开启的网页，使旧内容脚本由新文档替换；缺少有效文档身份时，本版拒绝操作。

示例规则：

```json
{
  "blockedRequests": [
    {"origin": "https://ads.example", "pathPrefix": "/advert/", "resourceTypes": ["script", "image", "xmlhttprequest"]}
  ],
  "cosmeticSelectors": ["#advert-overlay"]
}
```

规则中的地址是示例，需要替换为实际观察到的广告请求来源。没有内置猜测广告名单。`resourceTypes` 使用 Chrome DNR 名称；省略时匹配全部受支持类型。请求规则用 `tabIds` 精确限制到启用的标签页，目标 URL 用转义后的来源和路径前缀匹配。关闭或停用标签页会移除其规则。规则会保存供下一次启用，但关闭浏览器后不会自动给新标签页赋予控制权限。

扩展安装时请求 HTTP/HTTPS 页面访问权限，以便向选择的页面注入隔离世界脚本。后台只接受扩展控制页发出的操作；普通页面不能把文字变成调用命令。每次内容操作取得主文档的 Chrome `documentId`，验证注入脚本返回的来源，并将消息发送到该文档。内容脚本在同步执行前再次核对预期来源及每文档随机 token；标签页导航后不会把旧命令发送给新文档。规则应用后的重新加载也在已核对的文档中执行。已启用页面的内容脚本读取对应标签页策略，其他标签页不启用文字读取或隐藏控制。请求黑名单作用于整个选定标签页会话；隐藏规则另核对精确页面来源。

默认省略输入框、编辑区、密码及标记为私密的子树。用户可勾选包含编辑区文字；此时包含当前编辑缓冲区，密码类型、已用 autocomplete 标记的密码/验证码/支付卡字段以及显式私密区域仍排除。无法从任意普通文本推断全部秘密。查询参数和非路由片段不出现在导出链接中。

请求规则安装后的下一次匹配请求由浏览器在发送前阻止。隐藏规则通过 CSS 生效；扩展加载策略是异步的，不保证首次启动时绝无短暂显示。它不会回收已经产生的副作用，不会删除页面代码，也不会终止共享 GPU 进程。

## Node / MCP 子进程

使用 Node 24 或更高版本。在本目录安装已固定版本的依赖：

```sh
npm ci --ignore-scripts
npx playwright install chromium
```

可通过 `executablePath` 指定已经安装的 Chrome / Chromium，不必重复下载。锁文件固定 Playwright **1.62.1**；实际浏览器版本与成功范围以本机验证结果为准。Playwright 的浏览器默认版本下载和本目录代码不是同一个交付对象。

宿主配置文件示例：

```json
{
  "mode": "launch",
  "allowedOrigins": ["https://app.example"],
  "includeEditableText": false,
  "allowTextInput": false,
  "blockedRequests": [{"origin": "https://ads.example", "pathPrefix": "/"}],
  "cosmeticRules": [{"origin": "https://app.example", "selector": "#advert-overlay"}],
  "timeoutMs": 10000
}
```

```sh
node cli.mjs --config /absolute/path/config.json
```

程序先输出 `{"event":"ready","schemaVersion":1}`，然后逐行接受 JSON，逐行返回结果。单行输入最多 64 KiB，单次输出最多 1 MiB。没有任意 JavaScript、任意 CDP 方法或任意 shell 命令入口。

```jsonl
{"id":1,"method":"open","args":{"url":"https://app.example/"}}
{"id":2,"method":"snapshot","args":{"pageId":"returned-page-id"}}
{"id":3,"method":"metrics","args":{"pageId":"returned-page-id"}}
```

| 方法 | 参数 | 实际行为 |
| --- | --- | --- |
| `open` | `url` | 在自己启动的隔离上下文中新建网页 |
| `targets` | 无 | 列出已选择页面和观察到的专用 Worker |
| `capabilities` | 无 | 返回实际引擎、版本和能力差异 |
| `query` | `pageId, options` | 根据当前 DOM/ARIA 查询可见节点 |
| `fields` | `pageId, query, limit` | 按字面名称观察已授权的普通输入字段 |
| `setText` | `pageId, snapshotId, nodeId, value` | 使用新鲜字段句柄输入并读回 |
| `controls` | `pageId, query, role, limit` | 查询可操作按钮、标签、菜单项或链接 |
| `invoke` | `pageId, snapshotId, nodeId` | 点击当前观察到的控件 |
| `snapshot` | `pageId` | 返回文字、导航节点、快照 ID；每次替换此页面的上一快照 |
| `activate` | `pageId, snapshotId, nodeId` | 对仍新鲜的链接执行真实点击，保留应用路由处理器 |
| `navigate` | `pageId, url` | 跳转到宿主白名单来源内的 URL |
| `routeEvidence` | `pageId, limit` | 读取实际路由事件、请求发起位置和受限脚本清单；`limit` 为 1–128 |
| `analyzeScript` | `pageId, scriptHandle` | 读取已观察脚本，返回哈希、位置和静态路由/API 候选；不返回源码全文 |
| `navigateObserved` | `pageId, routeHandle` | 用新鲜、单次使用的句柄遍历已经观察到的浏览器历史项 |
| `metrics` | `pageId` | 返回累计任务/脚本时间、JS 堆字节和 DOM 计数 |
| `addBlockRule` | `rule` | 添加请求拒绝规则，不自动重试请求、不撤销已经发送的操作 |
| `networkEvents` | 无 | 最近 512 条脱敏的请求决策；包含丢弃数量 |
| `hide` | `pageId, selector` | 隐藏精确匹配的一个元素，返回恢复 ID |
| `restore` | `hideId` | 当前样式仍匹配扩展修改时恢复原样式 |
| `closeTarget` | `targetId` | 关闭自己启动的页面，或终止其已观察专用 Worker；报告实际关闭确认 |
| `close` | 无 | 释放此次会话资源 |

直接 JSON-lines 调用需提供 `cli.mjs` 的 `METHODS` 为该方法列出的全部键；返回的句柄必须来自本次实际观察。通过 MCP 调用时使用 `tools/list` 的 snake_case 参数与当前 schema，不把 Node 参数名直接套入 MCP 请求。

`engine` 可选 `chromium`、`firefox`、`webkit`，CDP 连接限 Chromium。普通字段观察需要 `includeEditableText: true`，写入还需 `allowTextInput: true`。表单步骤为 fields → setText → controls → invoke/activate → query；密码、验证码/支付字段和私有子树仍排除。输入、点击和跳转后重新观察业务状态。具体字段限制及原生/DOM 差异见 [ADVANCED_CHECKS.md](../ADVANCED_CHECKS.md)，受约束浏览器流量配置见 [DEFENSIVE-OBSERVATION.md](../DEFENSIVE-OBSERVATION.md)。

JavaScript 接口从 `runtime.mjs` 导入 `RuntimeBrowser`。`launch(config)` 启动独立浏览器；`connect(config)` 连接已经由用户明确启用的 CDP 端点。连接模式必须配置字面量回环地址 `http://127.0.0.1:端口` 或 `http://[::1]:端口`，以及非空 `targetIds`。只采纳明确选择的目标 ID，且目标当前来源必须在 `allowedOrigins` 中。连接关闭会断开适配器；不会终止附着的现有标签页。没有自动探测端口、浏览器登录态或调试权限。

`allowedOrigins` 在会话创建时固定。拒绝规则可在运行时追加。主文档和子框架文档的跨来源跳转也经过 CDP Fetch 拦截，包含重定向。快照只读取白名单来源的帧，最多 16 帧、256 个导航节点、262144 个文字字符。节点动作核对快照年龄、页面版本、帧 URL、节点身份及当前内容；过期或变更时拒绝。页面输出始终为不可信观察数据，不能自行授予宿主权限。

运行时 CPU 数值是渲染器累计任务/脚本时长，内存数值是 JS 堆统计；它们不等于原始 CPU 寄存器或完整进程内存。适配器不读取网络请求体、认证头、Cookies 或密码。Page/CDP Fetch 不覆盖浏览器外部进程和所有后台 Worker 网络流量，也不撤销已有 WebSocket 连接；已经发送的请求不会被声称为成功取消。新建上下文阻止 Service Worker，选定页面绕过 Service Worker 与缓存，以减少页面请求绕开拦截的路径。

## 内部路由与脚本调用证据

Node 适配器的路由采集作用于已授权的单个页面主帧。它使用 CDP 的真实导航和请求事件，记录文档导航、History API 导航、片段导航、请求方法/类型/响应状态，以及最多 8 层请求发起函数和脚本位置。每次请求按脱敏后的 `documentURL` 关联最近匹配的路由事件；`association.causalityProven` 始终为 `false`，表示这种关联没有证明完整业务因果链。`responseObserved`、`loadingFinished` 和 `failureObserved` 分开报告，`serverEffectConfirmed` 始终为 `false`。发送前被阻止的请求也可能产生请求意图事件，不能据此声称服务器执行过操作。

```jsonl
{"id":4,"method":"routeEvidence","args":{"pageId":"returned-page-id","limit":64}}
{"id":5,"method":"analyzeScript","args":{"pageId":"returned-page-id","scriptHandle":"returned-script-handle"}}
{"id":6,"method":"navigateObserved","args":{"pageId":"returned-page-id","routeHandle":"returned-route-handle"}}
```

`routeEvidence` 临时创建独立 CDP 会话并启用 Debugger 来列出当前已知脚本，随后禁用并断开该会话。只授予主帧默认执行环境中、允许来源内的已观察 JavaScript 脚本读取句柄。未知执行环境、隔离环境、跨来源脚本和 WebAssembly 不授予读取句柄；具有 `//# sourceURL` 标签的脚本只返回元数据，因为标签可以由脚本自行填写。没有隐式下载脚本 URL、Source Map 或浏览器外的资源。Debugger 会话无法确认断开时返回 `debugger_cleanup_unknown`，该采集器此后拒绝继续采集源码或执行路由跳转；宿主应保留这项不确定状态，关闭此次适配器会话并要求显式恢复。

脚本返回两种明确命名的哈希：`cdpContentSHA256` 来自浏览器的 `scriptParsed` 元数据，`sourceUtf8SHA256` 是实际读取的源码文本重新编码为 UTF-8 后的 SHA-256。哈希用于对应同一份源码，不证明软件发布者身份；`sourceAuthenticated` 为 `false`。源位置采用从 0 开始的行列号。读取期间遇到文档切换或脚本 live edit 会拒绝混合新旧来源。

`analyzeScript` 使用有界字符串词法扫描发现 `fetch`、XHR、常见请求调用、路由属性和 History API 附近的 URL 候选。它跳过注释和动态模板，不执行 JavaScript，不解析完整 AST，也不恢复动态计算、闭包、私有协议或任意框架语义。返回的候选始终标记 `runtimeVerified:false`、`executionAuthorized:false`；即使 URL 与实际事件一致，也仅列出对应事件 ID，不把相同 URL 当作实现关系的证明。源码全文、查询参数值、请求头、请求体、响应体与 `history.state` 不会保存在证据条目或导出结果中。源码里的普通路径和函数名仍可包含应用信息，不能自动判断任意字串是否私密。

只有已观察路由在当前浏览器历史中存在**唯一**、允许来源内、无需保留敏感查询值的匹配项，才会获得 `routeHandle`。同一 URL 对应多个历史项时返回 `ambiguous_history_entry`，不会猜测不同 `history.state` 的归属。句柄有效期 30 秒，绑定当前页面版本和历史项，派发前消费；`navigateObserved` 调用浏览器的 `navigateToHistoryEntry` 保留 SPA 的 `popstate` 行为。`dispatched:true` 仅表示已派发，完成情况应重新观察。静态候选 ID 不能用于该动作。页面转换期间可能返回 `page_changed_during_evidence`；调用方可以在截止时间内重新读取证据，不应因此自动重放点击或跳转。

采集器分别保存最近 128 条路由、128 条请求和最多 128 个脚本。每个响应分组最多约 192 KiB，额外省略的条数在 `omittedFromResponse` 中报告。单份源码最多 256 KiB，同一文档累计读取最多 1 MiB；完整文档导航重置源码预算。查询字符串被去除，只有形如 `#/route` 的路由片段保留；查询或不透明片段被去除后的地址不给历史跳转句柄。普通独立 MV3 扩展仍使用前文的 DOM/链接、规则与隐藏控制，这套 CDP 源码证据接口由 Node/MCP 适配器提供。

本地 JavaScript bundle 也可以在不启动浏览器、不执行代码的情况下分析：

```sh
node route-analysis.mjs --file /absolute/path/app.js --base-url https://app.example/
```

本地文件必须是最多 256 KiB 的普通 UTF-8 文件；符号链接和 FIFO 等非普通文件被拒绝。相对 URL 按显式提供的 `base-url` 解析，并在结果中标明该假设。本地分析仍只产生候选，不赋予网络请求或路由执行权限。

## 验证与复现

`package.json` 的入口覆盖本目录实际交付的六个测试文件。在本目录运行完整套件：

```sh
RUNTIME_CHROMIUM=/absolute/path/to/chrome npm test
```

只有浏览器路径确实需要定制时才设置 `RUNTIME_CHROMIUM`；也可直接使用 `npm test`。纯本地、无需 Playwright 或浏览器启动的回归入口：

```sh
npm run test:unit
```

`extension.test.mjs` 在模拟 Chrome API/DOM 下执行原版后台和内容脚本，检查来源/文档身份、导航交错、正常读取/隐藏/恢复/链接操作，以及规则应用、文档内重新加载和停用。`route-evidence.test.mjs` 直接运行本地源码分析器，并用模拟 CDP 测试历史句柄的唯一性、派发前消费、等待期间导航、脚本来源、live edit、Debugger 清理未知状态和文件输入边界。这些回归不构成真实扩展弹窗、DNR 或 CDP 浏览器集成验收。

浏览器集成及其相邻配置检查的单独入口：

```sh
RUNTIME_CHROMIUM=/absolute/path/to/chrome npm run test:browser
```

该入口运行 `runtime.test.mjs`、`compatibility.test.mjs`、`form-input.test.mjs`、`traffic-policy.test.mjs`，覆盖实际 DOM/ARIA、表单、SPA 历史、不同引擎及受约束流量的本地 fixtures。浏览器启动缺依赖或被系统拒绝时，保留失败与阻碍原因。不要将纯本地回归、握手成功或目录检查记成真实浏览器功能通过。

`RUNTIME_CHROMIUM` 指定 Chromium 可执行路径，`RUNTIME_TEST_ENGINES=chromium,firefox,webkit` 可选择集成测试引擎。真实扩展 UI 安装、DNR 和浏览器导航需在允许启动对应浏览器的环境中检查。

协议依据：[Chrome 文档注入身份](https://developer.chrome.com/docs/extensions/reference/api/scripting#type-InjectionResult)、[按文档发送消息](https://developer.chrome.com/docs/extensions/reference/api/tabs#method-sendMessage)、[Chrome DNR](https://developer.chrome.com/docs/extensions/reference/api/declarativeNetRequest)、[CDP Fetch](https://chromedevtools.github.io/devtools-protocol/tot/Fetch/)、[CDP Performance](https://chromedevtools.github.io/devtools-protocol/tot/Performance/)、[Playwright BrowserContext](https://playwright.dev/docs/api/class-browsercontext)。这些浏览器接口提供可用的运行时信息；没有自动恢复任意闭源应用的内部语义，也不覆盖 Windows/macOS 原生 UI 或任意 GPU 渲染 API。
