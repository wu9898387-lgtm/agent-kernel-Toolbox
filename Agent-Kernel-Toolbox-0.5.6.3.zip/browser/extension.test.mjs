// Runs the shipped extension scripts with synthetic Chrome/DOM boundaries.
// This is not a real-browser extension or DNR integration acceptance.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {randomUUID,randomFillSync} from 'node:crypto';
import {createContext,runInContext} from 'node:vm';

const source=readFileSync(new URL('./extension/content.js',import.meta.url),'utf8');
const allowed='https://owned.example',other='https://other.example';

function documentFixture(origin){
  const effects={reads:0,writes:0,mounts:0,reloads:0,clicks:0};
  const values=new Map([['display','inline-block'],['priority','']]);
  const style={getPropertyValue:()=>values.get('display'),getPropertyPriority:()=>values.get('priority'),
    setProperty:(_name,value,priority='')=>{effects.writes++;values.set('display',value);values.set('priority',priority);},
    removeProperty:()=>{effects.writes++;values.delete('display');values.delete('priority');}};
  const overlay={tagName:'DIV',style,isConnected:true};
  const link={tagName:'A',innerText:'Owned route',href:origin+'/next?private=query',isConnected:true,
    closest:()=>null,querySelector:()=>null,getClientRects:()=>[{}],getAttribute:()=>null,matches:()=>false,
    click:()=>{effects.clicks++;}};
  const text={nodeValue:'Synthetic visible text',parentElement:{closest:()=>null,getClientRects:()=>[{}]}};
  const doc={id:randomUUID(),effects,values,handler:null};
  const context={URL,crypto:{randomUUID},location:{origin,href:origin+'/',reload:()=>{effects.reloads++;}},
    document:{title:'Owned fixture',body:{},documentElement:{append:()=>{effects.mounts++;}},
      querySelectorAll:selector=>selector==='#overlay'?[overlay]:selector==='a[href],[role="link"]'?[link]:[],
      createTreeWalker:()=>{let visited=false;return {currentNode:text,nextNode:()=>{if(visited)return false;visited=true;effects.reads++;return true;}};},
      createElement:()=>({remove:()=>{},sheet:{insertRule:()=>{effects.writes++;},cssRules:[]}})},
    NodeFilter:{SHOW_TEXT:4},CSS:{supports:()=>true},getComputedStyle:()=>({display:'block',visibility:'visible'}),
    chrome:{runtime:{id:'fixture-extension',onMessage:{addListener:fn=>{doc.handler=fn;}},
      sendMessage:async()=>({policy:null})}}};
  doc.context=createContext(context);
  doc.install=()=>runInContext(source,doc.context);
  return doc;
}

async function fixture(hooks={}){
  let handler,removed;
  const policy={site:allowed,blockedRequests:[{origin:allowed,pathPrefix:'/blocked',resourceTypes:['script']}],cosmeticSelectors:['#overlay']};
  const f={current:documentFixture(allowed),active:{7:policy},saved:{},rules:[],sent:[],injections:[],
    navigate(origin){this.current=documentFixture(origin);this.current.install();return this.current;}};
  const api={
    runtime:{id:'fixture-extension',getURL:file=>'chrome-extension://fixture-extension/'+file,
      onMessage:{addListener:fn=>{handler=fn;}}},
    storage:{session:{get:async()=>({activeTabs:structuredClone(f.active)}),set:async value=>{f.active=value.activeTabs;}},
      local:{get:async()=>({policies:structuredClone(f.saved)}),set:async value=>{f.saved=value.policies;}}},
    tabs:{get:async id=>({id,url:f.current.context.location.href}),
      sendMessage:async(_id,message,options)=>{
        f.sent.push({message,options});
        if(options?.documentId!==f.current.id)throw Error('document_no_longer_available');
        return await new Promise(resolve=>f.current.handler(message,{id:'fixture-extension'},resolve));
      },onRemoved:{addListener:fn=>{removed=fn;}},
      reload:async()=>{throw Error('unscoped_tab_reload_forbidden');}},
    scripting:{executeScript:async options=>{
      await hooks.beforeInjection?.(f);
      assert.deepEqual(options.target,{tabId:7,frameIds:[0]});
      const doc=f.current,result=doc.install();f.injections.push(doc);
      await hooks.afterInjection?.(f);
      return hooks.injectionResult?.(doc,result)??[{frameId:0,documentId:doc.id,result}];
    },getRegisteredContentScripts:async()=>[],registerContentScripts:async()=>{},
      updateContentScripts:async()=>{},unregisterContentScripts:async()=>{}},
    declarativeNetRequest:{getSessionRules:async()=>structuredClone(f.rules),updateSessionRules:async({removeRuleIds,addRules=[]})=>{
      f.rules=f.rules.filter(r=>!removeRuleIds.includes(r.id)).concat(addRules);
    }},
  };
  globalThis.chrome=api;
  await import(new URL('./extension/background.mjs?test='+randomUUID(),import.meta.url));
  f.call=(operation,args={})=>new Promise(resolve=>handler({operation,tabId:7,...args},
    {id:'fixture-extension',url:api.runtime.getURL('control.html')},resolve));
  f.remove=()=>removed(7);
  return f;
}

test('extension scopes real script read, hide, restore and link actions to one document',async()=>{
  const f=await fixture();
  const read=await f.call('read');
  assert.equal(read.text,'Synthetic visible text');assert.equal(read.url,allowed+'/');
  assert.equal(read.links[0].href,allowed+'/next');
  const hide=await f.call('hide',{selector:'#overlay'});
  assert.equal(hide.hidden,true);assert.equal(f.current.values.get('display'),'none');
  assert.equal((await f.call('restore',{hideId:hide.hideId})).restored,true);
  assert.equal(f.current.values.get('display'),'inline-block');
  assert.equal((await f.call('navigate',{snapshotId:read.snapshotId,nodeId:read.links[0].nodeId})).dispatched,true);
  assert.equal(f.current.effects.clicks,1);
  assert.ok(f.sent.every(r=>r.options.documentId===f.current.id&&r.message.expectedOrigin===allowed));
  assert.equal(new Set(f.sent.map(r=>r.message.documentToken)).size,1);
});

test('ordinary HTTP retains read, hide, cosmetics and reload when randomUUID is unavailable',async()=>{
  const f=await fixture(),origin='http://owned.example';
  f.current=documentFixture(origin);
  f.active[7]={...f.active[7],site:origin,blockedRequests:[]};
  let randomCalls=0;
  f.current.context.crypto={getRandomValues:bytes=>{randomCalls++;return randomFillSync(bytes);}};
  const read=await f.call('read');
  assert.equal(read.text,'Synthetic visible text');assert.equal(read.url,origin+'/');
  assert.match(read.snapshotId,/^[0-9a-f]{32}$/u);assert.match(read.links[0].nodeId,/^[0-9a-f]{32}$/u);
  const hidden=await f.call('hide',{selector:'#overlay'});
  assert.equal(hidden.hidden,true);assert.match(hidden.hideId,/^[0-9a-f]{32}$/u);
  const applied=await f.call('apply',{policy:f.active[7],reload:true});
  assert.equal(applied.active,true);assert.equal(f.current.effects.mounts,1);assert.equal(f.current.effects.reloads,1);
  assert.match(f.sent[0].message.documentToken,/^[0-9a-f]{32}$/u);
  assert.equal(randomCalls,4);
});

test('extension refuses a new origin reached after the tab check and before injection',async()=>{
  const f=await fixture({beforeInjection:f=>f.navigate(other)});
  assert.equal((await f.call('read')).error,'tab_origin_changed');
  assert.equal(f.sent.length,0);assert.equal(f.current.effects.reads,0);assert.equal(f.current.effects.writes,0);
});

test('extension messages target the injected document when navigation replaces it before send',async()=>{
  const f=await fixture({afterInjection:f=>f.navigate(allowed)});
  assert.equal((await f.call('hide',{selector:'#overlay'})).error,'document_no_longer_available');
  assert.equal(f.sent.length,1);assert.equal(f.sent[0].options.documentId,f.injections[0].id);
  assert.notEqual(f.sent[0].options.documentId,f.current.id);assert.equal(f.current.effects.writes,0);
});

test('content script checks both origin and document token before reading or changing DOM',()=>{
  const first=documentFixture(allowed),scope=first.install();
  const replacement=documentFixture(allowed);replacement.install();
  const send=(doc,message)=>{let reply;doc.handler(message,{id:'fixture-extension'},r=>{reply=r;});return reply;};
  const message={source:'agent-kernel-runtime',operation:'hide',selector:'#overlay',expectedOrigin:allowed,documentToken:scope.documentToken};
  assert.equal(send(replacement,message).error,'document_changed');
  assert.equal(replacement.effects.writes,0);
  const foreign=documentFixture(other);foreign.install();
  assert.equal(send(foreign,{...message,operation:'read'}).error,'tab_origin_changed');
  assert.equal(foreign.effects.reads,0);
  assert.equal(send(first,{...message,documentToken:undefined}).error,'document_changed');
  assert.equal(first.effects.writes,0);
});

test('extension fails closed when Chrome does not return a usable document identity',async()=>{
  const f=await fixture({injectionResult:(_doc,result)=>[{frameId:0,result}]});
  assert.equal((await f.call('hide',{selector:'#overlay'})).error,'document_identity_unavailable');
  assert.equal(f.sent.length,0);assert.equal(f.current.effects.writes,0);
});

test('policy apply and reload run in the bound document and deactivate restores local state',async()=>{
  const f=await fixture(),policy=f.active[7];
  const applied=await f.call('apply',{policy,reload:true});
  assert.equal(applied.active,true);assert.equal(applied.reloadRequested,true);
  assert.equal(f.current.effects.reloads,1);assert.equal(f.rules.length,1);
  const hidden=await f.call('hide',{selector:'#overlay'});assert.equal(hidden.hidden,true);
  assert.equal((await f.call('deactivate')).active,false);
  assert.equal(f.current.values.get('display'),'inline-block');assert.equal(f.rules.length,0);assert.deepEqual(f.active,{});
});

test('policy apply never reloads or styles a different origin reached during injection',async()=>{
  const f=await fixture({beforeInjection:f=>f.navigate(other)}),policy=f.active[7];
  assert.equal((await f.call('apply',{policy,reload:true})).error,'tab_origin_changed');
  assert.equal(f.current.effects.reloads,0);assert.equal(f.current.effects.mounts,0);assert.equal(f.current.effects.writes,0);
});

test('deactivation removes tab rules without clearing a replacement origin document',async()=>{
  const f=await fixture();f.rules=[{id:1,condition:{tabIds:[7]}}];f.navigate(other);
  assert.equal((await f.call('deactivate')).active,false);
  assert.equal(f.rules.length,0);assert.equal(f.sent.length,0);assert.equal(f.current.effects.writes,0);
});
