(() => {
  if(globalThis.__agentKernelRuntimeInstalled)return globalThis.__agentKernelRuntimeInstalled;
  function newId(){
    if(typeof crypto.randomUUID==='function')return crypto.randomUUID();
    // randomUUID is secure-context-only; getRandomValues also supports ordinary HTTP.
    const bytes=new Uint8Array(16);crypto.getRandomValues(bytes);
    return Array.from(bytes,value=>value.toString(16).padStart(2,'0')).join('');
  }
  const documentToken=newId();
  const documentScope=Object.freeze({origin:location.origin,documentToken});
  globalThis.__agentKernelRuntimeInstalled=documentScope;
  let snapshotId=null,snapshotUrl=null,nodes=new Map(),style=null,cosmeticObserver=null;
  const hidden=new Map();
  const privateSelector='input,textarea,select,[contenteditable]:not([contenteditable="false"]),[data-sensitive],[data-private],[aria-hidden="true"],script,style,noscript,template';
  function cleanUrl(value){try{if(typeof value!=='string'||value.length>8192)return null;const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.origin+u.pathname.slice(0,2048)+(u.hash.startsWith('#/')?u.hash.split('?')[0].slice(0,512):''):null;}catch{return null;}}
  function visible(el,includeEditableText=false){const blocked=includeEditableText?'input,textarea,select,[data-sensitive],[data-private],[aria-hidden="true"],script,style,noscript,template':privateSelector;if(el.closest(blocked))return false;const css=getComputedStyle(el);return css.display!=='none'&&css.visibility!=='hidden'&&el.getClientRects().length>0;}
  function describe(el){if(el.querySelector(privateSelector))return null;return {name:(el.getAttribute('aria-label')||el.innerText||'').replace(/\s+/gu,' ').trim().slice(0,512),href:el.tagName==='A'?el.href:null,disabled:el.matches(':disabled')||el.getAttribute('aria-disabled')==='true'};}
  function read(includeEditableText=false){
    nodes=new Map();snapshotId=newId();snapshotUrl=location.href;
    const chunks=[];let size=0,visited=0,truncated=false;
    const walker=document.createTreeWalker(document.body??document.documentElement,NodeFilter.SHOW_TEXT);
    while(walker.nextNode()){
      if(++visited>20000){truncated=true;break;}
      const el=walker.currentNode.parentElement;if(!el||!visible(el,includeEditableText))continue;
      const part=walker.currentNode.nodeValue.replace(/\s+/gu,' ').trim();if(!part)continue;
      if(size+part.length>65536){truncated=true;break;}chunks.push(part);size+=part.length;
    }
    if(includeEditableText){const fields=document.querySelectorAll('textarea,input');for(let i=0;i<Math.min(fields.length,256);i++){
      const el=fields[i];if(el.closest('[data-sensitive],[data-private],[aria-hidden="true"]')||(el.tagName==='INPUT'&&!['text','search','email','url','tel','number'].includes(el.type))||/(?:password|one-time-code|cc-)/iu.test(el.autocomplete))continue;
      const css=getComputedStyle(el);if(css.display==='none'||css.visibility==='hidden'||!el.getClientRects().length)continue;
      if(size+el.value.length>65536){truncated=true;break;}if(el.value){chunks.push(el.value);size+=el.value.length;}
    }}
    const links=[],candidates=document.querySelectorAll('a[href],[role="link"]');
    for(let i=0;i<Math.min(candidates.length,128);i++){
      const el=candidates[i];if(!visible(el))continue;const value=describe(el),nodeId=newId();if(!value||(value.href!==null&&value.href.length>8192))continue;
      nodes.set(nodeId,{el,value:JSON.stringify(value)});links.push({nodeId,...value,href:cleanUrl(value.href)});
    }
    return {observationOnly:true,sourceAuthenticated:false,executionAuthorized:false,includeEditableText,snapshotId,title:document.title.slice(0,512),url:cleanUrl(location.href),text:chunks.join('\n'),links,truncated:truncated||candidates.length>128};
  }
  function cosmetics(selectors){
    if(!Array.isArray(selectors)||selectors.length>64)throw Error('selector_budget');
    cosmeticObserver?.disconnect();cosmeticObserver=null;style?.remove();style=document.createElement('style');
    const mount=()=>{
      if(!document.documentElement)return false;
      document.documentElement.append(style);
      for(const s of selectors){if(typeof s!=='string'||s.length>512||/[{};]/u.test(s)||!CSS.supports(`selector(${s})`))throw Error('invalid_selector');style.sheet.insertRule(`${s} { display:none !important; }`,style.sheet.cssRules.length);}
      return true;
    };
    if(!mount()){const observer=new MutationObserver(()=>{if(mount())observer.disconnect();});cosmeticObserver=observer;observer.observe(document,{childList:true});}
    return {applied:selectors.length};
  }
  function restore(hideId){
    const value=hidden.get(hideId);if(!value)throw Error('hide_not_found');
    hidden.delete(hideId);const {el,display,priority}=value;
    if(!el.isConnected||el.style.getPropertyValue('display')!=='none'||el.style.getPropertyPriority('display')!=='important')return {restored:false};
    if(display)el.style.setProperty('display',display,priority);else el.style.removeProperty('display');return {restored:true};
  }
  function execute(m){
    if(m.operation==='read')return read(m.includeEditableText===true);
    if(m.operation==='cosmetics'){
      const result=cosmetics(m.selectors);
      // A tab-level reload can race into a replacement document; reload this checked document.
      if(m.reload===true)location.reload();
      return result;
    }
    if(m.operation==='clear'){cosmeticObserver?.disconnect();cosmeticObserver=null;style?.remove();style=null;for(const id of hidden.keys())restore(id);nodes.clear();snapshotId=null;return {cleared:true};}
    if(m.operation==='navigate'){
      if(m.snapshotId!==snapshotId||location.href!==snapshotUrl)throw Error('stale_snapshot');
      const n=nodes.get(m.nodeId);if(!n||!n.el.isConnected||!visible(n.el)||JSON.stringify(describe(n.el))!==n.value)throw Error('stale_node');
      const v=describe(n.el);if(v.disabled)throw Error('disabled');
      if(v.href){const u=new URL(v.href);if(u.origin!==location.origin||!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('origin_not_allowed');}
      snapshotId=null;nodes.clear();n.el.click();return {dispatched:true,navigationCompleted:false};
    }
    if(m.operation==='hide'){
      if(typeof m.selector!=='string'||m.selector.length>512||hidden.size>=128)throw Error('invalid_selector');
      const matches=document.querySelectorAll(m.selector);if(matches.length!==1)throw Error('selector_must_match_one');
      const el=matches[0];if(['HTML','BODY','HEAD'].includes(el.tagName))throw Error('root_element_denied');
      const hideId=newId();hidden.set(hideId,{el,display:el.style.getPropertyValue('display'),priority:el.style.getPropertyPriority('display')});
      el.style.setProperty('display','none','important');return {hideId,hidden:true};
    }
    if(m.operation==='restore')return restore(m.hideId);
    throw Error('unknown_operation');
  }
  chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    if(sender.id!==chrome.runtime.id||message?.source!=='agent-kernel-runtime')return;
    try{
      if(message.expectedOrigin!==location.origin)throw Error('tab_origin_changed');
      if(message.documentToken!==documentToken)throw Error('document_changed');
      reply(execute(message));
    }catch(e){reply({error:/^[a-z_]{1,80}$/u.test(e.message)?e.message:'operation_failed'});}
  });
  chrome.runtime.sendMessage({operation:'getTabPolicy'}).then(r=>{if(r?.policy?.site===location.origin)cosmetics(r.policy.cosmeticSelectors);}).catch(()=>{});
  return documentScope;
})();
