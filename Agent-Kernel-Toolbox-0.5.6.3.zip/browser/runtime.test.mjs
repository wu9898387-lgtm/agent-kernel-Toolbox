import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {existsSync} from 'node:fs';
import {RuntimeBrowser, matchesRule, validateRule} from './runtime.mjs';
import {validateQuery} from './semantic-query.mjs';
import {analyzeJavaScript} from './route-analysis.mjs';
import {validatePolicy,compileRules} from './extension/rules.mjs';

test('scope validation and non-executing static route analysis',()=>{
  const rule=validateRule({origin:'https://example.com',pathPrefix:'/ads/'});
  assert.equal(matchesRule(rule,'https://example.com/ads/1','Fetch'),true);
  assert.equal(matchesRule(rule,'https://example.com.evil/ads/1','Fetch'),false);
  assert.throws(()=>validateQuery({maxNodes:0}),/invalid_query_options/);
  const parsed=analyzeJavaScript("fetch('/api/items?token=private'); const route='/settings'; globalThis.pwned=true;",{
    baseURL:'https://example.com/',allowedOrigins:['https://example.com']});
  assert.ok(parsed.candidates.some(c=>c.url==='https://example.com/api/items'&&c.queryRedacted));
  assert.equal(parsed.executionAuthorized,false);
  assert.equal(globalThis.pwned,undefined);
  const policy=validatePolicy({site:'https://example.com',blockedRequests:[rule]});
  const [compiled]=compileRules(policy,7,[]);
  assert.deepEqual(compiled.condition.tabIds,[7]);
  assert.equal(new RegExp(compiled.condition.regexFilter).test('https://example.com.evil/ads/'),false);
});

test('real Chromium DOM, state, shadow, redaction and SPA history',async t=>{
  const body=`<!doctype html><meta charset="utf-8"><title>Runtime fixture</title>
    <a id="next" href="/next" onclick="event.preventDefault();history.pushState({},'',this.href);document.querySelector('#status').textContent='Next page'">Next page</a>
    <a href="/api?token=private">API link</a><button role="tab" aria-selected="true">订单</button>
    <p id="status">Initial page</p><button aria-expanded="false" aria-label="Details"></button>
    <a href="/action" role="button">Anchor action</a><input type=reset value="Reset action">
    <button role="link">Button link</button><div role="menuitem">Menu entry</div>
    <button id="unicode" aria-label="${'界'.repeat(100)}"></button>
    <input type="password" value="PASSWORD_SECRET"><div data-private><p>PRIVATE_SECRET</p></div>
    <div aria-hidden="true">HIDDEN_SECRET</div><div id="shadow"></div><div data-private id="private-shadow"></div>
    ${'<p>Ordinary long content for snapshot size measurement. '.repeat(1500)}
    <script>
      document.querySelector('#shadow').attachShadow({mode:'open'}).innerHTML='<button role="tab" aria-selected="false">Shadow tab</button><span data-sensitive>SHADOW_SECRET</span><input value="INPUT_SECRET">';
      document.querySelector('#private-shadow').attachShadow({mode:'open'}).innerHTML='<button>PRIVATE_SHADOW_SECRET</button>';
      addEventListener('popstate',()=>document.querySelector('#status').textContent='Initial page');
    </script>`;
  const server=createServer((req,res)=>{
    res.setHeader('content-type','text/html; charset=utf-8');res.end(body);
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base=`http://127.0.0.1:${server.address().port}`;
  const executablePath=process.env.RUNTIME_CHROMIUM||(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
  const runtime=await RuntimeBrowser.launch({allowedOrigins:[base],executablePath,headless:true});
  t.after(()=>runtime.close());
  const {pageId}=await runtime.open(base+'/');

  await t.test('queries labels/states and open shadows with sensitive text excluded',async()=>{
    const result=await runtime.query(pageId,{selector:'[role="tab"],button,a,p',maxNodes:128});
    const nodes=result.frames.flatMap(f=>f.nodes??[]);
    assert.ok(nodes.some(n=>n.name==='订单'&&n.states.selected==='true'));
    // Match filtering searches through the bounded DOM, beyond the response node limit.
    const shadow=await runtime.query(pageId,{query:'Shadow tab'});
    assert.ok(shadow.frames.flatMap(f=>f.nodes??[]).some(n=>n.name==='Shadow tab'&&n.states.selected==='false'));
    for(const value of ['PASSWORD_SECRET','PRIVATE_SECRET','HIDDEN_SECRET','SHADOW_SECRET','INPUT_SECRET','PRIVATE_SHADOW_SECRET'])
      assert.equal(JSON.stringify(result).includes(value)||JSON.stringify(shadow).includes(value),false,value);
    const secrets=await runtime.query(pageId,{query:'SECRET'});
    assert.equal(secrets.frames.flatMap(f=>f.nodes??[]).length,0);
    const api=nodes.find(n=>n.name==='API link');assert.equal(api.href,base+'/api');
    const controlsByRole={};
    for(const role of ['button','link','tab','menuitem']){
      const controls=await runtime.controls(pageId,'',role,32);
      controlsByRole[role]=controls.frames.flatMap(f=>f.nodes??[]).map(n=>n.name);
      assert.ok(controls.frames.flatMap(f=>f.nodes??[]).every(n=>n.role===role));
      assert.equal(JSON.stringify(controls).includes('PRIVATE_SHADOW_SECRET'),false);
    }
    for(const name of ['Details','Anchor action','Reset action'])assert.ok(controlsByRole.button.includes(name),name);
    for(const name of ['Next page','API link','Button link'])assert.ok(controlsByRole.link.includes(name),name);
    assert.deepEqual(controlsByRole.tab,['订单','Shadow tab']);
    assert.deepEqual(controlsByRole.menuitem,['Menu entry']);
    assert.equal(controlsByRole.button.includes('Button link'),false);
    assert.equal(controlsByRole.link.includes('Anchor action'),false);
  });

  await t.test('compact query saves output and UTF-8 budget is respected',async()=>{
    const full=await runtime.snapshot(pageId),compact=await runtime.query(pageId,{query:'订单',maxNodes:8,maxTextBytes:128});
    const snapshotBytes=Buffer.byteLength(JSON.stringify(full)),queryBytes=Buffer.byteLength(JSON.stringify(compact));
    assert.ok(queryBytes*10<snapshotBytes);
    t.diagnostic(JSON.stringify({snapshotBytes,queryBytes,outputReductionPercent:Number((100*(1-queryBytes/snapshotBytes)).toFixed(2)),tokenCountMeasured:false}));
    assert.ok(compact.frames.reduce((n,f)=>n+(f.textBytes??0),0)<=128);
    assert.ok(compact.frames.flatMap(f=>f.nodes??[]).some(n=>n.name==='订单'));
    assert.equal(compact.actionsIssued,false);
    assert.equal(compact.closedShadowRootsReadable,false);
    const unicode=await runtime.query(pageId,{selector:'#unicode',maxTextBytes:128});
    assert.equal(unicode.frames[0].textBytes,126);
    assert.equal(Buffer.byteLength(unicode.frames[0].nodes[0].name),126);
    assert.equal(unicode.truncated,true);
  });

  await t.test('fresh links navigate through SPA handlers and observed history returns',async()=>{
    const initial=await runtime.routeEvidence(pageId,16);
    assert.ok(initial.routes.length);
    const snapshot=await runtime.snapshot(pageId);
    const link=snapshot.frames.flatMap(f=>f.nodes??[]).find(n=>n.name==='Next page');
    assert.ok(link);
    await runtime.activate(pageId,snapshot.snapshotId,link.nodeId);
    await runtime.get(pageId).page.waitForURL(base+'/next');
    await runtime.get(pageId).page.waitForFunction(()=>document.querySelector('#status').textContent==='Next page');
    assert.equal(runtime.get(pageId).page.url(),base+'/next');
    const evidence=await runtime.routeEvidence(pageId,16);
    const prior=evidence.routes.find(r=>r.url===base+'/'&&r.routeHandle);
    assert.ok(prior);
    await runtime.navigateObserved(pageId,prior.routeHandle);
    await runtime.get(pageId).page.waitForURL(base+'/');
    await runtime.get(pageId).page.waitForFunction(()=>document.querySelector('#status').textContent==='Initial page');
    assert.equal((await runtime.query(pageId,{query:'Initial page'})).frames[0].nodes[0].name,'Initial page');
    await assert.rejects(()=>runtime.navigateObserved(pageId,prior.routeHandle),/stale_route_handle/);
  });

  await t.test('invalid selectors and denied origins remain rejected',async()=>{
    await assert.rejects(()=>runtime.query(pageId,{selector:'['}),/invalid_query_selector/);
    await assert.rejects(()=>runtime.open('https://example.org/'),/origin_not_allowed/);
  });
});
