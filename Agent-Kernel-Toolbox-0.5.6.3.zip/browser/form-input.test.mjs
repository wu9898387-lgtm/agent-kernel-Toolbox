import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {RuntimeBrowser,validateConfig} from './runtime.mjs';
import {TextInputRefusal} from './text-input.mjs';

test('proxy and text permissions require operator configuration',()=>{
  assert.throws(()=>validateConfig({allowedOrigins:['https://example.com'],proxy:{server:'http://user:secret@proxy:8080'}}),/invalid_proxy/);
  assert.throws(()=>validateConfig({allowedOrigins:['https://example.com'],allowTextInput:'true'}),/invalid_text_input_option/);
});
for(const engine of (process.env.RUNTIME_TEST_ENGINES??'chromium').split(','))test(`fresh observed form fields on ${engine}`,async t=>{
  const html=`<!doctype html><meta charset=utf-8><title>Text input contract</title>
  ${'<a href="/irrelevant" style="display:none">Hidden link</a>'.repeat(270)}
  <label for=search>Quick search</label><input id=search name=q type=search value=initial>
  <label>Notes<textarea id=notes></textarea></label><input type=submit id=submit value=Go><output id=result></output>
  <input type=password value=PASSWORD_SECRET><input autocomplete=one-time-code value=OTP_SECRET>
  <div data-private><input value=PRIVATE_SECRET></div><div data-private id=shadow></div>
  <input type=hidden value=HIDDEN_SECRET><input type=text readonly aria-label=Readonly value=original>
  <script>document.querySelector('#shadow').attachShadow({mode:'open'}).innerHTML='<input aria-label="private shadow" value="SHADOW_SECRET">';
  document.querySelector('#submit').onclick=()=>document.querySelector('#result').textContent=document.querySelector('#search').value;</script>`;
  const server=createServer((_q,r)=>{r.setHeader('Content-Type','text/html; charset=utf-8');r.end(html);});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base=`http://127.0.0.1:${server.address().port}`;
  const executablePath=engine==='chromium'?(process.env.RUNTIME_CHROMIUM??'/usr/bin/chromium'):
    engine==='webkit'?process.env.RUNTIME_WEBKIT:process.env.RUNTIME_FIREFOX;
  const runtime=await RuntimeBrowser.launch({engine,executablePath,allowedOrigins:[base],headless:true,includeEditableText:true,allowTextInput:true});
  t.after(()=>runtime.close());const {pageId}=await runtime.open(base+'/'),page=runtime.get(pageId).page;
  const full=await runtime.snapshot(pageId);
  for(const secret of ['PASSWORD_SECRET','OTP_SECRET','PRIVATE_SECRET','HIDDEN_SECRET','SHADOW_SECRET'])assert.equal(JSON.stringify(full).includes(secret),false);
  let fields=await runtime.fields(pageId);assert.equal(fields.fields.length,3);
  for(const secret of ['PASSWORD_SECRET','OTP_SECRET','PRIVATE_SECRET','HIDDEN_SECRET','SHADOW_SECRET'])assert.equal(JSON.stringify(fields).includes(secret),false);
  let field=fields.fields.find(n=>n.name==='Quick search');assert.ok(field);
  const changed=await runtime.setText(pageId,fields.snapshotId,field.nodeId,'中文 sqlite3');
  assert.equal(changed.textVerified,true);assert.equal(changed.businessEffectConfirmed,false);
  await assert.rejects(()=>runtime.setText(pageId,fields.snapshotId,field.nodeId,'replay'),e=>e instanceof TextInputRefusal&&e.message==='stale_field_snapshot');
  let controls=await runtime.controls(pageId,'Go','button',1),button=controls.frames.flatMap(f=>f.nodes??[]).find(n=>n.name==='Go');
  assert.ok(button,JSON.stringify({controlsExamined:controls.controlsExamined,truncated:controls.truncated}));
  assert.equal(controls.controlsExamined,1,'irrelevant link roles must not consume the button scan budget');
  await runtime.invoke(pageId,controls.snapshotId,button.nodeId);await page.waitForFunction(()=>document.querySelector('#result').textContent==='中文 sqlite3');
  fields=await runtime.fields(pageId,'Quick search');field=fields.fields[0];
  await page.locator('#search').fill('changed by APP');
  await assert.rejects(()=>runtime.setText(pageId,fields.snapshotId,field.nodeId,'must not overwrite'),e=>e instanceof TextInputRefusal&&e.message==='stale_field');
  assert.equal(await page.locator('#search').inputValue(),'changed by APP');
  fields=await runtime.fields(pageId,'Readonly');field=fields.fields[0];assert.equal(field.canSetText,false);
  await assert.rejects(()=>runtime.setText(pageId,fields.snapshotId,field.nodeId,'must not edit'),e=>e instanceof TextInputRefusal&&e.message==='field_not_editable');
  fields=await runtime.fields(pageId,'Notes');field=fields.fields[0];
  runtime.config.allowTextInput=false;
  await assert.rejects(()=>runtime.setText(pageId,fields.snapshotId,field.nodeId,'denied'),e=>e instanceof TextInputRefusal&&e.message==='browser_text_input_not_authorized');
  runtime.config.allowTextInput=true;
  assert.equal((await runtime.setText(pageId,fields.snapshotId,field.nodeId,'permitted')).textVerified,true);
  fields=await runtime.fields(pageId,'Notes');field=fields.fields[0];
  await page.locator('#notes').evaluate(el=>el.setAttribute('data-private',''));
  await assert.rejects(()=>runtime.setText(pageId,fields.snapshotId,field.nodeId,'private'),e=>e instanceof TextInputRefusal&&e.message==='stale_field');
});
