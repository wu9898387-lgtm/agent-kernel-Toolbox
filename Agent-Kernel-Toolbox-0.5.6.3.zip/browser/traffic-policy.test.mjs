import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {existsSync} from 'node:fs';
import {TrafficPolicy,validateTrafficPolicy,retryAfterMilliseconds} from './traffic-policy.mjs';
import {RuntimeBrowser,validateConfig} from './runtime.mjs';

const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const pageHTML='<!doctype html><title>Traffic policy owned fixture</title><link rel="icon" href="data:,">';
const executablePath=process.env.RUNTIME_CHROMIUM||(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
function config(origin,limits={}){return {maxRequests:50,maxConcurrent:8,maxQueued:64,queueTimeoutMs:5000,
  defaultCooldownMs:100,maxCooldownMs:2000,origins:[{origin,minIntervalMs:0,maxConcurrent:2,maxRequests:50}],...limits};}
function fake(url,continued,aborted){const request={url:()=>url};return {request:()=>request,
  continue:async()=>{continued.push(request);},abort:async()=>{aborted.push(request);}};}

test('traffic operator config is canonical, bounded and explicit about owned Chromium coverage',async()=>{
  const base='https://example.com';
  assert.equal(validateTrafficPolicy(undefined),undefined);
  for(const value of [null,false,{},config(base,{arbitraryScript:'x'}),config(base,{maxRequests:0}),
    config(base,{maxQueued:513}),config(base,{queueTimeoutMs:Infinity}),config(base,{maxConcurrent:true}),
    config(base,{defaultCooldownMs:3000,maxCooldownMs:2000}),config(base,{origins:[{origin:base,minIntervalMs:0,maxConcurrent:0,maxRequests:1}]}),
    config(base,{origins:[{origin:'https://user:secret@example.com',minIntervalMs:0,maxConcurrent:1,maxRequests:1}]})])
    assert.throws(()=>validateTrafficPolicy(value),/traffic/);
  assert.throws(()=>validateTrafficPolicy(config(base,{origins:[
    {origin:'https://EXAMPLE.com:443',minIntervalMs:0,maxConcurrent:1,maxRequests:10},
    {origin:base,minIntervalMs:0,maxConcurrent:1,maxRequests:10}]})),/duplicate_traffic_origin/);
  assert.throws(()=>validateTrafficPolicy(config(base,{origins:[
    {origin:base,group:'backend',minIntervalMs:10,maxConcurrent:1,maxRequests:10},
    {origin:'https://alias.example.com',group:'backend',minIntervalMs:0,maxConcurrent:1,maxRequests:10}]})),/inconsistent_traffic_group_limits/);
  assert.throws(()=>validateConfig({allowedOrigins:[base],engine:'firefox',trafficPolicy:config(base)}),/owned_chromium/);
  await assert.rejects(RuntimeBrowser.connect({trafficPolicy:config(base)}),/requires_owned_launch/);
});

test('Retry-After accepts seconds and HTTP date, clamps values and never interprets header text as code',()=>{
  const now=Date.parse('Fri, 13 Nov 2026 12:00:00 GMT');
  assert.equal(retryAfterMilliseconds('2',{now,maximum:5000}),2000);
  assert.equal(retryAfterMilliseconds('9999999999',{now,maximum:5000}),5000);
  assert.equal(retryAfterMilliseconds('Fri, 13 Nov 2026 12:00:03 GMT',{now,maximum:5000}),3000);
  assert.equal(retryAfterMilliseconds('Fri, 13 Nov 2026 11:59:00 GMT',{now,maximum:5000}),0);
  for(const value of [undefined,'1.5','-1','0; run()','x'.repeat(129),'1\n2'])
    assert.equal(retryAfterMilliseconds(value,{now,fallback:80,maximum:5000}),80);
});

test('one admission per request and same logical-origin group cannot overspend total budget',async()=>{
  const continued=[],aborted=[];
  const policy=new TrafficPolicy({maxRequests:2,maxConcurrent:4,maxQueued:8,queueTimeoutMs:1000,
    origins:[{origin:'https://a.test',group:'shared',minIntervalMs:0,maxConcurrent:4,maxRequests:2},
             {origin:'https://b.test',group:'shared',minIntervalMs:0,maxConcurrent:4,maxRequests:2}]});
  const routes=[fake('https://a.test/1',continued,aborted),fake('https://b.test/2',continued,aborted),fake('https://a.test/3',continued,aborted)];
  await Promise.all(routes.map(route=>policy.handle(route)));
  await policy.handle(routes[0]); // A duplicate callback cannot spend or send a second time.
  assert.equal(continued.length,2);assert.equal(aborted.length,2);
  assert.equal(policy.snapshot().counts.admitted,2);assert.equal(policy.snapshot().groups.length,1);
  assert.equal(policy.snapshot().counts.duplicatesBlocked,1);
  continued.forEach(request=>policy.finished(request));await policy.close();
  assert.equal(policy.snapshot().counts.active,0);
});

test('queue deadlines and close settle bounded pending routes without releasing a live request early',async()=>{
  const continued=[],aborted=[];
  const policy=new TrafficPolicy(config('https://a.test',{maxQueued:2,queueTimeoutMs:25,
    origins:[{origin:'https://a.test',minIntervalMs:0,maxConcurrent:1,maxRequests:50}]}));
  const active=fake('https://a.test/active',continued,aborted);await policy.handle(active);
  const first=policy.handle(fake('https://a.test/queued1',continued,aborted));
  const second=policy.handle(fake('https://a.test/queued2',continued,aborted));
  await policy.handle(fake('https://a.test/overflow',continued,aborted));
  await Promise.all([first,second]);
  assert.equal(continued.length,1);assert.equal(aborted.length,3);
  assert.equal(policy.snapshot().counts.queueTimeouts,2);assert.equal(policy.snapshot().counts.active,1);
  const waiting=policy.handle(fake('https://a.test/close',continued,aborted));await policy.close();await waiting;
  policy.contextDidClose();assert.equal(policy.snapshot().counts.active,0);
  assert.equal(policy.snapshot().counts.queued,0);assert.equal(policy.timer,null);
});

async function fixture(t){
  const hits=[],held=[];let active=0,peak=0,upgrades=0;
  const handler=which=>(request,response)=>{
    const url=new URL(request.url,'http://fixture');
    const hit={which,path:url.pathname,method:request.method,at:performance.now(),ended:false};hits.push(hit);
    active++;peak=Math.max(peak,active);response.once('close',()=>{if(!hit.ended){hit.ended=true;active--;}});
    response.setHeader('access-control-allow-origin','*');
    if(url.pathname==='/limited'||url.pathname==='/busy-post'){
      hit.respondedAt=performance.now();response.writeHead(url.pathname==='/limited'?429:503,{'retry-after':'1'});response.end('backoff');return;
    }
    if(url.pathname==='/redirect'||url.pathname==='/redirect-post'){
      response.writeHead(url.pathname==='/redirect'?302:307,{location:api.second+'/redirected'});response.end();return;
    }
    if(url.pathname==='/held'){held.push(response);return;}
    if(url.pathname.startsWith('/slow')){setTimeout(()=>response.end('slow'),140);return;}
    if(url.pathname==='/worker.js'){response.setHeader('content-type','application/javascript');response.end("fetch('/worker-fetch')");return;}
    if(url.pathname==='/'||url.pathname==='/other'){response.setHeader('content-type','text/html');response.end(pageHTML);return;}
    response.end('okay');
  };
  const first=createServer(handler('first')),second=createServer(handler('second'));
  for(const server of [first,second])server.on('upgrade',(_request,socket)=>{upgrades++;socket.destroy();});
  await Promise.all([first,second].map(server=>new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))));
  const api={first:`http://127.0.0.1:${first.address().port}`,second:`http://127.0.0.1:${second.address().port}`,hits,
    get active(){return active;},get peak(){return peak;},get upgrades(){return upgrades;},
    async until(path){const until=performance.now()+5000;while(!hits.some(hit=>hit.path===path)){assert.ok(performance.now()<until,'server did not observe '+path);await pause(5);}}};
  t.after(async()=>{held.forEach(response=>response.destroy());for(const server of [first,second])server.closeAllConnections();await Promise.all([first,second].map(server=>new Promise(resolve=>server.close(resolve))));});
  return api;
}
async function runtime(t,origins,trafficPolicy,extra={}){
  const browser=await RuntimeBrowser.launch({allowedOrigins:origins,headless:true,executablePath,trafficPolicy,...extra});
  t.after(()=>browser.close());return browser;
}

test('real Chromium policy mediates shared tabs, spacing/concurrency,429/503 cooldown and never repeats POST', {timeout:90000},async t=>{
  const server=await fixture(t),origins=[server.first,server.second];
  const policy=config(server.first,{maxRequests:80,origins:origins.map(origin=>({origin,group:'same-backend',minIntervalMs:75,maxConcurrent:2,maxRequests:80}))});
  const browser=await runtime(t,origins,policy,{blockedRequests:[{origin:server.first,pathPrefix:'/operator-denied'}]});
  const first=await browser.open(server.first+'/'),second=await browser.open(server.second+'/other');
  const page=browser.pages.get(first.pageId).page,other=browser.pages.get(second.pageId).page;
  await Promise.all([page.evaluate(()=>Promise.all([1,2].map(value=>fetch('/slow'+value).then(response=>response.text())))),
    other.evaluate(()=>Promise.all([3,4].map(value=>fetch('/slow'+value).then(response=>response.text()))))]);
  const firstPhase=server.hits.filter(hit=>hit.path.startsWith('/slow'));
  assert.equal(firstPhase.length,4);assert.ok(server.peak<=2,{peak:server.peak});
  for(let index=1;index<firstPhase.length;index++)assert.ok(firstPhase[index].at-firstPhase[index-1].at>=50,'dispatch interval was not observed at loopback server');
  assert.equal(browser.capabilities().trafficPolicy.counts.admitted,server.hits.length,'page/CDP handlers spent a duplicate admission');
  assert.equal(browser.capabilities().trafficPolicy.groups.length,1,'logical origin aliases split their budget');
  assert.equal(await page.evaluate(()=>fetch('/limited?private=not-logged').then(response=>response.status)),429);
  await page.evaluate(()=>fetch('/after429').then(response=>response.text()));
  const limited=server.hits.find(hit=>hit.path==='/limited'),after429=server.hits.find(hit=>hit.path==='/after429');
  assert.ok(after429.at-limited.respondedAt>=900,'429 Retry-After cooldown was skipped');
  assert.equal(await page.evaluate(()=>fetch('/busy-post',{method:'POST',body:'single-effect'}).then(response=>response.status)),503);
  await page.evaluate(()=>fetch('/after503').then(response=>response.text()));
  const busy=server.hits.find(hit=>hit.path==='/busy-post'),after503=server.hits.find(hit=>hit.path==='/after503');
  assert.ok(after503.at-busy.respondedAt>=900,'503 Retry-After cooldown was skipped');
  assert.equal(server.hits.filter(hit=>hit.path==='/busy-post'&&hit.method==='POST').length,1);
  assert.equal(await page.evaluate(()=>fetch('/operator-denied').then(()=>false).catch(()=>true)),true);
  assert.equal(server.hits.some(hit=>hit.path==='/operator-denied'),false);
  assert.equal(browser.capabilities().trafficPolicy.faulted,false,'an existing block rule tainted the traffic transport');
  const serialized=JSON.stringify(browser.events.filter(event=>event.kind==='traffic_policy'));
  assert.equal(serialized.includes('not-logged'),false);assert.equal(serialized.includes('single-effect'),false);
  console.log('TRAFFIC_POLICY_REAL '+JSON.stringify({serverRequests:server.hits.length,peakConcurrent:server.peak,
    intervalSamplesMs:firstPhase.slice(1).map((hit,index)=>Math.round(hit.at-firstPhase[index].at)),
    retryAfter429Ms:Math.round(after429.at-limited.respondedAt),retryAfter503Ms:Math.round(after503.at-busy.respondedAt),
    postAttempts:server.hits.filter(hit=>hit.path==='/busy-post').length,counters:browser.capabilities().trafficPolicy.counts}));
});

test('real Chromium redirects,popups,unregistered tabs,workers and WebSocket do not escape the gate',{timeout:90000},async t=>{
  const server=await fixture(t),browser=await runtime(t,[server.first],config(server.first));
  const {pageId}=await browser.open(server.first+'/'),page=browser.pages.get(pageId).page;
  assert.equal(await page.evaluate(()=>fetch('/redirect').then(()=>false).catch(()=>true)),true);
  assert.equal(await page.evaluate(()=>fetch('/redirect-post',{method:'POST',body:'one-post'}).then(()=>false).catch(()=>true)),true);
  assert.equal(server.hits.filter(hit=>hit.path==='/redirect-post').length,1);
  assert.equal(server.hits.some(hit=>hit.path==='/redirected'),false,'an automatic redirect hop reached the server');
  await page.evaluate(()=>{window.open('/popup?private=discarded','traffic-popup');});await pause(150);
  const unregistered=await browser.context.newPage();await assert.rejects(unregistered.goto(server.first+'/unregistered'));await unregistered.close();
  assert.equal(server.hits.some(hit=>hit.path==='/popup'||hit.path==='/unregistered'),false);
  const workers=await page.evaluate(()=>['Worker','SharedWorker'].map(name=>{try{new globalThis[name]('/worker.js');return 'unexpected';}catch(error){return error.name;}}));
  assert.deepEqual(workers,['SecurityError','SecurityError']);
  assert.equal(server.hits.some(hit=>hit.path==='/worker.js'||hit.path==='/worker-fetch'),false);
  const ws=await page.evaluate(()=>new Promise(resolve=>{const socket=new WebSocket(location.origin.replace('http:','ws:')+'/socket');
    socket.onopen=()=>resolve('opened');socket.onerror=()=>resolve('blocked');socket.onclose=()=>resolve('blocked');setTimeout(()=>resolve('timeout'),1000);}));
  assert.equal(ws,'blocked');assert.equal(server.upgrades,0,'websocket handshake bypassed HTTP policy');
  const capability=browser.capabilities().trafficPolicy;
  assert.equal(capability.counts.redirectsBlocked,2);assert.equal(capability.counts.websocketsBlocked,1);
  assert.ok(capability.counts.unregisteredTargetsBlocked>=1);assert.equal(capability.faulted,false);
});

test('real total budget denies additional actual HTTP requests',{timeout:90000},async t=>{
  const server=await fixture(t),policy=config(server.first,{maxRequests:3,
    origins:[{origin:server.first,minIntervalMs:0,maxConcurrent:2,maxRequests:3}]});
  const browser=await runtime(t,[server.first],policy),{pageId}=await browser.open(server.first+'/');
  const result=await browser.pages.get(pageId).page.evaluate(()=>Promise.all([1,2,3].map(number=>fetch('/budget'+number).then(()=>true).catch(()=>false))));
  assert.equal(result.filter(Boolean).length,2);assert.equal(server.hits.length,3);
  const counts=browser.capabilities().trafficPolicy.counts;assert.equal(counts.admitted,3);assert.equal(counts.budgetDenials,1);
});

test('real queued deadlines and context close settle pending routes and abort the held request',{timeout:90000},async t=>{
  const server=await fixture(t),policy=config(server.first,{maxQueued:2,queueTimeoutMs:150,
    origins:[{origin:server.first,minIntervalMs:0,maxConcurrent:1,maxRequests:50}]});
  const browser=await runtime(t,[server.first],policy),{pageId}=await browser.open(server.first+'/'),page=browser.pages.get(pageId).page;
  await page.evaluate(()=>{globalThis.held=fetch('/held').then(()=>true).catch(()=>false);});await server.until('/held');
  const result=await page.evaluate(()=>Promise.all([1,2,3].map(number=>fetch('/queue'+number).then(()=>true).catch(()=>false))));
  assert.deepEqual(result,[false,false,false]);
  assert.equal(server.hits.some(hit=>hit.path.startsWith('/queue')),false);
  assert.equal(browser.capabilities().trafficPolicy.counts.queueTimeouts,2);
  assert.equal(browser.capabilities().trafficPolicy.counts.queueOverflows,1);
  await page.evaluate(()=>{globalThis.pending=Promise.all([1,2].map(number=>fetch('/close'+number).then(()=>true).catch(()=>false)));});
  const until=performance.now()+1000;while(browser.capabilities().trafficPolicy.counts.queued===0&&performance.now()<until)await pause(5);
  assert.ok(browser.capabilities().trafficPolicy.counts.queued>0);
  await browser.close();const snapshot=browser.capabilities().trafficPolicy;
  assert.equal(snapshot.closed,true);assert.equal(snapshot.contextClosed,true);
  assert.equal(snapshot.counts.active,0);assert.equal(snapshot.counts.queued,0);assert.equal(browser.traffic.timer,null);
  assert.equal(server.hits.some(hit=>hit.path.startsWith('/close')),false);
});
