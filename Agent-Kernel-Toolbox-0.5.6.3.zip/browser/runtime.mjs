/** Selected Chromium runtime access. Page content is untrusted observation data. */
import {createRequire} from 'node:module';
import {randomUUID, createHash} from 'node:crypto';
import {RouteEvidence} from './route-evidence.mjs';
import {validateQuery, captureQuery} from './semantic-query.mjs';
import {PortableEvidence} from './portable-evidence.mjs';
import {describeTextField,TextInputRefusal} from './text-input.mjs';
import {TrafficPolicy,validateTrafficPolicy,installTrafficTransportGuards} from './traffic-policy.mjs';

const MAX_NODES = 256, MAX_TEXT = 262144, MAX_FRAMES = 16, MAX_RULES = 256;
const MAX_EVENTS = 512, SNAPSHOT_TTL = 30000;
const TYPES = new Set(['Document','Stylesheet','Image','Media','Font','Script','TextTrack','XHR','Fetch','Ping','Manifest','Other']);
const METRICS = new Set(['Timestamp','Documents','Frames','JSEventListeners','Nodes','LayoutCount','RecalcStyleCount','LayoutDuration','RecalcStyleDuration','ScriptDuration','TaskDuration','JSHeapUsedSize','JSHeapTotalSize']);
const CONTROL_SELECTOR='a[href],button,input[type="submit" i],input[type="button" i],input[type="reset" i],[role="link"],[role="button"],[role="tab"],[role="menuitem"]';
// Filter by requested role before per-handle protocol calls; describeElement still
// checks the actual role, visibility and privacy before retaining a control.
const CONTROL_ROLE_SELECTORS=new Map([
  ['button','button,input[type="submit" i],input[type="button" i],input[type="reset" i],[role="button"]'],
  ['link','a[href],[role="link"]'],['tab','[role="tab"]'],['menuitem','[role="menuitem"]']
]);

function fail(code) { throw new Error(code); }
export class ObservedControlRefusal extends Error {}
function text(value, max = 4096) {
  if (typeof value !== 'string' || value.length > max || /[\u0000-\u001f\u007f]/u.test(value)) fail('invalid_text');
  return value;
}
export function origin(value) {
  const u = new URL(text(value));
  if (!['http:','https:'].includes(u.protocol) || u.username || u.password || u.pathname !== '/' || u.search || u.hash) fail('invalid_origin');
  return u.origin;
}
export function sanitizedUrl(value) {
  try {
    const u = new URL(value);
    if (!['http:','https:'].includes(u.protocol) || u.username || u.password) return null;
    const route = u.hash.startsWith('#/') ? u.hash.split('?')[0].slice(0,512) : '';
    return `${u.origin}${u.pathname.slice(0,2048)}${route}`;
  } catch { return null; }
}
export function validateRule(rule) {
  if (!rule || typeof rule !== 'object' || Array.isArray(rule)) fail('invalid_rule');
  if (Object.keys(rule).some(k => !['origin','pathPrefix','resourceTypes'].includes(k))) fail('invalid_rule');
  const result = {origin: origin(rule.origin), pathPrefix: text(rule.pathPrefix ?? '/', 1024)};
  if (!result.pathPrefix.startsWith('/') || /[?#]/u.test(result.pathPrefix)) fail('invalid_path_prefix');
  if (rule.resourceTypes !== undefined) {
    if (!Array.isArray(rule.resourceTypes) || !rule.resourceTypes.length || rule.resourceTypes.length > TYPES.size || rule.resourceTypes.some(t => !TYPES.has(t))) fail('invalid_resource_types');
    result.resourceTypes = [...new Set(rule.resourceTypes)];
  }
  return Object.freeze(result);
}
export function matchesRule(rule, url, type) {
  try { const u = new URL(url); return u.origin === rule.origin && u.pathname.startsWith(rule.pathPrefix) && (!rule.resourceTypes || rule.resourceTypes.includes(type)); }
  catch { return false; }
}
function validateCosmetic(rule) {
  if (!rule || typeof rule !== 'object' || Array.isArray(rule) || Object.keys(rule).some(k => !['origin','selector'].includes(k))) fail('invalid_cosmetic_rule');
  const selector = text(rule.selector,512);
  if (!selector.trim() || /[{};]/u.test(selector) || ['*','html','body',':root'].includes(selector.trim())) fail('invalid_selector');
  return Object.freeze({origin: origin(rule.origin), selector});
}
export function validateConfig(config) {
  if (!config || !Array.isArray(config.allowedOrigins) || !config.allowedOrigins.length || config.allowedOrigins.length > 64) fail('allowed_origins_required');
  const allowedOrigins = [...new Set(config.allowedOrigins.map(origin))];
  const engine=config.engine??'chromium';
  if(!['chromium','firefox','webkit'].includes(engine))fail('unsupported_browser_engine');
  const blockedRequests = config.blockedRequests ?? [], cosmeticRules = config.cosmeticRules ?? [];
  if (!Array.isArray(blockedRequests) || blockedRequests.length > MAX_RULES || !Array.isArray(cosmeticRules) || cosmeticRules.length > MAX_RULES) fail('rule_budget');
  const timeoutMs = config.timeoutMs ?? 10000;
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 30000) fail('invalid_timeout');
  if (config.includeEditableText !== undefined && typeof config.includeEditableText !== 'boolean') fail('invalid_editable_text_option');
  if(config.allowTextInput!==undefined&&typeof config.allowTextInput!=='boolean')fail('invalid_text_input_option');
  let proxy;
  if(config.proxy!==undefined){
    if(!config.proxy||typeof config.proxy!=='object'||Array.isArray(config.proxy)||Object.keys(config.proxy).some(k=>k!=='server')||typeof config.proxy.server!=='string')fail('invalid_proxy');
    const u=new URL(config.proxy.server);
    if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.pathname!=='/'||u.search||u.hash||u.port==='0')fail('invalid_proxy');
    proxy={server:u.origin};
  }
  const validatedCosmetics=cosmeticRules.map(validateCosmetic);
  if(validatedCosmetics.some(r=>!allowedOrigins.includes(r.origin)))fail('cosmetic_origin_not_allowed');
  const trafficPolicy=validateTrafficPolicy(config.trafficPolicy,allowedOrigins);
  if(trafficPolicy&&engine!=='chromium')fail('traffic_policy_requires_owned_chromium');
  return {engine,allowedOrigins, blockedRequests:blockedRequests.map(validateRule), cosmeticRules:validatedCosmetics, timeoutMs,includeEditableText:config.includeEditableText===true,allowTextInput:config.allowTextInput===true,proxy,trafficPolicy};
}
function playwright() {
  const require = createRequire(import.meta.url);
  try { return require('playwright'); }
  catch (e) {
    if (e.code !== 'MODULE_NOT_FOUND') throw e;
    if (!process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES) fail('playwright_not_installed');
    return require(`${process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES}/playwright`);
  }
}
function fingerprint(v) { return createHash('sha256').update(JSON.stringify(v)).digest('hex'); }
function captureDocument({maxText,includeEditableText}) {
  const blocked = 'input,textarea,select,[data-sensitive],[data-private],[aria-hidden="true"],script,style,noscript,template'+(includeEditableText?'':',[contenteditable]:not([contenteditable="false"])');
  const chunks = [];
  let bytes = 0, visited = 0, truncated = false;
  const walker = document.createTreeWalker(document.body ?? document.documentElement, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    if (++visited > 20000) { truncated = true; break; }
    const n = walker.currentNode, p = n.parentElement;
    if (!p || p.closest(blocked)) continue;
    const css = getComputedStyle(p);
    if (css.display === 'none' || css.visibility === 'hidden' || !p.getClientRects().length) continue;
    const part = n.nodeValue.replace(/\s+/gu,' ').trim();
    if (!part) continue;
    if (bytes + part.length > maxText) { truncated = true; break; }
    chunks.push(part); bytes += part.length;
  }
  if(includeEditableText) {
    const fields=document.querySelectorAll('textarea,input');
    for(let i=0;i<Math.min(fields.length,256);i++) {
      const el=fields[i];
      if(el.closest('[data-sensitive],[data-private],[aria-hidden="true"]') || (el.tagName==='INPUT'&&!['text','search','email','url','tel','number'].includes(el.type)) || /(?:password|one-time-code|cc-)/iu.test(el.getAttribute('autocomplete')||el.autocomplete))continue;
      const css=getComputedStyle(el);if(css.display==='none'||css.visibility==='hidden'||!el.getClientRects().length)continue;
      const value=el.value;
      if(bytes+value.length>maxText){truncated=true;break;}
      if(value){chunks.push(value);bytes+=value.length;}
    }
  }
  return {title:document.title.slice(0,512), text:chunks.join('\n'), truncated, visited};
}
function describeElement(el) {
  const privateSelector='input:not([type="submit" i]):not([type="button" i]):not([type="reset" i]),textarea,select,[contenteditable]:not([contenteditable="false"]),[data-sensitive],[data-private],[aria-hidden="true"]';
  let owner=el,sensitive=el.querySelector(privateSelector);
  while(owner){sensitive ||= owner.closest(privateSelector);owner=owner.getRootNode().host;}
  if (sensitive || !el.isConnected) return null;
  const css = getComputedStyle(el);
  if (css.display === 'none' || css.visibility === 'hidden' || !el.getClientRects().length) return null;
  const tag = el.tagName.toLowerCase();
  const inputButton=tag==='input'&&['submit','button','reset'].includes(el.type);
  const name = (el.getAttribute('aria-label') || (inputButton?el.value:el.innerText) || '').replace(/\s+/gu,' ').trim().slice(0,512);
  const role = el.getAttribute('role') || (tag === 'a' ? 'link' : tag === 'button'||inputButton ? 'button' : 'generic');
  const href = tag === 'a' ? el.href : null;
  if (href !== null && href.length > 8192) return null;
  return {tag,role,name,href,disabled:el.matches(':disabled') || el.getAttribute('aria-disabled') === 'true'};
}
function installCosmetics({rules,token}) {
  if(window.top!==window)return;
  const selected = rules.filter(r => r.origin === location.origin);
  if (!selected.length) return;
  const key=`__agentKernelCosmetics_${token}`;
  if(globalThis[key])return;
  const state={style:null,observer:null};globalThis[key]=state;
  const apply = () => {
    if (!document.documentElement) return false;
    const style = document.createElement('style');
    style.setAttribute('data-agent-kernel','cosmetic-rules');
    state.style=style;
    document.documentElement.append(style);
    for (const r of selected) {
      try { if (CSS.supports(`selector(${r.selector})`)) style.sheet.insertRule(`${r.selector} { display: none !important; }`,style.sheet.cssRules.length); }
      catch { /* Invalid selectors do not become scripts or broader selectors. */ }
    }
    return true;
  };
  if (!apply()) {
    const observer = new MutationObserver(() => { if (apply()) observer.disconnect(); });state.observer=observer;
    observer.observe(document,{childList:true});
  }
}
function removeCosmetics(token){
  const key=`__agentKernelCosmetics_${token}`,state=globalThis[key];
  if(state){state.observer?.disconnect();state.style?.remove();delete globalThis[key];}
}

export class RuntimeBrowser {
  constructor(browser, config, ownsBrowser) {
    this.browser = browser; this.config = validateConfig(config); this.ownsBrowser = ownsBrowser;
    this.allowed = new Set(this.config.allowedOrigins); this.rules = [...this.config.blockedRequests];
    this.pages = new Map(); this.workers = new Map(); this.snapshots = new Map(); this.hidden = new Map();
    this.events = []; this.eventsDropped = 0; this.closed = false;
    this.traffic=null;
    if(this.config.trafficPolicy&&!ownsBrowser)fail('traffic_policy_requires_owned_launch');
  }
  static async launch(config) {
    const {engine,proxy}=validateConfig(config);
    const browser = await playwright()[engine].launch({headless:config.headless !== false, executablePath:config.executablePath,proxy});
    const self = new RuntimeBrowser(browser,config,true);
    try{
      self.context = await browser.newContext({serviceWorkers:'block',acceptDownloads:false});
      if(self.config.trafficPolicy)await self.installTrafficPolicy();
      return self;
    }catch(error){await browser.close().catch(()=>{});throw error;}
  }
  static async connect(config) {
    if(config?.trafficPolicy!==undefined)fail('traffic_policy_requires_owned_launch');
    if(validateConfig(config).engine!=='chromium')fail('cdp_connection_requires_chromium');
    const endpoint = new URL(text(config.endpoint));
    if (!['http:','ws:'].includes(endpoint.protocol) || !['127.0.0.1','[::1]'].includes(endpoint.hostname) || endpoint.username || endpoint.password || endpoint.search || endpoint.hash) fail('loopback_cdp_required');
    if (!Array.isArray(config.targetIds) || !config.targetIds.length || config.targetIds.length > 16 || config.targetIds.some(t=>typeof t !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/u.test(t))) fail('explicit_target_ids_required');
    const browser = await playwright().chromium.connectOverCDP(endpoint.href,{timeout:config.timeoutMs ?? 10000});
    const self = new RuntimeBrowser(browser,config,false), wanted = new Set(config.targetIds);
    try {
      for (const context of browser.contexts()) for (const page of context.pages()) {
        const session = await context.newCDPSession(page);
        const {targetInfo} = await session.send('Target.getTargetInfo');
        await session.detach();
        if (wanted.has(targetInfo.targetId)) {
          self.assertURL(page.url());
          await self.register(page,false,targetInfo.targetId); wanted.delete(targetInfo.targetId);
        }
      }
      if (wanted.size) fail('target_not_found');
      return self;
    } catch (e) { await self.close(); throw e; }
  }
  async installTrafficPolicy(){
    if(!this.ownsBrowser||this.config.engine!=='chromium'||!this.context||typeof this.context.routeWebSocket!=='function')fail('traffic_policy_coverage_unavailable');
    this.traffic=new TrafficPolicy(this.config.trafficPolicy,{
      record:event=>this.record(event),
      ownsRequest:request=>{
        // Unknown popup targets and worker-originated requests have no action
        // authority here. Refuse them instead of creating an untracked bucket.
        try{const page=request.frame().page();return [...this.pages.values()].some(entry=>entry.page===page&&entry.owned&&!page.isClosed());}
        catch{return false;}
      },
      onFault:()=>this.context.close(),
    });
    this.context.on('requestfinished',request=>this.traffic.finished(request));
    this.context.on('requestfailed',request=>this.traffic.finished(request,true));
    this.context.on('response',response=>this.traffic.response(response));
    this.context.on('close',()=>this.traffic.contextDidClose());
    await this.context.route('**/*',route=>this.traffic.handle(route));
    await this.context.routeWebSocket('**/*',async socket=>{
      this.traffic.blockWebSocket(socket.url());
      try{await socket.close({code:1008,reason:'traffic_policy_websocket_blocked'});}
      catch{this.traffic.fault('websocket_close_unknown');}
    });
    await this.context.addInitScript(installTrafficTransportGuards);
  }
  assertURL(value) {
    const u = new URL(text(value,8192));
    if (!['http:','https:'].includes(u.protocol) || u.username || u.password || !this.allowed.has(u.origin)) fail('origin_not_allowed');
    return u;
  }
  record(event) {
    this.events.push({at:new Date().toISOString(),...event});
    if (this.events.length > MAX_EVENTS) { this.events.shift(); this.eventsDropped++; }
  }
  get(id) {
    if (this.closed) fail('browser_closed');
    const entry = this.pages.get(id);
    if (!entry || entry.page.isClosed()) fail('target_not_found');
    return entry;
  }
  async register(page, owned, id = randomUUID()) {
    page.setDefaultTimeout(this.config.timeoutMs); page.setDefaultNavigationTimeout(this.config.timeoutMs);
    const session = this.config.engine==='chromium'?await page.context().newCDPSession(page):null, entry = {page,session,owned,id,revision:0};
    this.pages.set(id,entry);
    const onWorker = worker => { const workerId = randomUUID(); this.workers.set(workerId,{worker,pageId:id,owned}); worker.once('close',()=>this.workers.delete(workerId)); };
    page.on('worker',onWorker); for (const worker of page.workers()) onWorker(worker);
    page.on('framenavigated',frame => { if (frame === page.mainFrame()) {
      entry.revision++;
      this.clearHides(id,entry.revision-1).catch(()=>{});
    } });
    // Unknown popups are never adopted into this instance's action authority.
    page.on('popup',popup => { this.record({kind:'unadopted_popup',pageId:id}); if (owned) popup.close().catch(()=>{}); });
    page.on('dialog',dialog => dialog.dismiss().catch(()=>{}));
    if(!session){
      entry.routes=new PortableEvidence({page,allowedOrigins:this.config.allowedOrigins});await entry.routes.start();
      await page.route('**/*',async route=>{
        const request=route.request(),url=request.url();
        const type=({document:'Document',stylesheet:'Stylesheet',image:'Image',media:'Media',font:'Font',script:'Script',texttrack:'TextTrack',xhr:'XHR',fetch:'Fetch',eventsource:'Other',websocket:'Other',manifest:'Manifest',other:'Other'})[request.resourceType()]??'Other';
        const blocked=this.rules.some(rule=>matchesRule(rule,url,type));
        let denied=false;if(type==='Document'){try{this.assertURL(url);}catch{denied=true;}}
        this.record({kind:blocked||denied?'request_blocked':'request_allowed',pageId:id,url:sanitizedUrl(url),resourceType:type,reason:denied?'origin_scope':blocked?'block_rule':null});
        try{await(blocked||denied?route.abort('blockedbyclient'):route.continue());}
        catch{this.record({kind:'request_resolution_unknown',pageId:id});}
      });
      entry.cosmeticToken=randomUUID();const args={rules:this.config.cosmeticRules,token:entry.cosmeticToken};
      await page.addInitScript(installCosmetics,args);
      if(page.url()!=='about:blank')await page.evaluate(installCosmetics,args);
      return entry;
    }
    // The Page domain must be enabled for this session's new-document scripts.
    await session.send('Page.enable');
    entry.routes=new RouteEvidence({session,page,allowedOrigins:this.config.allowedOrigins});
    await entry.routes.start();
    await session.send('Network.enable');
    await session.send('Network.setBypassServiceWorker',{bypass:true});
    await session.send('Network.setCacheDisabled',{cacheDisabled:true});
    await session.send('Performance.enable');
    session.on('Fetch.requestPaused',async event => {
      if(this.traffic&&(event.responseStatusCode!==undefined||event.responseErrorReason!==undefined)){
        // Playwright context.route does not intercept redirect hops. Stop 3xx
        // responses before Chromium follows them, including cross-origin 307
        // POST redirects. Never fetch/retry/replay the original request.
        const redirect=event.responseStatusCode>=300&&event.responseStatusCode<400;
        if(redirect)this.traffic.blockRedirect(event.request.url);
        try{
          if(redirect||event.responseErrorReason)await session.send('Fetch.failRequest',{requestId:event.requestId,errorReason:'BlockedByClient'});
          else await session.send('Fetch.continueResponse',{requestId:event.requestId});
        }catch{this.traffic.fault('response_resolution_unknown');}
        return;
      }
      const url = event.request.url, type = event.resourceType;
      const blocked = this.rules.some(r=>matchesRule(r,url,type));
      let documentDenied = false;
      if (type === 'Document') { try { this.assertURL(url); } catch { documentDenied = true; } }
      this.record({kind:blocked || documentDenied ? 'request_blocked':'request_allowed',pageId:id,url:sanitizedUrl(url),resourceType:type,reason:documentDenied?'origin_scope':blocked?'block_rule':null});
      try { await session.send(blocked || documentDenied ? 'Fetch.failRequest':'Fetch.continueRequest', blocked || documentDenied ? {requestId:event.requestId,errorReason:'BlockedByClient'} : {requestId:event.requestId}); }
      catch { this.record({kind:'request_resolution_unknown',pageId:id}); }
    });
    await session.send('Fetch.enable',{patterns:[{urlPattern:'*',requestStage:'Request'},
      ...this.traffic?[{urlPattern:'*',requestStage:'Response'}]:[]]});
    entry.cosmeticToken=randomUUID();entry.cosmeticWorld=`ak-cosmetics-${entry.cosmeticToken}`;
    const args={rules:this.config.cosmeticRules,token:entry.cosmeticToken};
    const {identifier}=await session.send('Page.addScriptToEvaluateOnNewDocument',{source:`(${installCosmetics.toString()})(${JSON.stringify(args)})`,worldName:entry.cosmeticWorld});
    entry.cosmeticScriptId=identifier;
    if (page.url() !== 'about:blank') await this.inCosmeticWorld(entry,installCosmetics,args);
    return entry;
  }
  async inCosmeticWorld(entry,fn,arg){
    if(!entry.session)return await entry.page.evaluate(fn,arg);
    const {frameTree}=await entry.session.send('Page.getFrameTree');
    const {executionContextId}=await entry.session.send('Page.createIsolatedWorld',{frameId:frameTree.frame.id,worldName:entry.cosmeticWorld});
    const result=await entry.session.send('Runtime.evaluate',{expression:`(${fn.toString()})(${JSON.stringify(arg)})`,contextId:executionContextId,returnByValue:true});
    if(result.exceptionDetails)fail('cosmetic_operation_failed');
  }
  async open(url) {
    this.assertURL(url);
    if (!this.ownsBrowser || !this.context) fail('attached_session_cannot_create_targets');
    if (this.pages.size >= 16) fail('target_budget');
    const page = await this.context.newPage();
    const entry = await this.register(page,true);
    try { await page.goto(url,{waitUntil:'domcontentloaded'}); this.assertURL(page.url()); }
    catch (e) { await page.close(); this.pages.delete(entry.id); throw e; }
    return {pageId:entry.id,url:sanitizedUrl(page.url())};
  }
  async targets() {
    return {pages:[...this.pages.values()].filter(e=>!e.page.isClosed()).map(e=>({pageId:e.id,url:sanitizedUrl(e.page.url()),owned:e.owned})),workers:[...this.workers.entries()].map(([id,e])=>({workerId:id,pageId:e.pageId,url:sanitizedUrl(e.worker.url()),owned:e.owned}))};
  }
  capabilities(){
    const cdp=this.config.engine==='chromium';
    return {engine:this.config.engine,version:this.browser.version(),dom:true,openShadowDOM:true,
      observedControlQuery:true,plainTextFieldObservation:this.config.includeEditableText,
      plainTextInput:this.config.includeEditableText&&this.config.allowTextInput,
      networkObservation:true,requestBlocking:true,cdp,attachExistingTargets:cdp,
      scriptSources:cdp?'observed_default_realm':'observed_inline_only',initiatorStacks:cdp,
      navigationMode:cdp?'browser_history_entry':'observed_url_reload',nativeProcessMemory:false,
      trafficPolicy:this.traffic?.snapshot()??{enabled:false}};
  }
  async controls(pageId,query='',role='',limit=32){
    if(typeof query!=='string'||query.length>256||!['','button','link','tab','menuitem'].includes(role)||!Number.isSafeInteger(limit)||limit<1||limit>64)fail('invalid_control_query');
    return this.snapshot(pageId,{query,role,limit});
  }
  async snapshot(pageId,selection=null) {
    const entry = this.get(pageId); this.assertURL(entry.page.url());
    await this.releaseSnapshots(pageId);
    const revision = entry.revision, snapshotId = randomUUID(), nodes = new Map(), frames = [];
    const allocated=new Set();let retained=false;
    let chars = 0,examined=0;
    const deadline=Date.now()+this.config.timeoutMs;
    const allFrames = entry.page.frames();
    try {
    for (const [frameIndex,frame] of allFrames.slice(0,MAX_FRAMES).entries()) {
      try { this.assertURL(frame.url()); } catch { frames.push({frameIndex,status:'origin_denied'}); continue; }
      const frameUrl = frame.url();
      const doc = selection?{title:await frame.evaluate(()=>document.title.slice(0,512)),text:'',truncated:false,visited:0}:
        await frame.evaluate(captureDocument,{maxText:Math.max(0,MAX_TEXT-chars),includeEditableText:this.config.includeEditableText});
      chars += doc.text.length;
      const candidates = frame.locator(CONTROL_ROLE_SELECTORS.get(selection?.role)??CONTROL_SELECTOR);
      const count = Math.min(await candidates.count(),selection?5000-examined:MAX_NODES-nodes.size);
      const exported = [];
      for (let i=0;i<count;i++) {
        if(selection&&(nodes.size>=selection.limit||Date.now()>=deadline))break;
        examined++;const handle=await candidates.nth(i).elementHandle();if(!handle)continue;allocated.add(handle);
        if (nodes.size >= MAX_NODES) { await handle.dispose(); continue; }
        const value = await handle.evaluate(describeElement);
        if (!value || selection&&((selection.role&&value.role!==selection.role)||!value.name.toLocaleLowerCase().includes(selection.query.toLocaleLowerCase()))) { await handle.dispose(); continue; }
        const nodeId = randomUUID();
        const navigation = (value.tag === 'a' || value.role === 'link') && (value.href === null || sanitizedUrl(value.href) !== null);
        nodes.set(nodeId,{handle,frame,frameUrl,value,fingerprint:fingerprint(value),navigation});
        exported.push({nodeId,role:value.role,name:value.name,href:sanitizedUrl(value.href),disabled:value.disabled,navigation});
      }
      if (frame.url() !== frameUrl) fail('frame_changed_during_snapshot');
      frames.push({frameIndex,url:sanitizedUrl(frameUrl),...doc,nodes:exported});
      if(selection&&(nodes.size>=selection.limit||examined>=5000||Date.now()>=deadline))break;
    }
    if (entry.revision !== revision) fail('page_changed_during_snapshot');
    this.snapshots.set(snapshotId,{pageId,revision,created:Date.now(),nodes});
    retained=true;
    return {schemaVersion:1,observationOnly:true,sourceAuthenticated:false,executionAuthorized:false,includeEditableText:this.config.includeEditableText,pageId,snapshotId,revision,frames,
      queryApplied:selection!==null,documentTextIncluded:selection===null,controlsExamined:examined,
      truncated:allFrames.length>MAX_FRAMES || nodes.size>=MAX_NODES || chars>=MAX_TEXT || !!selection&&(nodes.size>=selection.limit||examined>=5000||Date.now()>=deadline)};
    } finally { if(!retained)for(const handle of allocated)await handle.dispose().catch(()=>{}); }
  }
  async query(pageId,options={}) {
    const settings=validateQuery(options),entry=this.get(pageId);this.assertURL(entry.page.url());
    const revision=entry.revision,allFrames=entry.page.frames(),frames=[];
    let remainingNodes=settings.maxNodes,remainingBytes=settings.maxTextBytes,truncated=allFrames.length>MAX_FRAMES;
    for(const [frameIndex,frame] of allFrames.slice(0,MAX_FRAMES).entries()){
      try{this.assertURL(frame.url());}catch{frames.push({frameIndex,status:'origin_denied'});continue;}
      const frameUrl=frame.url();
      const result=await frame.evaluate(captureQuery,{...settings,maxNodes:remainingNodes,maxTextBytes:remainingBytes});
      if(frame.url()!==frameUrl||entry.revision!==revision)fail('page_changed_during_query');
      remainingNodes-=result.nodes.length;remainingBytes-=result.textBytes;truncated ||= result.truncated;
      frames.push({frameIndex,url:sanitizedUrl(frameUrl),...result,nodes:result.nodes.map(n=>({...n,href:sanitizedUrl(n.href)}))});
      if(!remainingNodes||!remainingBytes){truncated ||= frames.length<allFrames.length;break;}
    }
    if(entry.revision!==revision)fail('page_changed_during_query');
    return {schemaVersion:1,pageId,revision,frames,truncated,observationOnly:true,sourceAuthenticated:false,
      executionAuthorized:false,actionsIssued:false,queryMode:'literal_case_insensitive',closedShadowRootsReadable:false};
  }
  async releaseSnapshots(pageId) {
    for (const [id,s] of this.snapshots) if (s.pageId === pageId) {
      for (const e of s.nodes.values()) await e.handle.dispose().catch(()=>{});
      this.snapshots.delete(id);
    }
  }
  async fields(pageId,query='',limit=16) {
    if(!this.config.includeEditableText)fail('editable_field_observation_not_authorized');
    if(typeof query!=='string'||query.length>256||!Number.isSafeInteger(limit)||limit<1||limit>32)fail('invalid_field_query');
    const entry=this.get(pageId);this.assertURL(entry.page.url());await this.releaseSnapshots(pageId);
    const revision=entry.revision,snapshotId=randomUUID(),nodes=new Map(),fields=[],allFrames=entry.page.frames();let retained=false,truncated=allFrames.length>MAX_FRAMES,examined=0;
    try{
      for(const [frameIndex,frame] of allFrames.slice(0,MAX_FRAMES).entries()){
        try{this.assertURL(frame.url());}catch{continue;}
        const frameUrl=frame.url(),candidates=frame.locator('input,textarea'),count=await candidates.count();
        if(count>256)truncated=true;
        for(let i=0;i<Math.min(count,256);i++){
          examined++;const handle=await candidates.nth(i).elementHandle();if(!handle)continue;
          let kept=false;
          try{
            const value=await handle.evaluate(describeTextField);
            if(!value||!`${value.name} ${value.labels.join(' ')}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()))continue;
            const nodeId=randomUUID();nodes.set(nodeId,{handle,frame,frameUrl,value,fingerprint:fingerprint(value)});kept=true;
            fields.push({nodeId,frameIndex,...value,canSetText:this.config.allowTextInput&&!value.disabled&&!value.readOnly});
          }finally{if(!kept)await handle.dispose().catch(()=>{});}
          if(fields.length>=limit){truncated=true;break;}
        }
        if(frame.url()!==frameUrl||entry.revision!==revision)fail('page_changed_during_snapshot');
        if(fields.length>=limit)break;
      }
      if(entry.revision!==revision)fail('page_changed_during_snapshot');
      this.snapshots.set(snapshotId,{kind:'text_fields',pageId,revision,created:Date.now(),nodes});retained=true;
      return {pageId,snapshotId,fields,examined,truncated,observationOnly:true,actionsIssued:false};
    }finally{if(!retained)for(const node of nodes.values())await node.handle.dispose().catch(()=>{});}
  }
  async setText(pageId,snapshotId,nodeId,value){
    let dispatched=false,snapshot;
    try{
      if(!this.config.allowTextInput||!this.config.includeEditableText)fail('browser_text_input_not_authorized');
      if(typeof value!=='string'||value.includes('\0')||Buffer.byteLength(value)>2048)fail('invalid_browser_text');
      const entry=this.get(pageId);snapshot=this.snapshots.get(snapshotId);
      if(!snapshot||snapshot.kind!=='text_fields'||snapshot.pageId!==pageId||snapshot.revision!==entry.revision||Date.now()-snapshot.created>SNAPSHOT_TTL)fail('stale_field_snapshot');
      const node=snapshot.nodes.get(nodeId);if(!node)fail('field_not_found');
      this.assertURL(entry.page.url());this.assertURL(node.frame.url());
      if(node.frame.url()!==node.frameUrl||fingerprint(await node.handle.evaluate(describeTextField))!==node.fingerprint)fail('stale_field');
      if(node.value.disabled||node.value.readOnly)fail('field_not_editable');
      this.snapshots.delete(snapshotId);dispatched=true;
      await node.handle.fill(value,{timeout:this.config.timeoutMs});
      const after=await node.handle.evaluate(describeTextField);
      const textVerified=after!==null&&after.value===value;
      return {status:textVerified?'acknowledged':'unknown',dispatched:true,textVerified,businessEffectConfirmed:false,requiresNewSnapshot:true};
    }catch(error){
      if(!dispatched)throw new TextInputRefusal(/^[a-z][a-z0-9_]{1,80}$/u.test(error.message)?error.message:'field_preflight_failed');
      throw error;
    }finally{if(dispatched)for(const node of snapshot.nodes.values())await node.handle.dispose().catch(()=>{});}
  }
  async currentNode(pageId,snapshotId,nodeId) {
    const entry = this.get(pageId), snapshot = this.snapshots.get(snapshotId);
    if (!snapshot || snapshot.pageId !== pageId || snapshot.revision !== entry.revision || Date.now()-snapshot.created > SNAPSHOT_TTL) fail('stale_snapshot');
    const node = snapshot.nodes.get(nodeId); if (!node) fail('node_not_found');
    this.assertURL(entry.page.url()); this.assertURL(node.frame.url());
    if (node.frame.url() !== node.frameUrl || fingerprint(await node.handle.evaluate(describeElement)) !== node.fingerprint) fail('stale_node');
    return {entry,node};
  }
  async activate(pageId,snapshotId,nodeId) {
    return await this.clickObserved(pageId,snapshotId,nodeId,true);
  }
  async invoke(pageId,snapshotId,nodeId) {
    return await this.clickObserved(pageId,snapshotId,nodeId,false);
  }
  async clickObserved(pageId,snapshotId,nodeId,navigationOnly) {
    let entry,node,snapshot;
    try {
      ({entry,node}=await this.currentNode(pageId,snapshotId,nodeId));
      if (node.value.disabled || (navigationOnly&&!node.navigation)) fail('navigation_only');
      if(!navigationOnly&&!node.navigation&&node.value.tag!=='button'&&!['button','tab','menuitem'].includes(node.value.role))fail('observed_control_required');
      if (node.value.href) this.assertURL(node.value.href);
      snapshot=this.snapshots.get(snapshotId);if(!snapshot)fail('stale_snapshot');
    }catch(error){throw new ObservedControlRefusal(/^[a-z][a-z0-9_]{1,80}$/u.test(error.message)?error.message:'control_preflight_failed');}
    // Consume before dispatch: an ambiguous click failure cannot replay this token.
    this.snapshots.delete(snapshotId);
    // A real click preserves the application's own SPA router and event handlers.
    try { await node.handle.click({timeout:this.config.timeoutMs,noWaitAfter:true}); }
    catch(e) { this.record({kind:'navigation_click_outcome_unknown',pageId,nodeId});throw e; }
    finally { for(const n of snapshot.nodes.values())await n.handle.dispose().catch(()=>{}); }
    this.record({kind:'navigation_click_dispatched',pageId,nodeId});
    return {dispatched:true,url:sanitizedUrl(entry.page.url()),navigationCompleted:false,
      businessEffectConfirmed:false,mode:navigationOnly?'observed_navigation':'observed_control'};
  }
  async navigate(pageId,url) {
    const entry = this.get(pageId); this.assertURL(entry.page.url()); this.assertURL(url);
    await this.releaseSnapshots(pageId);
    const response = await entry.page.goto(url,{waitUntil:'domcontentloaded'});
    this.assertURL(entry.page.url());
    return {url:sanitizedUrl(entry.page.url()),status:response?.status() ?? null};
  }
  async metrics(pageId) {
    const entry = this.get(pageId); this.assertURL(entry.page.url());
    if(!entry.session){
      const dom=await entry.page.evaluate(()=>{
        const walker=document.createTreeWalker(document,NodeFilter.SHOW_ELEMENT);let nodes=0;
        while(nodes<5000&&walker.nextNode())nodes++;
        return {nodes,nodeCountTruncated:nodes===5000,documentReadyState:document.readyState,timestamp:performance.now()};
      });
      return {pageId,dom,metrics:{},cpuCountersAvailable:false,heapCountersAvailable:false,
        scope:'bounded_dom_observation',memoryContentsRead:false};
    }
    const {metrics} = await entry.session.send('Performance.getMetrics');
    const counters = await entry.session.send('Memory.getDOMCounters');
    return {pageId,metrics:Object.fromEntries(metrics.filter(m=>METRICS.has(m.name) && Number.isFinite(m.value)).map(m=>[m.name,m.value])),dom:counters,scope:'renderer_runtime_counters',memoryContentsRead:false};
  }
  async routeEvidence(pageId,limit=64){
    const entry=this.get(pageId);this.assertURL(entry.page.url());
    return {pageId,...await entry.routes.evidence(limit)};
  }
  async analyzeScript(pageId,scriptHandle){
    const entry=this.get(pageId);this.assertURL(entry.page.url());
    return {pageId,...await entry.routes.analyze(scriptHandle)};
  }
  async navigateObserved(pageId,routeHandle){
    const entry=this.get(pageId);this.assertURL(entry.page.url());
    try{return await entry.routes.navigate(routeHandle);}
    finally{await this.releaseSnapshots(pageId);}
  }
  addBlockRule(rule) {
    if (this.rules.length >= MAX_RULES) fail('rule_budget');
    const validated = validateRule(rule); this.rules.push(validated);
    this.record({kind:'block_rule_added',origin:validated.origin,pathPrefix:validated.pathPrefix});
    return {active:true,rule:validated,alreadyDispatchedCancelled:false};
  }
  networkEvents() { return {events:this.events.slice(),dropped:this.eventsDropped}; }
  async hide(pageId,selector) {
    const entry = this.get(pageId); this.assertURL(entry.page.url());
    const rule = validateCosmetic({origin:new URL(entry.page.url()).origin,selector});
    if (this.hidden.size >= 128) fail('hidden_element_budget');
    const locator = entry.page.locator(rule.selector); if (await locator.count() !== 1) fail('selector_must_match_one');
    const handle = await locator.elementHandle();
    const previous = await handle.evaluate(el=>{
      if (['HTML','BODY','HEAD'].includes(el.tagName)) throw Error('root_element_denied');
      const previous = {value:el.style.getPropertyValue('display'),priority:el.style.getPropertyPriority('display')};
      el.style.setProperty('display','none','important'); return previous;
    });
    const hideId = randomUUID(); this.hidden.set(hideId,{pageId,revision:entry.revision,handle,previous});
    return {hideId,hidden:true,scope:'one_dom_element',gpuProcessTerminated:false};
  }
  async restore(hideId) {
    const h = this.hidden.get(hideId); if (!h) fail('hide_id_not_found');
    const entry = this.get(h.pageId); this.assertURL(entry.page.url());
    if (entry.revision !== h.revision) fail('stale_hidden_element');
    const restored = await this.restoreHandle(h);
    await h.handle.dispose(); this.hidden.delete(hideId);
    return {restored};
  }
  async restoreHandle(h){
    return await h.handle.evaluate((el,prior)=>{
      if (!el.isConnected || el.style.getPropertyValue('display') !== 'none' || el.style.getPropertyPriority('display') !== 'important') return false;
      if (prior.value) el.style.setProperty('display',prior.value,prior.priority); else el.style.removeProperty('display');
      return true;
    },h.previous);
  }
  async clearHides(pageId,maximumRevision=Infinity){
    for(const [id,h]of this.hidden)if(h.pageId===pageId&&h.revision<=maximumRevision){
      this.hidden.delete(id);
      await this.restoreHandle(h).catch(()=>{});await h.handle.dispose().catch(()=>{});
    }
  }
  async closeTarget(targetId) {
    const worker = this.workers.get(targetId);
    if (worker) {
      if (!worker.owned) fail('target_not_owned');
      const entry = this.get(worker.pageId); this.assertURL(entry.page.url());
      let closed = false; worker.worker.once('close',()=>{closed=true;});
      await worker.worker.evaluate(()=>self.close()).catch(()=>{});
      const until = Date.now()+this.config.timeoutMs;
      while (!closed && Date.now()<until) await new Promise(resolve=>setTimeout(resolve,10));
      if (closed) this.workers.delete(targetId);
      return {targetId,closed,outcome:closed?'confirmed':'unknown'};
    }
    const entry = this.get(targetId); if (!entry.owned) fail('target_not_owned');
    await entry.page.close({runBeforeUnload:false}); await this.releaseSnapshots(targetId);
    entry.routes?.close();
    await this.clearHides(targetId);
    this.pages.delete(targetId);
    return {targetId,closed:entry.page.isClosed(),scope:'owned_page_and_its_workers',sharedGpuProcessTerminated:false};
  }
  async close() {
    if (this.closed) return;
    await this.traffic?.close();
    for (const id of this.pages.keys()) await this.releaseSnapshots(id);
    for(const entry of this.pages.values()){
      entry.routes?.close();
      await this.clearHides(entry.id);
      if(entry.cosmeticScriptId)await entry.session.send('Page.removeScriptToEvaluateOnNewDocument',{identifier:entry.cosmeticScriptId}).catch(()=>{});
      if(entry.cosmeticToken)await this.inCosmeticWorld(entry,removeCosmetics,entry.cosmeticToken).catch(()=>{});
    }
    if (!this.ownsBrowser) for (const {session} of this.pages.values()) {
      if(!session)continue;
      await session.send('Fetch.disable').catch(()=>{});
      await session.send('Network.setBypassServiceWorker',{bypass:false}).catch(()=>{});
      await session.send('Network.setCacheDisabled',{cacheDisabled:false}).catch(()=>{});
      await session.detach().catch(()=>{});
    }
    this.closed = true;
    await this.browser.close();
  }
}
