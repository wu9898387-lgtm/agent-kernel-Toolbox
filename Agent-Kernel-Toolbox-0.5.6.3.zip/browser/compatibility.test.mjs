import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {existsSync} from 'node:fs';
import {RuntimeBrowser} from './runtime.mjs';

const engines=(process.env.RUNTIME_TEST_ENGINES??'chromium').split(',');
for(const engine of engines)test(`APP routes, interface evidence and controls on ${engine}`,async t=>{
  let blockedReachedServer=0;
  const application=`<!doctype html><meta charset="utf-8"><title>Owned APP fixture</title>
  <a id="settings" href="/settings" role="tab" aria-selected="false">打开设置</a>
  <a id="blocked" href="/blocked">Blocked request</a><p id="status">home:ready</p>
  <button id="button-route" role="tab">按钮页面</button>
  <div id="shadow"></div><div id="private-shadow" data-private></div><input type="password" value="SECRET_PASSWORD">
  <script src="/app.js"></script><script>
  function goSettings(event){event.preventDefault();history.pushState({},'', '/settings');
    fetch('/interface/settings?session=SECRET_QUERY').then(r=>r.json()).then(data=>{
      document.querySelector('#status').textContent='settings:'+data.state;
      document.querySelector('#settings').setAttribute('aria-selected','true');
    });}
  document.querySelector('#settings').addEventListener('click',goSettings);
  document.querySelector('#blocked').addEventListener('click',event=>{event.preventDefault();
    fetch('/interface/blocked').then(()=>document.querySelector('#status').textContent='unexpected')
      .catch(()=>document.querySelector('#status').textContent='blocked:confirmed');});
  document.querySelector('#shadow').attachShadow({mode:'open'}).innerHTML='<button aria-expanded="true">APP shadow state</button>';
  document.querySelector('#private-shadow').attachShadow({mode:'open'}).innerHTML='<button>PRIVATE_SHADOW_SECRET</button>';
  document.querySelector('#button-route').addEventListener('click',()=>{history.pushState({},'', '/button-page');document.querySelector('#status').textContent='button:ready';});
  addEventListener('popstate',()=>document.querySelector('#status').textContent='home:ready');
  </script>`;
  const server=createServer((request,response)=>{
    if(request.url.startsWith('/interface/settings')){response.setHeader('content-type','application/json');response.end('{"state":"ready"}');return;}
    if(request.url==='/interface/blocked'){blockedReachedServer++;response.end('unexpected');return;}
    if(request.url==='/app.js'){response.setHeader('content-type','application/javascript');response.end("globalThis.fixtureVersion=1; const profilePath='/profile';");return;}
    response.setHeader('content-type','text/html; charset=utf-8');response.end(application);
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base=`http://127.0.0.1:${server.address().port}`;
  const executablePath=engine==='chromium'?(process.env.RUNTIME_CHROMIUM||(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined)):
    engine==='webkit'?process.env.RUNTIME_WEBKIT:process.env.RUNTIME_FIREFOX;
  const runtime=await RuntimeBrowser.launch({engine,executablePath,allowedOrigins:[base],headless:true});
  t.after(()=>runtime.close());
  const {pageId}=await runtime.open(base+'/');
  const capability=runtime.capabilities();assert.equal(capability.engine,engine);
  const page=runtime.get(pageId).page;
  let snapshot=await runtime.snapshot(pageId);
  assert.equal(JSON.stringify(snapshot).includes('PRIVATE_SHADOW_SECRET'),false);
  assert.equal(JSON.stringify(snapshot).includes('SECRET_PASSWORD'),false);
  let link=snapshot.frames.flatMap(frame=>frame.nodes??[]).find(node=>node.name==='打开设置');
  await runtime.activate(pageId,snapshot.snapshotId,link.nodeId);
  await page.waitForFunction(()=>document.querySelector('#status').textContent==='settings:ready');
  const query=await runtime.query(pageId,{query:'打开设置'});
  assert.equal(query.frames[0].nodes[0].states.selected,'true');
  const shadow=await runtime.query(pageId,{query:'APP shadow state'});
  assert.equal(shadow.frames[0].nodes[0].states.expanded,'true');
  const evidence=await runtime.routeEvidence(pageId,64);
  const request=evidence.requests.find(item=>item.url===base+'/interface/settings');
  assert.ok(request,'real interface request was recorded');
  assert.equal(request.method,'GET');assert.equal(request.status,200);assert.equal(request.responseObserved,true);
  assert.equal(request.queryRedacted,true);assert.equal(request.association.causalityProven,false);
  assert.equal(JSON.stringify(evidence).includes('SECRET_QUERY'),false);
  let analyzed;
  for(const script of evidence.scripts.filter(item=>item.sourceReadable&&item.scriptHandle)){
    const result=await runtime.analyzeScript(pageId,script.scriptHandle);
    if(result.candidates.some(candidate=>candidate.url===base+'/interface/settings')){analyzed=result;break;}
  }
  assert.ok(analyzed,'observed source produced the same interface URL candidate');
  const candidate=analyzed.candidates.find(item=>item.url===base+'/interface/settings');
  assert.ok(candidate.observedRequestURLMatches.includes(request.eventId));
  assert.equal(candidate.correspondenceProvesImplementation,false);
  const latest=await runtime.routeEvidence(pageId,64),prior=latest.routes.find(item=>item.url===base+'/'&&item.routeHandle);
  assert.ok(prior);
  const navigation=await runtime.navigateObserved(pageId,prior.routeHandle);
  assert.equal(navigation.mode,engine==='chromium'?'browser_history_entry':'observed_url_reload');
  await page.waitForURL(base+'/');
  await page.waitForFunction(()=>document.querySelector('#status').textContent==='home:ready');
  await assert.rejects(()=>runtime.navigateObserved(pageId,prior.routeHandle),/stale_route_handle/);
  runtime.addBlockRule({origin:base,pathPrefix:'/interface/blocked'});
  snapshot=await runtime.snapshot(pageId);
  link=snapshot.frames.flatMap(frame=>frame.nodes??[]).find(node=>node.name==='Blocked request');
  await runtime.activate(pageId,snapshot.snapshotId,link.nodeId);
  await page.waitForFunction(()=>document.querySelector('#status').textContent==='blocked:confirmed');
  assert.equal(blockedReachedServer,0);
  assert.ok(runtime.networkEvents().events.some(event=>event.kind==='request_blocked'&&event.url===base+'/interface/blocked'));
  const hidden=await runtime.hide(pageId,'#blocked');assert.equal(hidden.hidden,true);
  assert.equal((await runtime.restore(hidden.hideId)).restored,true);
  const metrics=await runtime.metrics(pageId);assert.equal(metrics.memoryContentsRead,false);
  snapshot=await runtime.snapshot(pageId);
  const button=snapshot.frames.flatMap(frame=>frame.nodes??[]).find(node=>node.name==='按钮页面');
  assert.equal(button.navigation,false);
  const invoked=await runtime.invoke(pageId,snapshot.snapshotId,button.nodeId);
  assert.equal(invoked.mode,'observed_control');assert.equal(invoked.businessEffectConfirmed,false);
  await page.waitForFunction(()=>document.querySelector('#status').textContent==='button:ready');
  await assert.rejects(()=>runtime.invoke(pageId,snapshot.snapshotId,button.nodeId),/stale_snapshot/);
  await assert.rejects(()=>runtime.open('https://example.org/'),/origin_not_allowed/);
  t.diagnostic(JSON.stringify({engine,version:capability.version,routeMode:capability.navigationMode,
    observedInterfaceStatus:request.status,sourceCandidateMatchedRequest:true,postcondition:'settings:ready',blockedReachedServer}));
});
