#define _POSIX_C_SOURCE 200809L
#include "agent.h"
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct { uint64_t identity; int64_t value; uint64_t generation; } DemoObject;
typedef struct { RAAgent *agent; DemoObject *object; uint64_t location; } DemoContext;
static volatile sig_atomic_t running=1;
static void stop(int signal_number) { (void)signal_number;running=0; }
static int publish(DemoContext *context) {
    return ra_agent_object(context->agent,context->object->identity,context->object->generation,
        context->location,context->object,sizeof(*context->object),offsetof(DemoObject,value),context->object->value);
}
static uint32_t snapshot(void *raw,const RARequest *request,RAResult *result) {
    DemoContext *context=raw;(void)request;
    result->value=context->object->value;result->generation=context->object->generation;return RA_OK;
}
static uint32_t compare_set(void *raw,const RARequest *request,RAResult *result) {
    DemoContext *context=raw;
    if(context->object->value!=request->expected) return RA_CONFLICT;
    context->object->value=request->argument;
    if(publish(context)<0) return RA_CALLBACK_FAILED;
    return snapshot(raw,request,result);
}
static uint32_t checked_add(void *raw,const RARequest *request,RAResult *result) {
    DemoContext *context=raw;int64_t value=context->object->value, increment=request->argument;
    if(value!=request->expected) return RA_CONFLICT;
    if((increment>0 && value>INT64_MAX-increment) || (increment<0 && value<INT64_MIN-increment)) return RA_CONFLICT;
    context->object->value=value+increment;
    if(publish(context)<0) return RA_CALLBACK_FAILED;
    return snapshot(raw,request,result);
}
static uint32_t move_object(void *raw,const RARequest *request,RAResult *result) {
    DemoContext *context=raw;
    if(context->object->value!=request->expected || context->location==UINT64_MAX) return RA_CONFLICT;
    DemoObject *replacement=malloc(sizeof(*replacement));
    if(!replacement) return RA_CALLBACK_FAILED;
    /* Semantic migration copies defined fields; allocator headers and arbitrary
       pointer graphs are never copied as an object migration algorithm. */
    replacement->identity=context->object->identity;replacement->value=context->object->value;
    replacement->generation=context->object->generation;free(context->object);context->object=replacement;
    ++context->location;if(publish(context)<0) return RA_CALLBACK_FAILED;
    return snapshot(raw,request,result);
}
static uint32_t reincarnate(void *raw,const RARequest *request,RAResult *result) {
    DemoContext *context=raw;
    if(context->object->value!=request->expected || context->object->generation==UINT64_MAX) return RA_CONFLICT;
    ++context->object->generation;context->object->value=request->argument;
    if(publish(context)<0) return RA_CALLBACK_FAILED;
    return snapshot(raw,request,result);
}
int main(int argc,char **argv) {
    if(argc!=3) {fputs("usage: runtime-agent-demo PRIVATE_ENV SESSION_HEX\n",stderr);return 2;}
    RAAgent agent;DemoObject *object=malloc(sizeof(*object));
    if(!object) return 2;
    *object=(DemoObject){1,7,1};DemoContext context={&agent,object,1};
    if(ra_agent_open(&agent,argv[1],argv[2])<0) {perror("agent_open");free(object);return 2;}
    if(ra_agent_register(&agent,1,1,snapshot,&context)<0 ||
       ra_agent_register(&agent,2,2,compare_set,&context)<0 ||
       ra_agent_register(&agent,3,2,checked_add,&context)<0 ||
       ra_agent_register(&agent,4,2,move_object,&context)<0 ||
       ra_agent_register(&agent,5,2,reincarnate,&context)<0 ||publish(&context)<0 ||ra_agent_ready(&agent)<0) {
        perror("agent_register");ra_agent_close(&agent);free(context.object);return 2;
    }
    struct sigaction action;memset(&action,0,sizeof(action));action.sa_handler=stop;
    if(sigaction(SIGTERM,&action,NULL)<0 ||sigaction(SIGINT,&action,NULL)<0) {ra_agent_close(&agent);free(context.object);return 2;}
    printf("{\"ready\":true,\"pid\":%ld,\"object_size\":%zu,\"value_offset\":%zu}\n",(long)getpid(),sizeof(DemoObject),offsetof(DemoObject,value));fflush(stdout);
    int agent_enabled=1;
    while(running) {
        if(agent_enabled && ra_agent_poll(&agent)<0) {perror("agent_disabled");agent_enabled=0;}
        struct timespec pause={0,1000000};(void)nanosleep(&pause,NULL);
    }
    ra_agent_close(&agent);free(context.object);return 0;
}
