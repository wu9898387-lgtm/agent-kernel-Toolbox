#define _POSIX_C_SOURCE 200809L
#include "agent.h"
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <sys/file.h>
#include <time.h>
#include <unistd.h>

typedef struct {RAAgent *agent;atomic_uint calls;atomic_uint entered;atomic_uint callback_error;int64_t value;} Context;
static void put32(unsigned char *p,uint32_t value) {
    for(unsigned i=0;i<4u;++i) p[i]=(unsigned char)(value>>(i*8u));
}
static void put64(unsigned char *p,uint64_t value) {
    for(unsigned i=0;i<8u;++i) p[i]=(unsigned char)(value>>(i*8u));
}
static uint64_t get64(const unsigned char *p) {
    uint64_t value=0;for(unsigned i=0;i<8u;++i) value|=(uint64_t)p[i]<<(i*8u);return value;
}
static uint32_t callback(void *raw,const RARequest *request,RAResult *result) {
    Context *context=raw;(void)request;
    (void)atomic_fetch_add_explicit(&context->calls,1u,memory_order_relaxed);
    atomic_store_explicit(&context->entered,1u,memory_order_release);
    struct timespec pause={0,150000000};(void)nanosleep(&pause,NULL);
    ++context->value;
    if(ra_agent_object(context->agent,1,1,1,&context->value,sizeof(context->value),0,context->value)<0)
        atomic_store_explicit(&context->callback_error,1u,memory_order_relaxed);
    /* Recursive poll is a nonblocking no-op, registration returns EBUSY rather
       than reacquiring flock on this shared open file description. */
    if(ra_agent_poll(context->agent)!=0 ||
       ra_agent_register(context->agent,2,1,callback,context)!=-1 || errno!=EBUSY)
        atomic_store_explicit(&context->callback_error,1u,memory_order_relaxed);
    result->value=context->value;result->generation=1;return RA_OK;
}
static void *poll_thread(void *raw) {
    RAAgent *agent=raw;return (void *)(intptr_t)ra_agent_poll(agent);
}
int main(int argc,char **argv) {
    if(argc!=3) return 2;
    RAAgent agent;Context context={.agent=&agent,.calls=ATOMIC_VAR_INIT(0),.entered=ATOMIC_VAR_INIT(0),
                                  .callback_error=ATOMIC_VAR_INIT(0),.value=7};
    if(ra_agent_open(&agent,argv[1],argv[2])<0 ||
       ra_agent_register(&agent,1,2,callback,&context)<0 ||
       ra_agent_object(&agent,1,1,1,&context.value,sizeof(context.value),0,context.value)<0 ||
       ra_agent_ready(&agent)<0) return 2;
    int controller=open(argv[1],O_RDWR|O_CLOEXEC|O_NOFOLLOW);
    if(controller<0 || flock(controller,LOCK_EX)<0) return 2;
    unsigned char payload[32]={0};put32(payload,1);put32(payload+4,1);put64(payload+8,1);
    if(pwrite(controller,payload,sizeof(payload),64)!=(ssize_t)sizeof(payload)) return 2;
    unsigned char sequence[8];put64(sequence,1);
    if(pwrite(controller,sequence,sizeof(sequence),48)!=(ssize_t)sizeof(sequence) ||flock(controller,LOCK_UN)<0) return 2;
    pthread_t first,second;
    if(pthread_create(&first,NULL,poll_thread,&agent)!=0) return 2;
    unsigned wait=0;
    while(atomic_load_explicit(&context.entered,memory_order_acquire)==0u) {
        if(++wait>2000u) return 2;
        struct timespec pause={0,1000000};(void)nanosleep(&pause,NULL);
    }
    if(pthread_create(&second,NULL,poll_thread,&agent)!=0 ||pthread_join(second,NULL)!=0 ||pthread_join(first,NULL)!=0) return 2;
    unsigned calls=atomic_load_explicit(&context.calls,memory_order_relaxed);
    uint64_t ack=get64(agent.block+56);
    if(calls!=1u ||context.value!=8 ||ack!=1 ||atomic_load_explicit(&context.callback_error,memory_order_relaxed)!=0u) {
        fprintf(stderr,"calls=%u value=%" PRId64 " ack=%" PRIu64 "\n",calls,context.value,ack);return 1;
    }
    /* Every error/no-work exit must release the process-local gate. */
    agent.block[0]^=1u;
    if(ra_agent_poll(&agent)!=-1 ||errno!=EPROTO) return 1;
    agent.block[0]^=1u;
    if(ra_agent_poll(&agent)!=0 ||ra_agent_register(&agent,2,1,callback,&context)<0 ||
       ra_agent_object(&agent,1,1,2,&context.value,sizeof(context.value),0,context.value)<0 ||ra_agent_ready(&agent)<0) return 1;
    if(flock(controller,LOCK_EX)<0 ||ra_agent_poll(&agent)!=0 ||flock(controller,LOCK_UN)<0 ||ra_agent_poll(&agent)!=0) return 1;
    (void)close(controller);ra_agent_close(&agent);
    puts("{\"ok\":true,\"calls\":1,\"value\":8,\"ack_seq\":1}");return 0;
}
