# 协作式语义代理

Agent-Kernel-Toolbox 0.5.6.2 提供一个 C 进程内代理和标准库 Rust 外部控制器，供能够接入代理的自有应用使用。函数指针只保存在应用内，共享文件对外发布固定槽 ID、参数 schema 和状态。

## 构建部署组件

需要 Linux、C11 编译器和 Rust 1.89+。Cargo 无第三方依赖。输出目录可以预先创建；已有同名产物会被拒绝覆盖，目录中的其他文件会保留：

```sh
python3 native/runtime-agent/build.py --output-directory /absolute/new-build
```

也可用 `--cc /absolute/cc` 与 `--cargo /absolute/cargo` 指定工具链。输出包含：

| 文件 | 用途 |
| --- | --- |
| `runtime-agent-demo` | 可直接运行的自有示范应用，提供下表五个固定槽 |
| `runtime-agent.o` | 可与应用链接的 PIC C 对象 |
| `agent.h` | 应用接入头文件 |
| `runtime-control` | 外部只读状态/固定槽调用控制器 |
| `compiler-object-layout.json` | ABI、构建 ID 和四个产物的 SHA-256 |
| `build.json` | 与 `compiler-object-layout.json` 内容相同的元数据入口 |

构建 ID 来自按顺序连接的 `agent.h`、`agent.c` 与 `demo.c` 内容，兼容现有构建脚本和 pin 的计算方式；应用程序自身的身份和允许范围应另外登记。构建不会启动目标应用。编译在临时目录完成后才发布产物，Cargo 中间文件自动清理；工具链失败不会留下半成品或删除输出目录中的其他文件。

将对象链接进应用，例如：

```sh
cc -std=c11 -O2 -I/absolute/new-build /absolute/app.c /absolute/new-build/runtime-agent.o -o /absolute/app
```

应用的其他编译参数和链接库由自身需要决定。

## 运行内置示范

在第一个终端创建私有目录和随机 session，再启动示范程序。保留终端打印的 session，供第二个终端使用：

```sh
mkdir -m 700 /absolute/private-demo
session=$(python3 -c 'import secrets; print(secrets.token_hex(16))')
printf '%s\n' "$session"
/absolute/new-build/runtime-agent-demo /absolute/private-demo/environment "$session"
```

在第二个终端读取状态，`SESSION_HEX` 替换为刚才打印的值：

```sh
/absolute/new-build/runtime-control status /absolute/private-demo/environment SESSION_HEX
```

示范应用初始值为 7，注册以下槽。控制调用使用下节列出的参数格式；从最新状态中读取 `epoch`、`request_seq` 和 `object_generation`，下一次序号为 `request_seq + 1`。

| 槽 | 操作 | 后置状态 |
| --- | --- | --- |
| 1 | 语义字段快照 | 返回当前值和对象代次 |
| 2 | 比较后设置 | 当前值等于 `EXPECTED_VALUE` 时写入 `ARGUMENT` |
| 3 | 带溢出检查的加法 | 预期值匹配且不溢出时增加 `ARGUMENT` |
| 4 | 对象迁移 | 预期值匹配后迁移到新分配块，保持身份与对象代次，推进地址定位代次 |
| 5 | 对象重新实例化 | 预期值匹配后推进对象代次并写入 `ARGUMENT`，旧代次句柄失效 |

停止示范应用可在其终端按 Ctrl-C。环境文件属于本次实例，重新运行时使用新的文件路径；应用不会覆盖旧环境。示范槽的语义由 `demo.c` 定义，接入其他应用时应登记该应用自己的操作。

## 应用接入

1. 在向其他线程发布代理句柄前调用 `ra_agent_open`，使用私有目录、新的环境文件路径和不可预测的 16 字节 session（32 个小写十六进制字符）。
2. 用 `ra_agent_register` 注册固定的语义 callback 槽，最多八个；当前参数 schema 支持整数状态和参数。
3. 用 `ra_agent_object` 发布对象 ID、代次、地址定位代次、大小、字段偏移和值，然后调用 `ra_agent_ready`。
4. 在应用自己的协作安全点调用 `ra_agent_poll`。应用的所有相关写入者必须参加该安全点协议，callback 必须有界。
5. 停止并 join 所有相关线程后调用 `ra_agent_close`。不要从 callback 内关闭代理、复制已初始化的句柄或跨越 callback 边界跳转。

环境文件使用 `O_EXCL|O_NOFOLLOW` 创建，权限为 0600。控制器核对文件身份、属主、大小、magic、ABI、session、epoch、PID、启动 ticks、对象代次和 callback 表。进程间使用文件锁，进程内用 C11 原子 gate 串行化代理操作。

## 控制器

读取已登记应用的当前状态：

```sh
/absolute/new-build/runtime-control status /absolute/private/environment SESSION_HEX
```

状态包含对象、代次、build ID、实际应用发布的字段布局和值。布局应由接入应用使用 C 编译器的 `sizeof` / `offsetof` 产生，地址仅供诊断。

固定调用和长连接语法：

```text
runtime-control call ENV SESSION EPOCH NEXT_SEQUENCE OBJECT_GENERATION SLOT EXPECTED_VALUE ARGUMENT TIMEOUT_MS
runtime-control serve ENV SESSION
```

`serve` 从 stdin 接收 `status` 或 `call EPOCH NEXT_SEQUENCE OBJECT_GENERATION SLOT EXPECTED_VALUE ARGUMENT TIMEOUT_MS`，每行返回 JSON。请求最多 512 字节，超时范围 1–1000 ms。槽号和参数应来自应用已登记的 callback schema。

MCP 的 `semantic.*` 接口还固定控制器摘要、环境路径、session、epoch、PID、build ID 和槽 allowlist；控制器从私有快照运行。ACK 需要结合应用的后置状态读取确认业务效果。

## 验证设施

构建契约测试使用受控的工具链替身，检查既存目录、输出文件名、摘要、拒绝覆盖及失败清理：

```sh
python3 native/runtime-agent/test_build.py -v
```

Rust 单元测试和实际 C/Rust 集成测试需要上述工具链。以下命令在 Toolbox 根目录运行：

```sh
cargo test --manifest-path native/runtime-agent/Cargo.toml --offline --locked
cargo clippy --manifest-path native/runtime-agent/Cargo.toml --all-targets --offline --locked -- -D warnings
RUNTIME_CARGO=/absolute/cargo python3 -m unittest discover -s tests -p test_semantic_agent.py -v
RUNTIME_CARGO=/absolute/cargo python3 -m unittest discover -s tests -p test_semantic_object_integration.py -v
```

`concurrent_test.c` 可单独用 C11 与 pthread 编译并执行，无需 Rust。它验证两个 poll 线程遇到同一序号时只调用一次，以及回调内发布、递归 poll 和错误路径释放 gate：

```sh
cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Wconversion -Wshadow -pthread native/runtime-agent/agent.c native/runtime-agent/concurrent_test.c -o /absolute/concurrent-test
/absolute/concurrent-test /absolute/private-demo/concurrent-environment SESSION_HEX
```

## Unknown 与平台条件

控制器超时返回 `semantic_outcome_unknown`，共享环境保留未确认序号并阻断下一次派发。核对 ACK 和应用状态后才能处理未决结果，不自动重放旧请求。

当前 wire ABI 使用 little-endian 字节和 Linux 进程/锁接口。该组件不为未接入代理的程序提供自动对象恢复，也不绕过其他写入者的同步协议。产品版本为 `0.5.6.2`，Cargo 元数据版本为 `0.5.6+toolbox.2`。
