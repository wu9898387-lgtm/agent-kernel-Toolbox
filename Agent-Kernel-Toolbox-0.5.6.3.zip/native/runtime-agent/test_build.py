"""Build contract tests with controlled toolchain outputs; no Rust execution claim."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('runtime_agent_build', ROOT / 'build.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


def toolchain_output(arguments, **kwargs):
    if arguments[0] == 'test-cc':
        output = Path(arguments[arguments.index('-o') + 1])
        output.write_bytes(b'controlled C output: ' + output.name.encode())
    elif arguments[0] == 'test-cargo':
        output = Path(arguments[arguments.index('--target-dir') + 1]) / 'release/runtime-control'
        output.parent.mkdir(parents=True)
        output.write_bytes(b'controlled Rust output; not executable')
    else:
        raise AssertionError('unexpected toolchain')
    return subprocess.CompletedProcess(arguments, 0)


class BuildContractTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.sentinel = self.directory / 'keep.txt'
        self.sentinel.write_bytes(b'preserve existing unrelated files')

    def build(self):
        return builder.build(self.directory, cc='test-cc', cargo='test-cargo')

    def test_existing_directory_produces_compatible_artifacts_and_digest(self):
        with patch.object(builder.subprocess, 'run', side_effect=toolchain_output):
            result = self.build()
        self.assertEqual({path.name for path in self.directory.iterdir()},
                         set(builder.ARTIFACT_NAMES) | {'keep.txt'})
        self.assertEqual(self.sentinel.read_bytes(), b'preserve existing unrelated files')
        expected = hashlib.sha256(b''.join((ROOT / name).read_bytes()
            for name in ('agent.h', 'agent.c', 'demo.c'))).hexdigest()
        self.assertEqual(result['build_id'], expected)
        legacy = self.directory / 'compiler-object-layout.json'
        self.assertEqual(legacy.read_bytes(), (self.directory / 'build.json').read_bytes())
        self.assertEqual(json.loads(legacy.read_text()), result)
        self.assertEqual(set(result['artifacts']),
                         {'runtime-agent-demo', 'runtime-control', 'runtime-agent.o', 'agent.h'})
        for name, digest in result['artifacts'].items():
            self.assertEqual(hashlib.sha256((self.directory / name).read_bytes()).hexdigest(), digest)

    def test_all_existing_artifact_names_are_preserved_without_compiling(self):
        for name in builder.ARTIFACT_NAMES:
            with self.subTest(name=name):
                path = self.directory / name
                path.write_bytes(b'existing product')
                with patch.object(builder.subprocess, 'run') as compiler:
                    with self.assertRaisesRegex(ValueError, 'refusing_to_overwrite_build'):
                        self.build()
                    compiler.assert_not_called()
                self.assertEqual(path.read_bytes(), b'existing product')
                path.unlink()

    def test_dangling_symlink_is_not_followed_or_replaced(self):
        destination = self.directory / 'runtime-control'
        destination.symlink_to(self.directory / 'absent')
        with self.assertRaisesRegex(ValueError, 'refusing_to_overwrite_build'):
            self.build()
        self.assertTrue(destination.is_symlink())
        self.assertFalse((self.directory / 'absent').exists())

    def test_compiler_failure_removes_only_temporary_build_products(self):
        def fail_cargo(arguments, **kwargs):
            if arguments[0] == 'test-cargo':
                raise subprocess.CalledProcessError(1, arguments)
            return toolchain_output(arguments, **kwargs)
        with patch.object(builder.subprocess, 'run', side_effect=fail_cargo):
            with self.assertRaises(subprocess.CalledProcessError):
                self.build()
        self.assertEqual(list(self.directory.iterdir()), [self.sentinel])

    def test_publication_conflict_preserves_competing_file_and_rolls_back_own_files(self):
        real_link = os.link

        def concurrent_create(source, destination):
            if destination.name == 'runtime-control':
                destination.write_bytes(b'another build owns this file')
            return real_link(source, destination)

        with patch.object(builder.subprocess, 'run', side_effect=toolchain_output):
            with patch.object(builder.os, 'link', side_effect=concurrent_create):
                with self.assertRaises(FileExistsError):
                    self.build()
        self.assertEqual({path.name for path in self.directory.iterdir()},
                         {'keep.txt', 'runtime-control'})
        self.assertEqual((self.directory / 'runtime-control').read_bytes(),
                         b'another build owns this file')

    def test_rollback_keeps_replaced_file_from_another_writer(self):
        real_link = os.link

        def replace_then_conflict(source, destination):
            if destination.name == 'runtime-control':
                replaced = self.directory / 'runtime-agent-demo'
                replaced.unlink()
                replaced.write_bytes(b'replacement belongs to another writer')
                destination.write_bytes(b'publication conflict')
            return real_link(source, destination)

        with patch.object(builder.subprocess, 'run', side_effect=toolchain_output):
            with patch.object(builder.os, 'link', side_effect=replace_then_conflict):
                with self.assertRaises(FileExistsError):
                    self.build()
        self.assertEqual((self.directory / 'runtime-agent-demo').read_bytes(),
                         b'replacement belongs to another writer')
        self.assertEqual((self.directory / 'runtime-control').read_bytes(), b'publication conflict')
        self.assertEqual(self.sentinel.read_bytes(), b'preserve existing unrelated files')


if __name__ == '__main__':
    unittest.main()
