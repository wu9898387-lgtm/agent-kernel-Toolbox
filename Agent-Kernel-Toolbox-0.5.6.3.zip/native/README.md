# 原生组件

本目录保存需要在部署机器上构建或接入应用的实际组件。Python 进程观察、内存、CPU、AT-SPI 和调试适配器已包含在根目录的 `runtime-access.pyz` 中。

| 目录或文件 | 用途 | 构建条件 |
| --- | --- | --- |
| `build.py`、`render_filter.cpp` | 选择性 OpenGL 绘制过滤库 | Linux、C++17 编译器 |
| `worker/` | 进程连接观察与独立 STOP/恢复 watchdog | Linux、Go 1.23+ |
| `runtime-agent/` | 应用内 C 语义代理与外部 Rust 控制器 | Linux、C11、Rust 1.89+ |
| `probe-sdk/` | 应用显式发布对象/生命周期事件的 C SDK | C 编译器；应用配合接入 |
| `managed-jvm/` | JDI 对象操作与同 schema HotSwap 控制器 | JDK 21+、Linux pidfd |
| `managed-probe/` | JVMTI 事件 agent 与 JNI 对象标签接口 | Linux、GCC、含开发头文件的 JDK |

以下命令均从 Toolbox 根目录执行，输出路径应位于安装者控制的私有目录。构建所得文件的摘要需填写到相应 Host 配置中。

## OpenGL 过滤库

```sh
python3 native/build.py --output /absolute/private/libagent_kernel_render.so
```

输出文件必须尚不存在。在目标进程的启动 profile 中将 `render_library` 设为该库的绝对路径，Host 会创建并维护本次会话的渲染策略，再在显式启动的自有应用中加载；不要全局修改 `LD_PRELOAD`。

库按明确的 program ID 或绘制序号过滤 OpenGL draw/clear/blit 调用，记录有界诊断事件。程序 ID 可能随上下文和资源重建而复用，应重新观察。它不根据图形内容推断广告，不覆盖 Vulkan、Direct3D 或 Metal。

### 策略和事件语义

过滤层覆盖源码列出的 24 个核心 draw、clear 和 framebuffer-blit 入口，以及 EGL/GLX 函数指针查询路径。仅匹配明确 program ID 或 command sequence 的规则时抑制调用；program 规则作用于 draw，clear/blit 只匹配显式 sequence。一次 multi-draw 作为一条命令计数，拒绝它会抑制整次 multi-draw。

前 1024 条调用逐条输出诊断，之后每 256 条输出一次计数。事件包含 PID、GL context、program、sequence、blocked、invalid_policy 和 dropped_events；有界非阻塞管道可能丢失事件。应用能够产生伪造诊断，事件仅作为观察资料。诊断写入使用私有复制描述符并检查管道身份；关闭诊断读取端不会要求结束应用。

策略按 10 ms 间隔轮询，在其后的下一条拦截命令生效。无效或不可用的新策略保留最后一份合法规则并增加 `invalid_policy`；初始策略无效时不抑制绘制。program ID 属于具体上下文且可在删除后复用，当前规则对各上下文的同号 program 生效；sequence 在新进程中重置。启动的后代可能继承预加载环境，必须用事件中的 PID 区分来源。

使用底层 Python 接口集成时，`observation_extension.native_runtime.write_render_policy()` 创建策略，`ProcessSession.launch(..., render_library=..., render_policy=...)` 将其绑定到显式启动的应用，`set_render_policy()` 原子替换规则，`read_render_events()` 读取有界诊断。完整 Python 源码从根目录 pyz 导入；正常 MCP 使用 `render.events` / `render.block` 和 Host 的会话授权。底层接口调用者仍需自行负责授权、持久请求日志和 Unknown 处理。

过滤不覆盖扩展别名、直接厂商分发、静态链接或 legacy immediate mode。像素不由该生产组件读取；实际效果需在匹配驱动和目标应用中验证。

## Go 进程辅助服务

```sh
cd native/worker
go build -trimpath -ldflags="-s -w" -o /absolute/private/runtime-native-worker .
```

将输出绝对路径和实际 SHA-256 填入 `native_helper.path` 与 `native_helper.sha256`。连接观察仍需要目标的 `allow_connections`；控制操作还需要独立控制授权。此组件不是通用命令执行器。

## 协作式语义代理

在应用中集成 `runtime-agent/agent.h` 和构建出的 C 对象，再按应用自己的安全点与写入者协议注册固定 callback 槽。Rust 控制器通过私有共享文件与该应用交互。构建及接入步骤见 [runtime-agent/README.md](runtime-agent/README.md)。

## 程序事件 SDK

将 `probe-sdk/probe.c` 与应用一起编译，包含 `probe-sdk/probe.h`，按头文件的明确入口发布分配、对象和状态事件。SDK 必须由应用主动接入；发布的对象身份不等同于某次内存地址。

## JVM 控制器与事件代理

JDI 构建、配置和操作见 [managed-jvm/README.md](managed-jvm/README.md)。

构建 JVMTI 事件 agent：

```sh
python3 native/managed-probe/build.py --java-home /absolute/jdk --output /absolute/new-agent-directory
```

命令需要 `include/jvmti.h` 和 Linux JNI 头文件，输出 `libmanaged_probe.so` 和包含摘要的构建元数据。普通 JVMTI 事件观察由 agent 提供；需要应用协作标签和语义事件时，将 `managed-probe/RuntimeProbe.java` 编译到应用的 classpath，并按其固定 JNI 接口调用。应用在启动时加载登记的 agent，Host 的 profile 固定 JVM、classpath、agent 及其摘要。

## 进程身份与清理

`ProcessSession` 固定 pidfd、procfs PID、PID namespace、boot ID、启动时间、UID 与执行文件。显式读取在底层适配器单次最多 64 KiB，MCP `process.read_memory` 单次最多 32 KiB，累计预算均为每会话 4 MiB。寄存器捕获可能短暂打断本组件启动的子进程主线程；其他线程不会因此形成一致快照。已有停止状态或不可中断状态会拒绝。

调试清理无法确认时保留 `debug_cleanup_unresolved`，对应活动会话不能通过普通 close 隐去未决附加；先解决附加状态或明确结束 owned 目标。`terminate_owned()` 仅结束本组件启动的子进程；已有进程须以完整 expected identity 附加、独立授予 `allow_terminate`，再调用 `terminate_selected()`。两者使用 pidfd 发信号，选定进程终止拒绝自身、PID 1 和祖先进程。

## 原生操作范围

MCP 的 `process.*`、`native.*` 等入口使用 Host 登记的进程身份和独立权限。读取、调试、控制、写入和输入互不代替。内核拒绝 ptrace、缺少桌面无障碍或缺少设备时，相应能力保持不可用。

内存和寄存器修改要求前置状态匹配及读回。出现 Unknown 时保留状态，停止同一目标的进一步修改，核对实际状态后再对账。结束自有目标的独立清理入口保持可用。完整配置和恢复命令见 [主 README](../README.md)。

静态原生路由分析的安装和配置见 [REVERSE.md](REVERSE.md)。

## 组件检查

```sh
python3 -m unittest discover -s tests -p test_runtime.py -v
python3 -m unittest discover -s tests -p test_native_control.py -v
python3 -m unittest discover -s tests -p test_lifecycle.py -v
```

这些测试需要对应内核权限和编译器；`test_runtime.py` 还含可选浏览器路径。Go worker 的单元/模糊测试和基准入口见 [NATIVE_WORKER.md](../NATIVE_WORKER.md)，协作式代理的 demo、并发测试和 Rust 测试见 [runtime-agent/README.md](runtime-agent/README.md)。OpenGL 的平台驱动与目标绘制效果须另外实际检查，构建成功不能替代渲染确认。
