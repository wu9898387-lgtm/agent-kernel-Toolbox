//go:build linux

package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"testing"
)

func encodedIP(ip net.IP) string {
	var result strings.Builder
	for at := 0; at < len(ip); at += 4 {
		fmt.Fprintf(&result, "%08X", binary.NativeEndian.Uint32(ip[at:at+4]))
	}
	return result.String()
}

func TestAddressAndOwnership(t *testing.T) {
	for _, literal := range []string{"127.0.0.1", "10.20.30.40", "::1", "2001:db8::42"} {
		ip := net.ParseIP(literal)
		v6 := strings.Contains(literal, ":")
		if !v6 {
			ip = ip.To4()
		}
		value, err := address(encodedIP(ip)+":01BB", v6)
		if err != nil || value.Address != literal || value.Port != 443 {
			t.Fatalf("address roundtrip: %s %+v %v", literal, value, err)
		}
	}
	raw := []byte("header\n 0: 0100007F:01BB 00000000:0000 0A 0:0 0:0 0 0 0 123\n 1: 0100007F:9999 00000000:0000 0A 0:0 0:0 0 0 0 456\n")
	rows, err := parseInet(raw, "tcp", map[string][]int{"123": {7, 9}})
	if err != nil || len(rows) != 1 || rows[0].Inode != "123" || rows[0].State != "LISTEN" || len(rows[0].FDs) != 2 {
		t.Fatalf("inode ownership: %+v %v", rows, err)
	}
	rows, err = parseUnix([]byte("header\n00000000: 2 0 0 1 03 123 /private/socket name\n"), map[string][]int{"123": {7}})
	if err != nil || len(rows) != 1 || len(rows[0].PathSHA256) != 64 {
		t.Fatalf("unix digest: %+v %v", rows, err)
	}
}

func FuzzTableParsers(f *testing.F) {
	f.Add([]byte("header\n"))
	f.Add([]byte("header\n 0: 0100007F:01BB 00000000:0000 0A 0:0 0:0 0 0 0 123\n"))
	f.Fuzz(func(t *testing.T, raw []byte) {
		if len(raw) > 65536 {
			return
		}
		sockets := map[string][]int{"123": {3}}
		_, _ = parseInet(raw, "tcp", sockets)
		_, _ = parseInet(raw, "tcp6", sockets)
		_, _ = parseUnix(raw, sockets)
	})
}
