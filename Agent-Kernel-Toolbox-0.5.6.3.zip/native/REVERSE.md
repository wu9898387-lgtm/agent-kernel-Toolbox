# Native binary route and URL evidence

This optional backend performs offline analysis of a host-authorized ELF, PE, or Mach-O file.
It produces a chain from a URL or path-shaped string to the machine instruction
that references it, the containing function, and that function's immediate
callers. Returned instruction references include decoded instruction bytes; a
string without resolved references remains explicitly marked `string_only`.

All candidates have `dynamic_verified: false` and `semantic_verified: false`.
`/settings` may be a filename or unused data. A call edge near a route string
does not, by itself, prove that a particular route invokes a particular handler.
This backend does not issue HTTP requests, jump to discovered functions, execute
the target, attach a debugger, modify the file, or authorize a later action.

## Install the optional backend

The supplied installer pins the author's official release archives and verifies
their exact lengths and SHA-256 digests before extraction. It requires Python
3.12+ and Linux x86_64 with a compatible glibc loader. It creates a new private
directory, preserves the upstream files, and runs no Debian install scripts.

```sh
python3 tools/install_reverse_native.py --destination /absolute/private/reverse-native
```

The result includes the absolute executable paths and a `provenance.json` file.
For the main host, configure `reverse_native.radare2` to the returned `radare2`
path. Register the target in the existing `binaries` registry; `binary.routes`
accepts that registry ID. The model does not provide a path or raw r2 command.
See the parent [reverse integration guide](../REVERSE.md) for host configuration.

An already installed radare2 executable can also be used. NixOS hosts should
supply a working native package or operator-managed wrapper; the extracted
Debian executable requires its expected `/lib64` loader and compatible system
libraries. The backend derives an adjacent `usr/lib` only for the
private extracted layout and otherwise uses the configured executable normally.

| Component | Pinned version | Archive bytes | Archive SHA-256 |
| --- | --- | ---: | --- |
| radare2 | 6.2.4 | 8,648,924 | `7019eedc0e0e87d1f53d6b8f5fc62b898567679c5efdce7fbfc557c9e7655e90` |
| Official radare2-mcp | 1.9.0 | 208,448 | `d426861a726f7e9bc13a44cc3bbfd8553c51b33fc05f1ff0eda75b433222d9e3` |

Sources: [radare2 release](https://github.com/radareorg/radare2/releases/tag/6.2.4),
[radare2-mcp release](https://github.com/radareorg/radare2-mcp/releases/tag/1.9.0),
and their [radare2](https://api.github.com/repos/radareorg/radare2/releases/tags/6.2.4)
and [MCP](https://api.github.com/repos/radareorg/radare2-mcp/releases/tags/1.9.0)
release asset metadata. Download digests authenticate consistency with that
retrieved release metadata; they are not a separate publisher-signature proof.

## Python contract

```python
import sys
sys.path.insert(0, "/absolute/Agent-Kernel-Toolbox/runtime-access.pyz")
from observation_extension.reverse_native import inspect_reverse

result = inspect_reverse(
    "/absolute/authorized/application",
    radare2="/absolute/private/reverse-native/usr/bin/radare2",
    expected_sha256="<64 hex characters from trusted configuration>",
    max_functions=128,
    max_candidates=64,
    timeout_seconds=20,
)
```

`expected_sha256` is optional at the Python layer. It should be supplied whenever
authorization is intended to bind previously reviewed bytes. The backend opens
the source with `O_NOFOLLOW`, checks that it is a bounded regular ELF, PE, or Mach-O file,
copies it through that descriptor, checks the original inode's size and change
timestamps again, and analyzes the private read-only snapshot. Its digest
identifies the bytes actually copied; no later path lookup chooses the target.

`ReverseNativeError.code` contains a stable refusal or failure code. Examples
include `reverse_binary_digest_mismatch`, `reverse_binary_open_denied`,
`reverse_binary_unsupported_format`, `reverse_backend_unavailable`,
`reverse_backend_timeout`, and `reverse_backend_output_limit`.

The result contains:

| Field | Meaning |
| --- | --- |
| `binary` | Snapshot SHA-256, size, source device/inode and whether a supplied digest matched |
| `backend` | Tool name, reported version, fixed analysis commands and offline mode |
| `format` | Architecture, bit width, endianness, stripped and PIE indicators |
| `candidates` | URL/path text, virtual address, file offset, references and verification state |
| `candidates[].references` | Function ID, xref type, instruction address, bytes and unannotated opcode |
| `functions` | IDs, addresses, bounded symbol names and analyzed sizes |
| `callgraph` | Immediate caller/callee IDs with the corresponding CALL instruction |
| `coverage` | Examined string/function counts, one caller layer, and explicit omissions/truncation |

Unused strings remain `string_only`. Unresolved function ownership and reference
budgets are reported instead of creating fabricated edges. Model-facing output
does not contain raw string-table dumps, source paths, instruction comments,
symbolic string substitutions, tool stderr, or URL userinfo/query/fragment data.
The URI path can still contain application-specific data; this is not a general
secret recognizer.

## Execution and resource boundaries

Only fixed commands (`aaa`, `izj`, `aflj`, `axtj`, `pdj` and metadata/configuration
queries) enter radare2. Address suffixes come from validated unsigned 64-bit
integers. Source filenames are passed as process arguments after copying to a
fixed private name, not interpolated into a command. `-NN` disables user scripts
and dynamic plugins. User environment values such as `LD_PRELOAD`, proxy URLs,
and r2 configuration are not inherited. Automatic debug-info loading, external
demanglers, library loading and PDB extraction are disabled.

After loading the one snapshot, radare2's command sandbox is enabled with grain
`none` and its enabled state is checked. This tool-specific setting is not an
OS security boundary against a vulnerability in a native binary parser.

| Budget | Limit |
| --- | ---: |
| Input ELF / PE / Mach-O | 32 MiB |
| Cumulative tool stdout | 8 MiB |
| Tool stderr | 128 KiB; not returned |
| Serialized result | 256 KiB; explicit failure if exceeded |
| Candidate strings | 64 maximum |
| Returned functions | 128 maximum |
| References per candidate / callers per function | 8 / 8 |
| Total caller edges | 256 |
| Tool virtual address space | 512 MiB, or lower inherited limit |
| Tool wall deadline | 20 seconds default, configurable from 0.1 to 60 seconds |
| CPU / file output / core files / descriptors | ceil(deadline)+1 seconds / 0 / 0 / 64 |

The deadline covers child startup and all command reads and writes. Source-file
copying occurs before that child deadline. On exit or error the owned process
group is killed before its leader is reaped; descendants remaining in that group
cannot retain its output pipe after cleanup. This is not process-container
isolation against a child that deliberately creates a new session. The private snapshot is removed.
Peak RSS and large-application throughput have not been measured.

## Optional MCP and decompilation

The installer also supplies the author-maintained `radare2-mcp` 1.9.0 executable.
It is a separate optional service. Toolbox's `binary.routes` uses fixed direct
radare2 JSON commands and does not expose arbitrary upstream commands.
The upstream server's `pdc` output is register-oriented pseudo-decompilation;
it does not recover the original C source or prove a live route-to-handler map.

## Focused checks

From the Toolbox root:

```sh
RUNTIME_RADARE2=/absolute/private/reverse-native/usr/bin/radare2 \
python3 -m unittest discover -s tests -p test_reverse_backends.py -v
```

The ELF fixture is compiled with GCC and inspected through the configured backend.
To exercise PE and Mach-O, also set `RUNTIME_CROSS_BINARIES` to an operator-created
JSON array. Each entry contains `target`, an absolute `path`, and the expected
`format` (`PE` or `Mach-O`). Use `tests/fixtures/reverse_cross_format.c` with a
matching cross compiler; this test checks real instruction references and call
edges. The related JavaScript test uses `RUNTIME_JSHOOK_ENTRY`.

Unavailable optional backends or cross fixtures are explicitly skipped. Target
executables are inspected, not launched. Format acceptance does not prove that
all architectures, indirect calls, encrypted or runtime-built routes, or arbitrary
application semantics can be recovered. Candidate text is limited to supported
ASCII URL/path syntax; static candidates alone do not authorize an action.
