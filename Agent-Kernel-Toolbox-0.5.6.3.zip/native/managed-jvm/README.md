# JVM 语义对象与 HotSwap

该组件通过 JDI 启动已登记 JVM，在应用固定的 `()V` 方法安全点停止，执行字段读取、比较写入、固定 `(I)I` 方法调用和同 schema 的类方法体替换。对象由 JVM unique ID、类加载器 ID、classpath 摘要和 class epoch 共同定位。

## 构建

需要 Linux pidfd 和 JDK 21+ 的 `jdk.compiler` / `jdk.jdi` 模块，无第三方 Java 包。输出目录必须尚不存在：

```sh
python3 native/managed-jvm/build.py --java /absolute/jdk/bin/java --output /absolute/new-helper-directory
```

命令输出 `helper_directory` 与 `helper_sha256`。构建脚本直接使用 Toolbox 的 `runtime-access.pyz`，无需额外展开 Python 源码。

## 登记应用

Host 在 `managed_jvms.<profile_id>` 中登记 JVM profile，需要固定：

- `java` / `java_sha256`：JVM 可执行文件和摘要。
- `helper_directory` / `helper_sha256`：已构建控制器目录及输出的摘要。
- `class_path` / `class_path_sha256`：应用类目录或 JAR 及摘要。
- `main_class`、`root_class`、`safe_point_method`、`root_field`：固定入口和对象定位点。
- `fields`、`methods`：允许观察/修改的字段和允许调用的方法。
- 可选 `patches`：预登记的 class 补丁文件。

类目录、JAR 和补丁会复制到私有快照后使用。第一个登记字段用于方法调用和 HotSwap 的整数状态前置条件。目录摘要使用打包模块 `observation_extension.managed_jvm.classpath_sha256` 的规则，不能用目录名或单个文件摘要代替。

## MCP 操作顺序

1. 用 `managed.open` 打开登记的 profile。
2. 用 `managed.snapshot` 获取当前对象句柄、epoch 和字段状态。
3. 按实际需要调用 `managed.set_field`、`managed.invoke` 或 `managed.redefine`，提供前置状态及新请求 ID。
4. 再读取状态确认效果，使用 `managed.advance` 前进到下一个安全点。
5. 用 `managed.close` 释放此次会话。

字段修改要求旧值匹配并读回；对象句柄过期、final 字段、越界值或未登记方法会拒绝。JVM 自身决定 HotSwap 能力，通常不允许改变类结构；已有栈帧可能继续执行旧方法体，返回值中保留 class epoch。

## 结果与清理

派发后超时、方法异常、后置快照失败或替换结果不明会进入 Unknown，阻断后续修改。独立 guardian 持有 Host pidfd 并监控命令期限，回收本组件启动的控制器及 JVM。该路径不接受任意 JDWP 端点。

目标程序的业务效果仍需单独读取确认。JVM 对象身份不表示固定物理地址，此组件的 JDI 路径不覆盖 Android ART、CLR 或未开放相应接口的运行时。

## Python 接入示例

直接集成可从 pyz 导入 `ManagedJvm` 和 `classpath_sha256`。下面针对受控 fixture：`profile` 已登记 `value` 字段、`bump` 方法及 `registered-patch` 补丁，初始 value 为 7，bump 将传入值加到该字段。`private_directory` 必须是实际存在的私有绝对目录，`bundle_directory` 指向完整 Toolbox。输入和补丁仍使用实际摘要。

```python
import sys
sys.path.insert(0, "/absolute/Agent-Kernel-Toolbox/runtime-access.pyz")
from observation_extension.managed_jvm import ManagedJvm, classpath_sha256

# profile, private_directory, bundle_directory are operator-owned values.
agent = ManagedJvm(profile, private_directory, bundle_root=bundle_directory)
try:
    def checked(result):
        if not result.get('ok') or result.get('status') == 'unknown':
            raise RuntimeError('managed operation was not confirmed')
        return result

    snapshot = checked(agent.snapshot())
    object_id = snapshot['object_id']
    checked(agent.set_field(object_id, 'value', 7, 9))
    checked(agent.invoke(object_id, 'bump', 9, 3))
    snapshot = checked(agent.snapshot())
    checked(agent.redefine(object_id, snapshot['class_epoch'], 'registered-patch', 12))
    checked(agent.advance())
finally:
    agent.close()
```

方法、字段与补丁名称来自配置，示例数值需要与目标状态一致。直接 Python 接入由调用方负责 Host 级授权、持久请求日志和 Unknown 处置；MCP 接入通过 `managed.*` 复用这些宿主设施。完整的 fixture 构建和 profile 组装位于 `tests/test_managed_jvm.py`。

## 验证

从 Toolbox 根目录运行：

```sh
RUNTIME_JAVA=/absolute/jdk/bin/java python3 -m unittest discover -s tests -p test_managed_jvm.py -v
python3 -m unittest discover -s tests -p test_managed_guardian.py -v
```

用例检查字段比较写入、固定方法调用、GC 后对象身份、同 schema HotSwap、结构改变拒绝、Unknown 围栏、描述符释放和宿主死亡清理。JVM/调试启动被系统拒绝时保留实际失败信息；本机 JVM 检查不替代 ART、CLR 或其他目标运行时的验证。
