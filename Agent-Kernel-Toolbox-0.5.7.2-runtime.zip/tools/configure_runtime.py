#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import stat
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
READ_ONLY_TOOLS = ["runtime.status", "runtime.capabilities", "runtime.audit", "build.inspect"]


class SetupError(ValueError):
    pass


def absolute_path(value):
    path = Path(value)
    if not path.is_absolute() or ".." in path.parts:
        raise SetupError("absolute_path_required")
    return path


def directory(path, create=False):
    current = Path(path.anchor)
    info = current.lstat()
    for part in path.parts[1:]:
        current /= part
        try:
            found = current.lstat()
        except FileNotFoundError:
            if not create:
                continue
            current.mkdir(mode=0o700)
            current.chmod(0o700)
            found = current.lstat()
        if not stat.S_ISDIR(found.st_mode):
            raise SetupError("directory_or_symlink_invalid")
        info = found
    if info.st_mode & 0o022:
        raise SetupError("unsafe_parent")
    return current.exists()


def remove_owned(path, identity):
    try:
        info = path.lstat()
        if (info.st_dev, info.st_ino) == identity:
            path.unlink()
    except FileNotFoundError:
        pass


def configure(config, state_directory, mcp_config=None, *, include_extensions=False,
              coordination_directory=None):
    config, state = absolute_path(config), absolute_path(state_directory)
    mcp = absolute_path(mcp_config) if mcp_config is not None else None
    coordination = absolute_path(coordination_directory) if coordination_directory is not None else None
    outputs = [config] + ([mcp] if mcp is not None else [])
    if (len(set(outputs)) != len(outputs)
            or any(state == p or state in p.parents or p in state.parents for p in outputs)
            or any(p in q.parents for p in outputs for q in outputs)):
        raise SetupError("path_conflict")
    if coordination is not None and (coordination == state or coordination in state.parents
            or state in coordination.parents or any(coordination == p or coordination in p.parents
                                                     or p in coordination.parents for p in outputs)):
        raise SetupError('coordination_path_conflict')
    for path in outputs:
        if os.path.lexists(path):
            raise SetupError("path_must_not_exist")
        directory(path.parent)
    if directory(state):
        info = state.lstat()
        if info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise SetupError("state_directory_must_be_private")
    if coordination is not None and directory(coordination):
        info = coordination.lstat()
        if info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise SetupError('coordination_directory_must_be_private')
    tools = READ_ONLY_TOOLS + (["runtime.extensions"] if include_extensions else [])
    values = [{"schema_version": 1, "state_directory": str(state),
               "allowed_tools": tools, "portable_build": {"profiles": {}}}]
    if coordination is not None:
        values[0]['coordination_directory'] = str(coordination)
    if mcp is not None:
        values.append({"mcpServers": {"runtime-access": {
            "command": str(Path(sys.executable).resolve()),
            "args": [str(ROOT / "runtime-access.pyz"), "serve", "--config", str(config),
                     "--bundle-root", str(ROOT)]}}})
    staged, published = [], []
    try:
        for path, value in zip(outputs, values):
            directory(path.parent, create=True)
            fd, name = tempfile.mkstemp(prefix=".runtime-setup-", dir=path.parent)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                info = os.fstat(fd)
                identity = (info.st_dev, info.st_ino)
                staged.append((Path(name), path, identity))
                os.fchmod(fd, 0o600)
                json.dump(value, stream, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(fd)
        for temporary, path, identity in staged:
            os.link(temporary, path, follow_symlinks=False)
            published.append((path, identity))
    except BaseException:
        for path, identity in reversed(published):
            remove_owned(path, identity)
        raise
    finally:
        for temporary, _path, identity in staged:
            remove_owned(temporary, identity)
    return {"config": str(config), **({"mcp_config": str(mcp)} if mcp is not None else {})}


class Parser(argparse.ArgumentParser):
    def error(self, _message):
        raise SetupError("invalid_arguments")


def main(argv=None):
    parser = Parser(description="Create a private read-only runtime configuration.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--state-directory", required=True)
    parser.add_argument("--mcp-config")
    parser.add_argument('--coordination-directory',
                        help='Explicit private shared coordination directory; use a distinct runtime state for every host')
    parser.add_argument("--extensions", action="store_true",
                        help="Enable read-only extension schema/profile inspection")
    try:
        args = parser.parse_args(argv)
        result = configure(args.config, args.state_directory, args.mcp_config,
                           include_extensions=args.extensions,
                           coordination_directory=args.coordination_directory)
    except (SetupError, OSError) as error:
        code = str(error) if isinstance(error, SetupError) else "write_failed"
        print(json.dumps({"ok": False, "error": code}), file=sys.stderr)
        return 2
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
