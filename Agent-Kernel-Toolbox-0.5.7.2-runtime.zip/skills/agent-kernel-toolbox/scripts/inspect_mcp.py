#!/usr/bin/env python3
"""Inspect a selected Agent-Kernel-Toolbox zipapp through real read-only stdio MCP."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import tempfile
import time

VERSIONS = ('2025-11-25', '2025-06-18')
MAX_REPLY = 2 * 1024 * 1024


def json_value(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError('duplicate reply key')
            value[key] = item
        return value
    def invalid(_value):
        raise ValueError('non-finite reply number')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def canonical(value):
    return json.dumps(value, ensure_ascii=True, allow_nan=False, sort_keys=True,
                      separators=(',', ':')).encode()


def inspect(args):
    records = []
    sequence = 0
    buffered = bytearray()
    child = None
    failed = False
    negotiated = None
    catalog_count = None
    catalog_sha256 = None
    shutdown_forced = False
    full_records = getattr(args, 'full_records', False)
    with tempfile.TemporaryFile() as diagnostics:
        try:
            child = subprocess.Popen([args.python, str(args.entry), 'serve', '--config', str(args.config)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=diagnostics)

            def send(method, params=None, notify=False):
                nonlocal sequence
                message = {'jsonrpc': '2.0', 'method': method}
                if params is not None:
                    message['params'] = params
                if not notify:
                    sequence += 1
                    message['id'] = sequence
                child.stdin.write(json.dumps(message, separators=(',', ':')).encode() + b'\n')
                child.stdin.flush()
                if notify:
                    return None
                deadline = time.monotonic() + args.timeout
                while b'\n' not in buffered:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0 or not select.select([child.stdout], [], [], remaining)[0]:
                        raise RuntimeError('MCP reply timed out')
                    data = os.read(child.stdout.fileno(), 65536)
                    if not data:
                        raise RuntimeError('MCP closed before reply')
                    buffered.extend(data)
                    if len(buffered) > MAX_REPLY:
                        raise RuntimeError('MCP reply exceeded budget')
                raw, _, tail = buffered.partition(b'\n')
                buffered[:] = tail
                reply = json_value(raw)
                if (type(reply) is not dict or reply.get('jsonrpc') != '2.0'
                        or type(reply.get('id')) is not int or reply['id'] != sequence):
                    raise RuntimeError('MCP reply identity mismatch')
                if ('result' in reply) == ('error' in reply):
                    raise RuntimeError('MCP reply must contain exactly one result or error')
                if 'result' in reply and type(reply['result']) is not dict:
                    raise RuntimeError('MCP method result must be an object')
                if 'error' in reply and (type(reply['error']) is not dict
                        or type(reply['error'].get('code')) is not int
                        or type(reply['error'].get('message')) is not str):
                    raise RuntimeError('MCP error response is malformed')
                records.append({'method': method, 'response': reply})
                if 'error' in reply:
                    raise RuntimeError('MCP protocol error: ' + str(reply['error']['code']) + ': '
                                       + reply['error']['message'][:160])
                return reply['result']

            initialized = send('initialize', {'protocolVersion': args.protocol, 'capabilities': {},
                'clientInfo': {'name': 'agent-kernel-toolbox-skill', 'version': '1'}})
            negotiated = initialized.get('protocolVersion')
            if type(negotiated) is not str or negotiated != args.protocol or negotiated not in VERSIONS:
                raise RuntimeError('MCP negotiated protocol differs from requested supported version')
            capabilities = initialized.get('capabilities')
            info = initialized.get('serverInfo')
            if (type(capabilities) is not dict or type(capabilities.get('tools')) is not dict
                    or 'listChanged' in capabilities['tools'] and type(capabilities['tools']['listChanged']) is not bool
                    or type(info) is not dict or type(info.get('name')) is not str
                    or type(info.get('version')) is not str):
                raise RuntimeError('MCP initialization capabilities or server identity are malformed')
            send('notifications/initialized', notify=True)
            catalog = send('tools/list', {})
            tools = catalog.get('tools')
            if type(tools) is not list or any(type(row) is not dict or type(row.get('name')) is not str
                    or type(row.get('inputSchema')) is not dict for row in tools):
                raise RuntimeError('MCP tool catalog is malformed')
            names = {row['name'] for row in tools}
            if len(names) != len(tools):
                raise RuntimeError('MCP tool catalog contains duplicate names')
            catalog_count, catalog_sha256 = len(tools), hashlib.sha256(canonical(catalog)).hexdigest()
            if not full_records:
                records[-1]['response']['result'] = {'tool_count': catalog_count,
                    'tool_names': sorted(names), 'catalog_sha256': catalog_sha256,
                    'schemas_omitted_from_report': True}
            for name in ('runtime.status', 'runtime.capabilities', 'build.inspect'):
                if name in names:
                    result = send('tools/call', {'name': name, 'arguments': {}})
                    records[-1]['tool'] = name
                    value, content = result.get('structuredContent'), result.get('content')
                    if (type(result.get('isError')) is not bool or type(value) is not dict
                            or type(value.get('ok')) is not bool or result['isError'] is value['ok']
                            or type(content) is not list or len(content) != 1
                            or type(content[0]) is not dict or content[0].get('type') != 'text'
                            or type(content[0].get('text')) is not str
                            or canonical(json_value(content[0]['text'])) != canonical(value)):
                        raise RuntimeError('MCP tool text/structured result or error flag is inconsistent')
                    if not full_records:
                        records[-1]['response']['result'] = {'structuredContent': value,
                            'isError': result['isError'], 'text_matches_structured': True,
                            'duplicate_text_omitted_from_report': True}
                    if result['isError'] or value['ok'] is not True:
                        failed = True
        except (OSError, ValueError, RuntimeError, KeyError, TypeError, RecursionError) as error:
            failed = True
            records.append({'inspection_error': str(error)})
        finally:
            if child is not None:
                if child.stdin and not child.stdin.closed:
                    try:
                        child.stdin.close()
                    except OSError:
                        failed = True
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    failed = True
                    shutdown_forced = True
                    child.terminate()
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=3)
                if child.stdout:
                    child.stdout.close()
                failed |= child.returncode != 0
            diagnostics.seek(0)
            stderr = diagnostics.read(16385)
    report = {'passed': not failed, 'scope': 'stdio_handshake_catalog_and_advertised_inspection_tools_only',
        'all_backends_verified': False, 'exit_code': child.returncode if child else None,
        'protocol_requested': args.protocol, 'protocol_negotiated': negotiated,
        'catalog_tools': catalog_count, 'catalog_sha256': catalog_sha256,
        'records_compact': not full_records, 'shutdown_forced': shutdown_forced,
        'records': records, 'stderr': stderr[:16384].decode('utf-8', 'replace'),
        'stderr_truncated': len(stderr) > 16384}
    encoded = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    if args.report:
        args.report.write_text(encoded)
    print(encoded, end='')
    return int(failed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry', required=True, type=Path)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--protocol', choices=VERSIONS, default=VERSIONS[0])
    parser.add_argument('--timeout', type=float, default=15)
    parser.add_argument('--report', type=Path)
    parser.add_argument('--full-records', action='store_true',
                        help='Retain full catalog schemas and duplicate tool text for protocol diagnosis')
    args = parser.parse_args()
    if not args.entry.is_absolute() or not args.entry.is_file() or args.entry.suffix != '.pyz':
        parser.error('--entry must name the selected absolute runtime-access.pyz file')
    if not .1 <= args.timeout <= 60:
        parser.error('--timeout must be in (0, 60] seconds')
    if args.config is not None and (not args.config.is_absolute() or not args.config.is_file()):
        parser.error('--config must name an existing absolute configuration file')
    with tempfile.TemporaryDirectory(prefix='toolbox-inspect-') as temporary:
        if args.config is None:
            args.config = Path(temporary) / 'config.json'
            args.config.write_text(json.dumps({'schema_version': 1,
                'state_directory': str(Path(temporary) / 'state'),
                'allowed_tools': ['runtime.status', 'runtime.capabilities', 'build.inspect'],
                'portable_build': {'profiles': {}}}))
            args.config.chmod(0o600)
        return inspect(args)


if __name__ == '__main__':
    raise SystemExit(main())
