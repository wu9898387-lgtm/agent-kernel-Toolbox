#!/usr/bin/env python3
"""Verify toolbox bytes without executing archive members.

Embedded hashes establish consistency. Pin an independently obtained ZIP digest
when publisher identity matters. Local configuration and installed dependencies
are outside the shipped file inventory.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import zipfile
import zlib

MAX_ARCHIVE_BYTES = 1536 * 1024
MAX_EXPANDED_BYTES = 4 * 1024 * 1024
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_ENTRIES = 320


def valid_path(name):
    return (type(name) is str and re.fullmatch(r'[A-Za-z0-9_./-]{1,200}', name)
            and not name.startswith('/') and not any(part in ('', '.', '..') for part in name.split('/')))


def json_object(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError('duplicate_manifest_key')
            value[key] = item
        return value
    value = json.loads(raw, object_pairs_hook=pairs)
    if type(value) is not dict:
        raise ValueError('manifest_object_required')
    return value


def read_archive(raw):
    if type(raw) is not bytes or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('archive_budget')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        if not 1 <= len(entries) <= MAX_ENTRIES:
            raise ValueError('entry_limit')
        values, total = {}, 0
        for item in entries:
            if (not valid_path(item.filename) or item.filename in values
                    or stat.S_IFMT(item.external_attr >> 16) != stat.S_IFREG
                    or item.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)
                    or item.flag_bits & 1 or item.file_size > MAX_FILE_BYTES):
                raise ValueError('invalid_archive_entry')
            total += item.file_size
            if total > MAX_EXPANDED_BYTES:
                raise ValueError('expanded_budget')
            with archive.open(item) as stream:
                data = stream.read(MAX_FILE_BYTES + 1)
                if len(data) != item.file_size or stream.read(1):
                    raise ValueError('archive_size_mismatch')
            values[item.filename] = data
        return values


def hash_inventory(values, hashes):
    if type(hashes) is not dict or set(hashes) != set(values):
        raise ValueError('member_inventory_mismatch')
    for name, digest in hashes.items():
        if (not valid_path(name) or type(digest) is not str
                or re.fullmatch(r'[0-9a-f]{64}', digest) is None
                or hashlib.sha256(values[name]).hexdigest() != digest):
            raise ValueError('member_digest_mismatch')


def validate_python_sources(values):
    roots = {'__main__.py', '_s19_03_closure_common.py', 'page_snapshot_recognizer.py'}
    if not {'__main__.py', 'observation_extension/__init__.py',
            'observation_extension/runtime_mcp.py'} <= values.keys():
        raise ValueError('missing_or_invalid_python_sources')
    for name in values:
        if name in roots:
            continue
        if (re.fullmatch(r'observation_extension/[A-Za-z_][A-Za-z0-9_]*\.py', name) is None
                or Path(name).name.startswith(('test_', 'demo_', 'example_'))
                or name.endswith('_test.py')):
            raise ValueError('unexpected_runtime_member')


def verify_members(values):
    values = dict(values)
    inventory = json_object(values.pop('CONTENTS.json'))
    if set(inventory) != {'schema_version', 'package_id', 'package_name', 'package_version', 'files', 'python_files'}:
        raise ValueError('invalid_inventory')
    if (inventory['schema_version'] != 1 or inventory['package_id'] != 'agent-kernel.toolbox'
            or inventory['package_name'] != 'Agent-Kernel-Toolbox'
            or type(inventory['package_version']) is not str
            or re.fullmatch(r'[0-9]+(?:\.[0-9]+){2,3}', inventory['package_version']) is None):
        raise ValueError('invalid_inventory')
    hash_inventory(values, inventory['files'])
    inner = read_archive(values['runtime-access.pyz'])
    hash_inventory(inner, inventory['python_files'])
    validate_python_sources(inner)
    if inner.get('__main__.py') != b'from observation_extension.runtime_mcp import main\nif __name__ == "__main__":\n    raise SystemExit(main())\n':
        raise ValueError('unexpected_entrypoint')
    runtime = json_object(values['runtime-manifest.json'])
    if ((runtime.get('id'), runtime.get('name'), runtime.get('version')) !=
            (inventory['package_id'], inventory['package_name'], inventory['package_version'])
            or runtime.get('entrypoint') != 'runtime-access.pyz'
            or runtime.get('inventory') != 'CONTENTS.json'
            or runtime.get('python_members') != len(inner)):
        raise ValueError('runtime_manifest_mismatch')
    return {'status': 'verified_toolbox_consistency', 'name': inventory['package_name'],
            'package_version': inventory['package_version'], 'members': len(values) + 1,
            'python_members': len(inner), 'runtime_sources_verified': True,
            'publisher_authenticated': False}


def verify(raw, expected_sha256=None):
    if type(raw) is not bytes or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('archive_budget')
    digest = hashlib.sha256(raw).hexdigest()
    if expected_sha256 is not None and (type(expected_sha256) is not str
            or re.fullmatch(r'[0-9a-f]{64}', expected_sha256) is None or expected_sha256 != digest):
        raise ValueError('archive_digest_mismatch')
    try:
        result = verify_members(read_archive(raw))
    except (KeyError, TypeError, UnicodeError, RecursionError, zipfile.BadZipFile,
            zlib.error, EOFError, RuntimeError) as error:
        raise ValueError('invalid_archive') from error
    return {**result, 'archive_sha256': digest,
            'expected_archive_digest_pinned': expected_sha256 is not None}


def read_regular(root, name):
    if not valid_path(name):
        raise ValueError('invalid_file_path')
    path = root / name
    if not path.resolve().is_relative_to(root):
        raise ValueError('file_outside_toolbox')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_FILE_BYTES:
            raise ValueError('invalid_file')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(fd)
        if len(raw) != before.st_size or any(getattr(before, k) != getattr(after, k)
                for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')):
            raise ValueError('file_changed')
        return raw
    finally:
        os.close(fd)


def verify_directory(directory):
    try:
        root = Path(directory).resolve()
        raw = read_regular(root, 'CONTENTS.json')
        inventory = json_object(raw)
        files = inventory.get('files')
        if type(files) is not dict or not 1 <= len(files) < MAX_ENTRIES or 'CONTENTS.json' in files:
            raise ValueError('invalid_inventory')
        values, total = {'CONTENTS.json': raw}, len(raw)
        for name in files:
            data = read_regular(root, name)
            total += len(data)
            if total > MAX_EXPANDED_BYTES:
                raise ValueError('expanded_budget')
            values[name] = data
        return verify_members(values)
    except (KeyError, TypeError, UnicodeError, RecursionError, zipfile.BadZipFile,
            zlib.error, EOFError, RuntimeError) as error:
        raise ValueError('invalid_installed_toolbox') from error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--expected-sha256')
    args = parser.parse_args()
    try:
        with args.archive.open('rb') as stream:
            raw = stream.read(MAX_ARCHIVE_BYTES + 1)
        print(json.dumps(verify(raw, args.expected_sha256), sort_keys=True))
        return 0
    except (OSError, ValueError):
        print('toolbox_verification_failed', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
