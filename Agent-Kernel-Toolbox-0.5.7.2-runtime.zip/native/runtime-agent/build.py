#!/usr/bin/env python3
"""Build the C SDK and dependency-free Rust controller."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
ARTIFACT_NAMES = ('runtime-control', 'runtime-agent.o', 'agent.h', 'build.json')


def build(output, *, cargo=None, cc=None):
    output = Path(output).resolve()
    output.mkdir(mode=0o700, parents=True, exist_ok=True)
    if any(os.path.lexists(output / name) for name in ARTIFACT_NAMES):
        raise ValueError('refusing_to_overwrite_build')
    cargo = cargo or shutil.which('cargo')
    cc = cc or shutil.which('cc')
    if not cargo or not cc:
        raise ValueError('rust_and_c_toolchains_required')
    source_digest = hashlib.sha256(b''.join((ROOT / name).read_bytes()
        for name in ('agent.h', 'agent.c'))).hexdigest()
    with tempfile.TemporaryDirectory(prefix='runtime-agent-build-', dir=output) as directory:
        staging = Path(directory)
        controller = staging / 'runtime-control'
        agent_object = staging / 'runtime-agent.o'
        header = staging / 'agent.h'
        flags = [cc, '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic',
                 '-Wconversion', '-Wshadow']
        subprocess.run([*flags, '-fPIC', '-DRA_BUILD_ID="' + source_digest + '"',
            '-c', str(ROOT / 'agent.c'), '-o', str(agent_object)], check=True, timeout=60)
        target = staging / 'cargo-target'
        subprocess.run([cargo, 'build', '--release', '--offline', '--locked',
            '--manifest-path', str(ROOT / 'Cargo.toml'), '--target-dir', str(target)],
            check=True, timeout=180)
        shutil.copyfile(target / 'release' / 'runtime-control', controller)
        shutil.copyfile(ROOT / 'agent.h', header)
        controller.chmod(0o500)
        result = {'schema_version': 1, 'version': '0.5.7.2', 'build_id': source_digest,
                  'build_id_scope': 'agent.h and agent.c; application identity is registered separately',
                  'platform': 'linux', 'abi': 1, 'environment_bytes': 4096,
                  'layout_source': 'C compiler sizeof/offsetof emitted by agent status at runtime',
                  'artifacts': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in (controller, agent_object, header)}}
        metadata = json.dumps(result, sort_keys=True, indent=2) + '\n'
        (staging / 'build.json').write_text(metadata)
        # Same-filesystem links publish without replacing even a dangling symlink.
        # On failure remove only names still referring to our staged inodes.
        published = []
        try:
            for name in ARTIFACT_NAMES:
                source = staging / name
                destination = output / name
                identity = source.stat()
                os.link(source, destination)
                published.append((destination, identity.st_dev, identity.st_ino))
        except BaseException:
            for destination, device, inode in reversed(published):
                try:
                    current = destination.lstat()
                    if (current.st_dev, current.st_ino) == (device, inode):
                        destination.unlink()
                except FileNotFoundError:
                    pass
            raise
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', required=True, type=Path)
    parser.add_argument('--cargo')
    parser.add_argument('--cc')
    arguments = parser.parse_args()
    print(json.dumps(build(arguments.output_directory, cargo=arguments.cargo, cc=arguments.cc), sort_keys=True))
