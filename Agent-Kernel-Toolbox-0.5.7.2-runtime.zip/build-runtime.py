#!/usr/bin/env python3
"""Build the runtime from an explicit functional resource allowlist."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
MAX_ARCHIVE_BYTES = 1536 * 1024
MAX_EXPANDED_BYTES = 4 * 1024 * 1024
MAX_MEMBERS = 320
EXTERNAL = (
    'LICENSE',
    'RELEASE_NOTES.txt',
    'browser/cli.mjs',
    'browser/extension/background.mjs',
    'browser/extension/content.js',
    'browser/extension/control.css',
    'browser/extension/control.html',
    'browser/extension/control.mjs',
    'browser/extension/manifest.json',
    'browser/extension/rules.mjs',
    'browser/package-lock.json',
    'browser/package.json',
    'browser/portable-evidence.mjs',
    'browser/route-analysis.mjs',
    'browser/route-evidence.mjs',
    'browser/runtime.mjs',
    'browser/semantic-query.mjs',
    'browser/text-input.mjs',
    'browser/traffic-policy.mjs',
    'build-runtime.py',
    'native/build.py',
    'native/managed-jvm/RuntimeManagedAgent.java',
    'native/managed-jvm/build.py',
    'native/managed-probe/RuntimeProbe.java',
    'native/managed-probe/build.py',
    'native/managed-probe/managed_probe.c',
    'native/probe-sdk/probe.c',
    'native/probe-sdk/probe.h',
    'native/render_filter.cpp',
    'native/runtime-agent/Cargo.lock',
    'native/runtime-agent/Cargo.toml',
    'native/runtime-agent/agent.c',
    'native/runtime-agent/agent.h',
    'native/runtime-agent/build.py',
    'native/runtime-agent/src/main.rs',
    'native/worker/GO-LICENSE',
    'native/worker/GO-PATENTS',
    'native/worker/go.mod',
    'native/worker/main.go',
    'native/worker/platform_linux.go',
    'native/worker/platform_other.go',
    'requirements-optional.txt',
    'runtime-manifest.json',
    'skills/agent-kernel-toolbox/SKILL.md',
    'skills/agent-kernel-toolbox/agents/openai.yaml',
    'skills/agent-kernel-toolbox/scripts/inspect_mcp.py',
    'tools/RuntimeAccessEmulate.java',
    'tools/RuntimeAccessEmulateMemory.java',
    'tools/RuntimeAccessExport.java',
    'tools/check_installation.py',
    'tools/configure_runtime.py',
    'tools/coordinated_watchdog.py',
    'tools/environment_probe_agent.py',
    'tools/extract_sources.py',
    'tools/file_activity_agent.py',
    'tools/lldb_agent.py',
    'tools/managed_jvm_guardian.py',
    'tools/native_probe.js',
    'tools/native_probe_agent.py',
    'tools/native_symbolic_agent.py',
    'tools/runtime-platform.py',
    'tools/tree_guardian.py',
    'tools/execution_lab_worker.py',
    'tools/execution_lab_runner.c',
    'tools/execution_lab_native.h',
    'tools/execution_lab_dynamorio.c',
    'tools/CMakeLists.lab.txt',
    'native/runtime-extensions/monitor_native_helper.c',
    'native/runtime-extensions/monitor_preload.c',
    'native/runtime-extensions/hardening_sdk.h',
    'native/runtime-extensions/hardening_sdk.c',
    'native/runtime-extensions/hardening_runner.c',
    'native/runtime-extensions/detours_agent.cpp',
    'native/runtime-extensions/detours_model.cpp',
    'native/runtime-extensions/detours_model.def',
    'native/runtime-extensions/CMakeLists.txt',
    'verify-runtime.py',
)


def read_source(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > 2 * 1024 * 1024:
            raise ValueError('invalid_source')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(2 * 1024 * 1024 + 1)
        after = os.fstat(fd)
        if len(raw) != before.st_size or any(getattr(before, k) != getattr(after, k)
                for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')):
            raise ValueError('source_changed_or_oversized')
        return raw
    finally:
        os.close(fd)


def archive(files):
    result = io.BytesIO()
    with zipfile.ZipFile(result, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for name, raw in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 17, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            package.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return result.getvalue()


def load_verifier(root):
    spec = importlib.util.spec_from_file_location('toolbox_build_verifier', root / 'verify-runtime.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    return verifier


def python_sources(root=ROOT):
    """Read one source tree or the delivered zipapp without executing its code."""
    root = Path(root)
    verifier = load_verifier(root)
    if (root / 'src').is_dir():
        inner = {str(path.relative_to(root / 'src')): read_source(path)
                 for path in sorted((root / 'src').rglob('*.py'))}
    else:
        inner = verifier.read_archive(read_source(root / 'runtime-access.pyz'))
        inventory = verifier.json_object(read_source(root / 'CONTENTS.json'))
        verifier.hash_inventory(inner, inventory['python_files'])
    verifier.validate_python_sources(inner)
    return inner


def build(root=ROOT):
    root = Path(root)
    if len(set(EXTERNAL)) != len(EXTERNAL):
        raise ValueError('duplicate_resource')
    inner = python_sources(root)
    outer = {name: read_source(root / name) for name in EXTERNAL}
    outer['runtime-access.pyz'] = archive(inner)
    manifest = json.loads(outer['runtime-manifest.json'])
    inventory = {
        'schema_version': 1, 'package_id': manifest['id'],
        'package_name': manifest['name'], 'package_version': manifest['version'],
        'files': {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(outer.items())},
        'python_files': {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(inner.items())},
    }
    outer['CONTENTS.json'] = (json.dumps(inventory, sort_keys=True, indent=2) + '\n').encode()
    load_verifier(root).verify_members(outer)
    if len(outer) > MAX_MEMBERS or sum(map(len, outer.values())) > MAX_EXPANDED_BYTES:
        raise ValueError('runtime_expanded_size_or_member_budget')
    raw = archive(outer)
    if len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError('runtime_archive_size_budget')
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    raw = build()
    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
    print(json.dumps({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
